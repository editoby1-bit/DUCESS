-- ============================================================
-- DUCESS: account-number prefix changes
-- Run this in the Supabase SQL editor (or via `supabase db execute`).
-- ============================================================
-- I don't have the current body of your existing
-- generate_staff_salary_account_number() / generate_staff_operational_account_number()
-- functions (they live in your Supabase project, not the app repo), so these
-- CREATE OR REPLACE statements are written fresh rather than patched. If your
-- current functions do anything beyond "read a sequence, format, return" (for
-- example: writing an audit row, checking for duplicates against a table,
-- taking parameters) send me the current definitions and I'll merge instead
-- of replace. As written, these are drop-in safe: same names, same "returns
-- text, no arguments" signature the app already calls.
--
-- Both use their own independent, dedicated sequence so nothing here reads
-- or depends on knowing your accounts table schema. Existing account numbers
-- are never changed retroactively — only numbers generated AFTER you run
-- this will use the new prefix.
-- ============================================================

-- ------------------------------------------------------------
-- 1) STAFF (salary) ACCOUNT NUMBER: prefix 2 -> 0
-- ------------------------------------------------------------

create sequence if not exists staff_salary_account_seq;

-- One-time bootstrap: if you already have staff accounts numbered like
-- 2XXXXX, uncomment and run this ONCE so the new '0' numbers continue
-- counting up rather than restarting at 0000001. Replace 'staff' with
-- your real accounts table/column names, or skip this block entirely
-- if you'd rather just start fresh at 0000001.
--
-- select setval(
--   'staff_salary_account_seq',
--   coalesce((
--     select max(substring(account_number from 2)::bigint)
--     from staff
--     where account_number ~ '^[02][0-9]+$'
--   ), 0)
-- );

create or replace function generate_staff_salary_account_number()
returns text
language plpgsql
as $$
declare
  next_val bigint;
begin
  next_val := nextval('staff_salary_account_seq');
  return '0' || lpad(next_val::text, 6, '0');
end;
$$;

-- ------------------------------------------------------------
-- 2) TELLER OPERATIONAL ACCOUNT NUMBER: prefix "T" + 4-digit
--    (this is the account already wired up in the app as
--    accountType = 'staff_operational', restricted to tellers)
-- ------------------------------------------------------------

create sequence if not exists staff_operational_account_seq;

create or replace function generate_staff_operational_account_number()
returns text
language plpgsql
as $$
declare
  next_val bigint;
begin
  next_val := nextval('staff_operational_account_seq');
  if next_val > 9999 then
    raise exception 'Teller operational account numbers exhausted (T9999 reached) — widen the digit count in generate_staff_operational_account_number().';
  end if;
  return 'T' || lpad(next_val::text, 4, '0');
end;
$$;

-- ============================================================
-- Sanity check after running:
--   select generate_staff_salary_account_number();      -- e.g. 0000001
--   select generate_staff_operational_account_number(); -- e.g. T0001
-- ============================================================

-- ============================================================
-- STAFF ID (staff_code) RENAME — required for the new "Edit ID"
-- feature in Staff Directory to actually take effect.
-- ============================================================
-- IMPORTANT — read this before running:
-- Staff ID (staff_code) may be the basis of the staff member's login
-- email if your setup uses synthetic emails (staff_code + a fixed
-- suffix, e.g. TLR001@ducess.internal) rather than a separate stored
-- auth_email per staff. If that's the case, renaming staff_code
-- WITHOUT also updating the matching row in auth.users will lock
-- that staff member out — their password stays registered against
-- the OLD email, but lookups will compute a NEW one that matches
-- nothing.
--
-- Check which mode you're in first:
--   select staff_code, auth_email from staff limit 5;
-- If auth_email is populated for your staff, you're in "explicit
-- email" mode and the simple version below (Option A) is all you
-- need — renaming staff_code never touches login.
-- If auth_email is NULL/empty and login still works, you're in
-- "synthetic suffix" mode and you need Option B, which also updates
-- auth.users.email to match.
-- ============================================================

-- ---- Option A: explicit auth_email column (safe, simple) ----
create or replace function ducess_update_staff_code(
  staff_id uuid,
  new_staff_code text,
  updated_by_staff_id uuid default null,
  updated_by_name text default null
)
returns setof staff
language plpgsql
security definer
as $$
begin
  if exists (
    select 1 from staff
    where staff_code = upper(new_staff_code)
      and id <> staff_id
  ) then
    raise exception 'Staff ID "%" is already in use', new_staff_code;
  end if;

  update staff
  set staff_code = upper(new_staff_code),
      updated_at = now()
  where id = staff_id;

  return query select * from staff where id = staff_id;
end;
$$;

-- ---- Option B: synthetic-email mode — ALSO syncs auth.users.email.
-- Only use this version (replacing the one above) if your login
-- emails are derived from staff_code. Adjust the suffix to match
-- whatever your app actually uses (see syntheticEmailSuffix in
-- ducess-config.js / ducess-gateway.js).
--
-- create or replace function ducess_update_staff_code(
--   staff_id uuid,
--   new_staff_code text,
--   updated_by_staff_id uuid default null,
--   updated_by_name text default null
-- )
-- returns setof staff
-- language plpgsql
-- security definer
-- as $$
-- declare
--   v_auth_user_id uuid;
--   v_suffix text := '@ducess.internal'; -- <-- match your real suffix
-- begin
--   if exists (
--     select 1 from staff
--     where staff_code = upper(new_staff_code)
--       and id <> staff_id
--   ) then
--     raise exception 'Staff ID "%" is already in use', new_staff_code;
--   end if;
--
--   select auth_user_id into v_auth_user_id from staff where id = staff_id;
--
--   update staff
--   set staff_code = upper(new_staff_code),
--       updated_at = now()
--   where id = staff_id;
--
--   if v_auth_user_id is not null then
--     update auth.users
--     set email = lower(new_staff_code) || v_suffix,
--         raw_user_meta_data = raw_user_meta_data || jsonb_build_object('staff_code', upper(new_staff_code))
--     where id = v_auth_user_id;
--   end if;
--
--   return query select * from staff where id = staff_id;
-- end;
-- $$;

-- ============================================================
-- FULL DATA WIPE — for starting fresh testing from zero.
-- Run in the Supabase SQL editor. THIS IS IRREVERSIBLE — there is
-- no undo once these run. Take a backup/export first if there's
-- anything in here you might want later.
-- ============================================================

-- ---- PART A: business/transactional data (safe — staff logins
-- are untouched, so nobody gets locked out). Run this first. ----
begin;

truncate table debt_repayments cascade;
truncate table debts cascade;
truncate table cod_resolutions cascade;
truncate table cod_submissions cascade;
truncate table staff_cash_ledger cascade;
truncate table approval_requests cascade;
truncate table customer_transactions cascade;
truncate table customer_account_balances cascade;
truncate table customer_accounts cascade;
truncate table customers cascade;
truncate table audit_log cascade;

-- Reset the account-number sequences too, so numbering restarts
-- clean (only relevant if you've already run the prefix-change SQL
-- above — harmless no-op otherwise since these are created there).
alter sequence if exists staff_salary_account_seq restart with 1;
alter sequence if exists staff_operational_account_seq restart with 1;

commit;

-- ---- PART B: staff/login data — OPTIONAL, only run this if you
-- genuinely want every staff account gone too, including admin.
-- ⚠️ If you run this, NOBODY will be able to log in afterward until
-- a new admin is created directly in the database (the app's own
-- "Add Staff" flow needs an already-logged-in admin to run it).
-- Safer alternative: skip this block entirely and just manually
-- deactivate/remove test staff one at a time from the app's own
-- Staff Directory once Part A is done — keeps your real admin
-- account intact.
-- ============================================================
-- begin;
-- delete from staff_temp_grants;
-- delete from staff_role_permissions;
-- delete from staff where staff_code <> 'YOUR_ADMIN_STAFF_ID_HERE'; -- keep one admin
-- -- If you truly want to wipe every staff row including admin, also
-- -- run: delete from auth.users where id in (select auth_user_id from staff);
-- -- (only if your schema links auth.users this way — check first)
-- commit;
