(() => {
  const runtimeConfig = window.__DUCESS_CONFIG__ || {};
  const STORAGE_KEY = runtimeConfig.storageKey || 'duces_enterprise_ledger_v1';
  const gateway = window.DucessGateway?.createGateway?.({
    storageKey: STORAGE_KEY,
    useSupabaseBackend: runtimeConfig.useSupabaseBackend === true,
    supabase: runtimeConfig.supabase || {}
  }) || null;
  // Enforced DD/MM/YYYY throughout (2026-08-14): numeric, unambiguous, not
  // dependent on month-name locale rendering.
  const DATE_FMT = new Intl.DateTimeFormat('en-GB', { day:'2-digit', month:'2-digit', year:'numeric' });
  const TIME_FMT = new Intl.DateTimeFormat('en-GB', { hour:'2-digit', minute:'2-digit', hour12:true });
  const THEMES = ['classic','ducess-sheet','ocean','dark-slate','neutral-stone'];
  const THEME_LABELS = { classic:'Classic', 'ducess-sheet':'Ducess Sheet', ocean:'Ocean', 'dark-slate':'Dark Slate', 'neutral-stone':'Neutral Stone' };
  const money = (n) => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
  // SURGICAL ADDITION 2026-08-19: amount fields were native type="number",
  // which can never display thousand-separator commas (a browser
  // restriction, not something CSS/JS can override on a number input) — so
  // a value like 500000 was indistinguishable from 50000 at a glance.
  // Converted to formatted text inputs; parseAmountInput() is the ONLY
  // correct way to read a numeric value back out of one (every call site
  // that used to do Number(byId(id).value) on these fields must use this
  // instead, or commas in the typed value would silently parse as NaN).
  function parseAmountInput(id) {
    return Number(String(byId(id)?.value || '').replace(/,/g, '').trim()) || 0;
  }
  // Amount fields show thousand-separator commas as you type (1,500,000.50).
  // The box's .value getter hands back the PLAIN number (no commas), so every
  // existing read such as Number(byId('txAmount').value) keeps working unchanged.
  const AMOUNT_FIELD_IDS = ['txAmount','oeAmount','floatTopupAmount','cashReceiptAmount','staffCreditAmount','codDebtAmount','codAcceptedPosition','codAdjustment','itrAmount','journalFormAmount','journalAmount'];
  const AMOUNT_FIELDS_ALLOW_NEGATIVE = ['codAdjustment','codAcceptedPosition'];
  const formatAmountText = (raw, allowNegative) => {
    let t = String(raw ?? '');
    const neg = allowNegative && t.trim().startsWith('-');
    t = t.replace(/[^\d.]/g, '');
    const dot = t.indexOf('.');
    let intPart = (dot === -1 ? t : t.slice(0, dot)).replace(/^0+(?=\d)/, '');
    const decPart = dot === -1 ? '' : '.' + t.slice(dot + 1).replace(/\./g, '').slice(0, 2);
    intPart = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (neg ? '-' : '') + intPart + decPart;
  };
  function bindAmountCommaFormatting(id) {
    const el = typeof id === 'string' ? byId(id) : id;
    if (!el || el.dataset.commaFormatted) return;
    el.dataset.commaFormatted = '1';
    const allowNeg = AMOUNT_FIELDS_ALLOW_NEGATIVE.includes(el.id);
    const nativeValue = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    const initial = nativeValue.get.call(el);
    el.type = 'text';
    el.inputMode = allowNeg ? 'text' : 'decimal';
    Object.defineProperty(el, 'value', {
      configurable: true,
      get() { return nativeValue.get.call(el).replace(/,/g, ''); },
      set(v) { nativeValue.set.call(el, formatAmountText(v, allowNeg)); }
    });
    nativeValue.set.call(el, formatAmountText(initial, allowNeg));
    el.addEventListener('input', () => {
      const before = nativeValue.get.call(el);
      const caret = el.selectionStart ?? before.length;
      const sig = before.slice(0, caret).replace(/[^\d.-]/g, '').length;
      const after = formatAmountText(before, allowNeg);
      if (after === before) return;
      nativeValue.set.call(el, after);
      let seen = 0, pos = 0;
      while (pos < after.length && seen < sig) { if (/[\d.-]/.test(after[pos])) seen += 1; pos += 1; }
      try { el.setSelectionRange(pos, pos); } catch (_e) {}
    });
  }
  // Bind every amount box the moment it appears on screen (any screen or popup).
  function bindAllAmountFields(root = document) {
    AMOUNT_FIELD_IDS.forEach(fid => { const el = root.querySelector ? root.querySelector(`#${fid}`) : null; if (el && el.tagName === 'INPUT') bindAmountCommaFormatting(el); });
  }
  let amountBindQueued = false;
  new MutationObserver(() => {
    if (amountBindQueued) return;
    amountBindQueued = true;
    requestAnimationFrame(() => { amountBindQueued = false; bindAllAmountFields(); });
  }).observe(document.documentElement, { childList: true, subtree: true });
  const uid = (p='id') => `${p}_${Math.random().toString(36).slice(2,9)}${Date.now().toString(36).slice(-4)}`;
  const today = () => new Date().toISOString().slice(0,10);
  const byId = (id) => document.getElementById(id);
  const q = (sel, root=document) => root.querySelector(sel);
  const qq = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  const escapeHtml = (value) => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  const formatFileSize = (bytes) => { const size = Number(bytes || 0); if (size >= 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} MB`; if (size >= 1024) return `${Math.round(size / 1024)} KB`; return `${size} B`; };
  const isSupportedFieldNoteFile = (file) => !!file && (String(file.type || '').startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp)$/i.test(String(file.name || '')));
  const FIELD_NOTE_MAX_BYTES = 2 * 1024 * 1024;
  const CUSTOMER_PHOTO_MAX_BYTES = 1024 * 1024;
  // SURGICAL PATCH 2026-08-22 (Supabase egress overage — see the polling and
  // list-view fixes elsewhere): reduced from 700px/0.55 quality significantly.
  // The actual on-screen display size for these photos is a small thumbnail
  // (~260x110px in Check Balance, similar in the approval review panel), so
  // 480px max side is still comfortably larger than anything the UI ever
  // renders it at, while cutting typical file size roughly 60-65%.
  const COMPRESSED_IMAGE_MAX_SIDE = 480;
  const COMPRESSED_IMAGE_QUALITY = 0.45;
  // SURGICAL FIX 2026-09-17 (client request, Supabase egress): field notes
  // get pushed even smaller than customer photos, and PDFs are no longer
  // accepted at all (see isSupportedFieldNoteFile above and the file input's
  // accept attribute) — a field note only ever needs to be "just barely
  // enough for viewing" a handwritten note/receipt, not archival quality.
  // Customer photos keep the less-aggressive 480/0.45 setting above since
  // those are used for identification.
  const FIELD_NOTE_IMAGE_MAX_SIDE = 320;
  const FIELD_NOTE_IMAGE_QUALITY = 0.32;
  const estimateDataUrlBytes = (dataUrl) => {
    const value = String(dataUrl || '');
    const base64 = value.includes(',') ? value.split(',')[1] : value;
    return Math.max(0, Math.floor((base64.length * 3) / 4));
  };
  async function fileToDataUrl(file) {
    return await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('Unable to read selected file'));
      reader.readAsDataURL(file);
    });
  }
  async function compressImageFile(file, options = {}) {
    const maxSide = Number(options.maxSide || COMPRESSED_IMAGE_MAX_SIDE);
    const quality = Number(options.quality || COMPRESSED_IMAGE_QUALITY);
    const fallbackDataUrl = await fileToDataUrl(file);
    try {
      const img = await new Promise((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = () => reject(new Error('Unable to process selected image'));
        el.src = fallbackDataUrl;
      });
      let { width, height } = img;
      const scale = Math.min(1, maxSide / Math.max(width, height, 1));
      width = Math.max(1, Math.round(width * scale));
      height = Math.max(1, Math.round(height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, width, height);
      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      return {
        name: String(file.name || 'image').replace(/\.[^.]+$/, '') + '.jpg',
        type: 'image/jpeg',
        size: estimateDataUrlBytes(dataUrl),
        dataUrl
      };
    } catch (error) {
      return {
        name: file.name || 'image',
        type: file.type || '',
        size: Number(file.size || 0),
        dataUrl: fallbackDataUrl
      };
    }
  }
  // SURGICAL ADDITION 2026-08-19: Check Balance's "Field Note (Form)" button
  // shows the CURRENT staff's own field note — today's upload if there is
  // one (checking both credit and debit journals for today), otherwise the
  // most recently uploaded one overall. This is staff/session-level, not
  // tied to whichever customer happens to be pulled up — field notes are
  // attached to a journal submission (which can span several customers),
  // not to any single customer's account.
  function getLatestFieldNoteForStaff(staffId) {
    const attachments = state.ui.staffJournalAttachments || {};
    const today = businessDate();
    let todayMatch = null;
    let latestOverall = null;
    Object.entries(attachments).forEach(([key, val]) => {
      if (!val?.fieldNote) return;
      const [sid, date] = key.split(':');
      if (sid !== staffId) return;
      if (date === today && !todayMatch) todayMatch = val.fieldNote;
      if (!latestOverall || new Date(val.fieldNote.uploadedAt || 0) > new Date(latestOverall.uploadedAt || 0)) latestOverall = val.fieldNote;
    });
    return todayMatch || latestOverall || null;
  }

  async function readFieldNoteFile(file) {
    if (!file) return null;
    // SURGICAL FIX 2026-09-17: PDFs are no longer accepted for field notes
    // at all (see isSupportedFieldNoteFile) — only photos, compressed down
    // to FIELD_NOTE_IMAGE_MAX_SIDE/QUALITY. The old PDF branch (raw
    // fileToDataUrl, no compression) is gone since it can never be reached.
    const compressed = await compressImageFile(file, { maxSide: FIELD_NOTE_IMAGE_MAX_SIDE, quality: FIELD_NOTE_IMAGE_QUALITY });
    return {
      name: compressed.name || 'field-note.jpg',
      type: compressed.type || 'image/jpeg',
      size: Number(compressed.size || 0),
      dataUrl: String(compressed.dataUrl || ''),
      uploadedAt: new Date().toISOString()
    };
  }

  const ROLE_LABELS = {
    customer_service: 'Customer Service Officer',
    teller: 'Teller',
    cash_officer: 'Treasury',
    approving_officer: 'Approving Officer',
    admin_officer: 'Administrative Officer',
    report_officer: 'Report Officer',
    // ROLE/STAFF SEPARATION 2026-10-11: a staff member who has been added
    // but not yet given a role. Display-only — never offered as a role to
    // pick (see ASSIGNABLE_ROLE_KEYS) and carries no permissions at all.
    unassigned: 'Unassigned'
  };
  const UNASSIGNED_ROLE = 'unassigned';
  const ASSIGNABLE_ROLE_KEYS = Object.keys(ROLE_LABELS).filter(k => k !== UNASSIGNED_ROLE);
  // Roles that operate cash (own an operational account / close a day).
  const CASH_HANDLING_ROLES = ['teller', 'cash_officer', 'admin_officer'];

  const MODULES = {
    customer_service: {
      title: 'Customer Service',
      desc: 'Check balance, open, maintain, reactivate accounts and print statements.',
      icon: '👤',
      // SURGICAL ADDITION 2026-09-04 (client request): "my_statement" is
      // universal (see hasPermission's free-tool list) — every staff role
      // needs somewhere to reach it, and this module is already the one
      // every role can open (via check_balance).
      tools: ['check_balance','account_opening','account_maintenance','account_reactivation','work_review']
    },
    cash_officer: {
      title: 'Treasury',
      desc: 'Fund tellers, receive cash, and move money between accounts.',
      icon: '💰',
      // SURGICAL ADDITION 2026-09-06 (client-confirmed design): Treasury is
      // now the one who funds Tellers and receives cash (from Collectors or
      // anyone else) — not Admin — so cash_receipt needs to be reachable
      // from here, not just Administration. my_statement added 2026-09-07
      // so Treasury can see their own totals here too.
      // SURGICAL REMOVAL 2026-09-09 (client-confirmed design): "Credit Staff
      // Account" (staff_credit) is dissolved out of Treasury entirely.
      // Funding a Teller now happens through Non Cash (intra_transfer),
      // which force-locks the Debit side to the acting Treasury officer's
      // own account whenever the Credit side is a staff operational
      // account — see renderIntraTransfer/bindIntraTransfer. Treasury
      // funds itself via Cash Receipt (unchanged). Admin still has
      // staff_credit via the 'administration' module below — this removal
      // is Treasury-only, per client instruction.
      tools: ['debit','credit','intra_transfer','treasury_review']
    },
    tellering: {
      title: 'Tellering',
      desc: 'Credit and debit customer accounts from your operational balance.',
      icon: '💳',
      tools: ['check_balance','debit','credit','journal_debit','journal_credit','journal_register','intra_transfer','teller_review']
    },
    approvals: {
      title: 'Approval',
      desc: 'Approve or reject submitted requests and review approval history.',
      icon: '✅',
      // SURGICAL ADDITION 2026-09-07 (client request): "My Approvals" —
      // Approving Officer's own unique totals view (how much they've
      // approved, by date), separate from the cash statement everyone else
      // gets since they never hold a cash account themselves.
      tools: ['approval_queue','approval_customer_service','approval_tellering','approval_non_cash','approval_others','approval_history','my_approvals','approval_review']
    },
    administration: {
      title: 'Administration',
      desc: 'Manage working tools, operational postings, temporary grants, staff settings, and central close of day.',
      icon: '🛠️',
      // SURGICAL FIX 2026-09-04: cash_receipt and staff_credit had full
      // permissions/render/bind logic (admin_officer is already granted
      // both in DEFAULT_PERMS) but were never listed in ANY module's
      // tools array — so no tab button rendered for either, on any role,
      // anywhere. Wiring them in here (Administration uses the generic
      // tool-tab loop, not a hardcoded button row) is what actually makes
      // "Credit Staff Account" reachable for the first time.
      // SURGICAL ADDITION 2026-09-07: my_statement added so Admin can see
      // their own totals now that Admin has an operational account too.
      // SURGICAL CHANGE 2026-10-21 (client): Staff Salary, All Customers',
      // Teller and Overall Balance moved to Approval -> Daily/Weekly/
      // Monthly/Yearly Balances. Income & Expense Balance stays here too
      // because it also carries the Create Account / Post into Account forms.
      tools: ['central_close_day','cash_receipt','staff_credit','operational_posting','operational_accounts','staff_roster','transaction_summary','permissions']
    },
    balances: {
      title: 'Balances',
      desc: 'Review business balance and operational balance with filters and teller summaries.',
      icon: '📊',
      // SURGICAL ADDITION 2026-09-04 (client request): read-only
      // Received-From Totals report — sits alongside teller_balances, does
      // NOT feed business_balance/renderOverallBalance in any way (see
      // renderCollectorBalance's own comment). SURGICAL REMOVAL 2026-09-14
      // (client-confirmed design): the "Collector" role is retired
      // entirely — this report now only covers Teller/Admin/Customer.
      tools: ['business_balance','operational_balance','teller_balances','collector_balance']
    }
  };

  // 2026-10-28: Data Backup is a paid add-on. While this is false the page is
  // shown blurred and locked (with a lock beside it in the menu), nothing on it
  // works, and it makes no requests. Set to true when the client activates it.
  const DATA_BACKUP_ACTIVE = false;

  const TOOL_LABELS = {
    check_balance: 'Check Balance',
    my_statement: 'My Statement',
    my_approvals: 'My Approvals',
    work_review: 'Work Review',
    teller_review: 'Tellerng Review',
    approval_review: 'Approval Review',
    treasury_review: 'Treasury Review',
    account_opening: 'Account Opening',
    account_maintenance: 'Account Maintenance',
    account_reactivation: 'Account Reactivation',
    account_statement: 'Account Statement',
    cash_receipt: 'Cash Receipt',
    staff_credit: 'Credit Staff Account',
    credit: 'Credit Entry',
    debit: 'Debit Entry',
    journal_debit: 'Debit Entry',
    journal_credit: 'Credit Entry',
    journal_register: 'Journal Register',
    intra_transfer: 'Debit To Credit Entry',
    my_close_day: 'My Close of Day',
    central_close_day: 'Central Close of Day',
    approval_queue: 'Approval Queue',
    approval_customer_service: 'Customer Service',
    approval_tellering: 'Teller',
    approval_non_cash: 'Non Cash',
    approval_others: 'Administration',
    approval_history: 'Approval History',
    permissions: 'Permissions Matrix',
    operational_posting: 'Income & Expense Posting',
    operational_accounts: 'Income & Expense Balance',
    staff_directory: 'Staff Salary Balance',
    staff_roster: 'Staff Directory',
    customer_directory: "All Customers' Balance",
    business_balance: 'Business Balance',
    operational_balance: 'Operational Balance',
    overall_balance: 'Overall Balance',
    teller_balances: 'Teller Balances',
    collector_balance: 'Received-From Totals',
    transaction_summary: 'Transaction Summary'
  };

  const DEFAULT_PERMS = {
    customer_service: ['check_balance','account_opening','account_maintenance','account_reactivation','account_statement','work_review'],
    // SURGICAL REMOVAL 2026-09-09: 'staff_credit' dropped from Treasury's
    // permission set — see the matching comment on the cash_officer module
    // above. Admin (admin_officer, below) keeps it untouched.
    // SURGICAL REMOVAL 2026-09-17 (client-confirmed design): "Journal
    // Posting" (journal_register) removed from Treasury entirely — Treasury
    // funds tellers via Non Cash (still role-agnostic), just without a
    // Journal Register view of their own.
    cash_officer: ['debit','credit','intra_transfer','treasury_review'],
    teller: ['check_balance','credit','debit','journal_debit','journal_credit','journal_register','intra_transfer','teller_review'],
    // SURGICAL FIX 2026-09-07 (client request): Approving Officer gets its
    // own totals view ("my_approvals" — how much they've approved, by date)
    // rather than the cash statement everyone else gets, since they never
    // hold a cash account themselves.
    approving_officer: ['approval_queue','approval_customer_service','approval_tellering','approval_non_cash','approval_others','approval_history','my_approvals','approval_review'],
    admin_officer: ['work_review','teller_review','approval_review','treasury_review','check_balance','account_opening','account_maintenance','account_reactivation','account_statement','cash_receipt','staff_credit','credit','debit','journal_debit','journal_credit','journal_register','intra_transfer','central_close_day','approval_queue','approval_customer_service','approval_tellering','approval_non_cash','approval_others','approval_history','my_approvals','permissions','operational_accounts','operational_posting','overall_balance','staff_directory','staff_roster','customer_directory','business_balance','operational_balance','teller_balances','collector_balance','my_close_day','transaction_summary'],
    report_officer: ['check_balance','account_statement','business_balance','operational_balance','teller_balances','collector_balance','operational_accounts','staff_directory']
  };

  // Sub-tool registries (Approval / Balances / Administration) must exist
  // before startup runs hasPermission() on a restored tool — see 2026-10-22 fix.
  // SURGICAL ADDITION 2026-10-21 (client sheet: "Approval / Operational
  // Balances"): the Approval sidebar is split into the client's
  // sub-headings. Each sub-item is a view onto an EXISTING tool — the
  // approval queue filtered to specific request types, or a balance report
  // with a fixed period — so no approval or balance logic is duplicated.
  const APPROVAL_SUB_TOOLS = {
    appr_opening:    { base: 'approval_customer_service', section: 'customer_service', types: ['account_opening','create_operational_account'], label: 'Approve Account Opening' },
    appr_update:     { base: 'approval_customer_service', section: 'customer_service', types: ['account_maintenance'], label: 'Approve Account Update' },
    appr_reactivate: { base: 'approval_customer_service', section: 'customer_service', types: ['account_reactivation'], label: 'Approve Reactivation' },
    appr_block:      { base: 'approval_customer_service', section: 'customer_service', types: ['account_block'], label: 'Approve Account Block' },
    appr_close:      { base: 'approval_customer_service', section: 'customer_service', types: ['account_closure'], label: 'Approve Account Closure' },
    appr_direct:     { base: 'approval_tellering', section: 'tellering', types: ['customer_credit','customer_debit','cash_receipt'], label: 'Approve Direct Postings' },
    appr_non_cash:   { base: 'approval_non_cash', section: 'non_cash', types: ['intra_bank_transfer','inter_staff_credit'], label: 'Approve Non Cash Postings' },
    appr_journals:   { base: 'approval_tellering', section: 'tellering', types: ['customer_credit_journal','customer_debit_journal'], label: 'Approve Journals' },
    // Client (2026-10-22): "Others" only ever held Administration's two
    // request types, so it's now an Administration group with one item each.
    appr_op_entry:   { base: 'approval_others', section: 'others', types: ['operational_entry'], label: 'Approve Income & Expense Posting' },
    appr_op_account: { base: 'approval_others', section: 'others', types: ['create_operational_account'], label: 'Approve New Income/Expense Account' },
  };
  // SURGICAL CHANGE 2026-10-21 (client): the Administration balance
  // reports move to Approvals, grouped by period — Daily / Weekly /
  // Monthly / Yearly, each listing the same five balance reports. Tool key
  // is balp_<period>_<report>; the report opens on that period, with the
  // usual date buttons + From/To pickers to change it.
  const BALANCE_PERIODS = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['yearly','Yearly']];
  const BALANCE_REPORTS = [
    ['overall',   'overall_balance',      'Overall Balance'],
    ['all',       'overall_balance',      'All Accounts'],
    ['customers', 'customer_directory',   "All Customers' Balance"],
    ['salary',    'staff_directory',      'Staff Salary Balance'],
    ['income',    'operational_accounts', 'Income Balance'],
    ['expense',   'operational_accounts', 'Expense Balance'],
    ['tellers',   'teller_balances',      'Tellerng Balance'],
    ['treasury',  'overall_balance',      'Treasury Balance'],
  ];
  const BALANCE_SUB_TOOLS = {};
  BALANCE_PERIODS.forEach(([pk, pl]) => BALANCE_REPORTS.forEach(([rk, base, rl]) => {
    BALANCE_SUB_TOOLS[`balp_${pk}_${rk}`] = { base, preset: pk, report: rk, short: rl, label: `${pl} ${rl}` };
  }));
  // SURGICAL ADDITION 2026-10-22 (client sheet "Administrative / Audit &
  // ICT Unit"): Administration is regrouped into Administrative, Audits,
  // ICT Unit and Operations (the existing tools).
  const ADMIN_SUB_TOOLS = {
    adm_staff:     { base: 'staff_roster',    label: 'Staff Management & Roles' },
    adm_balance:   { base: 'overall_balance', label: 'Account Balance' },
    aud_cs:        { base: 'overall_balance', label: 'Customer Service / Marketing Audit' },
    aud_tellers:   { base: 'overall_balance', label: 'Tellering / Non-Tellering Audit' },
    aud_types:     { base: 'overall_balance', label: 'Account Types Audit' },
    aud_customers: { base: 'overall_balance', label: 'Customer Accounts Audit' },
    ict_access:    { base: 'staff_roster',    label: 'Staff Access Control' },
    ict_backup:    { base: 'staff_roster',    label: DATA_BACKUP_ACTIVE ? 'Data Backup' : 'Data Backup 🔒' },
    ict_security:  { base: 'staff_roster',    label: 'Data Security' },
    ict_network:   { base: 'staff_roster',    label: 'Network Management' },
    ict_cyber:     { base: 'staff_roster',    label: 'Cybersecurity' },
  };
  Object.entries({ ...APPROVAL_SUB_TOOLS, ...BALANCE_SUB_TOOLS, ...ADMIN_SUB_TOOLS }).forEach(([k, v]) => { TOOL_LABELS[k] = v.label; });

  let realtimeBound = false;
  let realtimeUnsub = null;
  let realtimeRefreshInFlight = false;
  let realtimeRefreshQueued = false;
  let realtimePollingTimer = null;
  let pendingWatchTimer = null;
  // Fix B 2026-10-22 (storage): see bulkStore below.
  let bulkIdbOk = false;
  let bulkWriteTimer = null;
  let bulkStoreInstance = null;
  let bulkReady = Promise.resolve();
  // 2026-10-29 (client clean slate): every device clears its OLD saved browser
  // data once, the first time it opens this version, then loads fresh from the
  // database. Sign-in is kept. To force another one-time clear later, change
  // the date text in RESET_TOKEN; never leave it changing on every release.
  (function oneTimeLocalReset() {
    const RESET_TOKEN = '2026-10-29-clean-slate';
    const TOKEN_KEY = STORAGE_KEY + '__reset';
    try {
      if (localStorage.getItem(TOKEN_KEY) === RESET_TOKEN) return;
      localStorage.removeItem(STORAGE_KEY);
      if (typeof indexedDB !== 'undefined') indexedDB.deleteDatabase('ducess_cache');
      localStorage.setItem(TOKEN_KEY, RESET_TOKEN);
    } catch (_) { /* storage unavailable: nothing to clear */ }
  })();

  const state = bootstrapState();
  state.ui = state.ui || { module: null, tool: null, selectedCustomerId: null, theme: 'classic', businessFilter: { preset: 'daily', from: '', to: '' }, operationalFilter: { preset: 'daily', from: '', to: '' }, approvalsLimit: 20, businessEntriesLimit: 20, operationalEntriesLimit: 20, tellerEntriesLimit: 20, approvalsSection:'tellering', generatedJournals:{}, customerDirectorySearch: '' };
  state.ui.customerDirectorySearch = state.ui.customerDirectorySearch || '';
  ['staffProfiles','staffProfilesLoaded','staffProfilesSource','ictSource','ictLogs','admSelectedStaffId','admProfileDraft'].forEach(k => { delete state.ui[k]; });
  if (state.ui.module && !MODULES[state.ui.module]) state.ui.module = null;
  // 2026-11-05: a saved/restored module must still be allowed for whoever is signed in now.
  if (state.ui.module && !moduleAllowed(state.ui.module)) { state.ui.module = null; state.ui.tool = null; }
  if (state.ui.module && state.ui.tool && !hasPermission(state.ui.tool)) state.ui.tool = null;
  ensureState();
  resetJournalUiState();
  if (isSupabaseApprovalMode()) {
    bulkReady = restoreBulkState();
    bulkReady.finally(() => { syncAllSharedStateFromGateway(); });
    setupRealtimeSubscriptions();
  }

  function bootstrapState() {
    if (gateway?.appState?.bootstrapState) return gateway.appState.bootstrapState(seed);
    const loaded = load();
    return loaded || seed();
  }

  function seed() {
    // In Supabase mode, seed with empty staff/customers — real data comes from Supabase sync.
    // Demo data is only used in local (non-Supabase) mode.
    const isSupabase = typeof gateway !== 'undefined' && gateway?.__meta?.adapter === 'supabase';
    const demoStaff = isSupabase ? [] : [
      { id:'st1', name:'Daniel Johnson', role:'customer_service', active:true },
      { id:'st2', name:'Mary Daniel', role:'teller', active:true },
      { id:'st3', name:'Francis Etta', role:'approving_officer', active:true },
      { id:'st4', name:'Admin Officer', role:'admin_officer', active:true }
    ];
    const demoCustomers = isSupabase ? [] : [
      { id:'c1', accountNumber:'1000', oldAccountNumber:'A-221', name:'Emma Johnson', address:'14 Palm Street', nin:'12345678901', bvn:'2200114422', phone:'08012345678', balance:32000, photo:'', active:true, createdAt:new Date().toISOString(), transactions:[
          txObj('credit', 15000, 'Opening contribution', 'SYSTEM', 'system', null, 'customer', today()),
          txObj('credit', 17000, 'Cash contribution', 'SYSTEM', 'system', null, 'customer', today())
        ] },
      { id:'c2', accountNumber:'1001', oldAccountNumber:'A-222', name:'Uduak Peters', address:'Market Road', nin:'22345678901', bvn:'2200118899', phone:'08022223333', balance:6500, photo:'', active:true, createdAt:new Date().toISOString(), transactions:[
          txObj('credit', 6500, 'Savings credit', 'SYSTEM', 'system', null, 'customer', today())
        ] }
    ];
    const s = {
      staff: demoStaff,
      customers: demoCustomers,
      approvals: [],
      audit: [],
      staffAccounts: {},
      operations: { incomeAccounts: [], expenseAccounts: [], entries: [] },
      cod: [],
      tempGrants: [],
      businessExtras: [],
      businessDate: today(),
      dayClosures: [],
      activeStaffId: 'st4'
    };
    s.staff.forEach(st => ensureStaffAccount(st.id, s));
    s.audit.push({ id: uid('aud'), at: new Date().toISOString(), actorId: 'system', actor: 'System', action: 'seed', details: 'Initial demo data created' });
    return s;
  }

  function txObj(type, amount, details, postedBy, postedById, approvedBy, counterparty, dateISO, extra={}) {
    return {
      id: uid('tx'),
      type,
      amount: Number(amount||0),
      details: details || '',
      postedBy,
      postedById,
      approvedBy,
      counterparty: counterparty || '',
      date: `${dateISO || today()}T12:00:00.000Z`,
      balanceAfter: null,
      ...extra
    };
  }

  function ensureState() {
    state.staff ||= [];
    state.customers ||= [];
    state.approvals ||= [];
    state.audit ||= [];
    state.operations ||= { incomeAccounts: [], expenseAccounts: [], entries: [] };
    state.operations.incomeAccounts ||= [];
    state.operations.expenseAccounts ||= [];
    state.operations.entries ||= [];
    state.cod ||= [];
    state.tempGrants ||= [];
    state.roleAssignments ||= [];
    state.staffAccounts ||= {};
    state.businessExtras ||= [];
    state.dayClosures ||= [];
    // SURGICAL ADDITION 2026-09-14 (client-confirmed design): every Journal
    // now gets a permanent, referenceable Journal Number (JN1, JN2, ...) and
    // can be saved as a draft — built up, stored, and sent for approval
    // later — instead of only existing in the moment it's typed and
    // submitted. See nextJournalNumber(), saveJournalDraft(),
    // sendJournalForApproval(), renderJournalRegister().
    state.journals ||= [];
    if (!state.businessDate) {
      const latest = latestClosedBusinessDay();
      state.businessDate = latest?.date ? (latest.nextBusinessDate || nextDate(latest.date)) : today();
    }
    reconcileBusinessDateFromClosures();
    state.staff.forEach(st => { ensureStaffWalletCustomer(st.id); ensureStaffAccount(st.id); });
    normalizeStaffWalletAccounts();
    syncAllStaffWallets();
    recalcAllCustomerBalances();
    recalcAllTellerBalances();
  }

  // Fix B 2026-10-22 (storage): browser storage (localStorage) holds only
  // ~5 MB — at hundreds of postings a day the saved copy of approvals and
  // transactions would outgrow it within weeks, after which every load
  // would re-download the whole history. In live (Supabase) mode the bulky
  // part — approvals, audit, customers with their transactions, and the
  // incremental-sync markers that describe them — now lives in IndexedDB
  // (hundreds of MB), written together so data and markers always match.
  // localStorage keeps the small rest. Offline/local mode is unchanged. If
  // IndexedDB is unavailable, everything stays in localStorage as before.
  // A function declaration (not a const) so startup code above it can call it.
  function bulkStore() { return (bulkStoreInstance ||= makeBulkStore()); }
  function makeBulkStore() {
    const DB_NAME = 'ducess_cache', STORE = 'kv', KEY = `${STORAGE_KEY}__bulk`;
    let dbPromise = null;
    function open() {
      if (dbPromise) return dbPromise;
      dbPromise = new Promise((resolve, reject) => {
        try {
          const req = indexedDB.open(DB_NAME, 1);
          req.onupgradeneeded = () => req.result.createObjectStore(STORE);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
          req.onblocked = () => reject(new Error('IndexedDB blocked'));
        } catch (err) { reject(err); }
      });
      return dbPromise;
    }
    async function run(mode, fn) {
      const db = await open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, mode);
        const req = fn(tx.objectStore(STORE));
        tx.oncomplete = () => resolve(req.result);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
      });
    }
    return {
      open,
      get: () => run('readonly', st => st.get(KEY)),
      put: (value) => run('readwrite', st => st.put(value, KEY)),
    };
  }

  async function restoreBulkState() {
    if (typeof indexedDB === 'undefined') return;
    try {
      await bulkStore().open();
      if (state.__bulkInIdb) {
        const snap = await bulkStore().get();
        if (snap) {
          state.approvals = snap.approvals || [];
          state.audit = snap.audit || [];
          state.customers = snap.customers || state.customers || [];
          state.__sync = snap.__sync || {};
          state.__history = snap.__history || null;
          syncStaffBusinessEffectsFromApprovedRequests();
          syncOperationalEffectsFromApprovedRequests();
          recalcAllCustomerBalances();
          recalcAllTellerBalances();
        } else {
          state.__sync = {};
          state.__history = null;
        }
      }
      bulkIdbOk = true;
      save();
      flushBulkWrite();
    } catch (err) {
      console.warn('[DUCESS] IndexedDB unavailable — keeping data in browser storage.', err);
    }
  }

  function scheduleBulkWrite() {
    clearTimeout(bulkWriteTimer);
    bulkWriteTimer = setTimeout(flushBulkWrite, 1500);
  }
  function flushBulkWrite() {
    clearTimeout(bulkWriteTimer);
    bulkWriteTimer = null;
    if (!bulkIdbOk) return;
    bulkStore().put({ savedAt: new Date().toISOString(), approvals: state.approvals || [], audit: state.audit || [], customers: state.customers || [], __sync: state.__sync || {}, __history: state.__history || null })
      .catch(err => { console.warn('[DUCESS] IndexedDB save failed — back to browser storage.', err); bulkIdbOk = false; save(); });
  }
  window.addEventListener('pagehide', () => { if (bulkWriteTimer) flushBulkWrite(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && bulkWriteTimer) flushBulkWrite(); });

  function load() {
    if (gateway?.appState?.loadState) return gateway.appState.loadState();
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  // SURGICAL FIX 2026-10-22 (memory management): browser storage holds
  // ~5 MB. The whole working copy (customers + transactions + approvals) is
  // saved here, and an over-quota save used to THROW — breaking whatever
  // action was running. Now a failed save retries with a slim copy that
  // leaves out data the server re-sends on every load (live mode only:
  // approvals, transactions, audit). Local/offline mode can't drop data, so
  // it warns once instead.
  let storageWarned = false;
  function save() {
    const write = (obj) => {
      if (gateway?.appState?.saveState) gateway.appState.saveState(obj);
      else localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
    };
    // Admin caches (profiles with photos, ICT logs) are reloaded each
    // session, so they stay out of browser storage.
    const { staffProfiles, ictLogs, ...persistUi } = state.ui || {};
    const useBulk = bulkIdbOk && isSupabaseApprovalMode();
    const persist = useBulk
      ? { ...state, ui: persistUi, approvals: [], audit: [], customers: (state.customers || []).map(c => ({ ...c, transactions: [] })), __sync: undefined, __history: undefined, __bulkInIdb: true }
      : { ...state, ui: persistUi, __bulkInIdb: undefined };
    try { write(persist); if (useBulk) scheduleBulkWrite(); return; }
    catch (err) {
      if (isSupabaseApprovalMode()) {
        try {
          write({ ...persist, __sync: undefined, __history: undefined, approvals: [], audit: [], customers: (state.customers || []).map(c => ({ ...c, transactions: [] })), __slimSaved: new Date().toISOString() });
          return;
        } catch (err2) { /* fall through to warning */ }
      }
      if (!storageWarned) { storageWarned = true; console.warn('[DUCESS] Browser storage is full — state not saved.', err); try { showToast('Browser storage is full — clear site data or contact admin'); } catch (_) {} }
    }
  }

  function currentStaff() {
    return state.staff.find(s => s.id === state.activeStaffId) || state.staff.find(s => s.active !== false) || state.staff[0] || null;
  }

  function getStaffBackendId(staff = currentStaff()) {
    if (!staff) return '';
    return staff.uuid || staff.authUserId || staff.auth_user_id || staff.supabaseUserId || staff.supabase_user_id || staff.userId || staff.user_id || staff.backendId || staff.backend_id || staff.id || '';
  }

  function resetJournalUiState() {
    state.ui ||= {};
    state.ui.generatedJournals = {};
    state.ui.collapsedJournals = {};
    state.ui.staffJournals = {};
    state.ui.staffJournalAttachments = {};
    state.ui.selectedJournalCustomerId = null;
  }
  function businessDate() { return state.businessDate || today(); }
  function nextDate(iso) { const d=new Date(`${iso}T12:00:00Z`); d.setUTCDate(d.getUTCDate()+1); return d.toISOString().slice(0,10); }

  function latestClosedBusinessDay() {
    const closureRows = Array.isArray(state.dayClosures) ? state.dayClosures : [];
    const codRows = Array.isArray(state.cod) ? state.cod : [];
    return [
      ...closureRows.map(row => ({
        date: String(row.date || row.businessDate || '').slice(0,10),
        nextBusinessDate: String(row.nextBusinessDate || '').slice(0,10)
      })),
      ...codRows
        .filter(row => row && row.status !== 'draft')
        .map(row => {
          const date = String(row.date || row.businessDate || '').slice(0,10);
          return { date, nextBusinessDate: date ? nextDate(date) : '' };
        })
    ]
      .filter(row => /^\d{4}-\d{2}-\d{2}$/.test(row.date))
      .sort((a,b) => a.date.localeCompare(b.date))
      .pop() || null;
  }

  function collectKnownBusinessDates() {
    const dates = [];
    const add = (value) => {
      const iso = String(value || '').slice(0,10);
      if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) dates.push(iso);
    };
    (state.dayClosures || []).forEach(row => { add(row.date || row.businessDate); add(row.nextBusinessDate); });
    (state.cod || []).forEach(row => add(row.date || row.businessDate));
    (state.approvals || []).forEach(row => add(approvalBusinessDate(row.type || row.requestType, row.payload || {})));
    (state.customers || []).forEach(customer => (customer.transactions || []).forEach(tx => add(tx.date || tx.businessDate || tx.business_date)));
    (state.businessExtras || []).forEach(row => add(row.date || row.businessDate));
    return Array.from(new Set(dates)).sort();
  }

  function reconcileBusinessDateFromClosures() {
    // DUCESS business date is sequential, not real calendar date.
    // Never repair backwards to the computer/calendar date or to an old closure.
    const latest = latestClosedBusinessDay();
    const current = String(state.businessDate || '').slice(0,10);
    let target = current;

    if (latest?.date) {
      const expectedOpenDate = latest.nextBusinessDate || nextDate(latest.date);
      if (!target || target === latest.date || target < expectedOpenDate) {
        target = expectedOpenDate;
      }
    }

    // Recovery guard: if synced approvals/transactions are already on a later
    // DUCESS business date, keep the active date at that later business date.
    // This prevents one device from falling back to an older local date.
    const latestKnownDate = collectKnownBusinessDates().pop();
    if (latestKnownDate) {
      const latestKnownClosed = isBusinessDateClosed(latestKnownDate);
      if (!target || target < latestKnownDate || (latestKnownClosed && target === latestKnownDate)) {
        target = latestKnownClosed ? nextDate(latestKnownDate) : latestKnownDate;
      }
    }

    if (!target) return false;
    if (target !== current) {
      state.businessDate = target;
      return true;
    }
    return false;
  }

  function approvalDisplayDate(approval) {
    const payloadDate = approvalBusinessDate(approval?.type, approval?.payload || {});
    return payloadDate || approval?.requestedAt || approval?.requested_at || '';
  }

  const COD_LOCKED_POSTING_TYPES = ['customer_credit','customer_debit','customer_credit_journal','customer_debit_journal','float_declaration','float_topup','wallet_fund','debt_repayment','operational_entry','close_of_day'];

  function approvalBusinessDate(type, payload = {}) {
    return String(payload?.date || payload?.businessDate || payload?.float_date || businessDate()).slice(0,10);
  }

  function isBusinessDateClosed(dateStr = businessDate()) {
    const target = String(dateStr || '').slice(0,10);
    if (!target) return false;
    // A DUCESS business date is closed if Central COD has closed it locally
    // OR if COD submissions for that date have synced from Supabase.
    // This makes COD Resolution dates authoritative across devices, not just
    // dependent on one browser's local dayClosures array.
    const locallyClosed = (state.dayClosures || []).some(row => String(row.date || row.businessDate || '').slice(0,10) === target);
    const codClosed = (state.cod || []).some(row => String(row.date || row.businessDate || '').slice(0,10) === target && row.status !== 'draft');
    return locallyClosed || codClosed;
  }

  function businessDateClosedMessage(dateStr = businessDate()) {
    return `Business date ${dateStr} is already closed. Posting is locked.`;
  }

  function shouldLockApprovalType(type) {
    return COD_LOCKED_POSTING_TYPES.includes(type);
  }


  function codRemainingBalance(formAmount, totalCredits, totalDebits) {
    return Number(formAmount || 0) - Number(totalCredits || 0) - Number(totalDebits || 0);
  }

  function buildCodDailySnapshot(dateStr, postingStaff = []) {
    const rows = postingStaff.map(st => {
      const formAmount = getStaffOperationalBalance(st.id);
      const creditCash = approvedCreditTotalForDateByMode(st.id, dateStr, 'cash');
      const creditTransfer = approvedCreditTotalForDateByMode(st.id, dateStr, 'transfer');
      const debitCash = approvedDebitTotalForDateByMode(st.id, dateStr, 'cash');
      const debitTransfer = approvedDebitTotalForDateByMode(st.id, dateStr, 'transfer');
      const totalCredits = creditCash + creditTransfer;
      const totalDebits = debitCash + debitTransfer;
      const netBookBalance = totalCredits - totalDebits;
      const remainingBalance = codRemainingBalance(formAmount, totalCredits, totalDebits);
      const variance = Math.abs(remainingBalance);
      const debt = Number(ensureStaffAccount(st.id)?.debtBalance || 0);
      return { staffId: st.id, staffName: st.name, formAmount, creditCash, creditTransfer, debitCash, debitTransfer, totalCredits, totalDebits, netBookBalance, remainingBalance, variance, debt };
    });
    return {
      rows,
      totalForm: rows.reduce((sum,row)=>sum+Number(row.formAmount||0),0),
      totalCredits: rows.reduce((sum,row)=>sum+Number(row.totalCredits||0),0),
      totalDebits: rows.reduce((sum,row)=>sum+Number(row.totalDebits||0),0),
      totalNetBookBalance: rows.reduce((sum,row)=>sum+Number(row.netBookBalance||0),0),
      totalRemainingBalance: rows.reduce((sum,row)=>sum+Number(row.remainingBalance||0),0),
      totalVariance: rows.reduce((sum,row)=>sum+Number(row.variance||0),0),
      totalDebt: rows.reduce((sum,row)=>sum+Number(row.debt||0),0)
    };
  }

  function carryForwardForms(fromDate, toDate, postingStaff = []) {
    // Disabled: each business day requires a fresh FORM declaration.
    // COD resolution handles previous day reconciliation.
    // No automatic carry-forward of remaining balance.
  }

  function finalizeBusinessDay(dateStr, postingStaff = []) {
    reconcileBusinessDateFromClosures();
    const closedDate = String(dateStr || businessDate()).slice(0,10);
    if (isBusinessDateClosed(closedDate)) return false;
    const nextOpenDate = nextDate(closedDate);
    const snapshot = buildCodDailySnapshot(closedDate, postingStaff);
    state.dayClosures.push({
      id: uid('dayclose'),
      date: closedDate,
      businessDate: closedDate,
      nextBusinessDate: nextOpenDate,
      closedAt: new Date().toISOString(),
      closedBy: currentStaff()?.name || '',
      closedById: currentStaff()?.id || '',
      snapshot
    });
    carryForwardForms(closedDate, nextOpenDate, postingStaff);
    state.businessDate = nextOpenDate;
    return true;
  }
  function staffById(id){ return state.staff.find(s=>s.id===id) || null; }
  // 2026-11-09 (client): accounts are kept in separate segments so each one has
  // its own totals — Customers, Staff, Income, Expenses, Tellerng, Treasury —
  // and "All Accounts" is where they are looked at together.
  function accountSegmentOf(c) {
    const t = String(c?.accountType || 'customer');
    return ({ customer: 'customer', staff_salary: 'staff', income: 'income', expense: 'expense', staff_operational: 'tellerng', treasury: 'treasury' })[t] || '';
  }
  const accountsInSegment = (seg) => (state.customers || []).filter(c => accountSegmentOf(c) === seg);
  // SURGICAL ADDITION 2026-09-28 (client correction): "Teller ID" is the
  // staff's FIRST NAME, not their T#### operational account number.
  function staffFirstName(st){ return String(st?.name || '').trim().split(/\s+/)[0] || '—'; }
  // 2026-11-09 (client): "Teller ID" always shows the Teller AND the account
  // number (e.g. "Mary Daniel • T1001"), never just a first name.
  function tellerIdLabel(st, acctNo) {
    if (!st) return '—';
    const no = acctNo || staffOperationalAccountNumber(st.id);
    return `${st.name || staffFirstName(st)}${no ? ' • ' + no : ''}`;
  }
  function tellerIdForAccount(c){ return c?.accountType === 'staff_operational' ? tellerIdLabel(staffById(c.linkedStaffId), c.accountNumber) : '—'; }
  function tellerBannerHtml(st = currentStaff()) {
    if (!st) return '';
    const no = staffOperationalAccountNumber(st.id);
    if (!no && !(staffHasRole(st, 'teller') || staffHasRole(st, 'admin_officer'))) return '';
    return `<div class="teller-id-banner"><span><span class="k">Teller ID</span><strong>${escapeHtml(st.name || '')}</strong></span><span><span class="k">Account No</span><strong>${escapeHtml(no || 'Not opened yet')}</strong></span></div>`;
  }
  // SURGICAL ADDITION 2026-09-28 (client correction): Account Status is a
  // small colour-coded box, not a full-size display field.
  function accountStatusOf(c){ return c ? customerStatusLabel(c) : '—'; }
  function accountStatusChip(c, id){ const v = accountStatusOf(c); return `<span class="acct-status-chip ${(v === 'Frozen' || v === 'Closed') ? 'is-frozen' : (v === 'Active' ? 'is-active' : '')}"${id ? ` id="${id}"` : ''}>${v}</span>`; }
  function setAccountStatusChip(el, c){ if (!el) return; const v = accountStatusOf(c); el.textContent = v; el.classList.add('acct-status-chip'); el.classList.toggle('is-active', v === 'Active'); el.classList.toggle('is-frozen', v === 'Frozen' || v === 'Closed'); }
  function customerName(id){ return state.customers.find(c=>c.id===id)?.name || ''; }
  function getStaffWalletCustomer(staffId){ const acc=ensureStaffAccount(staffId); return state.customers.find(c=>c.id===acc.linkedCustomerId) || null; }
  function ensureStaffWalletCustomer(staffId, sourceState=state){
    const st=(sourceState.staff||[]).find(x=>x.id===staffId); if(!st) return null;
    sourceState.customers ||= [];
    const existing=sourceState.customers.find(c=>c.staffId===staffId && c.accountType==='staff_wallet');
    if(existing){ if(existing.name!==st.name) existing.name=st.name; return existing; }
    // Use a deterministic id derived from staffId so re-creation after Supabase sync
    // always produces the same id — preventing stale selectedJournalCustomerId references.
    const stableId = `swc-${staffId}`;
    const idx=(sourceState.staff||[]).findIndex(x=>x.id===staffId);
    const c={ id: stableId, accountNumber: `${4000 + Math.max(0,idx)}`, oldAccountNumber:'', name: st.name, address:'', nin:'', bvn:'', phone:'', photo:'', active:true, createdAt:new Date().toISOString(), transactions:[], staffId, accountType:'staff_wallet'};
    sourceState.customers.push(c); return c;
  }
  function syncStaffWallet(staffId){ const acc=ensureStaffAccount(staffId); const c=getStaffWalletCustomer(staffId); if(c){ acc.walletBalance=Number(c.balance||0); } }
  function syncAllStaffWallets(){ Object.keys(state.staffAccounts||{}).forEach(syncStaffWallet); }
  function normalizeStaffWalletAccounts(){
    (state.staff||[]).forEach((st, idx) => {
      const wallet = ensureStaffWalletCustomer(st.id);
      const acctNo = String(4000 + idx);
      if (wallet) wallet.accountNumber = acctNo;
      const acc = ensureStaffAccount(st.id);
      acc.accountNumber = acctNo;
      acc.linkedCustomerId = wallet?.id || acc.linkedCustomerId || null;
    });
  }
  function isAdminStaff(staff=currentStaff()) {
    const role = String(staff?.role || staff?.roleCode || '').trim().toLowerCase();
    const label = String(staff?.roleLabel || staff?.title || '').trim().toLowerCase();
    return role === 'admin_officer' || role === 'admin' || label.includes('admin') || staffHasRole(staff, 'admin_officer');
  }
  function canCloseBusinessDay(staff=currentStaff()){ return !!staff && (isAdminStaff(staff) || staffHasRole(staff, 'approving_officer')); }

  // ===== ROLE / STAFF SEPARATION (2026-10-11, client request) =====
  // A staff member is a person (id, login, operational account, ledger,
  // balances, COD, debts — all keyed by staff id and NEVER by role).
  // A role is an assignment ON that person: staff.role is their CURRENT role
  // ('unassigned' until one is given) and state.roleAssignments is the full
  // history (who held which role, from when to when, who assigned it).
  // Permissions follow the current role; every historical record stays tied
  // to the staff member who performed it, and getStaffRoleAt() answers
  // "what role did they hold when they did it".
  function staffRoleCode(s) {
    const r = String(s?.role || s?.role_code || s?.roleCode || '').trim();
    return r || UNASSIGNED_ROLE;
  }
  // 2026-11-10 (client): one staff member can hold MORE THAN ONE role. staff.role stays
  // the main role (what the database keeps); staff.extraRoles holds the others.
  // Access is the combination of every role the person holds.
  function staffExtraRoleCodes(s) {
    const main = String(s?.role || s?.role_code || s?.roleCode || '').trim();
    return [...new Set((Array.isArray(s?.extraRoles) ? s.extraRoles : []).map(x => String(x || '').trim()).filter(x => x && x !== UNASSIGNED_ROLE && x !== main && ROLE_LABELS[x]))];
  }
  function staffRoleCodes(s) { const main = staffRoleCode(s); return [...(main !== UNASSIGNED_ROLE ? [main] : []), ...staffExtraRoleCodes(s)]; }
  function staffHasRole(s, code) { return staffRoleCodes(s).includes(code); }
  function staffRoleLabels(s) { const c = staffRoleCodes(s); return c.length ? c.map(roleLabelOf).join(' + ') : roleLabelOf(UNASSIGNED_ROLE); }
  function staffPermsOf(s) { return staffRoleCodes(s).flatMap(r => DEFAULT_PERMS[r] || []); }
  function hasAssignedRole(s) { return !!s && staffRoleCodes(s).length > 0; }
  function roleLabelOf(code) { return ROLE_LABELS[code] || (code ? String(code) : 'Unassigned'); }
  function getStaffRoleHistory(staffId) {
    return (state.roleAssignments || [])
      .filter(a => a.staffId === staffId)
      .sort((a, b) => String(a.assignedAt || '').localeCompare(String(b.assignedAt || '')));
  }
  // Role the staff member held at a given moment. No history rows (legacy
  // staff, or migration not run) → their current role; before the first row
  // → the first role they were ever given.
  function getStaffRoleAt(staffId, atIso) {
    const staff = (state.staff || []).find(x => x.id === staffId);
    const hist = getStaffRoleHistory(staffId);
    if (!hist.length) return staff ? staffRoleCode(staff) : UNASSIGNED_ROLE;
    const t = new Date(atIso || Date.now()).getTime();
    if (Number.isNaN(t)) return staff ? staffRoleCode(staff) : UNASSIGNED_ROLE;
    for (let i = hist.length - 1; i >= 0; i--) {
      if (new Date(hist[i].assignedAt).getTime() <= t) return hist[i].roleCode || UNASSIGNED_ROLE;
    }
    return hist[0].roleCode || UNASSIGNED_ROLE;
  }
  function staffEverHeldRole(staffId, roles) {
    const staff = (state.staff || []).find(x => x.id === staffId);
    if (staff && roles.includes(staffRoleCode(staff))) return true;
    return getStaffRoleHistory(staffId).some(a => roles.includes(a.roleCode));
  }
  async function syncRoleAssignmentsFromGateway() {
    if (!isSupabaseApprovalMode() || !gateway.staff?.listRoleAssignments) return;
    try {
      const res = await gateway.staff.listRoleAssignments();
      if (res?.ok && Array.isArray(res.data)) { state.roleAssignments = res.data; save(); }
    } catch (err) { console.warn('[DUCESS] role assignment sync failed:', err); }
  }

  function ensureStaffAccount(staffId, sourceState=state) {
    sourceState.staffAccounts ||= {};
    const st=(sourceState.staff||[]).find(x=>x.id===staffId);
    if (!sourceState.staffAccounts[staffId]) {
      const wallet = ensureStaffWalletCustomer(staffId, sourceState);
      sourceState.staffAccounts[staffId] = {
        staffId,
        accountNumber: wallet?.accountNumber || `${4000000 + Object.keys(sourceState.staffAccounts).length + 1}`,
        linkedCustomerId: wallet?.id || null,
        entries: [],
        balance: 0,
        walletBalance: wallet?.balance || 0,
        debtBalance: 0
      };
    }
    const acc = sourceState.staffAccounts[staffId];
    if (!acc.linkedCustomerId) acc.linkedCustomerId = ensureStaffWalletCustomer(staffId, sourceState)?.id || null;
    if (typeof acc.walletBalance !== 'number') acc.walletBalance = 0;
    if (typeof acc.debtBalance !== 'number') acc.debtBalance = 0;
    return acc;
  }

  function auditEntry(actor, action, details) {
    // actorRole = the role the actor held at the moment of the action
    // (role/staff separation) — survives later reassignment.
    const cs = currentStaff();
    return { id: uid('aud'), at: new Date().toISOString(), actorId: cs?.id || 'system', actor, actorRole: cs ? staffRoleCode(cs) : '', action, details };
  }

  function pushAudit(action, details) {
    const st = currentStaff();
    state.audit.unshift(auditEntry(st?.name || 'System', action, details));
    save();
  }

  const CHARGE_DEFS = [
    { key: 'commission', label: 'Commission', accountName: 'Commission' },
    { key: 'registrationFee', label: 'Registration Fee', accountName: 'Registration Fee' },
    { key: 'securityFee', label: 'Security Fee', accountName: 'Security Fee' },
    { key: 'passbookSold', label: 'Passbook Sold', accountName: 'Passbook Sold' }
  ];

  function ensureDefaultIncomeAccounts(targetState=state) {
    targetState.operations ||= { incomeAccounts: [], expenseAccounts: [], entries: [] };
    targetState.operations.incomeAccounts ||= [];
    const map = {
      'Commission': 'I1',
      'Registration Fee': 'I2',
      'Security Fee': 'I3',
      'Passbook Sold': 'I4'
    };
    Object.entries(map).forEach(([name, accountNumber], idx) => {
      if (!targetState.operations.incomeAccounts.some(a => String(a.name || '').trim().toLowerCase() === name.toLowerCase())) {
        targetState.operations.incomeAccounts.push({ id: `ia_auto_${idx+1}`, name, accountNumber, createdAt: new Date().toISOString() });
      }
    });
  }

  function getIncomeAccountByName(name) {
    const accounts = state.operations?.incomeAccounts || [];
    return accounts.find(a => String(a.name || '').trim().toLowerCase() === String(name || '').trim().toLowerCase()) || accounts[0] || null;
  }

  function getCommissionIncomeAccount() {
    return getIncomeAccountByName('Commission');
  }

  function normalizeChargeAmount(totalAmount, chargeAmount) {
    const total = Number(totalAmount || 0);
    const amount = Number(chargeAmount || 0);
    if (!(total > 0) || !(amount > 0)) return 0;
    return Math.min(total, Math.max(0, amount));
  }

  function normalizeChargePayload(totalAmount, payload={}) {
    const total = Number(totalAmount || payload?.amount || 0);
    if (!(total > 0)) return [];
    const sourceRows = Array.isArray(payload?.chargeBreakdown) ? payload.chargeBreakdown : null;
    let rows = sourceRows ? sourceRows.map(row => {
      const def = CHARGE_DEFS.find(d => d.key === row.key || d.label === row.label || d.accountName === row.accountName) || {};
      return {
        key: row.key || def.key || '',
        label: row.label || def.label || row.accountName || '',
        accountName: row.accountName || def.accountName || row.label || '',
        amount: normalizeChargeAmount(total, row.amount)
      };
    }) : CHARGE_DEFS.map(def => ({
      key: def.key,
      label: def.label,
      accountName: def.accountName,
      amount: normalizeChargeAmount(total, payload?.[def.key])
    }));
    if (!sourceRows && !rows.some(r => r.key === 'commission') && Number(payload?.commissionAmount || 0) > 0) {
      rows.unshift({ key: 'commission', label: 'Commission', accountName: 'Commission', amount: normalizeChargeAmount(total, payload.commissionAmount) });
    }
    let remaining = total;
    rows = rows.map(row => {
      const amount = Math.min(remaining, normalizeChargeAmount(total, row.amount));
      remaining = Math.max(0, remaining - amount);
      return { ...row, amount };
    }).filter(row => row.amount > 0 && row.label);
    return rows;
  }

  function getTotalChargeAmount(payload) {
    const total = Number(payload?.amount || 0);
    return normalizeChargePayload(total, payload).reduce((sum, row) => sum + Number(row.amount || 0), 0);
  }

  function getCustomerCreditAmount(payload) {
    const total = Number(payload?.amount || 0);
    const totalCharges = getTotalChargeAmount(payload);
    const explicit = Number(payload?.customerCreditAmount || 0);
    if (!(totalCharges > 0)) return total;
    return Math.max(0, explicit > 0 ? explicit : total - totalCharges);
  }

  function chargeSummaryText(payload) {
    const total = Number(payload?.amount || 0);
    const rows = normalizeChargePayload(total, payload);
    if (!rows.length) return '';
    const pieces = rows.map(row => `${row.label} ${money(row.amount)}`).join(' • ');
    const customerGets = getCustomerCreditAmount(payload);
    return ` • ${pieces} • To Customer Account ${money(customerGets)}`;
  }

  function commissionSummaryText(payload) {
    return chargeSummaryText(payload);
  }

  function chargeInlineMeta(payload) {
    const total = Number(payload?.amount || 0);
    const rows = normalizeChargePayload(total, payload);
    if (!rows.length) return '';
    return `${rows.map(row => `To ${row.label} ${money(row.amount)}`).join(' • ')} • To Customer Account ${money(getCustomerCreditAmount(payload))}`;
  }


  function cleanOperationalNote(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    return raw
      .replace(/\s*•\s*Trace\s+[A-Za-z0-9_-]+/gi, '')
      .replace(/\s*Trace\s+[A-Za-z0-9_-]+/gi, '')
      .replace(/\s*•\s*$/g, '')
      .trim();
  }


  function hasPermission(tool, staff=currentStaff()) {
    if (!staff) return false;
    if (APPROVAL_SUB_TOOLS[tool]) return hasPermission(APPROVAL_SUB_TOOLS[tool].base, staff);
    if (ADMIN_SUB_TOOLS[tool]) return staffHasRole(staff, 'admin_officer') || hasPermission(ADMIN_SUB_TOOLS[tool].base, staff);
    // Balances now live on the Approval side (client sheet), so anyone who
    // can work the approval queue can view them, as well as anyone who
    // already had the underlying balance report.
    if (BALANCE_SUB_TOOLS[tool]) return hasPermission(BALANCE_SUB_TOOLS[tool].base, staff) || hasPermission('approval_queue', staff);
    // ROLE/STAFF SEPARATION 2026-10-11: access is role-dependent. A staff
    // member with no role assigned has no access to anything (not even the
    // formerly-universal tools) until an admin assigns one.
    if (!hasAssignedRole(staff)) return false;
    // SURGICAL FIX 2026-09-07 (client request): my_statement used to be
    // universal — now it's only for roles who actually handle cash
    // (Teller, Treasury, Collector, Admin — see DEFAULT_PERMS below).
    // Customer Service and Report Officer don't get it; Approving Officer
    // gets its own separate "My Approvals" totals view instead.
    if (['check_balance','account_statement','operational_accounts','my_close_day'].includes(tool)) return true;
    const base = staffPermsOf(staff);
    const grantOn = (state.tempGrants || []).some(g => g.staffId === staff.id && g.tool === tool && g.enabled);
    return base.includes(tool) || grantOn;
  }

  // 2026-11-09 (client): each section belongs to its own role. Anyone else gets
  // a "No access" message. Admin can open every section. A temporary grant on any
  // tool of a section still opens that section for the person it was granted to.
  // A function (not a const) so it is available during start-up, before this line runs.
  function moduleRolesFor(moduleKey) {
    return ({
      customer_service: ['customer_service', 'report_officer', 'admin_officer'],
      tellering: ['teller', 'admin_officer'],
      cash_officer: ['cash_officer', 'admin_officer'],
      approvals: ['approving_officer', 'admin_officer'],
      administration: ['admin_officer']
    })[moduleKey];
  }
  function moduleAllowed(moduleKey, staff=currentStaff()) {
    if (!staff) return false;
    const roles = moduleRolesFor(moduleKey);
    if (roles && !staffRoleCodes(staff).some(r => roles.includes(r))) {
      const granted = (state.tempGrants || []).some(g => g.staffId === staff.id && g.enabled && MODULES[moduleKey].tools.includes(g.tool));
      if (!granted) return false;
    }
    return MODULES[moduleKey].tools.some(t => hasPermission(t, staff));
  }
  function noAccessMessage(label) {
    const st = currentStaff();
    const role = st ? staffRoleLabels(st) : 'your role';
    return `No access — ${label ? label + ' is not' : 'this is not'} available for ${role}`;
  }

  function showToast(msg) {
    const el = byId('toast');
    el.textContent = msg;
    el.classList.remove('hidden');
    clearTimeout(showToast.t);
    showToast.t = setTimeout(() => el.classList.add('hidden'), 2800);
  }

  function openModal(title, bodyHtml, actions=[]) {
    // 2026-11-09 (client): cash modals always show the Teller and Account number.
    if (/^(Cash Receipt|My Close of Day|Resolve Close of Day|Central Close of Day|Assign Float Top-Up)$|^JN\d/.test(String(title || '')) && !/Teller ID|teller-id-banner/.test(String(bodyHtml || ''))) {
      bodyHtml = tellerBannerHtml() + bodyHtml;
    }
    byId('modalTitle').textContent = title;
    const modalEl = document.querySelector('#modalBack .modal');
    if (modalEl) modalEl.setAttribute('data-modal-title', title);
    byId('modalBody').innerHTML = bodyHtml;
    const box = byId('modalActions');
    box.innerHTML = '';
    actions.forEach(a => {
      const btn = document.createElement('button');
      btn.textContent = a.label;
      btn.className = a.className || '';
      btn.onclick = a.onClick;
      box.appendChild(btn);
    });
    byId('modalBack').classList.remove('hidden');
    overlayDateInputsWithDDMMYYYY(byId('modalBody') || document);
  }
  function closeModal() {
    byId('modalBack').classList.add('hidden');
    const modalEl = document.querySelector('#modalBack .modal');
    if (modalEl) modalEl.removeAttribute('data-modal-title');
    const toggleTool = state.ui?.modalToggleTool;
    if (toggleTool && state.ui.tool === toggleTool) {
      state.ui.tool = null;
      state.ui.modalToggleTool = null;
      save();
      renderWorkspace();
      return;
    }
    state.ui.modalToggleTool = null;
  }

  function fmtDate(iso) {
    const raw = String(iso || '');
    // Keep DUCESS business dates as plain business dates.
    // Parsing YYYY-MM-DD with new Date() can shift one day in some browser timezones.
    const plainDate = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    const d = plainDate ? new Date(Number(plainDate[1]), Number(plainDate[2]) - 1, Number(plainDate[3]), 12, 0, 0) : new Date(raw);
    return isNaN(d) ? iso : DATE_FMT.format(d);
  }

  // SURGICAL PATCH 2026-08-13: audit entries are already stored with a full
  // timestamp (auditEntry() sets `at: new Date().toISOString()`), but the
  // Audit Trail table rendered them through fmtDate(), which only formats the
  // day — the time of occurrence was silently dropped. This is used only for
  // the Audit Trail column; fmtDate() itself is untouched everywhere else
  // since business/transaction dates are correctly date-only.
  function fmtDateTime(iso) {
    const raw = String(iso || '');
    const d = new Date(raw);
    if (isNaN(d)) return iso;
    return `${DATE_FMT.format(d)}, ${TIME_FMT.format(d)}`;
  }

  function recalcCustomerBalance(customer) {
    let bal = 0;
    (customer.transactions || []).sort((a,b)=>new Date(a.date)-new Date(b.date)).forEach(tx => {
      if (tx.type === 'credit') bal += Number(tx.amount || 0);
      if (tx.type === 'debit') bal -= Number(tx.amount || 0);
      tx.balanceAfter = bal;
    });
    customer.balance = bal;
  }

  function recalcAllCustomerBalances() {
    state.customers.forEach(recalcCustomerBalance);
    save();
  }

  function recalcStaffBalance(staffId) {
    const acc = ensureStaffAccount(staffId);
    let bal = 0;
    acc.entries.sort((a,b)=>new Date(a.date)-new Date(b.date)).forEach(e => {
      bal += Number(e.delta || 0);
      e.balanceAfter = bal;
    });
    acc.balance = bal;
  }
  function recalcAllTellerBalances() { Object.keys(state.staffAccounts).forEach(recalcStaffBalance); syncAllStaffWallets(); save(); }

  function addStaffEntry(staffId, type, amount, delta, note, extra={}) {
    const acc = ensureStaffAccount(staffId);
    acc.entries.push({
      id: uid('se'),
      type,
      amount: Number(amount || 0),
      delta: Number(delta || 0),
      note: note || '',
      date: new Date().toISOString(),
      postedBy: currentStaff()?.name || 'System',
      ...extra
    });
    recalcStaffBalance(staffId);
  }

  function getCustomerByAccountNo(accountNumber) {
    const key = String(accountNumber || '').trim();
    const customer = state.customers.find(c => String(c.accountNumber || '') === key);
    if (customer) return customer;
    const staff = (state.staff || []).find(st => {
      const acc = ensureStaffAccount(st.id);
      return String(acc.accountNumber || '') === key || String(st.staffCode || st.staff_code || '') === key || String(st.id || '') === key;
    });
    if (!staff) return null;
    const acc = ensureStaffAccount(staff.id);
    return {
      id: staff.id,
      customerId: staff.id,
      staffId: staff.id,
      staffUuid: getStaffBackendId(staff),
      accountNumber: acc.accountNumber || key,
      name: staff.name || staff.full_name || staff.id,
      balance: Number(acc.balance || 0),
      active: staff.active !== false && staff.is_active !== false,
      accountType: 'staff'
    };
  }

  function searchCustomersByName(term) {
    const q = String(term || '').trim().toLowerCase();
    if (!q) return [];
    return state.customers.filter(c => c.name.toLowerCase().includes(q) || c.accountNumber.includes(q));
  }

  function isSupabaseApprovalMode() { return gateway?.__meta?.adapter === 'supabase' && gateway?.approvals; }

  // Fix B 2026-10-22 (Supabase egress): login, tab return, the 5-minute
  // safety net and realtime fallbacks used to re-download EVERY approval,
  // customer and transaction. Whole-list syncs now ask the database only
  // for rows changed since the last sync (updated_at / inserted_at columns
  // from sql/2026-10-22-fix-b-incremental-sync.sql) and merge them in.
  // A row-count check catches deletes or anything missed and falls back
  // to the full reload, as does a database without those columns yet.
  const SYNC_OVERLAP_MS = 120000;
  const SYNC_MAX_DELTA = 100;
  // Full reload at least this often anyway (catches a delete + insert
  // between syncs, which the row count alone can't see). The app itself
  // never deletes these rows — only manual SQL clean-ups do — so weekly is
  // enough; a full reload grows with history (MBs at hundreds/day).
  const SYNC_FULL_EVERY_MS = 7 * 24 * 3600000;
  // With the deletion check installed (ducess_sync_digest) a mark carries a
  // digest and never needs the periodic full reload.
  const syncStale = (mark) => !mark?.digest && (!mark?.fullAt || Date.now() - new Date(mark.fullAt).getTime() > SYNC_FULL_EVERY_MS);
  let digestSupported = true;
  // Deletion check: the database returns a row count + id checksum for rows
  // added up to the time stored at the last sync. If that changed, rows
  // were deleted → { ok: false } (caller does a full reload). Unknown /
  // not installed → { ok: true, next: null } (fall back to the weekly reload).
  async function syncDigestCheck(kind, prev) {
    if (!digestSupported || !gateway.sync?.digest) return { ok: true, next: null };
    let res;
    try { res = await gateway.sync.digest(kind, prev?.at || null); } catch (_) { return { ok: true, next: null }; }
    if (!res?.ok || !res.data?.now) { if (res?.error?.code === 'SYNC_UNSUPPORTED') digestSupported = false; return { ok: true, next: null }; }
    const d = res.data;
    if (prev?.at && d.prev && (Number(d.prev.count) !== Number(prev.count) || String(d.prev.sum) !== String(prev.sum))) return { ok: false };
    return { ok: true, next: { at: d.at, count: Number(d.now.count), sum: String(d.now.sum) } };
  }
  const syncSupported = { approvals: true, customers: true };
  const syncSince = (cursor) => new Date(new Date(cursor).getTime() - SYNC_OVERLAP_MS).toISOString();
  const syncMaxTs = (cursor, rows) => rows.reduce((m, r) => (r.ts && new Date(r.ts) > new Date(m) ? r.ts : m), cursor);
  // Rows already merged inside the overlap window, keyed id -> timestamp,
  // so the overlap re-check doesn't re-download them every time.
  function syncRecent(cursor, rows) {
    const top = new Date(cursor).getTime(), floor = top - SYNC_OVERLAP_MS;
    const recent = {};
    rows.forEach(r => { const t = r.ts ? new Date(r.ts).getTime() : NaN; if (t > floor && t <= top) recent[r.id] = r.ts; });
    return Object.keys(recent).length <= 500 ? recent : null;
  }
  const recentRows = (recent) => Object.entries(recent || {}).map(([id, ts]) => ({ id, ts }));
  const isUnseen = (recent) => (r) => !recent || recent[r.id] !== r.ts;
  function setSyncMark(kind, mark) { state.__sync ||= {}; if (mark) state.__sync[kind] = mark; else delete state.__sync[kind]; }
  async function takeSyncSnapshot(kind) {
    if (!gateway.sync?.snapshot) return null;
    try {
      const res = await gateway.sync.snapshot(kind);
      if (res?.ok && res.data?.cursor) return res.data;
      if (res?.error?.code === 'SYNC_UNSUPPORTED') syncSupported[kind === 'approvals' ? 'approvals' : 'customers'] = false;
    } catch (_) {}
    return null;
  }
  async function syncChangedSince(kind, cursor) {
    try {
      const res = await gateway.sync.changedSince(kind, syncSince(cursor));
      if (res?.ok && Array.isArray(res.data)) return res.data;
      if (res?.error?.code === 'SYNC_UNSUPPORTED') syncSupported[kind === 'approvals' ? 'approvals' : 'customers'] = false;
    } catch (_) {}
    return null;
  }

  // ---- Fix B 2026-10-22: recent history + summaries --------------------
  // A device holds full detail from state.__history.from (a business date)
  // onwards, plus SUMMARY rows for everything older: approvals and customer
  // transactions marked payload.__bf / tx.__bf, each standing for __count
  // records with the same totals (see sql/2026-10-22-fix-b-history-window.sql
  // for exactly which records are summarised). Every screen keeps working
  // on state as before; a screen that needs an older date first calls
  // historyCovers(date), which fetches the missing detail and re-renders.
  // from === HISTORY_ALL means everything is held in full.
  const HISTORY_ALL = '1900-01-01';
  const historyEnabled = runtimeConfig.historyWindow !== false;
  let historySupported = true;
  let historyWindowCache = null;
  let historyLoading = null;
  let historyNeededDuringRender = false;
  const SUMMARISED_TYPES = ['customer_credit', 'customer_debit', 'inter_staff_credit', 'cash_receipt'];
  const histNum = (v) => (/^\s*-?\d+(\.\d+)?\s*$/.test(String(v ?? '')) ? Number(v) : 0);
  function historyBizDate(p = {}) {
    const d = String(p.date || p.businessDate || p.float_date || '');
    return /^\d{4}-\d{2}-\d{2}/.test(d) ? d.slice(0, 10) : '';
  }
  // JS twin of ducess_is_summarised (SQL).
  function isSummarisedApproval(a, from) {
    if (!from || from === HISTORY_ALL || !a || !SUMMARISED_TYPES.includes(a.type)) return false;
    if (a.status !== 'approved' && a.status !== 'rejected') return false;
    const p = a.payload || {};
    const d = historyBizDate(p);
    if (!d || d >= from) return false;
    if (p.accountType === 'staff' || p.accountType === 'staff_wallet') return false;
    if (a.status === 'rejected') return true;
    if (Array.isArray(p.chargeBreakdown) && p.chargeBreakdown.length) return false;
    return histNum(p.commissionAmount) === 0 && histNum(p.totalChargeAmount) === 0;
  }
  const representedCount = (list) => (list || []).reduce((n, a) => n + (a?.payload?.__bf ? Number(a.payload.__count || 1) : 1), 0);
  const historyFrom = () => state.__history?.from || null;
  const historyTxFrom = () => state.__history?.txFrom || null;
  // The later of the two start dates is what the device fully covers.
  const historyCoveredFrom = () => [historyFrom(), historyTxFrom()].filter(d => d && d !== HISTORY_ALL).sort().pop() || null;
  const historyActive = () => historyEnabled && historySupported && isSupabaseApprovalMode() && !!gateway.history?.window;
  function setHistory(patch) { state.__history = { ...(state.__history || {}), ...patch }; }

  // One window answer serves both the approvals and the customers load.
  async function getHistoryWindow(from) {
    const key = from || '';
    const hit = historyWindowCache && (historyWindowCache.key === key || historyWindowCache.from === key) && Date.now() - historyWindowCache.at < 300000;
    if (hit) return historyWindowCache.promise;
    const promise = (async () => {
      const res = await gateway.history.window(from || null);
      if (!res?.ok) { if (res?.error?.code === 'HISTORY_UNSUPPORTED') historySupported = false; return null; }
      return res.data?.from ? res.data : null;
    })();
    const entry = { key, from: null, at: Date.now(), promise };
    historyWindowCache = entry;
    const data = await promise;
    if (!data) { if (historyWindowCache === entry) historyWindowCache = null; return null; }
    entry.from = data.from;
    return data;
  }

  // Merges fresh approval rows. Returns false when a row would also be
  // inside a local summary (an older record changed) — caller reloads.
  function mergeApprovalRows(rows, removedIds = []) {
    const from = historyFrom();
    const byId = new Map((state.approvals || []).map(a => [String(a.id), a]));
    for (const a of rows || []) {
      if (!byId.has(String(a.id)) && isSummarisedApproval(a, from)) return false;
    }
    removedIds.forEach(id => byId.delete(String(id)));
    (rows || []).forEach(a => byId.set(String(a.id), a));
    state.approvals = [...byId.values()].sort((a, b) => new Date(b.requestedAt || 0) - new Date(a.requestedAt || 0));
    return true;
  }

  // True when the loaded history already reaches back to `date`
  // ('' / null = all dates). Otherwise starts fetching it and returns false.
  function historyCovers(date) {
    if (!historyEnabled || !isSupabaseApprovalMode()) return true;
    const from = historyCoveredFrom();
    if (!from) return true;
    const want = date ? String(date).slice(0, 10) : HISTORY_ALL;
    if (want >= from) return true;
    historyNeededDuringRender = true;
    loadOlderHistory(want);
    return false;
  }

  function loadOlderHistory(newFrom) {
    if (historyLoading) return historyLoading;
    historyLoading = (async () => {
      window.__ducessHistoryBusy = true;
      try {
        await bulkReady;
        const oldFrom = historyFrom(), oldTxFrom = historyTxFrom();
        const needA = !!oldFrom && oldFrom !== HISTORY_ALL && newFrom < oldFrom;
        const needT = !!oldTxFrom && oldTxFrom !== HISTORY_ALL && newFrom < oldTxFrom;
        if (!needA && !needT) return true;
        const target = newFrom === HISTORY_ALL ? null : newFrom;
        const none = { ok: true, data: [] };
        const [win, gapA, gapT] = await Promise.all([
          target ? gateway.history.window(target) : Promise.resolve({ ok: true, data: { from: HISTORY_ALL, approvals: [], transactions: [] } }),
          needA ? gateway.history.approvals(target, oldFrom) : Promise.resolve(none),
          needT ? gateway.history.transactions(target, oldTxFrom) : Promise.resolve(none),
        ]);
        if (!win?.ok || !gapA?.ok || !gapT?.ok) { showToast('Could not load older records — check the connection and try again.'); return false; }
        // Approvals: older summaries out, new summaries + the gap's detail in.
        if (needA) {
          // Keep detail rows the new summaries don't already stand for (a
          // request held in detail, e.g. approved after this device loaded
          // it, is inside the server's summary now); gap rows replace any
          // same-id row.
          const byId = new Map();
          (state.approvals || []).forEach(a => { if (!a?.payload?.__bf && !isSummarisedApproval(a, target || '')) byId.set(String(a.id), a); });
          gapA.data.forEach(a => byId.set(String(a.id), a));
          state.approvals = [...(win.data.approvals || []), ...byId.values()].sort((a, b) => new Date(b.requestedAt || 0) - new Date(a.requestedAt || 0));
        }
        // Transactions: same per customer.
        const byCustomer = (rows) => { const m = new Map(); rows.forEach(row => { const k = String(row.customer_id); const list = m.get(k) || []; list.push(gateway.history.toLocal(row)); m.set(k, list); }); return m; };
        const newSummary = byCustomer(needT ? (win.data.transactions || []) : []);
        const gapTx = byCustomer(gapT.data);
        if (needT) (state.customers || []).forEach(c => {
          if (c.accountType === 'staff_wallet') return;
          const id = String(c.id);
          const hadSummary = (c.transactions || []).some(t => t.__bf);
          if (!hadSummary && !gapTx.has(id) && !newSummary.has(id)) return;
          // Detail older than the new start is inside the new summary.
          const kept = (c.transactions || []).filter(t => !t.__bf && (!target || String(t.date || '').slice(0, 10) >= target));
          const seen = new Set(kept.map(t => String(t.id)));
          c.transactions = [
            ...(newSummary.get(id) || []),
            ...kept,
            ...(gapTx.get(id) || []).filter(t => !seen.has(String(t.id))),
          ];
        });
        setHistory({ ...(needA ? { from: newFrom } : {}), ...(needT ? { txFrom: newFrom } : {}) });
        if (state.__sync?.approvals) state.__sync.approvals.count = representedCount(state.approvals);
        historyWindowCache = null;
        syncStaffBusinessEffectsFromApprovedRequests();
        syncOperationalEffectsFromApprovedRequests();
        recalcAllCustomerBalances();
        recalcAllTellerBalances();
        save();
        return true;
      } catch (err) {
        console.warn('[DUCESS] loading older history failed', err);
        return false;
      } finally {
        historyLoading = null;
        window.__ducessHistoryBusy = false;
        renderWorkspace();
      }
    })();
    return historyLoading;
  }

  // A customer's statement needs that customer's full transaction list.
  function customerHistoryCovers(customer) {
    if (!customer || !(customer.transactions || []).some(t => t.__bf)) return true;
    historyNeededDuringRender = true;
    if (!historyLoading) {
      historyLoading = (async () => {
        window.__ducessHistoryBusy = true;
        try {
          const res = await gateway.history.customerTransactions(customer.id);
          if (res?.ok) {
            customer.transactions = res.data.map(gateway.history.toLocal);
            recalcCustomerBalance(customer);
            save();
          }
        } catch (err) { console.warn('[DUCESS] loading customer history failed', err); }
        finally { historyLoading = null; window.__ducessHistoryBusy = false; renderWorkspace(); }
      })();
    }
    return false;
  }

  async function syncApprovalsDelta() {
    const mark = state.__sync?.approvals;
    if (!syncSupported.approvals || !mark?.cursor || syncStale(mark) || !(state.approvals || []).length || !gateway.sync?.changedSince) return null;
    const changedAll = await syncChangedSince('approvals', mark.cursor);
    if (!changedAll || changedAll.length >= 1000) return null;
    const changed = changedAll.filter(isUnseen(mark.recent));
    if (changed.length > SYNC_MAX_DELTA) return null;
    const snap = await takeSyncSnapshot('approvals');
    if (!snap) return null;
    const digest = await syncDigestCheck('approvals', mark.digest);
    if (!digest.ok) return null;
    const ids = [...new Set(changed.map(r => String(r.id)))];
    let fresh = [];
    if (ids.length) {
      const res = await gateway.approvals.listApprovalRequests({ ids });
      if (!res?.ok || !Array.isArray(res.data)) return null;
      fresh = res.data;
    }
    const before = state.approvals;
    if (!mergeApprovalRows(fresh)) { state.approvals = before; return null; }
    if (representedCount(state.approvals) !== snap.count) { state.approvals = before; return null; }
    if (fresh.length) {
      syncStaffBusinessEffectsFromApprovedRequests();
      syncOperationalEffectsFromApprovedRequests();
      reconcileBusinessDateFromClosures();
    }
    const cursor = syncMaxTs(mark.cursor, changedAll);
    setSyncMark('approvals', { cursor, fullAt: mark.fullAt, digest: digest.next || undefined, count: snap.count, recent: syncRecent(cursor, [...recentRows(mark.recent), ...changedAll]) });
    save();
    return defaultResultOk(state.approvals);
  }

  // Overlapping whole-list syncs (startup + login, tab return + realtime)
  // share one download instead of each fetching everything.
  let approvalsSyncInFlight = null;
  let customersSyncInFlight = null;
  function syncApprovalsFromGateway(filters = {}) {
    if (filters && Object.keys(filters).length) return syncApprovalsFromGatewayOnce(filters);
    if (!approvalsSyncInFlight) approvalsSyncInFlight = syncApprovalsFromGatewayOnce().finally(() => { approvalsSyncInFlight = null; });
    return approvalsSyncInFlight;
  }
  function syncCustomersListFromGateway(filters = {}) {
    if (filters && Object.keys(filters).length) return syncCustomersListFromGatewayOnce(filters);
    if (!customersSyncInFlight) customersSyncInFlight = syncCustomersListFromGatewayOnce().finally(() => { customersSyncInFlight = null; });
    return customersSyncInFlight;
  }

  async function syncApprovalsFromGatewayOnce(filters = {}) {
    if (!isSupabaseApprovalMode() || !gateway.approvals?.listApprovalRequests) return defaultResultOk(state.approvals || []);
    const wholeList = !filters || !Object.keys(filters).length;
    if (wholeList) {
      await bulkReady;
      const delta = await syncApprovalsDelta();
      if (delta) return delta;
    }
    const snap = wholeList && syncSupported.approvals ? await takeSyncSnapshot('approvals') : null;
    // SURGICAL FIX 2026-09-30: fetch ALL requests by default (was the
    // gateway's default of the latest 100) — Opening Cash, Till and COD
    // are summed over every approved request, so a capped list dropped a
    // teller's older funding and the figures stopped adding up.
    let result = null;
    if (wholeList && historyActive() && historyFrom() !== HISTORY_ALL) {
      const hw = await getHistoryWindow(historyCoveredFrom());
      const recent = hw ? await gateway.history.approvals(hw.from) : null;
      if (recent?.ok) {
        result = { ok: true, data: [...hw.approvals, ...recent.data].sort((a, b) => new Date(b.requestedAt || 0) - new Date(a.requestedAt || 0)) };
        setHistory({ from: hw.from });
      } else if (recent?.error?.code === 'HISTORY_UNSUPPORTED') historySupported = false;
    }
    if (!result) {
      result = await gateway.approvals.listApprovalRequests({ all: true, ...filters });
      if (wholeList && result?.ok) setHistory({ from: HISTORY_ALL });
    }
    if (result?.ok && Array.isArray(result.data)) {
      state.approvals = result.data;
      if (wholeList) {
        const win = snap ? await syncChangedSince('approvals', snap.cursor) : null;
        const digest = snap && win ? await syncDigestCheck('approvals', null) : { next: null };
        setSyncMark('approvals', snap && win && { cursor: snap.cursor, fullAt: new Date().toISOString(), digest: digest.next || undefined, count: representedCount(result.data), recent: syncRecent(snap.cursor, win) });
      }
      syncStaffBusinessEffectsFromApprovedRequests();
      syncOperationalEffectsFromApprovedRequests();
      reconcileBusinessDateFromClosures();
      save();
    }
    return result;
  }

  // SURGICAL ADDITION 2026-10-01: refresh just the given request(s) and
  // merge them into state — used right after approve/reject so the step
  // stays tiny and inside the 20s request deadline (a full reload of every
  // approval there could make a SUCCESSFUL approval report "timed out").
  // Falls back to the full sync if the targeted read fails.
  async function syncApprovalsByIdFromGateway(ids) {
    const list = (ids || []).filter(Boolean).map(String);
    if (!list.length || !isSupabaseApprovalMode() || !(state.approvals || []).length) return syncApprovalsFromGateway();
    const result = await gateway.approvals.listApprovalRequests({ ids: list });
    if (!result?.ok || !Array.isArray(result.data)) return syncApprovalsFromGateway();
    if (!mergeApprovalRows(result.data)) return syncApprovalsFromGateway();
    syncStaffBusinessEffectsFromApprovedRequests();
    syncOperationalEffectsFromApprovedRequests();
    reconcileBusinessDateFromClosures();
    save();
    return result;
  }

  function resolveStaffWalletForBusinessPayload(payload = {}) {
    const accountNumber = String(payload.accountNumber || '').trim();
    const staffId = String(payload.staffAccountId || payload.staffId || payload.customerId || '').trim();
    let wallet = null;
    if (staffId) {
      wallet = state.customers.find(c => c.accountType === 'staff_wallet' && (c.staffId === staffId || c.id === staffId));
      if (!wallet && (state.staff || []).some(st => st.id === staffId)) wallet = ensureStaffWalletCustomer(staffId);
    }
    if (!wallet && accountNumber) wallet = state.customers.find(c => c.accountType === 'staff_wallet' && String(c.accountNumber || '') === accountNumber);
    if (!wallet && accountNumber) wallet = getCustomerByAccountNo(accountNumber);
    return wallet && (wallet.accountType === 'staff_wallet' || wallet.accountType === 'staff') ? wallet : null;
  }

  function applyApprovedStaffBusinessEntry(req, entryPayload = {}, txType = 'credit', rowKey = '') {
    if (!req || req.status !== 'approved') return;
    const payload = entryPayload || {};
    if (!(payload.accountType === 'staff' || payload.accountType === 'staff_wallet')) return;
    const wallet = resolveStaffWalletForBusinessPayload(payload);
    if (!wallet) return;
    wallet.transactions ||= [];
    const sourceApprovalId = req.id || payload.sourceApprovalId || '';
    const sourceRowKey = String(rowKey || payload.sourceRowKey || payload.accountNumber || payload.customerId || 'direct');
    if (sourceApprovalId && wallet.transactions.some(tx => tx.sourceApprovalId === sourceApprovalId && tx.sourceRowKey === sourceRowKey && tx.type === txType)) return;
    const grossAmount = Number(payload.amount || 0);
    if (!(grossAmount > 0)) return;
    const chargeBreakdown = txType === 'credit' ? normalizeChargePayload(grossAmount, payload) : [];
    const totalCharges = chargeBreakdown.reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const postedAmount = txType === 'credit' ? getCustomerCreditAmount({ ...payload, chargeBreakdown }) : grossAmount;
    const baseDetails = String(payload.details || '').trim();
    const detailTag = txType === 'credit' && totalCharges > 0 ? `${baseDetails ? ' • ' : ''}${chargeInlineMeta({ amount: grossAmount, chargeBreakdown, customerCreditAmount: postedAmount })}` : '';
    wallet.transactions.push(txObj(txType, postedAmount, `${baseDetails}${detailTag}`.trim(), req.requestedByName || staffName(req.requestedBy) || 'System', req.requestedBy || '', req.approvedBy || req.approvedByName || '', 'staff_wallet', payload.date || payload.businessDate || businessDate(), {
      receivedOrPaidBy: payload.receivedOrPaidBy || '',
      paymentMode: payload.paymentMode || payload.payoutSource || '',
      postedBy: req.requestedByName || staffName(req.requestedBy) || 'System',
      approvedBy: req.approvedBy || req.approvedByName || '',
      sourceAmount: grossAmount,
      chargeBreakdown,
      totalChargeAmount: totalCharges,
      customerCreditAmount: postedAmount,
      sourceApprovalId,
      sourceRowKey,
      accountType: 'staff_wallet'
    }));
    recalcCustomerBalance(wallet);
    const acc = ensureStaffAccount(wallet.staffId);
    if (acc) acc.walletBalance = Number(wallet.balance || 0);
  }

  function syncStaffBusinessEffectsFromApprovedRequests() {
    normalizeStaffWalletAccounts();
    (state.approvals || []).forEach(req => {
      if (!req || req.status !== 'approved') return;
      const p = req.payload || {};
      if (req.type === 'customer_credit' || req.type === 'customer_debit') {
        const txType = req.type === 'customer_debit' ? 'debit' : 'credit';
        applyApprovedStaffBusinessEntry(req, p, txType, 'direct');
      }
      if (req.type === 'customer_credit_journal' || req.type === 'customer_debit_journal') {
        const txType = req.type === 'customer_debit_journal' ? 'debit' : 'credit';
        (Array.isArray(p.rows) ? p.rows : []).forEach((row, index) => applyApprovedStaffBusinessEntry(req, { ...row, date: row.date || p.date || p.businessDate }, txType, row.id || `${index}:${row.accountNumber || row.customerId || ''}`));
      }
    });
    syncAllStaffWallets();
  }

  function syncOperationalEffectsFromApprovedRequests() {
    state.operations ||= { incomeAccounts: [], expenseAccounts: [], entries: [] };
    state.operations.incomeAccounts ||= [];
    state.operations.expenseAccounts ||= [];
    state.operations.entries ||= [];
    const addChargeOperationalEntries = (req, entries) => {
      (entries || []).forEach((entry, entryIndex) => {
        const grossAmount = Number(entry?.amount || 0);
        const chargeBreakdown = normalizeChargePayload(grossAmount, entry);
        if (!chargeBreakdown.length) return;
        const customerAccount = entry?.accountNumber || entry?.customerName || 'customer';
        const traceId = entry?.chargeTraceId || entry?.commissionTraceId || `${req.id || 'approval'}_${entryIndex}`;
        chargeBreakdown.forEach((chargeRow, chargeIndex) => {
          const incomeAccount = getIncomeAccountByName(chargeRow.accountName || chargeRow.label);
          const sourceChargeKey = `${req.id || 'approval'}:${entry?.id || entryIndex}:${chargeRow.key || chargeRow.label || chargeIndex}:${Number(chargeRow.amount || 0)}`;
          if (state.operations.entries.some(e => e.sourceChargeKey === sourceChargeKey)) return;
          state.operations.entries.unshift({
            id: uid('op'),
            kind: 'income',
            accountId: incomeAccount?.id || chargeRow.key || '',
            accountName: incomeAccount?.name || chargeRow.accountName || chargeRow.label || 'Charge Income',
            amount: Number(chargeRow.amount || 0),
            note: cleanOperationalNote(`${chargeRow.label || 'Charge'} from ${customerAccount}`),
            date: `${entry?.date || req.payload?.date || req.payload?.businessDate || today()}T12:00:00.000Z`,
            postedBy: req.requestedByName || staffName(req.requestedBy) || 'System',
            approvedBy: req.approvedBy || req.approvedByName || '',
            traceId,
            sourceTransactionType: req.type,
            sourceApprovalId: req.id,
            sourceChargeKey
          });
        });
      });
    };
    (state.approvals || []).forEach(req => {
      if (!req || req.status !== 'approved') return;
      const p = req.payload || {};
      if (req.type === 'operational_entry') {
        if (state.operations.entries.some(e => e.sourceApprovalId === req.id)) return;
        const amount = Number(p.amount || 0);
        const accountId = String(p.accountId || '').trim();
        if (!accountId || !(amount > 0)) return;
        const account = [...state.operations.incomeAccounts, ...state.operations.expenseAccounts]
          .find(a => String(a.id || '') === accountId);
        if (!account) return;
        const kind = state.operations.incomeAccounts.some(a => String(a.id || '') === accountId) ? 'income' : 'expense';
        state.operations.entries.unshift({
          id: uid('op'),
          kind,
          accountId,
          accountName: p.accountName || account.name,
          amount,
          note: p.note || '',
          date: `${p.date || today()}T12:00:00.000Z`,
          postedBy: req.requestedByName || staffName(req.requestedBy) || 'System',
          approvedBy: req.approvedBy || req.approvedByName || '',
          sourceApprovalId: req.id
        });
      }
      if (req.type === 'customer_credit') addChargeOperationalEntries(req, [p]);
      if (req.type === 'customer_credit_journal') addChargeOperationalEntries(req, Array.isArray(p.rows) ? p.rows : Array.isArray(p.entries) ? p.entries : []);
      if (req.type === 'create_operational_account') {
        const dest = p.category === 'income' ? state.operations.incomeAccounts : state.operations.expenseAccounts;
        if (!Array.isArray(dest)) return;
        const exists = dest.some(a => a.sourceApprovalId === req.id || (String(a.accountNumber || '') === String(p.accountNumber || '') && String(a.name || '').toLowerCase() === String(p.name || '').toLowerCase()));
        if (!exists) dest.push({ id: uid('oa'), name: p.name, accountNumber: p.accountNumber, createdAt: req.approvedAt || new Date().toISOString(), sourceApprovalId: req.id });
      }
    });
  }




  async function syncCodFromGateway(filters = {}) {
    if (!isSupabaseApprovalMode() || !gateway.cod?.listCodSubmissions) return defaultResultOk(state.cod || []);
    const result = await gateway.cod.listCodSubmissions(filters);
    if (result?.ok && Array.isArray(result.data)) {
      const existing = new Map((state.cod || []).map(item => [item.id, item]));
      result.data.forEach(item => {
        const prev = existing.get(item.id) || {};
        const merged = Object.assign({}, prev, item, {
          staffName: staffName(item.staffId) || item.staffName || item.staffId
        });
        // Preserve locally-stored per-mode breakdown fields not stored in Supabase
        ['totalCreditCash','totalCreditTransfer','totalDebitCash','totalDebitTransfer','formAmount'].forEach(key => {
          if (merged[key] == null || merged[key] === 0) {
            if (prev[key] != null && prev[key] !== 0) merged[key] = prev[key];
          }
        });
        existing.set(item.id, merged);
      });
      state.cod = Array.from(existing.values()).sort((a,b)=>new Date(b.submittedAt||b.resolvedAt||b.date)-new Date(a.submittedAt||a.resolvedAt||a.date));
      reconcileBusinessDateFromClosures();
      save();
    }
    return result;
  }

  async function syncDebtBalancesFromGateway(staffId) {
    if (!isSupabaseApprovalMode() || !gateway.cod?.listDebts) return defaultResultOk(null);
    const result = await gateway.cod.listDebts(staffId ? { staffId } : {});
    if (result?.ok && Array.isArray(result.data)) {
      const grouped = {};
      result.data.forEach(d => {
        grouped[d.staffId] = (grouped[d.staffId] || 0) + Number(d.amount || 0);
      });
      (state.staff || []).forEach(st => {
        const acc = ensureStaffAccount(st.id);
        acc.debtBalance = Number(grouped[st.id] || 0);
      });
      save();
    }
    return result;
  }

  async function syncStaffFromGateway(filters = {}) {
    if (!isSupabaseApprovalMode() || !gateway.staff?.listStaff) return defaultResultOk(state.staff || []);
    const result = await gateway.staff.listStaff(filters);
    if (result?.ok && Array.isArray(result.data) && result.data.length) {
      // In Supabase mode, staff is the authoritative source — replace local state entirely.
      // Do NOT merge with seed staff (st1/st2/st3/st4) — those are demo-only.
      const supabaseIds = new Set(result.data.map(item => item.id));
      const preserveLocal = (state.staff || []).filter(st =>
        // Keep local staff only if they came from Supabase (have a UUID-like id)
        // and are not in the result (may be inactive/filtered). Drop seed staff (st1 etc).
        supabaseIds.has(st.id) || (st.uuid && st.uuid !== st.id && !st.id.startsWith('st'))
      );
      const existing = new Map(preserveLocal.map(st => [st.id, st]));
      result.data.forEach(item => {
        existing.set(item.id, Object.assign({}, existing.get(item.id) || {}, {
          id: item.id,
          name: item.fullName || item.name || item.staffId || '',
          role: item.roleCode || item.role || UNASSIGNED_ROLE,
          active: item.isActive !== false,
          staffId: item.staffId || item.staff_code || '',
          branchId: item.branchId || null,
          uuid: item.uuid || item.id || '',
          authUserId: item.authUserId || item.auth_user_id || '',
          auth_user_id: item.authUserId || item.auth_user_id || '',
        }));
      });
      state.staff = Array.from(existing.values());
      normalizeStaffWalletAccounts();
      syncAllStaffWallets();
      save();
    }
    await syncExtraRolesFromGateway();
    await syncRoleAssignmentsFromGateway();
    return result;
  }
  // Extra roles live in their own small table so a person's main role (and everything the
  // database checks on it) is untouched. If the table isn't there yet, nobody gets extras.
  async function syncExtraRolesFromGateway() {
    if (!isSupabaseApprovalMode() || !gateway.adminx?.listExtraRoles) return;
    const res = await gateway.adminx.listExtraRoles();
    if (!res?.ok) return;
    const map = {};
    (res.data || []).forEach(r => { (map[String(r.staff_id)] ||= []).push(r.role_code); });
    let changed = false;
    (state.staff || []).forEach(st => {
      const next = (map[String(st.id)] || []).slice().sort();
      if (JSON.stringify(next) !== JSON.stringify((st.extraRoles || []).slice().sort())) { st.extraRoles = next; changed = true; }
    });
    if (changed) save();
  }

  function openExtraRolesModal(staffId) {
    const st = (state.staff || []).find(x => x.id === staffId);
    if (!st) return showToast('Staff not found');
    if (!isAdminStaff()) return showToast('Only an Administrative Officer can change roles');
    const name = st.name || st.full_name || '';
    const main = staffRoleCode(st);
    const current = new Set(staffExtraRoleCodes(st));
    const boxes = ASSIGNABLE_ROLE_KEYS.filter(k => k !== main).map(k => `<label style="display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;width:100%;margin:0;padding:8px 4px;text-align:left;font-size:14px;cursor:pointer;border-bottom:1px solid rgba(0,0,0,.08)"><input type="checkbox" data-extra-role="${k}" ${current.has(k) ? 'checked' : ''} style="width:18px;height:18px;min-width:18px;max-width:18px;flex:0 0 18px;margin:0;padding:0;appearance:auto;-webkit-appearance:checkbox"><span style="flex:1;text-align:left">${escapeHtml(ROLE_LABELS[k])}</span></label>`).join('');
    openModal('Additional Roles', `
      <p style="margin:0 0 10px"><strong>${escapeHtml(name)}</strong><br><span style="font-size:0.85em;color:var(--text-muted)">Main role: ${escapeHtml(roleLabelOf(main))}</span></p>
      <div class="note" style="margin-bottom:8px">${escapeHtml(name)} can use everything each ticked role allows, on top of the main role. Change the main role with Assign Role.</div>
      ${main === UNASSIGNED_ROLE ? '<div class="note" style="border-left-color:#c00000 !important">Give this person a main role first.</div>' : boxes}
    `, [
      { label: 'Cancel', className: 'secondary', onClick: closeModal },
      { label: 'Save Roles', onClick: async () => {
        if (main === UNASSIGNED_ROLE) return showToast('Assign a main role first');
        const picked = qq('[data-extra-role]').filter(el => el.checked).map(el => el.dataset.extraRole);
        const actor = currentStaff();
        const btn = document.querySelector('.modal-actions button:last-child');
        if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
        try {
          if (isSupabaseApprovalMode()) {
            const res = await gateway.adminx?.setExtraRoles?.(st.id, picked, actor?.name || '');
            if (!res?.ok) {
              showToast(res?.error?.code === 'TABLE_MISSING' ? 'Run the staff-extra-roles SQL script in Supabase first' : `Error: ${res?.error?.message || 'Could not save roles'}`);
              if (btn) { btn.disabled = false; btn.textContent = 'Save Roles'; }
              return;
            }
          }
          const before = staffRoleLabels(st);
          st.extraRoles = picked;
          save();
          pushAudit('staff_extra_roles_changed', `${name}: ${before} → ${staffRoleLabels(st)}`);
          closeModal(); render();
          showToast(`✓ ${name}: ${staffRoleLabels(st)}`);
        } catch (_e) {
          showToast('Unexpected error saving roles');
          if (btn) { btn.disabled = false; btn.textContent = 'Save Roles'; }
        }
      } }
    ]);
  }

  const nonWalletCustomers = () => (state.customers || []).filter(c => c.accountType !== 'staff_wallet');
  async function syncCustomersDelta() {
    const mark = state.__sync?.customers;
    if (!syncSupported.customers || !mark?.cursor || syncStale(mark) || !mark?.txCursor || !nonWalletCustomers().length || !gateway.sync?.changedSince) return null;
    const [allC, allT] = await Promise.all([syncChangedSince('customers', mark.cursor), syncChangedSince('transactions', mark.txCursor)]);
    if (!allC || !allT || allC.length >= 1000 || allT.length >= 1000) return null;
    const changedC = allC.filter(isUnseen(mark.recent));
    const changedT = allT.filter(isUnseen(mark.txRecent));
    const ids = [...new Set([...changedC.map(r => String(r.id)), ...changedT.map(r => String(r.customer_id))])];
    if (ids.length > SYNC_MAX_DELTA) return null;
    const [snapC, snapT] = await Promise.all([takeSyncSnapshot('customers'), takeSyncSnapshot('transactions')]);
    if (!snapC || !snapT) return null;
    // Transactions are insert-only: the count must grow by exactly the
    // rows that are new since the last sync, or something was missed.
    if (snapT.count !== mark.txCount + changedT.length) return null;
    const [digC, digT] = await Promise.all([syncDigestCheck('customers', mark.digest), syncDigestCheck('transactions', mark.txDigest)]);
    if (!digC.ok || !digT.ok) return null;
    if (ids.length) {
      // Fix B 2026-10-22 (egress): a changed customer row refreshes just its
      // details; new transactions are fetched by id and appended. (This used
      // to re-download each touched customer's whole history.)
      const custIds = [...new Set(changedC.map(r => String(r.id)))];
      const txIds = [...new Set(changedT.map(r => String(r.id)))];
      const [custRes, txRes] = await Promise.all([
        custIds.length ? gateway.history.customersByIds(custIds) : Promise.resolve({ ok: true, data: [] }),
        txIds.length ? gateway.history.transactionsByIds(txIds) : Promise.resolve({ ok: true, data: [] }),
      ]);
      if (!custRes?.ok || !txRes?.ok) return null;
      const byId = new Map((state.customers || []).map(c => [String(c.id), c]));
      custRes.data.map(normalizeGatewayCustomerForState).filter(Boolean).forEach(c => {
        const prev = byId.get(String(c.id));
        byId.set(String(c.id), { ...(prev || {}), ...c, transactions: prev?.transactions || [] });
      });
      for (const { customerId, tx } of txRes.data) {
        const c = byId.get(String(customerId));
        if (!c) return null;
        c.transactions ||= [];
        if (!c.transactions.some(t => String(t.id) === String(tx.id))) c.transactions.push(tx);
      }
      state.customers = [...byId.values()];
    }
    if (nonWalletCustomers().length !== snapC.count) return null;
    if (ids.length) {
      normalizeStaffWalletAccounts();
      syncAllStaffWallets();
      recalcAllCustomerBalances();
      recalcAllTellerBalances();
    }
    const cursor = syncMaxTs(mark.cursor, allC), txCursor = syncMaxTs(mark.txCursor, allT);
    setSyncMark('customers', { cursor, txCursor, fullAt: mark.fullAt, digest: (digC.next && digT.next) ? digC.next : undefined, txDigest: digT.next || undefined, count: snapC.count, txCount: snapT.count,
      recent: syncRecent(cursor, [...recentRows(mark.recent), ...allC]), txRecent: syncRecent(txCursor, [...recentRows(mark.txRecent), ...allT]) });
    save();
    return defaultResultOk(state.customers);
  }

  async function syncCustomersListFromGatewayOnce(filters = {}) {
    if (!isSupabaseApprovalMode() || !gateway.customers?.listCustomers) return defaultResultOk(state.customers || []);
    const wholeList = !filters || !Object.keys(filters).length;
    if (wholeList) {
      await bulkReady;
      const delta = await syncCustomersDelta();
      if (delta) return delta;
    }
    const snaps = wholeList && syncSupported.customers ? await Promise.all([takeSyncSnapshot('customers'), takeSyncSnapshot('transactions')]) : [null, null];
    let result = null;
    if (wholeList && historyActive() && historyTxFrom() !== HISTORY_ALL) {
      const hw = await getHistoryWindow(historyCoveredFrom());
      const recentTx = hw ? await gateway.history.transactions(hw.from) : null;
      if (recentTx?.ok) {
        result = await gateway.history.customers([...hw.transactions, ...recentTx.data]);
        if (result?.ok) setHistory({ txFrom: hw.from });
      } else if (recentTx?.error?.code === 'HISTORY_UNSUPPORTED') historySupported = false;
    }
    if (!result?.ok) {
      result = await gateway.customers.listCustomers(filters);
      if (wholeList && result?.ok) setHistory({ txFrom: HISTORY_ALL });
    }
    if (result?.ok && Array.isArray(result.data)) {
      // Replace customers entirely from Supabase — drop seed customers (c1, c2 etc)
      const incoming = result.data.map(normalizeGatewayCustomerForState).filter(Boolean);
      // Preserve any locally-created staff_wallet customers (they're not in Supabase)
      // 2026-10-26: drop wallets of staff who no longer exist (removed/wiped staff left ghost wallets in the browser).
      const liveStaffIds = new Set((state.staff || []).map(st => st.id));
      const staffWallets = (state.customers || []).filter(c => c.accountType === 'staff_wallet' && (!liveStaffIds.size || liveStaffIds.has(c.staffId)));
      state.customers = incoming;
      // Re-add staff wallets that aren't already in incoming
      const incomingIds = new Set(incoming.map(c => c.id));
      staffWallets.forEach(w => { if (!incomingIds.has(w.id)) state.customers.push(w); });
      if (wholeList) {
        const [snapC, snapT] = snaps;
        const [winC, winT] = snapC && snapT ? await Promise.all([syncChangedSince('customers', snapC.cursor), syncChangedSince('transactions', snapT.cursor)]) : [null, null];
        const [digC, digT] = winC && winT ? await Promise.all([syncDigestCheck('customers', null), syncDigestCheck('transactions', null)]) : [{}, {}];
        setSyncMark('customers', winC && winT && { cursor: snapC.cursor, txCursor: snapT.cursor, fullAt: new Date().toISOString(), digest: (digC.next && digT.next) ? digC.next : undefined, txDigest: digT.next || undefined, count: snapC.count, txCount: snapT.count, recent: syncRecent(snapC.cursor, winC), txRecent: syncRecent(snapT.cursor, winT) });
      }
      normalizeStaffWalletAccounts();
      syncAllStaffWallets();
      recalcAllCustomerBalances();
      recalcAllTellerBalances();
      save();
    }
    return result;
  }

  async function syncAuditFromGateway(filters = {}) {
    if (!isSupabaseApprovalMode() || !gateway.audit?.listAuditLog) {
      return;
    }
    const result = await gateway.audit.listAuditLog(filters);
    if (result?.ok && Array.isArray(result.data)) {
      state.audit = result.data;
      save();
    }
  }

  async function syncAllSharedStateFromGateway() {
    await syncStaffFromGateway();
    await syncCustomersListFromGateway();
    await syncApprovalsFromGateway();
    await syncCodFromGateway();
    await syncDebtBalancesFromGateway();
    safeRender();
  }

  async function refreshRealtimeState(reason = 'realtime') {
    if (!isSupabaseApprovalMode()) return defaultResultOk(false);
    if (realtimeRefreshInFlight) {
      realtimeRefreshQueued = true;
      return defaultResultOk('queued');
    }
    realtimeRefreshInFlight = true;
    try {
      await syncStaffFromGateway();
      await syncCustomersListFromGateway();
      await syncApprovalsFromGateway();
      await syncCodFromGateway();
      await syncDebtBalancesFromGateway();
      await syncAuditFromGateway();
      state.__lastRealtimeRefresh = { reason, at: new Date().toISOString() };
      save();
      safeRender();
      return defaultResultOk(true);
    } finally {
      realtimeRefreshInFlight = false;
      if (realtimeRefreshQueued) {
        realtimeRefreshQueued = false;
        setTimeout(() => refreshRealtimeState('queued').catch(err => console.warn('[DUCESS realtime sync failed]', err)), 80);
      }
    }
  }

  function debounce(fn, wait = 200) {
    let t;
    return function(...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function debounceAsync(fn, wait = 250) {
    let timer = null;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args).catch(err => console.warn('[DUCESS realtime sync failed]', err)), wait);
    };
  }

  function setupRealtimeSubscriptions() {
    if (!isSupabaseApprovalMode() || !gateway.__realtime?.subscribe || realtimeBound) return;
    // SURGICAL FIX 2026-09-30 (Supabase egress): approvals are now loaded
    // in FULL (see syncApprovalsFromGateway), so re-downloading the whole
    // list on every single approval change would grow with the business.
    // A realtime approval event now fetches only the changed request(s)
    // (light view, by id) and merges them in; the full list still loads on
    // login, tab return and the idle safety-net refresh.
    const changedApprovalIds = new Set();
    const removedApprovalIds = new Set();
    const flushApprovalChanges = debounceAsync(async () => {
      const ids = [...changedApprovalIds]; const removed = [...removedApprovalIds];
      changedApprovalIds.clear(); removedApprovalIds.clear();
      if (!ids.length && !removed.length) return;
      if (!state.approvals?.length) { await syncApprovalsFromGateway(); scheduleRender(); return; }
      let fresh = [];
      if (ids.length) {
        const res = await gateway.approvals.listApprovalRequests({ ids });
        if (!res?.ok || !Array.isArray(res.data)) { await syncApprovalsFromGateway(); scheduleRender(); return; }
        fresh = res.data;
      }
      if (!mergeApprovalRows(fresh, removed)) { await syncApprovalsFromGateway(); scheduleRender(); return; }
      syncStaffBusinessEffectsFromApprovedRequests();
      syncOperationalEffectsFromApprovedRequests();
      reconcileBusinessDateFromClosures();
      save();
      scheduleRender();
    }, 120);
    const refreshApprovals = (payload) => {
      const newId = payload?.new?.id; const oldId = payload?.old?.id;
      if (payload?.eventType === 'DELETE' && oldId) removedApprovalIds.add(String(oldId));
      else if (newId) changedApprovalIds.add(String(newId));
      else { syncApprovalsFromGateway().then(scheduleRender).catch(err => console.warn('[DUCESS realtime sync failed]', err)); return; }
      flushApprovalChanges();
    };
    const refreshCod = debounceAsync(async () => { await syncCodFromGateway(); await syncDebtBalancesFromGateway(); scheduleRender(); }, 120);
    const refreshBalances = debounceAsync(async (payload) => {
      const row = payload?.new || payload?.old || {};
      if (row.customer_id) await syncCustomerFromGateway({ customerId: row.customer_id });
      else if (row.account_id && gateway.accounts?.getAccountSummary) {
        const acct = await gateway.accounts.getAccountSummary(row.account_id);
        if (acct?.ok && acct.data?.accountNumber) await syncCustomerFromGateway({ accountNumber: acct.data.accountNumber });
        else await syncCustomersListFromGateway();
      } else {
        await syncCustomersListFromGateway();
      }
      await syncCodFromGateway();
      await syncDebtBalancesFromGateway();
      safeRender();
    }, 120);
    const refreshCustomers = debounceAsync(async () => { await syncCustomersListFromGateway(); scheduleRender(); }, 160);
    const refreshStaff = debounceAsync(async () => { await syncStaffFromGateway(); scheduleRender(); }, 160);
    realtimeUnsub = gateway.__realtime.subscribe({
      approval: refreshApprovals,
      cod: refreshCod,
      debt: refreshCod,
      balance: refreshBalances,
      customer: refreshCustomers,
      staff: refreshStaff,
      // SURGICAL FIX 2026-09-29 (Supabase egress): every change used to ALSO
      // run a full six-query refresh on every open screen, on top of the
      // targeted handler above for that table — double the reads per event.
      // Each table kind already has its own targeted refresh, so an event
      // now only marks live data as fresh (keeps the fallback poll quiet).
      onEvent: () => { state.__lastRealtimeRefresh = { reason: 'realtime-event', at: new Date().toISOString() }; },
      onStatus: (status) => { state.__realtimeStatus = status; save(); }
    });
    // SURGICAL FIX 2026-09-29 (Supabase egress): returning to the tab fires
    // BOTH 'focus' and 'visibilitychange', which ran two full refreshes back
    // to back. One shared handler now, skipped if data was refreshed in the
    // last 20s.
    const refreshOnReturn = (reason) => {
      const lastAt = state.__lastRealtimeRefresh?.at ? new Date(state.__lastRealtimeRefresh.at).getTime() : 0;
      if (Date.now() - lastAt < 20000) return;
      refreshRealtimeState(reason).catch(err => console.warn('[DUCESS realtime sync failed]', err));
    };
    window.addEventListener('focus', () => refreshOnReturn('window-focus'));
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshOnReturn('visibility-return');
    });
    // SURGICAL FIX 2026-08-22 (Supabase egress overage — org hit 141% of
    // free-tier quota, grace period ends Sep 20 2026): this was labeled a
    // "fallback" but ran completely unconditionally — every 8 seconds, on
    // every open tab, regardless of whether the realtime websocket
    // subscription above was already connected and delivering updates live.
    // state.__realtimeStatus IS already tracked (via onStatus above) but was
    // never actually checked here. Each tick runs 6 full-table queries
    // (refreshRealtimeState), so an 8-hour shift with one tab open was
    // ~450 ticks/hour x 6 queries — the single largest contributor to the
    // overage. Now: (1) only polls when realtime is NOT confirmed connected
    // — a true fallback, not a duplicate channel; (2) interval stretched
    // from 8s to 45s, since its only job is catching a dropped/missed
    // realtime event, not driving routine updates.
    //
    // ROBUSTNESS ADDITION (same date, deeper pass): onStatus only reflects
    // the websocket CHANNEL connecting — it does NOT confirm Postgres
    // replication is actually delivering row-change events for these
    // tables (that depends on the tables being added to the
    // supabase_realtime publication, a separate DB-level config). If that
    // publication were ever missing/misconfigured, the channel could
    // legitimately report 'SUBSCRIBED' while zero events ever arrive —
    // and with the gate above alone, that would silently suppress polling
    // forever, leaving the UI permanently stale with NO fallback, which is
    // worse than the original bug. So the gate now also force-polls if
    // it's been more than STALE_DATA_MS since the last successful refresh
    // of ANY kind (poll, realtime event, or focus/visibility trigger — all
    // already update state.__lastRealtimeRefresh), regardless of what the
    // channel status claims. This makes the poll self-healing: cheap when
    // realtime genuinely works, but never silently stuck if it doesn't.
    // SURGICAL FIX 2026-09-29 (Supabase egress): 90s meant a quiet office
    // with a healthy realtime connection still did a full refresh roughly
    // every 90s per open tab. 5 minutes keeps the self-healing safety net
    // while cutting idle reads ~70%. When realtime is NOT connected, the
    // 45s fallback below still applies as before.
    const STALE_DATA_MS = 300000;
    // SURGICAL ADDITION 2026-09-30 (client: Cash Received didn't move after
    // approval): while THIS user has requests awaiting approval, check just
    // those few rows every 20s (tiny query, visible tab only) and do a full
    // refresh the moment any of them is approved/rejected — so the Till
    // box updates promptly even if the realtime channel misses the event.
    if (!pendingWatchTimer) {
      pendingWatchTimer = setInterval(async () => {
        if (document.hidden || realtimeRefreshInFlight) return;
        const me = currentStaff();
        if (!me) return;
        const mine = (state.approvals || []).filter(r => r.status === 'pending' && (r.payload?.staffId === me.id || r.requestedBy === me.id || r.requestedByStaffId === getStaffBackendId(me)));
        if (!mine.length) return;
        try {
          const res = await gateway.approvals.listApprovalRequests({ ids: mine.map(r => r.id) });
          if (res?.ok && Array.isArray(res.data) && res.data.some(r => r.status !== 'pending')) {
            await refreshRealtimeState('pending-decided');
          }
        } catch (err) { console.warn('[DUCESS pending check failed]', err); }
      }, 20000);
    }
    if (!realtimePollingTimer) {
      realtimePollingTimer = setInterval(() => {
        const lastAt = state.__lastRealtimeRefresh?.at ? new Date(state.__lastRealtimeRefresh.at).getTime() : 0;
        const isStale = (Date.now() - lastAt) > STALE_DATA_MS;
        if (!document.hidden && (state.__realtimeStatus !== 'SUBSCRIBED' || isStale)) {
          refreshRealtimeState('polling-fallback').catch(err => console.warn('[DUCESS realtime polling failed]', err));
        }
      }, 45000);
    }
    realtimeBound = true;
  }

  function normalizeGatewayCustomerForState(customer) {
    if (!customer) return null;
    return {
      id: customer.id,
      accountNumber: String(customer.accountNumber || ''),
      oldAccountNumber: customer.oldAccountNumber || '',
      name: customer.name || customer.fullName || '',
      address: customer.address || '',
      nin: customer.nin || '',
      bvn: customer.bvn || '',
      phone: customer.phone || '',
      balance: Number(customer.balance ?? customer.bookBalance ?? 0),
      photo: customer.photo || '',
      active: typeof customer.active === 'boolean' ? customer.active : String(customer.status || 'active').toLowerCase() === 'active',
      // 2026-10-21: Account Block sets status 'frozen'; Account Closure sets
      // 'closed' (customer removed from service, records kept).
      frozen: String(customer.accountStatus || '').toLowerCase() === 'frozen',
      closed: String(customer.accountStatus || '').toLowerCase() === 'closed',
      accountStatus: String(customer.accountStatus || '').toLowerCase(),
      createdAt: customer.createdAt || customer.created_at || new Date().toISOString(),
      transactions: Array.isArray(customer.transactions) ? customer.transactions : [],
      // SURGICAL FIX 2026-09-08 (root cause found via client screenshot):
      // the gateway sends both .linkedStaffId and .staffId on each customer
      // (same value, see normalizeCustomerSummary in the gateway), but this
      // function only ever kept it under .staffId when building the
      // frontend's state.customers record. Every consumer written for the
      // Treasury/Admin operational-account features — getStaffOperational-
      // Breakdown, Cash Receipt, Fund Account's target-role detection, the
      // Staff Directory Op. Account column, all of it — checks
      // `c.linkedStaffId`, which was always undefined as a result. This is
      // why Cash Receipt has never worked for anyone and Fund Account never
      // correctly told Teller and Treasury targets apart. Kept .staffId too
      // in case anything else already depends on that name.
      staffId: customer.linkedStaffId || customer.staffId || null,
      linkedStaffId: customer.linkedStaffId || customer.staffId || null,
      accountType: customer.accountType || 'customer'
    };
  }

  async function syncCustomerFromGateway(ref = {}) {
    if (!isSupabaseApprovalMode() || !gateway.customers) return defaultResultOk(null);
    let result = null;
    if (ref.customerId && gateway.customers.getCustomerById) result = await gateway.customers.getCustomerById(ref.customerId);
    else if (ref.accountNumber && gateway.customers.getCustomerByAccountNumber) result = await gateway.customers.getCustomerByAccountNumber(ref.accountNumber);
    if (!result?.ok || !result.data) return result || defaultResultOk(null);
    const normalized = normalizeGatewayCustomerForState(result.data);
    if (!normalized) return defaultResultOk(null);
    const idx = state.customers.findIndex(c => c.id === normalized.id || c.accountNumber === normalized.accountNumber);
    if (idx >= 0) state.customers[idx] = { ...state.customers[idx], ...normalized };
    else state.customers.unshift(normalized);
    save();
    return defaultResultOk(normalized);
  }

  async function syncApprovalEffectsFromGateway(approvalRecord) {
  if (!approvalRecord?.type) return defaultResultOk(null);

  // Enrich approvalRecord.payload from local state when the gateway returns a
  // minimal record (e.g. after RPC approval). This ensures accountType is present.
  const localApproval = (state.approvals || []).find(r => r.id === approvalRecord.id);
  const enrichedPayload = Object.assign({}, localApproval?.payload || {}, approvalRecord.payload || {});

  if (approvalRecord.type === 'account_opening') {
    return syncCustomersListFromGateway();
  }

  if (['account_maintenance','account_reactivation','account_block','account_closure'].includes(approvalRecord.type)) {
    return syncCustomerFromGateway({ customerId: enrichedPayload.customerId, accountNumber: enrichedPayload.accountNumber });
  }

  if (approvalRecord.type === 'customer_credit' || approvalRecord.type === 'customer_debit') {
    if (enrichedPayload.accountType === 'staff' || enrichedPayload.accountType === 'staff_wallet') {
      // Staff wallet balances are maintained locally only. Apply the request directly
      // so the local balance updates — in Supabase mode applyRequest is not called
      // from approveRequestRemote, so without this the staff wallet never gets the transaction.
      const localReq = (state.approvals || []).find(r => r.id === approvalRecord.id);
      if (localReq) {
        localReq.status = 'approved';
        applyRequest(localReq);
      }
      return defaultResultOk(null);
    }
    return syncCustomerFromGateway({
      customerId: enrichedPayload.customerId,
      accountNumber: enrichedPayload.accountNumber
    });
  }

  if (approvalRecord.type === 'customer_credit_journal' || approvalRecord.type === 'customer_debit_journal') {
    const rows = Array.isArray(enrichedPayload.rows) ? enrichedPayload.rows : [];
    const hasStaffRow = rows.some(r => r.accountType === 'staff' || r.accountType === 'staff_wallet');
    if (hasStaffRow) {
      // Journal contains staff account rows — apply locally so all balances update.
      const localReq = (state.approvals || []).find(r => r.id === approvalRecord.id);
      if (localReq) {
        localReq.status = 'approved';
        applyRequest(localReq);
      }
      // Also sync any non-staff rows from Supabase
      for (const row of rows) {
        if (row.accountType === 'staff' || row.accountType === 'staff_wallet') continue;
        await syncCustomerFromGateway({ customerId: row.customerId, accountNumber: row.accountNumber });
      }
      return defaultResultOk(true);
    }
    for (const row of rows) {
      await syncCustomerFromGateway({ customerId: row.customerId, accountNumber: row.accountNumber });
    }
    return defaultResultOk(true);
  }

  if (approvalRecord.type === 'float_declaration') {
  syncApprovedFormFromApprovalRecord(approvalRecord);
  await syncCodFromGateway({
    staffId: approvalRecord.payload?.staffId,
    businessDate: approvalRecord.payload?.date
  });
  save();
  return defaultResultOk(true);
}

if (approvalRecord.type === 'float_topup') {
  return defaultResultOk(true);
}

  if (approvalRecord.type === 'wallet_fund' || (approvalRecord.type === 'debt_repayment' && enrichedPayload.source === 'my_balance')) {
    const localReq = (state.approvals || []).find(r => r.id === approvalRecord.id);
    if (localReq) {
      localReq.status = 'approved';
      localReq.approvedBy = approvalRecord.approvedBy || approvalRecord.approvedByName || localReq.approvedBy;
      localReq.approvedAt = approvalRecord.approvedAt || localReq.approvedAt || new Date().toISOString();
      applyRequest(localReq);
      save();
    }
    return defaultResultOk(true);
  }

  if (approvalRecord.type === 'debt_repayment') {
    return syncDebtBalancesFromGateway();
  }

  // 2026-10-24: Treasury accounts are business accounts with real
  // transactions — refresh the business-account side of these postings.
  if (approvalRecord.type === 'cash_receipt' || approvalRecord.type === 'inter_staff_credit') {
    const ids = approvalRecord.type === 'cash_receipt'
      ? [enrichedPayload.treasuryAccountId]
      : [enrichedPayload.sourceAccountId, enrichedPayload.targetAccountId];
    for (const id of ids.filter(Boolean)) {
      const c = (state.customers || []).find(x => x.id === id);
      if (c && c.accountType !== 'staff_operational') await syncCustomerFromGateway({ customerId: c.id, accountNumber: c.accountNumber });
    }
    return defaultResultOk(true);
  }

  return defaultResultOk(null);
}

  // A request sent to a particular approving officer is visible/actionable only to that
  // officer (and Admin). Everyone else with approval access is "routed away" from it.
  function isApprovalRoutedAway(req, viewer = currentStaff()) {
    if (!viewer || staffHasRole(viewer, 'admin_officer')) return false;
    const assignedTo = req?.payload?.assignedApproverId;
    return !!(assignedTo && assignedTo !== viewer.id);
  }

  function activeApprovingOfficers() {
    return (state.staff || []).filter(s => staffHasRole(s, 'approving_officer') && s.active !== false && s.is_active !== false);
  }

  function promptForApprovingOfficer() {
    const officers = activeApprovingOfficers();
    if (!officers.length) return Promise.resolve(null); // nobody to route to — admin-only fallback, no prompt needed
    return new Promise((resolve) => {
      openModal('Send to Approving Officer', `
        <p style="margin:0 0 10px;font-size:0.85em;color:var(--text-muted)">Choose who should approve this request. Only they — or an Administrative Officer — will be able to act on it.</p>
        <div class="field"><label>Approving Officer <span style="color:red">*</span></label>
          <select id="approverPickerSelect" class="entry-input">
            ${officers.map(o => `<option value="${o.id}">${escapeHtml(o.name || o.full_name || 'Officer')}</option>`).join('')}
          </select>
        </div>
      `, [
        {label:'Cancel', className:'secondary', onClick: () => { closeModal(); resolve(null); }},
        {label:'Send for Approval', onClick: () => {
          const select = byId('approverPickerSelect');
          const officer = officers.find(o => o.id === select?.value);
          closeModal();
          resolve(officer ? { id: officer.id, name: officer.name || officer.full_name || 'Officer' } : null);
        }}
      ]);
    });
  }

  async function submitApprovalThroughGateway(type, payload, meta = {}) {
    // Customer Service tools are re-checked at submit time, not just by greying out buttons.
    if (['account_opening', 'account_maintenance', 'account_reactivation'].includes(type) && !hasPermission(type)) {
      return defaultResultErr('NO_PERMISSION', 'You do not have permission to use this tool.');
    }
    reconcileBusinessDateFromClosures();
    const requestDate = approvalBusinessDate(type, payload);
    if (shouldLockApprovalType(type) && isBusinessDateClosed(requestDate)) {
      return defaultResultErr('BUSINESS_DATE_CLOSED', businessDateClosedMessage(requestDate));
    }
    // SURGICAL PATCH 2026-08-12b: promptForApprovingOfficer() opens a modal
    // (.modal-back, z-index 9999) to let the user pick an officer. But every
    // caller shows the global processing overlay (.processing-overlay,
    // z-index 10100) BEFORE calling this function, so the overlay sits on top
    // of the officer-picker modal and silently blocks all clicks on it —
    // the "Send for Approval" button becomes unclickable and the request
    // hangs forever on "Sending request...". Hide the overlay while the
    // picker modal is open, then restore it (with its original label) once
    // an officer has been chosen, before the network call proceeds.
    const _processingOverlayEl = byId('globalProcessingOverlay');
    const _wasProcessingVisible = !!(_processingOverlayEl && !_processingOverlayEl.classList.contains('hidden'));
    const _processingLabelText = _wasProcessingVisible ? (byId('processingText')?.textContent || 'Processing...') : '';
    if (_wasProcessingVisible) hideProcessing();
    const approver = await promptForApprovingOfficer();
    if (_wasProcessingVisible) { showProcessing(_processingLabelText); await nextPaint(); }
    if (activeApprovingOfficers().length && !approver) {
      return defaultResultErr('APPROVER_REQUIRED', 'Choose an approving officer to send this request to.');
    }
    if (approver) {
      payload = { ...payload, assignedApproverId: approver.id, assignedApproverName: approver.name };
    }
    // Role/staff separation: record the role the requester held when they
    // submitted this (the request stays tied to the staff member regardless).
    payload = { ...payload, submittedByRole: staffRoleCode(currentStaff()) };
    if (!isSupabaseApprovalMode()) return defaultResultOk(createRequest(type, payload, meta));
    const staff = currentStaff();
    let result;
    // SURGICAL PATCH 2026-08-12: the actual network call is made inside this IIFE so
    // it can be raced against a hard deadline via withRequestTimeout — see below.
    try {
      result = await withRequestTimeout((async () => {
        if (type === 'account_opening' && gateway.customers?.submitAccountOpening) {
          return await gateway.customers.submitAccountOpening({
  ...payload,
  fullName: payload.name,
  phone: payload.phone,
  address: payload.address,
  nin: payload.nin,
  bvn: payload.bvn,
  oldAccountNumber: payload.oldAccountNumber || '',
  generatedAccountNumber: payload.generatedAccountNumber || '',
  photo: payload.photo || null,
  photoRef: payload.photo || null,
  openedByStaffId: getStaffBackendId(staff),
  requestedByName: staff?.name || 'System'
});

        } else if (type === 'account_maintenance' && gateway.customers?.submitAccountMaintenance) {
          return await gateway.customers.submitAccountMaintenance({
            customerId: payload.customerId,
            updates: { ...payload.patch },
            requestedByStaffId: getStaffBackendId(staff),
            requestedByName: staff?.name || 'System'
          });
        } else if (type === 'account_reactivation' && gateway.customers?.submitAccountReactivation) {
          return await gateway.customers.submitAccountReactivation({
            customerId: payload.customerId,
            requestedByStaffId: getStaffBackendId(staff),
            note: payload.note || '',
            requestedByName: staff?.name || 'System'
          });
        } else if ((type === 'customer_credit' || type === 'customer_debit') && gateway.accounts && payload.accountType !== 'staff' && payload.accountType !== 'staff_wallet') {
          const fn = type === 'customer_credit' ? gateway.accounts.submitCredit : gateway.accounts.submitDebit;
          return await fn({
            accountId: payload.customerId,
            accountType: payload.accountType || 'customer',
            staffAccountId: payload.staffAccountId || '',
            staffAccountUuid: payload.staffAccountUuid || '',
            amount: Number(payload.amount || 0),
            details: payload.details || '',
            requestedByStaffId: getStaffBackendId(staff),
            businessDate: payload.date,
            requestedByName: staff?.name || 'System',
            customerId: payload.customerId, customerName: payload.customerName, accountNumber: payload.accountNumber, receivedOrPaidBy: payload.receivedOrPaidBy, payoutSource: payload.payoutSource, paymentMode: payload.paymentMode, staffId: payload.staffId, date: payload.date, customerCreditAmount: payload.customerCreditAmount, chargeBreakdown: payload.chargeBreakdown, totalChargeAmount: payload.totalChargeAmount, commissionAmount: payload.commissionAmount, chargeTraceId: payload.chargeTraceId || payload.commissionTraceId, commissionTraceId: payload.commissionTraceId
          });
        } else if ((type === 'customer_credit_journal' || type === 'customer_debit_journal') && gateway.accounts?.submitJournalEntries && !(payload.rows || []).some(row => row.accountType === 'staff' || row.accountType === 'staff_wallet')) {
          return await gateway.accounts.submitJournalEntries({
            entries: (payload.rows || []).map(row => ({ accountId: row.accountType === 'staff' ? (row.staffAccountUuid || row.staffAccountId || row.accountNumber || row.customerId) : row.customerId, accountType: row.accountType || 'customer', staffAccountId: row.staffAccountId || '', staffAccountUuid: row.staffAccountUuid || '', txType: type === 'customer_debit_journal' ? 'debit' : 'credit', amount: Number(row.amount || 0), details: row.details || '', customerId: row.customerId, customerName: row.customerName, accountNumber: row.accountNumber, receivedOrPaidBy: row.receivedOrPaidBy, payoutSource: row.payoutSource, paymentMode: row.paymentMode, customerCreditAmount: row.customerCreditAmount, chargeBreakdown: row.chargeBreakdown, totalChargeAmount: row.totalChargeAmount, commissionAmount: row.commissionAmount, chargeTraceId: row.chargeTraceId || row.commissionTraceId, commissionTraceId: row.commissionTraceId })),
            rows: payload.rows || [],
            requestedByStaffId: getStaffBackendId(staff),
            requestedByName: staff?.name || 'System',
            businessDate: payload.date,
            staffId: payload.staffId,
            date: payload.date,
            openingFloat: payload.openingFloat,
            formAmount: Number(payload.formAmount || 0),
            formPaymentMode: payload.formPaymentMode || 'cash',
            fieldNote: payload.fieldNote || null
          });
        } else if (gateway.approvals?.submitApprovalRequest) {
          return await gateway.approvals.submitApprovalRequest({
            requestType: type,
            requestedByStaffId: getStaffBackendId(staff),
            requestedByName: staff?.name || 'System',
            payload
          });
        }
        return undefined;
      })());
    } catch (requestError) {
      return defaultResultErr('REQUEST_TIMEOUT', requestError?.message || 'Request failed. Please check your connection and try again.');
    }
    if (!result?.ok) return result;
    if (result.data) {
      const exists = (state.approvals || []).some(item => item.id === result.data.id);
      if (!exists) state.approvals.unshift(result.data);
      save();
    }
    // Do not block the teller on a full approvals refresh after submit.
    // The request has already been inserted by Supabase; refresh the queue quietly in the background.
    syncApprovalsByIdFromGateway([result.data?.id]).catch(error => console.warn('Background approvals refresh failed after submit', error));
    pushAudit('request_created', `${type} by ${staff?.name || 'System'}</div>`);
    return result;
  }

  async function approveRequestRemote(id, payloadOverride = null) {
    const pendingReq = (state.approvals || []).find(r => r.id === id);
    if (pendingReq && shouldLockApprovalType(pendingReq.type)) {
      const reqDate = approvalBusinessDate(pendingReq.type, pendingReq.payload || {});
      if (isBusinessDateClosed(reqDate)) return defaultResultErr('BUSINESS_DATE_CLOSED', businessDateClosedMessage(reqDate));
    }
    if (!isSupabaseApprovalMode()) { approveRequest(id); return defaultResultOk(true); }
    const staff = currentStaff();

    // SURGICAL PATCH 2026-08-12c: same class of bug as submitApprovalThroughGateway
    // — these gateway calls had no timeout, so a stalled or interrupted connection
    // left "Approving request..." spinning forever with no way to recover. Bound
    // the whole remote approve operation with the same hard deadline used for
    // submissions, so a network interruption always resolves into a clear,
    // recoverable error instead of hanging.
    try {
      return await withRequestTimeout((async () => {
        // Detect staff account transactions before calling the gateway.
        // The gateway's approval flow (RPC or direct posting) tries to fetch
        // the account from Supabase customers table — staff accounts don't
        // exist there. Handle staff approvals entirely in local state.
        const pendingPayload = pendingReq?.payload || {};
        const isStaffDirectTx = (pendingReq?.type === 'customer_credit' || pendingReq?.type === 'customer_debit') &&
          (pendingPayload.accountType === 'staff' || pendingPayload.accountType === 'staff_wallet');
        const isStaffJournalTx = (pendingReq?.type === 'customer_credit_journal' || pendingReq?.type === 'customer_debit_journal') &&
          Array.isArray(pendingPayload.rows) && pendingPayload.rows.length > 0 &&
          pendingPayload.rows.some(r => r.accountType === 'staff' || r.accountType === 'staff_wallet');
        const isMyBalanceRequest = pendingReq?.type === 'wallet_fund' ||
          (pendingReq?.type === 'debt_repayment' && pendingPayload.source === 'my_balance');

        if (isStaffDirectTx || isStaffJournalTx || isMyBalanceRequest) {
          // Mark approved in Supabase via a minimal direct update (no posting RPC, no customer/debt-table fetch)
          const markResult = await gateway.approvals.markApprovalApprovedDirect({
            requestId: id,
            approvedByStaffId: getStaffBackendId(staff),
            approvedByName: staff?.name || 'System',
          });
          if (!markResult?.ok) return markResult;
          // Apply locally so balances update
          if (pendingReq) {
            pendingReq.status = 'approved';
            pendingReq.approvedBy = staff?.name || 'System';
            pendingReq.approvedAt = new Date().toISOString();
            applyRequest(pendingReq);
          }
          await syncApprovalsByIdFromGateway([id]);
          syncOperationalEffectsFromApprovedRequests();
          save();
          pushAudit('request_approved', `${pendingReq?.type || 'request'} approved`);
          render();
          return markResult;
        }

        const result = await gateway.approvals.approveRequest({
          requestId: id,
          approvedByStaffId: getStaffBackendId(staff),
          approvedByName: staff?.name || 'System',
          payload: payloadOverride || null
        });
        if (result?.ok) {
          await syncApprovalsByIdFromGateway([id]);
          await syncApprovalEffectsFromGateway(result.data);
          await syncCodFromGateway();
          syncOperationalEffectsFromApprovedRequests();
          save();
          pushAudit('request_approved', `${result.data?.type || 'request'} approved</div>`);
          render();
        }
        return result;
      })());
    } catch (requestError) {
      return defaultResultErr('REQUEST_TIMEOUT', requestError?.message || 'Request failed. Please check your connection and try again.');
    }
  }

  async function rejectRequestRemote(id) {
    if (!isSupabaseApprovalMode()) { rejectRequest(id); return defaultResultOk(true); }
    const staff = currentStaff();
    // SURGICAL PATCH 2026-08-12c: bound with the same hard deadline as approve —
    // see comment above.
    try {
      return await withRequestTimeout((async () => {
        const result = await gateway.approvals.rejectRequest({ requestId: id, rejectedByStaffId: getStaffBackendId(staff), rejectedByName: staff?.name || 'System' });
        if (result?.ok) { await syncApprovalsByIdFromGateway([id]); pushAudit('request_rejected', `${result.data?.type || 'request'} rejected</div>`); render(); }
        return result;
      })());
    } catch (requestError) {
      return defaultResultErr('REQUEST_TIMEOUT', requestError?.message || 'Request failed. Please check your connection and try again.');
    }
  }

  function defaultResultOk(data) { return { ok: true, data }; }
  function defaultResultErr(code, message) { return { ok: false, error: { code, message } }; }

  // SURGICAL PATCH 2026-08-12: gateway network calls had no timeout, so a stalled
  // connection left the "Sending request..." overlay spinning forever with no
  // feedback and no way out. Races a promise against a hard deadline so a hung
  // request always resolves into a clear, recoverable error instead of hanging.
  const REQUEST_TIMEOUT_MS = 20000;
  function withRequestTimeout(promise, ms = REQUEST_TIMEOUT_MS) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Request timed out — check your connection and try again.')), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  function createRequest(type, payload, meta={}) {
    const staff = currentStaff();
    const req = {
      id: uid('rq'),
      type,
      status: 'pending',
      payload,
      requestedAt: new Date().toISOString(),
      requestedBy: staff?.id || 'system',
      requestedByName: staff?.name || 'System',
      ...meta
    };
    state.approvals.unshift(req);
    pushAudit('request_created', `${type} by ${req.requestedByName}</div>`);
    save();
    return req;
  }



  function approveRequest(id) {
    const req = state.approvals.find(r => r.id === id);
    if (!req || req.status !== 'pending') return;
    if (shouldLockApprovalType(req.type)) {
      const reqDate = approvalBusinessDate(req.type, req.payload || {});
      if (isBusinessDateClosed(reqDate)) return showToast(businessDateClosedMessage(reqDate));
    }
    req.status = 'approved';
    req.approvedAt = new Date().toISOString();
    req.approvedBy = currentStaff()?.name || 'System';
    applyRequest(req);
    pushAudit('request_approved', `${req.type} approved</div>`);
    save();
    render();
  }

  function rejectRequest(id) {
    const req = state.approvals.find(r => r.id === id);
    if (!req || req.status !== 'pending') return;
    req.status = 'rejected';
    req.approvedAt = new Date().toISOString();
    req.approvedBy = currentStaff()?.name || 'System';
    pushAudit('request_rejected', `${req.type} rejected</div>`);
    save();
    render();
  }

  function applyRequest(req) {
    switch (req.type) {
      case 'account_opening': {
        const p = req.payload;
        const assignedAccountNumber = String(p.generatedAccountNumber || '').trim() || nextCustomerAccountNumber();
        p.generatedAccountNumber = assignedAccountNumber;
        state.customers.push({
          id: uid('c'),
          accountNumber: assignedAccountNumber,
          oldAccountNumber: p.oldAccountNumber || '',
          name: p.name,
          address: p.address,
          nin: p.nin,
          bvn: p.bvn,
          phone: p.phone,
          photo: p.photo || '',
          active: true,
          createdAt: new Date().toISOString(),
          transactions: []
        });
        break;
      }
      case 'account_maintenance': {
        const c = state.customers.find(x => x.id === req.payload.customerId);
        if (c) Object.assign(c, req.payload.patch);
        break;
      }
      case 'account_reactivation': {
        const c = state.customers.find(x => x.id === req.payload.customerId);
        if (c) { c.active = true; c.frozen = false; c.accountStatus = 'active'; }
        break;
      }
      case 'account_block': {
        const c = state.customers.find(x => x.id === req.payload.customerId);
        if (c) { c.frozen = true; c.accountStatus = 'frozen'; }
        break;
      }
      case 'account_closure': {
        const c = state.customers.find(x => x.id === req.payload.customerId);
        if (c) { c.closed = true; c.active = false; c.accountStatus = 'closed'; }
        break;
      }
      case 'intra_bank_transfer': {
        // SURGICAL FIX 2026-09-04: this called a non-existent
        // ensureCustomerAccount() — approving a Non Cash transaction threw
        // here and silently never moved either balance. Switched to the
        // same txObj()+recalcCustomerBalance() pattern every other real
        // balance change in this file uses (see customer_credit above).
        const src = (state.customers || []).find(c => c.id === req.payload.sourceAccountId || c.accountNumber === req.payload.sourceAccountNumber);
        const dst = (state.customers || []).find(c => c.id === req.payload.destAccountId || c.accountNumber === req.payload.destAccountNumber);
        const transferAmount = Number(req.payload.amount || 0);
        const transferDetails = String(req.payload.details || '').trim();
        if (src) {
          src.transactions ||= [];
          src.transactions.push(txObj('debit', transferAmount, transferDetails, req.requestedByName, req.requestedBy, currentStaff()?.name || '', dst?.name || req.payload.destAccountName || '', req.payload.date));
          recalcCustomerBalance(src);
        }
        if (dst) {
          dst.transactions ||= [];
          dst.transactions.push(txObj('credit', transferAmount, transferDetails, req.requestedByName, req.requestedBy, currentStaff()?.name || '', src?.name || req.payload.sourceAccountName || '', req.payload.date));
          recalcCustomerBalance(dst);
        }
        break;
      }
      case 'cash_receipt': {
        // Credit Cash Officer's own operational account balance — recorded in staff_cash_ledger
        // The frontend getStaffOperationalBalance reads from state.approvals directly,
        // so no separate ledger entry needed in local mode.
        // 2026-10-24: a receipt into a business Treasury account is a real
        // credit on that account.
        const treasury = (state.customers || []).find(c => c.id === (req.payload.treasuryAccountId || req.payload.operationalAccountId) && c.accountType === 'treasury');
        if (treasury) {
          const amt = Number(req.payload.amount || 0);
          treasury.transactions ||= [];
          treasury.transactions.push(txObj('credit', amt, String(req.payload.note || '').trim() || `Cash received${req.payload.receivedFromName ? ' from ' + req.payload.receivedFromName : ''}`, req.requestedByName, req.requestedBy, currentStaff()?.name || '', req.payload.receivedFromName || '', req.payload.date));
          recalcCustomerBalance(treasury);
        }
        break;
      }
      case 'inter_staff_credit': {
        // Cash Officer credits a Teller's operational account.
        // getStaffOperationalBalance reads from state.approvals directly, so no ledger entry needed in local mode.
        // SURGICAL ADDITION 2026-09-04 (client request): funding a teller's
        // operational balance no longer has to come from Treasury cash —
        // any staff or customer account can be the source. When one is
        // given, this is a REAL transfer: the source account's actual
        // balance is debited here, same as any other posting (same
        // txObj()+recalcCustomerBalance() pattern as intra_bank_transfer
        // above). The credit side of a teller's op balance stays derived
        // live from approved requests (see getStaffOperationalBreakdown),
        // so no separate credit-side entry is needed here.
        if (req.payload.sourceAccountId || req.payload.sourceAccountNumber) {
          const src = (state.customers || []).find(c => c.id === req.payload.sourceAccountId || c.accountNumber === req.payload.sourceAccountNumber);
          if (src) {
            const fundAmount = Number(req.payload.amount || 0);
            const fundDetails = String(req.payload.note || '').trim() || `Funding transfer to ${req.payload.targetAccountName || 'teller operational account'}`;
            src.transactions ||= [];
            src.transactions.push(txObj('debit', fundAmount, fundDetails, req.requestedByName, req.requestedBy, currentStaff()?.name || '', req.payload.targetAccountName || '', req.payload.date));
            recalcCustomerBalance(src);
          }
        }
        // 2026-10-24: money sent from a staff account into a business
        // account (e.g. the Till into a Treasury account) is a real credit there.
        {
          const dst = (state.customers || []).find(c => c.id === req.payload.targetAccountId || (req.payload.targetAccountNumber && c.accountNumber === req.payload.targetAccountNumber));
          if (dst && dst.accountType !== 'staff_operational') {
            const amt = Number(req.payload.amount || 0);
            dst.transactions ||= [];
            dst.transactions.push(txObj('credit', amt, String(req.payload.note || '').trim() || `Transfer from ${req.payload.sourceAccountName || 'staff account'}`, req.requestedByName, req.requestedBy, currentStaff()?.name || '', req.payload.sourceAccountName || '', req.payload.date));
            recalcCustomerBalance(dst);
          }
        }
        break;
      }
      case 'float_declaration': {
        if (!hasBaseOpeningBalanceForDate(req.payload.staffId, req.payload.date)) {
          addStaffEntry(
            req.payload.staffId,
            'approved_form',
            req.payload.amount,
            req.payload.amount,
            `Approved form for ${req.payload.date}`,
            { formDate: req.payload.date }
          );
        }
        break;
      }
      case 'float_topup': {
        // Legacy — no-op
        break;
      }
      case 'customer_credit': {
        // Resolve customer: for staff accounts, the customerId may be a staffId;
        // find the staff_wallet customer linked to that staff member.
        let c = state.customers.find(x => x.id === req.payload.customerId);
        if (!c && (req.payload.accountType === 'staff' || req.payload.accountType === 'staff_wallet')) {
          // Try finding the staff wallet customer linked to this staff
          c = state.customers.find(x => x.staffId === req.payload.customerId && x.accountType === 'staff_wallet');
          if (!c) c = state.customers.find(x => x.accountNumber === req.payload.accountNumber && x.accountType === 'staff_wallet');
          if (!c) c = state.customers.find(x => x.accountNumber === req.payload.accountNumber);
        }
        if (!c || isCustomerFrozen(c) || c.active === false) break;
        const sourceApprovalId = req.payload.sourceApprovalId || req.id || '';
        const sourceRowKey = String(req.payload.sourceRowKey || 'direct');
        if (sourceApprovalId && (c.transactions || []).some(tx => tx.sourceApprovalId === sourceApprovalId && tx.sourceRowKey === sourceRowKey && tx.type === 'credit')) break;
        const totalAmount = Number(req.payload.amount || 0);
        const chargeBreakdown = normalizeChargePayload(totalAmount, req.payload);
        const totalCharges = chargeBreakdown.reduce((sum, row) => sum + Number(row.amount || 0), 0);
        const customerCreditAmount = getCustomerCreditAmount({ ...req.payload, chargeBreakdown });
        const chargeTraceId = req.payload.chargeTraceId || req.payload.commissionTraceId || uid('ctr');
        const baseDetails = String(req.payload.details || '').trim();
        const chargeDetailTag = totalCharges > 0 ? `${baseDetails ? ' • ' : ''}${chargeInlineMeta({ amount: totalAmount, chargeBreakdown, customerCreditAmount })}` : '';
        c.transactions.push(txObj('credit', customerCreditAmount, `${baseDetails}${chargeDetailTag}`.trim(), req.requestedByName, req.requestedBy, currentStaff()?.name || '', 'customer', req.payload.date, {
          receivedOrPaidBy: req.payload.receivedOrPaidBy,
          paymentMode: req.payload.paymentMode || req.payload.payoutSource || '',
          postedBy: req.requestedByName,
          approvedBy: currentStaff()?.name || '',
          sourceAmount: totalAmount,
          chargeBreakdown,
          totalChargeAmount: totalCharges,
          commissionAmount: chargeBreakdown.find(row => row.key === 'commission')?.amount || 0,
          chargeTraceId,
          commissionTraceId: chargeTraceId,
          customerCreditAmount,
          sourceApprovalId,
          sourceRowKey,
          accountType: c.accountType || 'customer'
        }));
        recalcCustomerBalance(c);
        // Only a genuinely direct posting draws on the daily FORM here — rows
        // dispatched from a journal (sourceRowKey !== 'direct') already get a
        // single lump FORM deduction posted once, in the journal case below.
        if (sourceRowKey === 'direct') {
          // SURGICAL FIX 2026-09-04 (client-confirmed bug): delta was -totalAmount
          // here — a customer credit (deposit, cash coming IN) was reducing the
          // teller's operational balance instead of increasing it. Now +totalAmount.
          addStaffEntry(req.payload.staffId, 'customer_credit', totalAmount, totalAmount, `Customer credit ${c.accountNumber}`, { customerId: c.id, date: `${req.payload.date}T12:00:00.000Z`, chargeBreakdown, totalChargeAmount: totalCharges, chargeTraceId, customerCreditAmount });
        }
        if (totalCharges > 0) {
          state.operations.entries ||= [];
          state.businessExtras ||= [];
          chargeBreakdown.forEach(row => {
            const incomeAccount = getIncomeAccountByName(row.accountName || row.label);
            state.operations.entries.unshift({
              id: uid('op'),
              kind: 'income',
              accountId: incomeAccount?.id || row.key,
              accountName: incomeAccount?.name || row.accountName || row.label,
              amount: row.amount,
              note: cleanOperationalNote(`${row.label} from ${c.accountNumber}`),
              date: `${req.payload.date}T12:00:00.000Z`,
              postedBy: req.requestedByName,
              approvedBy: currentStaff()?.name || '',
              traceId: chargeTraceId,
              sourceTransactionType: 'customer_credit'
            });
            state.businessExtras.unshift({
              date: `${req.payload.date}T12:00:00.000Z`,
              accountNumber: incomeAccount?.accountNumber || 'I1',
              accountName: incomeAccount?.name || row.accountName || row.label,
              details: cleanOperationalNote(`${row.label} from ${c.accountNumber}`),
              kind: 'credit',
              amount: row.amount,
              balanceAfter: 0,
              receivedOrPaidBy: req.payload.receivedOrPaidBy || '',
              postedBy: currentStaff()?.name || req.requestedByName,
              type: 'charge_credit',
              traceId: chargeTraceId
            });
          });
          pushAudit('charges_applied', `${c.accountNumber} • Amount ${money(totalAmount)} • ${chargeInlineMeta({ amount: totalAmount, chargeBreakdown, customerCreditAmount })} • Trace ${chargeTraceId}`);
        }
        break;
      }
      case 'customer_debit': {
        // Resolve customer: for staff accounts, the customerId may be a staffId
        let c = state.customers.find(x => x.id === req.payload.customerId);
        if (!c && (req.payload.accountType === 'staff' || req.payload.accountType === 'staff_wallet')) {
          c = state.customers.find(x => x.staffId === req.payload.customerId && x.accountType === 'staff_wallet');
          if (!c) c = state.customers.find(x => x.accountNumber === req.payload.accountNumber && x.accountType === 'staff_wallet');
          if (!c) c = state.customers.find(x => x.accountNumber === req.payload.accountNumber);
        }
        if (!c || isCustomerFrozen(c) || c.active === false) break;
        const sourceApprovalId = req.payload.sourceApprovalId || req.id || '';
        const sourceRowKey = String(req.payload.sourceRowKey || 'direct');
        if (sourceApprovalId && (c.transactions || []).some(tx => tx.sourceApprovalId === sourceApprovalId && tx.sourceRowKey === sourceRowKey && tx.type === 'debit')) break;
        c.transactions.push(txObj('debit', req.payload.amount, req.payload.details, req.requestedByName, req.requestedBy, currentStaff()?.name || '', 'customer', req.payload.date, {
          receivedOrPaidBy: req.payload.receivedOrPaidBy,
          paymentMode: req.payload.paymentMode || req.payload.payoutSource || '',
          postedBy: req.requestedByName,
          approvedBy: currentStaff()?.name || '',
          sourceApprovalId,
          sourceRowKey,
          accountType: c.accountType || 'customer'
        }));
        recalcCustomerBalance(c);
        if (sourceRowKey === 'direct' && req.payload.payoutSource === 'teller') {
          // SURGICAL FIX 2026-09-04 (client-confirmed bug): delta was +amount
          // here — a customer debit (withdrawal, cash going OUT) was
          // increasing the teller's operational balance instead of reducing
          // it. Now -amount.
          addStaffEntry(req.payload.staffId, 'customer_debit', req.payload.amount, -req.payload.amount, `Customer debit ${c.accountNumber}`, { customerId: c.id, date: `${req.payload.date}T12:00:00.000Z` });
        }
        break;
      }
      case 'customer_credit_journal': {
        (req.payload.rows || []).forEach((row, index) => applyRequest({
          id: req.id,
          type:'customer_credit',
          payload:{...row, staffId:req.payload.staffId, date:req.payload.date, sourceApprovalId:req.id, sourceRowKey: row.id || `${index}:${row.accountNumber || row.customerId || ''}`},
          requestedByName:req.requestedByName,
          requestedBy:req.requestedBy
        }));
        // The journal's own FORM amount (not its row totals) is what draws down
        // the funding side, posted once per journal. SURGICAL ADDITION
        // 2026-09-22 (client-confirmed design, cont'd): the teller can fund a
        // journal from ANY account, not just a staff operational one. When
        // fundingLeg is set (a non-staff account was chosen), post it as an
        // ordinary customer_debit transaction against that account (opposite
        // direction from the rows, which were credited above) instead of a
        // staff cash ledger entry. Otherwise, fall back to the staff ledger
        // path exactly as before (fundingStaffId, defaulting to the
        // performing teller's own account).
        const journalFormAmount = Number(req.payload.formAmount || 0);
        if (req.payload.fundingLeg && req.payload.fundingLeg.accountId) {
          applyRequest({
            id: req.id,
            type: 'customer_debit',
            payload: { customerId: req.payload.fundingLeg.accountId, accountNumber: req.payload.fundingLeg.accountNumber, amount: journalFormAmount, details: `Journal funding leg for ${req.payload.journalNumber || ''}`, staffId: req.payload.staffId, date: req.payload.date, sourceApprovalId: req.id, sourceRowKey: 'funding-leg' },
            requestedByName: req.requestedByName,
            requestedBy: req.requestedBy
          });
        } else {
          const journalFundingStaffId = req.payload.fundingStaffId || req.payload.staffId;
          if (journalFormAmount > 0 && !ensureStaffAccount(journalFundingStaffId).entries.some(e => e.sourceApprovalId === req.id && e.type === 'customer_credit_journal')) {
            // SURGICAL FIX 2026-09-04 (client-confirmed bug): same direction fix
            // as plain customer_credit above — a credit journal's FORM amount
            // was reducing the operational balance instead of increasing it.
            addStaffEntry(journalFundingStaffId, 'customer_credit_journal', journalFormAmount, journalFormAmount, `Journal form for ${req.payload.date}`, { date: `${req.payload.date}T12:00:00.000Z`, sourceApprovalId: req.id, formPaymentMode: req.payload.formPaymentMode || 'cash' });
          }
        }
        break;
      }
      case 'customer_debit_journal': {
        (req.payload.rows || []).forEach((row, index) => applyRequest({
          id: req.id,
          type:'customer_debit',
          payload:{...row, staffId:req.payload.staffId, date:req.payload.date, sourceApprovalId:req.id, sourceRowKey: row.id || `${index}:${row.accountNumber || row.customerId || ''}`},
          requestedByName:req.requestedByName,
          requestedBy:req.requestedBy
        }));
        const journalFormAmount = Number(req.payload.formAmount || 0);
        if (req.payload.fundingLeg && req.payload.fundingLeg.accountId) {
          applyRequest({
            id: req.id,
            type: 'customer_credit',
            payload: { customerId: req.payload.fundingLeg.accountId, accountNumber: req.payload.fundingLeg.accountNumber, amount: journalFormAmount, details: `Journal funding leg for ${req.payload.journalNumber || ''}`, staffId: req.payload.staffId, date: req.payload.date, sourceApprovalId: req.id, sourceRowKey: 'funding-leg' },
            requestedByName: req.requestedByName,
            requestedBy: req.requestedBy
          });
        } else {
          const journalFundingStaffId = req.payload.fundingStaffId || req.payload.staffId;
          if (journalFormAmount > 0 && !ensureStaffAccount(journalFundingStaffId).entries.some(e => e.sourceApprovalId === req.id && e.type === 'customer_debit_journal')) {
            addStaffEntry(journalFundingStaffId, 'customer_debit_journal', journalFormAmount, -journalFormAmount, `Journal form for ${req.payload.date}`, { date: `${req.payload.date}T12:00:00.000Z`, sourceApprovalId: req.id, formPaymentMode: req.payload.formPaymentMode || 'cash' });
          }
        }
        break;
      }
      case 'operational_entry': {
        const amount = Number(req.payload.amount || 0);
        const accountId = String(req.payload.accountId || '').trim();
        const account = [...state.operations.incomeAccounts, ...state.operations.expenseAccounts]
          .find(a => String(a.id || '') === accountId);
        if (!accountId || !(amount > 0) || !account) break;
        if (state.operations.entries.some(e => e.sourceApprovalId === req.id)) break;
        const kind = state.operations.incomeAccounts.some(a => String(a.id || '') === accountId) ? 'income' : 'expense';
        state.operations.entries.unshift({
          id: uid('op'),
          kind,
          accountId,
          accountName: req.payload.accountName || account.name,
          amount,
          note: req.payload.note,
          date: `${req.payload.date || today()}T12:00:00.000Z`,
          postedBy: req.requestedByName,
          approvedBy: currentStaff()?.name || '',
          sourceApprovalId: req.id
        });
        break;
      }
      case 'create_operational_account': {
        const dest = req.payload.category === 'income' ? state.operations.incomeAccounts : state.operations.expenseAccounts;
        if (!dest.some(a => a.sourceApprovalId === req.id || (String(a.accountNumber || '') === String(req.payload.accountNumber || '') && String(a.name || '').toLowerCase() === String(req.payload.name || '').toLowerCase()))) {
          dest.push({ id: uid('oa'), name: req.payload.name, accountNumber: req.payload.accountNumber, createdAt: new Date().toISOString(), sourceApprovalId: req.id });
        }
        break;
      }
      case 'close_of_day': {
        const variance = Number(req.payload.actualCash||0) - Number(req.payload.expectedCash||0);
        state.cod.unshift({
          id: uid('cod'),
          staffId: req.payload.staffId,
          staffName: req.payload.staffName,
          date: req.payload.date,
          actualCash: req.payload.actualCash,
          expectedCash: req.payload.expectedCash,
          variance,
          overdraw: req.payload.overdraw || 0,
          note: req.payload.note,
          fieldPapers: req.payload.fieldPapers,
          status: variance === 0 && !(req.payload.overdraw>0) ? 'balanced' : 'flagged',
          approvedAt: new Date().toISOString(),
          approvedBy: currentStaff()?.name || ''
        });
        break;
      }
      case 'wallet_fund': {
        const acc = ensureStaffAccount(req.payload.staffId); const wallet=getStaffWalletCustomer(req.payload.staffId);
        if (wallet && !wallet.transactions?.some(tx => tx.sourceApprovalId === req.id && tx.type === 'credit')) {
          wallet.transactions ||= [];
          wallet.transactions.push(txObj('credit', req.payload.amount, req.payload.note || 'Wallet funded', req.requestedByName, req.requestedBy, currentStaff()?.name || '', 'staff_wallet', req.payload.date || businessDate(), { sourceApprovalId: req.id }));
          recalcCustomerBalance(wallet); acc.walletBalance = Number(wallet.balance||0);
          addStaffEntry(req.payload.staffId, 'wallet_fund', req.payload.amount, 0, req.payload.note || 'Wallet funded');
        }
        break;
      }
      case 'debt_repayment': {
        const acc = ensureStaffAccount(req.payload.staffId); const wallet=getStaffWalletCustomer(req.payload.staffId);
        if (wallet && !wallet.transactions?.some(tx => tx.sourceApprovalId === req.id && tx.type === 'debit')) {
          wallet.transactions ||= [];
          wallet.transactions.push(txObj('debit', req.payload.amount, req.payload.note || 'Debt repaid', req.requestedByName, req.requestedBy, currentStaff()?.name || '', 'staff_wallet', req.payload.date || businessDate(), { sourceApprovalId: req.id }));
          recalcCustomerBalance(wallet); acc.walletBalance = Number(wallet.balance||0);
          acc.debtBalance = Math.max(0, Number(acc.debtBalance||0) - Number(req.payload.amount||0));
          addStaffEntry(req.payload.staffId, 'debt_repayment', req.payload.amount, 0, req.payload.note || 'Debt repaid');
          state.businessExtras ||= [];
          if (!state.businessExtras.some(e => e.sourceApprovalId === req.id)) state.businessExtras.unshift({ sourceApprovalId:req.id, date:req.payload.date || businessDate(), accountNumber: acc.accountNumber, details:'Staff debt repayment', kind:'credit', amount:Number(req.payload.amount||0), balanceAfter:0, receivedOrPaidBy: req.requestedByName, postedBy: currentStaff()?.name || req.requestedByName });
        }
        break;
      }
      case 'temp_grant': {
        const existing = state.tempGrants.find(g => g.staffId === req.payload.staffId && g.tool === req.payload.tool);
        if (existing) existing.enabled = req.payload.enabled;
        else state.tempGrants.push({ ...req.payload });
        break;
      }
    }
    recalcAllCustomerBalances();
    recalcAllTellerBalances();
  }

  function nextCustomerAccountNumber(sourceState=state) {
    const nums = (sourceState.customers || [])
      .filter(c => String(c.accountType || 'customer') !== 'staff_wallet')
      .map(c => String(c.accountNumber || '').trim())
      .filter(no => /^1\d+$/.test(no))
      .map(no => Number(no))
      .filter(Boolean);
    return String((nums.length ? Math.max(...nums) : 999) + 1);
  }

  const customerPhotoCache = new Map();
  function lookupFill(root, customer) {
    const map = {
      name: customer?.name || '',
      phone: customer?.phone || '',
      // A teller's T-account balance is the operational balance (Till), not
      // the customer-style balance field (2026-10-22).
      balance: customer ? balanceHtml(customer.accountType === 'staff_operational' ? tellerTillBalance(customer.linkedStaffId) : customer.balance) : '—',
      address: customer?.address || '',
      nin: customer?.nin || '',
      bvn: customer?.bvn || ''
    };
    Object.entries(map).forEach(([k,v]) => {
      const el = q(`[data-fill="${k}"]`, root);
      if (el) { if(k==='balance') el.innerHTML = v || '—'; else el.textContent = v || '—'; }
    });
    const photo = q('[data-fill="photo"]', root);
    if (photo) {
      // Fix B 2026-10-22: customer lists no longer carry photos (egress);
      // the photo loads here, once per customer per session.
      const id = String(customer?.id || '');
      const src = customer?.photo || customerPhotoCache.get(id) || '';
      photo.dataset.photoFor = id;
      photo.innerHTML = src ? `<img src="${src}" alt="photo">` : '<span>No Photo</span>';
      if (!src && id && !photo.closest('.hidden') && !customerPhotoCache.has(id) && isSupabaseApprovalMode() && gateway.customers?.getCustomerPhoto) {
        customerPhotoCache.set(id, '');
        if (customerPhotoCache.size > 60) customerPhotoCache.delete(customerPhotoCache.keys().next().value);
        gateway.customers.getCustomerPhoto(id).then(res => {
          if (!res?.ok) { customerPhotoCache.delete(id); return; }
          if (!res.data) return;
          customerPhotoCache.set(id, res.data);
          if (photo.isConnected && photo.dataset.photoFor === id) photo.innerHTML = `<img src="${res.data}" alt="photo">`;
        }).catch(() => customerPhotoCache.delete(id));
      }
    }
    const nm = q('[data-fill="name"]', root);
    if (nm && customer && customerStatusLabel(customer) === 'Frozen') nm.innerHTML = `${escapeHtml(customer.name || '')} <span class="badge rejected">Frozen</span>`;
  }

  let _renderScheduled = false;
  // Input fields that must retain focus — a render while these are active
  // would destroy the DOM node and lose the cursor.
  const FOCUS_GUARD_SELECTORS = ['#txAmount', '#txAcc', '#journalAmount', '#journalAcc', '#txDetails', '#txCounterparty', '#journalDetails', '#journalCounterparty', '[data-charge-input]'];
  let _deferredRenderPending = false;

  function isInputFocused() {
    const active = document.activeElement;
    if (!active || active === document.body) return false;
    // SURGICAL PATCH 2026-08-14: this guard only protected a hardcoded
    // handful of transaction/journal field IDs, so a background sync every
    // ~8s (or any realtime event) could wipe focus out of EVERY OTHER field
    // in the app mid-keystroke — account opening, check balance, staff
    // creation, maintenance edits, all of it. Broadened to cover any
    // editable field generically, not just the old whitelist.
    const tag = active.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true;
    if (active.isContentEditable) return true;
    return FOCUS_GUARD_SELECTORS.some(sel => active.matches && active.matches(sel));
  }

  function scheduleRender() {
    if (_renderScheduled) return;
    // If a protected input has focus, queue a deferred render instead of
    // immediately replacing the DOM. The render fires as soon as the user
    // leaves the field (blur event on the input or its parent).
    if (isInputFocused()) {
      if (_deferredRenderPending) return;
      _deferredRenderPending = true;
      const runDeferred = () => {
        _deferredRenderPending = false;
        if (!isInputFocused()) {
          scheduleRender();
        } else {
          // Still focused — keep waiting
          _deferredRenderPending = true;
          document.activeElement.addEventListener('blur', runDeferred, { once: true });
        }
      };
      document.activeElement.addEventListener('blur', runDeferred, { once: true });
      return;
    }
    _renderScheduled = true;
    requestAnimationFrame(() => { _renderScheduled = false; render(); });
  }

  function safeRender() {
    if (isInputFocused()) scheduleRender();
    else render();
  }

  function render() {
    document.body.classList.remove('home-lock-scroll');
    if (!state.ui.module) document.body.classList.add('home-lock-scroll');
    bindHeader();
    renderHero();
    renderModules();
    renderWorkspace();
  }

  function bindHeader() {
    // Show logged-in staff identity — no dropdown switching after login
    const activeStaff = state.staff.find(s => s.id === state.activeStaffId);
    const nameEl = byId('staffNameDisplay');
    const roleEl = byId('staffRoleDisplay');
    if (nameEl) nameEl.textContent = activeStaff?.name || '';
    if (roleEl) roleEl.textContent = staffRoleLabels(activeStaff);
    byId('btnCOD').onclick = () => canCloseBusinessDay() ? confirmAction(`Close business date ${businessDate()}? This will open ${nextDate(businessDate())}.`, openCODModal) : showToast('Only Approval Officer or Admin can close day');
    byId('btnCOD').disabled = !canCloseBusinessDay();
    if (byId('btnLogout') && isSupabaseApprovalMode()) {
      byId('btnLogout').onclick = async () => {
        await gateway.auth.logout();
        showLoginScreen();
        byId('loginStaffId').value = '';
        byId('loginPassword').value = '';
        byId('loginError').classList.add('hidden');
      };
    }
    byId('btnAudit').onclick = openAuditModal;
    const themeBtn = byId('btnThemeCycle');
    if (themeBtn) {
      themeBtn.textContent = `◐ ${THEME_LABELS[state.ui.theme || 'classic'] || 'Classic'}`;
      themeBtn.onclick = () => {
        const curr = state.ui.theme || 'classic';
        const idx = THEMES.indexOf(curr);
        const next = THEMES[(idx + 1) % THEMES.length];
        applyTheme(next, true);
        showToast(`Theme: ${THEME_LABELS[next]}`);
      };
    }
    byId('globalNameSearch').oninput = debounce((e) => {
      if (!e.target.value.trim()) return;
      const results = searchCustomersByName(e.target.value);
      openCustomerSearchModal(results);
    }, 200);
    byId('modalClose').onclick = closeModal;
    byId('modalBack').onclick = (e) => { if (e.target === byId('modalBack')) closeModal(); };
  }

  function renderHero() {
    const hero = q('.hero-card');
    if (hero) hero.classList.add('hidden');
  }

  function cardMetric(label, value, hint, action='') {
    return `<div class="summary-card ${action ? 'clickable' : ''}" ${action ? `data-hero-card="${action}"` : ''}><div class="section-label">${label}</div><div class="value">${value}</div><div class="hint">${hint}</div></div>`;
  }

  function setButtonLoading(btn, isLoading, text = 'Processing...') {
  if (!btn) return;
  if (isLoading) {
    btn.dataset.originalText = btn.innerHTML;
    btn.innerHTML = `<span class="spinner"></span> ${text}`;
    btn.disabled = true;
  } else {
    btn.innerHTML = btn.dataset.originalText || btn.innerHTML;
    btn.disabled = false;
  }
}

let _processingCancelTimer = null;
function showProcessing(text = 'Processing...') {
  const overlay = byId('globalProcessingOverlay');
  const label = byId('processingText');
  const cancelBtn = byId('processingCancelBtn');
  if (label) label.textContent = text;
  overlay?.classList.remove('hidden');
  // SURGICAL PATCH 2026-08-12: a request should never trap the user behind an
  // unclosable spinner. The network call itself is time-bounded (see
  // withRequestTimeout), but reveal a manual Cancel button after a few seconds
  // too, so the UI is never the thing blocking someone during a slow connection.
  if (cancelBtn) {
    cancelBtn.classList.add('hidden');
    clearTimeout(_processingCancelTimer);
    _processingCancelTimer = setTimeout(() => cancelBtn.classList.remove('hidden'), 6000);
    cancelBtn.onclick = () => {
      hideProcessing();
      showToast('Cancelled — the request may still complete in the background');
    };
  }
}

function hideProcessing() {
  clearTimeout(_processingCancelTimer);
  byId('globalProcessingOverlay')?.classList.add('hidden');
  byId('processingCancelBtn')?.classList.add('hidden');
}

  function smoothScrollToOpenedSegment(selector) {
    // 2026-10-28: always bring the whole work area (heading + tool list + form)
    // to just under the pinned dashboard bar, so nothing opens half hidden
    // and nobody has to scroll back up to see it properly.
    requestAnimationFrame(() => {
      const target = q('.workspace-card') || (selector && q(selector));
      target?.scrollIntoView({ behavior:'smooth', block:'start' });
    });
  }

  function renderModules() {
    const current = state.ui.module;
    const moduleOrder = ['customer_service','tellering','cash_officer','approvals','administration'];
    byId('moduleGrid').innerHTML = `<div class="module-grid-title">DASHBOARD</div><div class="module-hub"><img src="logo.png" alt="Ducess Enterprises" class="module-hub-logo"></div>` + moduleOrder.map((key) => {
      const m = MODULES[key];
      const allowed = moduleAllowed(key);
      return `<div class="module-card ${current===key?'active':''} ${allowed?'':'disabled'}" data-module="${key}" data-module-key="${key}">
        <div class="module-icon">${m.icon}</div>
        <div class="module-title">${m.title}</div>
      </div>`;
    }).join('') + (currentStaff() && !hasAssignedRole(currentStaff()) ? `<div class="note" style="grid-column:1/-1;margin-top:12px">No role has been assigned to your staff profile yet, so no sections are available. Ask an Administrative Officer to assign you a role.</div>` : '');
    qq('.module-card').forEach(card => {
      card.onclick = () => {
        const key = card.dataset.module;
        if (!moduleAllowed(key)) return showToast(noAccessMessage(MODULES[key]?.title));
        if (state.ui.module === key) {
          state.ui.module = null;
          state.ui.tool = null;
        } else {
          state.ui.module = key;
          state.ui.tool = null;
        }
        save();
        render();
        if (state.ui.module) smoothScrollToOpenedSegment('.workspace-card');
      };
    });
  }

  function renderWorkspace() {
    const card = q('.workspace-card');
    const module = state.ui.module ? MODULES[state.ui.module] : null;
    if (!module) {
      if (card) card.classList.add('hidden');
      return;
    }
    if (card) card.classList.remove('hidden');
    byId('workspaceLabel').textContent = module.title;
    byId('workspaceTitle').textContent = state.ui.tool ? (TOOL_LABELS[state.ui.tool] || module.title) : `${module.title} Tools`;
    const renderToolButtons = () => {
      if (state.ui.module === 'tellering') {
        const toolBtn = (t) => module.tools.includes(t) ? `<button class="tool-tab ${state.ui.tool===t?'active':''}" data-tool="${t}" ${hasPermission(t)?'':'disabled'}>${TOOL_LABELS[t]}</button>` : '';
        state.ui.tellerGroupOpen ||= {};
        // A group auto-opens if the currently active tool lives inside it,
        // so navigating straight to a tool (or re-rendering) never hides
        // the very button that's active.
        const groupDefs = [
          ['direct', 'Direct Posting', ['debit', 'credit']],
          ['non_cash', 'Non Cash Posting', ['intra_transfer']],
          ['journal', 'Journal Posting', ['journal_debit', 'journal_credit', 'journal_register']]
        ];
        const groupHtml = groupDefs.map(([key, label, tools]) => {
          const isOpen = !!state.ui.tellerGroupOpen[key] || tools.includes(state.ui.tool);
          return `<button type="button" class="tool-group-toggle ${isOpen ? 'open' : ''}" data-posting-group="${key}">${label} <span class="tool-group-caret">${isOpen ? '▾' : '▸'}</span></button>
          <div class="tool-group-body ${isOpen ? '' : 'hidden'}">${tools.map(toolBtn).join('')}</div>`;
        }).join('');
        return `<div class="tool-columns tellering-mixed-columns tellering-tools-only">
          <div class="tool-column-title tellering-tools-only-title">Tellering Tools</div>
          ${toolBtn('check_balance')}
          ${groupHtml}
          ${toolBtn('teller_review')}
        </div>`;
      }
      if (state.ui.module === 'administration') {
        const toolBtn = (t) => `<button class="tool-tab ${state.ui.tool===t?'active':''}" data-tool="${t}" ${hasPermission(t)?'':'disabled'}>${escapeHtml(t === 'aud_cs' ? 'Customer Service / Marketing' : t === 'aud_tellers' ? 'Tellering / Non-Tellering' : t === 'aud_types' ? 'Account Types' : t === 'aud_customers' ? 'Customer Accounts' : TOOL_LABELS[t])}</button>`;
        state.ui.tellerGroupOpen ||= {};
        const group = (key, label, tools) => {
          const isOpen = !!state.ui.tellerGroupOpen[key] || tools.includes(state.ui.tool);
          return `<button type="button" class="tool-group-toggle ${isOpen ? 'open' : ''}" data-posting-group="${key}">${label} <span class="tool-group-caret">${isOpen ? '▾' : '▸'}</span></button>
          <div class="tool-group-body ${isOpen ? '' : 'hidden'}">${tools.map(toolBtn).join('')}</div>`;
        };
        return `<div class="tool-columns tellering-mixed-columns tellering-tools-only">
          <button class="tool-tab ${state.ui.tool==='check_balance'?'active':''}" data-tool="check_balance">${TOOL_LABELS.check_balance}</button>
          ${group('adm_g', 'Administrative', ['adm_staff','adm_balance'])}
          ${group('aud_g', 'Audits', ['aud_cs','aud_tellers','aud_types','aud_customers'])}
          ${group('ict_g', 'ICT Unit', ['ict_access','ict_backup','ict_security','ict_network','ict_cyber','central_close_day'])}
        </div>`;
      }
      if (state.ui.module === 'approvals') {
        const toolBtn = (t) => hasPermission(t) || module.tools.includes(t) ? `<button class="tool-tab ${state.ui.tool===t?'active':''}" data-tool="${t}" ${hasPermission(t)?'':'disabled'}>${TOOL_LABELS[t]}</button>` : '';
        state.ui.tellerGroupOpen ||= {};
        const group = (key, label, tools) => {
          const isOpen = !!state.ui.tellerGroupOpen[key] || tools.includes(state.ui.tool);
          return `<button type="button" class="tool-group-toggle ${isOpen ? 'open' : ''}" data-posting-group="${key}">${label} <span class="tool-group-caret">${isOpen ? '▾' : '▸'}</span></button>
          <div class="tool-group-body ${isOpen ? '' : 'hidden'}">${tools.map(toolBtn).join('')}</div>`;
        };
        return `<div class="tool-columns tellering-mixed-columns tellering-tools-only">
          <button class="tool-tab ${state.ui.tool==='check_balance'?'active':''}" data-tool="check_balance">${TOOL_LABELS.check_balance}</button>
          ${toolBtn('approval_queue')}
          ${group('appr_cs', 'Customer Service', ['appr_opening','appr_update','appr_reactivate','appr_block','appr_close'])}
          ${group('appr_tt', 'Tellering / Treasury', ['appr_direct','appr_non_cash','appr_journals'])}
          ${BALANCE_PERIODS.map(([pk, pl]) => {
            const keys = BALANCE_REPORTS.map(([rk]) => `balp_${pk}_${rk}`);
            const isOpen = !!state.ui.tellerGroupOpen[`balp_${pk}`] || keys.includes(state.ui.tool);
            return `<button type="button" class="tool-group-toggle ${isOpen ? 'open' : ''}" data-posting-group="balp_${pk}">${pl} Balances <span class="tool-group-caret">${isOpen ? '▾' : '▸'}</span></button>
          <div class="tool-group-body ${isOpen ? '' : 'hidden'}">${keys.map(k => `<button class="tool-tab ${state.ui.tool===k?'active':''}" data-tool="${k}" ${hasPermission(k)?'':'disabled'}>${escapeHtml(BALANCE_SUB_TOOLS[k].short)}</button>`).join('')}</div>`;
          }).join('')}
          ${toolBtn('approval_history')}
          ${toolBtn('my_approvals')}
          ${toolBtn('approval_review')}
        </div>`;
      }
      if (state.ui.module === 'cash_officer') {
        const toolBtn = (t) => module.tools.includes(t) ? `<button class="tool-tab ${state.ui.tool===t?'active':''}" data-tool="${t}" ${hasPermission(t)?'':'disabled'}>${TOOL_LABELS[t]}</button>` : '';
        state.ui.tellerGroupOpen ||= {};
        // SURGICAL REMOVAL 2026-09-17 (client-confirmed design): "Journal
        // Posting" (journal_register) removed from Treasury entirely — only
        // Non Cash Posting remains as a group here.
        const groupDefs = [
          ['direct', 'Direct Posting', ['debit', 'credit']],
          ['non_cash', 'Non Cash Posting', ['intra_transfer']]
        ];
        const groupHtml = groupDefs.map(([key, label, tools]) => {
          const isOpen = !!state.ui.tellerGroupOpen[key] || tools.includes(state.ui.tool);
          return `<button type="button" class="tool-group-toggle ${isOpen ? 'open' : ''}" data-posting-group="${key}">${label} <span class="tool-group-caret">${isOpen ? '▾' : '▸'}</span></button>
          <div class="tool-group-body ${isOpen ? '' : 'hidden'}">${tools.map(toolBtn).join('')}</div>`;
        }).join('');
        return `<div class="tool-columns tellering-mixed-columns tellering-tools-only">
          <div class="tool-column-title tellering-tools-only-title">Treasury Tools</div>
          <button class="tool-tab ${state.ui.tool==='check_balance'?'active':''}" data-tool="check_balance">${TOOL_LABELS.check_balance}</button>
          ${groupHtml}
          ${toolBtn('treasury_review')}
        </div>`;
      }
      if (state.ui.module === 'customer_service') {
        // 2026-10-24 (client design sheet): Account Opening expands in the
        // sidebar like every other group; each account type opens the same
        // Account Opening form for that type. Everything else is unchanged.
        const toolBtn = (t) => module.tools.includes(t) ? `<button class="tool-tab ${state.ui.tool===t?'active':''}" data-tool="${t}" ${hasPermission(t)?'':'disabled'}>${TOOL_LABELS[t]}</button>` : '';
        state.ui.tellerGroupOpen ||= {};
        const openingTypes = [['customer','Customer Account'],['staff_salary','Staff Account'],['income','Income Account'],['expense','Expenses Account'],['staff_operational','Teller Account'],['treasury','Treasury Account']];
        const curOpenType = state.ui.tool === 'account_opening' ? ((state.ui.accountOpeningDraft || {}).accountType || 'customer') : '';
        const openingOpen = !!state.ui.tellerGroupOpen.cs_opening || state.ui.tool === 'account_opening';
        const canOpen = hasPermission('account_opening');
        const openingGroup = module.tools.includes('account_opening') ? `<button type="button" class="tool-group-toggle ${openingOpen ? 'open' : ''}" data-posting-group="cs_opening">${TOOL_LABELS.account_opening} <span class="tool-group-caret">${openingOpen ? '▾' : '▸'}</span></button>
          <div class="tool-group-body ${openingOpen ? '' : 'hidden'}">${openingTypes.map(([v, l]) => `<button class="tool-tab ${curOpenType===v?'active':''}" data-open-acct-type="${v}" ${canOpen?'':'disabled'}>${l}</button>`).join('')}</div>` : '';
        return `<div class="tool-columns tellering-mixed-columns tellering-tools-only">
          ${toolBtn('check_balance')}
          ${openingGroup}
          ${toolBtn('account_maintenance')}
          ${toolBtn('account_reactivation')}
          ${toolBtn('work_review')}
        </div>`;
      }
      // SURGICAL CHANGE 2026-10-16 (client: uniform design across the
      // platform): every other module's sidebar uses the same sheet column
      // as Tellering/Treasury — each tool is a dark header bar.
      return `<div class="tool-columns tellering-mixed-columns tellering-tools-only">${module.tools.map(t => `<button class="tool-tab ${state.ui.tool===t?'active':''}" data-tool="${t}" ${hasPermission(t)?'':'disabled'}>${TOOL_LABELS[t]}</button>`).join('')}</div>`;
    };
    const tabs = `<div class="workspace-switcher"><div class="tool-tabs vertical-tool-tabs tellering-tool-tabs">${renderToolButtons()}</div><div class="workspace-tool-body spec-color-scheme sheet-uniform">${state.ui.tool ? renderTool(state.ui.tool) : `<div class="tool-empty-state"><div class="tool-empty-title">${module.title}</div><div class="tool-empty-note">Select a heading to open that work area.</div></div>`}</div></div>`;
    byId('workspace').innerHTML = tabs;
    // 2026-11-09 (client): a tool that is not yours says "No access" when tapped
    // instead of doing nothing.
    qq('#workspace .tool-tabs .tool-tab[disabled]').forEach(btn => { btn.removeAttribute('disabled'); btn.setAttribute('aria-disabled', 'true'); btn.classList.add('tool-denied'); });
    const wsEl = byId('workspace');
    if (wsEl && !wsEl.dataset.noAccessBound) {
      wsEl.dataset.noAccessBound = '1';
      wsEl.addEventListener('click', (e) => {
        const b = e.target && e.target.closest ? e.target.closest('.tool-denied') : null;
        if (!b) return;
        e.preventDefault(); e.stopImmediatePropagation();
        showToast(noAccessMessage(String(b.textContent || '').replace(/[▾▸🔒]/g, '').trim()));
      }, true);
    }
    qq('[data-posting-group]').forEach(btn => btn.onclick = () => {
      const key = btn.dataset.postingGroup;
      state.ui.tellerGroupOpen ||= {};
      // Default state is OPEN (undefined counts as open — see the isOpen
      // check above), so toggling must flip based on the EFFECTIVE current
      // state, not the raw stored value: undefined/true (open) -> false,
      // false (closed) -> true.
      state.ui.tellerGroupOpen[key] = !state.ui.tellerGroupOpen[key];
      save();
      renderWorkspace();
    });
    qq('.tool-tab').forEach(btn => btn.onclick = () => {
      const nextTool = btn.dataset.tool;
      if (state.ui.tool === nextTool) {
        state.ui.tool = null;
      } else {
        state.ui.tool = nextTool;
        state.ui.audAccountKind = '';
        if (nextTool === 'staff_directory') {
          // Always re-fetch fresh on entry — a newly approved staff_salary
          // account (or a status change) shouldn't be masked by a stale cache.
          state.ui.staffSalaryAccountsCache = null;
        }
        if (nextTool === 'credit' || nextTool === 'debit') {
          state.ui.txAccDraft = '';
          state.ui.txAmountDraft = '';
      state.ui.txDetailsDraft = '';
      state.ui.txCounterpartyDraft = '';
          state.ui.journalAccDraft = '';
          state.ui.selectedCustomerId = null;
          state.ui.selectedJournalCustomerId = null;
          state.ui.generatedJournals ||= {};
          state.ui.collapsedJournals ||= {};
          const st = currentStaff();
          const journalKey = `${st?.id || 'staff'}:${businessDate()}:${nextTool}`;
          state.ui.generatedJournals[journalKey] = false;
          state.ui.collapsedJournals[journalKey] = false;
        }
        if (nextTool === 'journal_debit' || nextTool === 'journal_credit') {
          state.ui.journalStandaloneKind = nextTool === 'journal_debit' ? 'debit' : 'credit';
          state.ui.journalAccDraft = '';
          state.ui.selectedJournalCustomerId = null;
        }
        if (nextTool === 'approval_customer_service') state.ui.approvalsSection = 'customer_service';
        if (nextTool === 'approval_tellering') state.ui.approvalsSection = 'tellering';
        if (nextTool === 'approval_non_cash') state.ui.approvalsSection = 'non_cash';
        if (nextTool === 'approval_others') state.ui.approvalsSection = 'others';
        if (APPROVAL_SUB_TOOLS[nextTool]) state.ui.approvalsSection = APPROVAL_SUB_TOOLS[nextTool].section;
        if (BALANCE_SUB_TOOLS[nextTool]) state.ui.balancePeriodFilter = { preset: BALANCE_SUB_TOOLS[nextTool].preset, from: '', to: '' };
      }
      if (state.ui.tool === 'check_balance') state.ui.checkBalanceLoaded = false;
      state.ui.modalToggleTool = state.ui.tool && ['my_close_day','central_close_day'].includes(state.ui.tool) ? state.ui.tool : null;
      save();
      renderWorkspace();
      if (nextTool === 'cash_receipt' && state.ui.tool === 'cash_receipt') openCashReceiptModal();
      if (nextTool === 'my_close_day' && state.ui.tool === 'my_close_day') openMyCODModal();
      if (nextTool === 'central_close_day' && state.ui.tool === 'central_close_day') openCODModal();
      if (['my_close_day','central_close_day'].includes(nextTool)) return;
      if (['approval_customer_service','approval_tellering','approval_non_cash','approval_others'].includes(nextTool) && state.ui.tool === nextTool) {
        smoothScrollToOpenedSegment('#approvalsSectionTabs');
        return;
      }
      if (state.ui.tool === nextTool) smoothScrollToOpenedSegment('.workspace-tool-body');
    });
    qq('[data-open-acct-type]').forEach(btn => btn.onclick = () => {
      const type = btn.dataset.openAcctType;
      const draft = state.ui.accountOpeningDraft ||= {};
      const isActive = state.ui.tool === 'account_opening' && (draft.accountType || 'customer') === type;
      if (isActive) {
        state.ui.tool = null;
      } else {
        if ((draft.accountType || 'customer') !== type) {
          draft.accountType = type;
          draft.opKind = type === 'staff_operational' ? 'teller' : '';
          draft.name = '';
          draft.linkedStaffId = '';
          draft.accountNumber = '';
        }
        state.ui.tool = 'account_opening';
        state.ui.audAccountKind = '';
      }
      state.ui.modalToggleTool = null;
      save();
      renderWorkspace();
      if (state.ui.tool === 'account_opening') smoothScrollToOpenedSegment('.workspace-tool-body');
    });
    if (state.ui.tool) bindToolHandlers();
  }

  // A screen that reached for older history than this device holds shows a
  // short loading note; it re-renders by itself once the records arrive.
  function renderTool(tool) {
    historyNeededDuringRender = false;
    const html = renderToolContent(tool);
    if (historyNeededDuringRender && historyLoading) return `<div class="form-card"><div class="note" id="historyLoadingNote">Loading older records…</div></div>`;
    return html;
  }

  function renderToolContent(tool) {
    if (APPROVAL_SUB_TOOLS[tool]) return renderApprovals();
    if (ADMIN_SUB_TOOLS[tool]) return renderAdminSub(tool);
    if (BALANCE_SUB_TOOLS[tool]) return renderPeriodBalance(BALANCE_SUB_TOOLS[tool]);
    switch(tool) {
      case 'check_balance': return renderCheckBalance();
      case 'my_statement': return renderMyStatement();
      case 'my_approvals': return renderMyApprovals();
      case 'work_review': case 'teller_review': case 'approval_review': case 'treasury_review': return renderStaffReview(tool);
      case 'account_opening': return renderAccountOpening();
      case 'account_maintenance': return renderAccountMaintenance();
      case 'account_reactivation': return renderAccountReactivation();
      case 'account_statement': return renderAccountStatement();
      case 'cash_receipt': return `<div class="tool-empty-state"><div class="tool-empty-title">Cash Receipt</div><div class="tool-empty-note">Cash Receipt opens in a modal. Click the heading again to open it.</div></div>`;
      case 'staff_credit': return renderStaffCredit();
      case 'credit': return renderJournalTool('credit');
      case 'debit': return renderJournalTool('debit');
      case 'journal_debit': case 'journal_credit': return renderJournalStandalone();
      case 'journal_register': return renderJournalRegister();
      case 'intra_transfer': return renderIntraTransfer();
      case 'transaction_summary': return renderTransactionSummary();
      case 'my_close_day': return `<div class="tool-empty-state"><div class="tool-empty-title">My Close of Day</div><div class="tool-empty-note">Close-of-day details open in a modal when this heading is selected.</div></div>`;
      case 'central_close_day': return `<div class="tool-empty-state"><div class="tool-empty-title">Central Close of Day</div><div class="tool-empty-note">Central close-of-day opens in a modal when this heading is selected.</div></div>`;
      case 'approval_customer_service':
      case 'approval_tellering':
      case 'approval_non_cash':
      case 'approval_others':
      case 'approval_queue': return renderApprovals();
      case 'approval_history': return renderApprovalHistory();
      case 'permissions': return renderPermissions();
      case 'operational_posting': return renderOperationalPosting();
      case 'operational_accounts': return renderOperationalAccounts();
      case 'staff_directory': return renderStaffDirectory();
      case 'staff_roster': return renderStaffRoster();
      case 'customer_directory': return renderCustomerDirectory();
      case 'business_balance': return renderBusinessBalance();
      case 'operational_balance': return renderOperationalBalance();
      case 'overall_balance': return renderOverallBalance();
      case 'teller_balances': return renderTellerBalances();
      case 'collector_balance': return renderCollectorBalance();
      default: return '<div class="note">Tool not found.</div>';
    }
  }

  function renderCheckBalance() {
    // SURGICAL PATCH 2026-08-14: lookupFill() restores name/phone/balance/
    // photo on every re-render, but never touched this input, and the
    // template had no persisted value either — so any re-render (background
    // poll, tool switch, even the Photo/Statement buttons) silently wiped the
    // account number box back to empty while everything else stayed filled.
    const loadedCustomer = state.ui.checkBalanceLoaded ? getSelectedCustomer() : null;
    const lookupVal = loadedCustomer?.accountNumber || '';
    return `
      <div class="form-card cs2-card check-balance-card">
        <div class="cs2-title">Check Balance</div>
        <div class="cs2-stack">
          <div class="cs2-row">
            <div class="cs2-label">Account Number</div>
            <div class="cs2-input-wrap cs2-short"><input id="lookupAcc" class="entry-input cs2-input" maxlength="12" value="${escapeHtml(lookupVal)}"></div>
            <button id="lookupBtn" class="sheet-btn cs2-btn cs2-btn-solid">Search</button>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">Account Name</div>
            <div class="display-field cs2-input cs2-display cs2-wide" data-fill="name">—</div>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">Phone Number</div>
            <div class="display-field cs2-input cs2-display cs2-medium" data-fill="phone">—</div>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">Available Balance</div>
            <div class="display-field cs2-input cs2-display cs2-medium" data-fill="balance">—</div>
          </div>
          <div class="cs2-button-row">
            <button id="searchPhotoBtn" class="sheet-btn cs2-btn cs2-btn-ghost">Photo</button>
            <button id="openStatementBtn" class="sheet-btn cs2-btn cs2-btn-ghost">Statement</button>
          </div>
          <div class="sheet-photo-row hidden" id="checkBalancePhotoRow">
            <div class="photo-box inline-photo" data-fill="photo"><span>No Photo</span></div>
          </div>
        </div>
      </div>`;
  }

  function renderAccountOpening() {
    const openingDraft = state.ui.accountOpeningDraft ||= {};
    const acctType = openingDraft.accountType || 'customer';
    const isCustomer = acctType === 'customer';
    const isStaffOp = acctType === 'staff_operational';
    const isStaffSalary = acctType === 'staff_salary';
    const needsStaffLink = isStaffOp; // salary no longer linked to staff
    const isSystemAssigned = acctType !== 'customer';
    // Teller Account (customer-service-opened, 2026-10-11) is the
    // 'staff_operational' type, linked to one teller. 2026-10-24 (client):
    // a Treasury Account is no longer linked to a staff member — it is a
    // business account ('treasury') that money flows in and out of like a
    // customer account.
    const opKind = 'teller';
    const staffOptions = (state.staff || [])
      .filter(s => s.is_active !== false && s.active !== false)
      .filter(s => !isStaffOp || isEligibleForOperationalAccount(s, opKind))
      .map(s =>
      `<option value="${s.id}" ${openingDraft.linkedStaffId === s.id ? 'selected' : ''}>${escapeHtml(s.name || '')} (${escapeHtml(staffRoleLabels(s))})</option>`
    ).join('');
    return `
      <div class="form-card cs2-card opening-card">
        <div class="cs2-title">Account Opening — ${({customer:'Customer Account',staff_salary:'Staff Account',income:'Income Account',expense:'Expenses Account',staff_operational:'Teller Account',treasury:'Treasury Account'})[acctType] || 'Customer Account'}</div>
        <div class="cs2-stack">
          <div class="cs2-row">
            <div class="cs2-label">${needsStaffLink ? 'Account Display Name' : 'Account Name'}</div>
            <div class="cs2-input-wrap cs2-wide">
              ${isStaffOp
                ? `<div class="display-field" id="openNameDisplay">${escapeHtml(String(openingDraft.name || 'Select a teller below'))}</div><input type="hidden" id="openName" value="${escapeHtml(String(openingDraft.name || ''))}">`
                : `<input id="openName" class="entry-input cs2-input" value="${escapeHtml(String(openingDraft.name || ''))}" autocomplete="off"
               >`}
            </div>
          </div>
          ${needsStaffLink ? `
          <div class="cs2-row">
            <div class="cs2-label">Link to Staff Member</div>
            <div class="cs2-input-wrap cs2-wide">
              <select id="openLinkedStaff" class="entry-input cs2-input">
                <option value="">— Select Teller Staff Member —</option>
                ${staffOptions}
              </select>
            </div>
          </div>
          ` : ''}
          ${(isCustomer || isStaffSalary) ? `
          ${isCustomer ? `
          <div class="cs2-row">
            <div class="cs2-label">Account Number <span style="font-weight:400;color:var(--muted);font-size:0.85em">(required — assigned by Customer Service)</span></div>
            <div class="cs2-input-wrap cs2-short"><input id="openAccountNumber" class="entry-input cs2-input" maxlength="6" inputmode="numeric" value="${escapeHtml(String(openingDraft.accountNumber || ''))}" autocomplete="off"></div>
          </div>` : ''}
          <div class="cs2-row">
            <div class="cs2-label">Address</div>
            <div class="cs2-input-wrap cs2-wide"><input id="openAddress" class="entry-input cs2-input" value="${escapeHtml(String(openingDraft.address || ''))}" autocomplete="off"></div>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">Phone Number</div>
            <div class="cs2-input-wrap cs2-medium"><input id="openPhone" class="entry-input cs2-input digit-11-input" inputmode="numeric" value="${escapeHtml(String(openingDraft.phone || ''))}" autocomplete="off"></div>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">NIN</div>
            <div class="cs2-input-wrap cs2-medium"><input id="openNin" class="entry-input cs2-input digit-11-input" inputmode="numeric" value="${escapeHtml(String(openingDraft.nin || ''))}" autocomplete="off"></div>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">BVN</div>
            <div class="cs2-input-wrap cs2-medium"><input id="openBvn" class="entry-input cs2-input digit-11-input" inputmode="numeric" value="${escapeHtml(String(openingDraft.bvn || ''))}" autocomplete="off"></div>
          </div>
          ${isCustomer ? `
          <div class="cs2-row">
            <div class="cs2-label">Old A/N</div>
            <div class="cs2-input-wrap cs2-short"><input id="openOldAccount" class="entry-input cs2-input" maxlength="4" inputmode="numeric" value="${escapeHtml(String(openingDraft.oldAccountNumber || ''))}" autocomplete="off"></div>
          </div>` : ''}
          <div class="cs2-upload-row">
            <button id="openPhotoBtn" type="button" class="sheet-btn cs2-btn cs2-btn-ghost">Photo Upload</button>
            <input id="openPhoto" class="entry-input cs-sheet-input hidden-photo-input" type="file" accept="image/*">
            <div id="openPhotoStatus" class="cs2-note-box">No photo selected</div>
          </div>
          ${isStaffSalary ? `<div class="cs2-note-box" id="openAccountNumberPreview" data-preview-type="${acctType}">Account Number:&nbsp;<strong>Loading…</strong></div>` : ''}` : `${(acctType === 'staff_operational' || acctType === 'treasury' || acctType === 'expense' || acctType === 'income') ? `<div class="cs2-note-box" id="openAccountNumberPreview" data-preview-type="${acctType}">Account Number:&nbsp;<strong>Loading…</strong></div>` : ''}`}
          <div class="cs2-button-row">
            <button id="submitOpening" class="sheet-btn cs2-btn cs2-btn-solid">Submit for Approval</button>
          </div>
        </div>
      </div>`;
  }

  function renderAccountMaintenance() {
    return maintenanceCommon('maintenance', 'Save');
  }
  function renderAccountReactivation() {
    return maintenanceCommon('reactivation', 'Activate');
  }
  function maintenanceCommon(prefix, btnLabel) {
    const isReactivation = prefix === 'reactivation';
    // SURGICAL REDESIGN 2026-08-14: this form only ever wrote field values
    // directly into the DOM (fillCustomer()), never into state — so once the
    // focus-guard fix defers a render until blur (tabbing to the next field),
    // the very next re-render rebuilds this template from scratch with
    // nothing to rehydrate from, wiping every field mid-edit. Persisted
    // draft added, mirroring the pattern Account Opening already uses.
    const draft = state.ui[`${prefix}Draft`] ||= {};
    const editable = !!draft.editable;
    const readonlyAttr = editable ? '' : 'readonly';
    const readonlyClass = editable ? '' : 'cs-readonly';
    const selected = getSelectedCustomer();
    const displayName = selected?.name || '—';
    const displayPhone = selected?.phone || '—';
    const displayStatus = selected ? customerStatusLabel(selected) : '—';
    return `
      <div class="form-card cs2-card ${isReactivation ? 'reactivation-card' : 'maintenance-card'}">
        <div class="cs2-title">${isReactivation ? 'Account Reactivation' : 'Account Maintenance'}</div>
        <div class="cs2-stack">
          <div class="cs2-row">
            <div class="cs2-label">Account Number</div>
            <div class="cs2-input-wrap cs2-short"><input id="${prefix}Acc" class="entry-input cs2-input" maxlength="12" value="${escapeHtml(draft.accountNumber || '')}"></div>
            <button id="${prefix}Search" class="sheet-btn cs2-btn cs2-btn-solid">Search</button>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">Account Name</div>
            <div class="cs2-input-wrap ${isReactivation ? 'cs2-wide' : 'cs2-name-narrow'}"><input id="${prefix}Name" class="entry-input cs2-input cs-detail-input ${readonlyClass}" ${readonlyAttr} value="${escapeHtml(draft.name || '')}"></div>
          </div>
          ${isReactivation ? '' : `<div class="cs2-row"><div class="cs2-label">Address</div><div class="cs2-input-wrap cs2-name-narrow"><input id="${prefix}Address" class="entry-input cs2-input cs-detail-input ${readonlyClass}" ${readonlyAttr} value="${escapeHtml(draft.address || '')}"></div></div>`}
          ${isReactivation ? '' : `<div class="cs2-row"><div class="cs2-label">Phone Number</div><div class="cs2-input-wrap cs2-medium"><input id="${prefix}Phone" class="entry-input cs2-input cs-detail-input digit-11-input ${readonlyClass}" inputmode="numeric" ${readonlyAttr} value="${escapeHtml(draft.phone || '')}"></div></div>`}
          ${isReactivation ? '' : `<div class="cs2-row"><div class="cs2-label">NIN</div><div class="cs2-input-wrap cs2-medium"><input id="${prefix}Nin" class="entry-input cs2-input cs-detail-input digit-11-input ${readonlyClass}" inputmode="numeric" ${readonlyAttr} value="${escapeHtml(draft.nin || '')}"></div></div>`}
          ${isReactivation ? '' : `<div class="cs2-row"><div class="cs2-label">BVN</div><div class="cs2-input-wrap cs2-medium"><input id="${prefix}Bvn" class="entry-input cs2-input cs-detail-input digit-11-input ${readonlyClass}" inputmode="numeric" ${readonlyAttr} value="${escapeHtml(draft.bvn || '')}"></div></div>`}
          ${isReactivation ? '' : `<div class="cs2-row"><div class="cs2-label">Old A/N</div><div class="cs2-input-wrap cs2-short"><input id="${prefix}OldAccount" class="entry-input cs2-input cs-detail-input ${readonlyClass}" maxlength="4" inputmode="numeric" ${readonlyAttr} value="${escapeHtml(draft.oldAccountNumber || '')}"></div></div>`}
          <div class="cs2-footer">
            <div class="cs2-status">Account Name: <strong id="${prefix}DisplayName">${escapeHtml(displayName)}</strong> &nbsp;&nbsp; Phone Number: <strong id="${prefix}DisplayPhone">${escapeHtml(displayPhone)}</strong> &nbsp;&nbsp; Current Status: <strong id="${prefix}DisplayStatus">${escapeHtml(displayStatus)}</strong></div>
            <div class="cs2-hint">${isReactivation ? 'Search account, confirm details, and submit reactivation.' : 'Search first, update details, then save for approval.'}</div>
          </div>
          <div class="cs2-button-row">
            <button id="${prefix}Edit" class="sheet-btn cs2-btn cs2-btn-ghost">Edit</button>
            <button id="${prefix}Submit" class="sheet-btn cs2-btn ${isReactivation ? 'cs2-btn-solid' : 'cs2-btn-ghost'}">${btnLabel}</button>
            ${isReactivation ? '' : `<button id="maintenanceBlock" class="sheet-btn cs2-btn cs2-btn-ghost" title="Freeze this account (needs approval)">Block Account</button><button id="maintenanceClose" class="sheet-btn cs2-btn cs2-btn-ghost" title="Close this account — customer removed, records kept (needs approval)">Close Account</button>`}
          </div>
        </div>
      </div>`;
  }

  // SURGICAL REDESIGN 2026-08-14: three issues fixed together.
  // (1) The generated statement lived ONLY in a throwaway DOM node
  // (byId('statementArea').innerHTML = ...), never in state — so ANY
  // re-render (a background sync fires every ~8s) wiped it instantly. It's
  // now derived from state.ui on every render, same as everything else that
  // behaves correctly in this app.
  // (2) Removed the standalone account-number search — this screen now only
  // ever shows the customer already selected via Check Balance
  // (state.ui.selectedCustomerId), with just date filters.
  // (3) "Print Statement" is no longer a standalone always-visible button —
  // it only appears once a statement has actually been generated, inside
  // the generated statement block itself.
  // The person who handed in / collected the money is saved on the entry either as
  // receivedOrPaidBy or, when it comes from the database, as its counterparty.
  function statementReceivedBy(tx) {
    const direct = String(tx?.receivedOrPaidBy || '').trim();
    if (direct) return direct;
    const cp = String(tx?.counterparty || '').trim();
    return ['', 'customer', 'staff_wallet', 'staff'].includes(cp.toLowerCase()) ? '' : cp;
  }

  function renderAccountStatement() {
    const customer = getSelectedCustomer();
    const filter = state.ui.accountStatementFilter ||= { from: '', to: '' };
    const generated = state.ui.accountStatementGenerated && customer;

    let statementHtml = '';
    const isTellerAccount = customer?.accountType === 'staff_operational' && customer.linkedStaffId;
    if (generated) { if (isTellerAccount) historyCovers(filter.from || null); else customerHistoryCovers(customer); }
    if (generated && isTellerAccount) {
      // 2026-10-22: a teller's T-account statement is the teller's own
      // operations, from the teller account's side (see staffLedgerEvents).
      const events = staffLedgerEvents(customer.linkedStaffId).slice().sort((a, b) => a.seq - b.seq).filter(ev => {
        const d = String(ev.date || '').slice(0,10);
        if (filter.from && d < filter.from) return false;
        if (filter.to && d > filter.to) return false;
        return true;
      });
      const rows = events.map((ev, i) => `<tr><td>${i+1}</td><td>${fmtDate(`${String(ev.date).slice(0,10)}T12:00:00.000Z`)}</td><td>${escapeHtml(ev.type || '')}${ev.details ? ` — ${escapeHtml(ev.details)}` : ''}</td>${tellerStatementCells(ev)}<td>${escapeHtml(ev.receivedOrPaidBy || '—')}</td><td>${escapeHtml(ev.postedBy || ev.staffName || '—')}</td><td>${escapeHtml(ev.approvedBy || '—')}</td></tr>`).join('');
      statementHtml = `
        <div class="record-card statement-record-minimal" id="statementPrintArea">
          <div class="lookup-card statement-lookup-minimal"><div class="stack"><div class="info-grid">
            <div class="info-item"><div class="k">A/C Name</div><div class="v">${escapeHtml(customer.name || '')}</div></div>
            <div class="info-item"><div class="k">Account Number</div><div class="v">${customer.accountNumber || '—'}</div></div>
            <div class="info-item"><div class="k">Teller</div><div class="v">${escapeHtml(staffById(customer.linkedStaffId)?.name || '—')}</div></div>
            ${(() => { const tb = getTillBreakdown(customer.linkedStaffId, businessDate()); return `<div class="info-item"><div class="k">Opening Cash</div><div class="v">${money(tb.openingCash)}</div></div><div class="info-item"><div class="k">Cash Received</div><div class="v">${money(tb.cashReceived)}</div></div><div class="info-item"><div class="k">Cash Withdrawal</div><div class="v">${money(tb.cashWithdrawal)}</div></div><div class="info-item"><div class="k">Till (Available Balance)</div><div class="v">${money(tb.till)}</div></div>`; })()}
          </div></div></div>
          <div class="table-wrap" style="margin-top:16px"><table class="table">
            <thead><tr><th>S/N</th><th>Date</th><th>Details</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Received/Paid By</th><th>Posted By</th><th>Approved By</th></tr></thead>
            <tbody>${rows || '<tr><td colspan="9">No entries in range</td></tr>'}</tbody>
          </table></div>
        </div>
        <div class="action-row compact-action-row" style="margin-top:10px"><button class="secondary tiny-btn" id="stmtPrintBtn">Print Statement</button></div>`;
    } else if (generated) {
      const rows = (customer.transactions || []).filter(tx => {
        const d = tx.date.slice(0,10);
        if (filter.from && d < filter.from) return false;
        if (filter.to && d > filter.to) return false;
        return true;
      }).map((tx, i) => `<tr>
        <td>${i+1}</td>
        <td>${fmtDate(tx.date)}</td>
        <td>${escapeHtml(tx.details || '')}</td>
        <td>${tx.type==='debit'?money(tx.amount):''}</td>
        <td>${tx.type==='credit'?money(tx.amount):''}</td>
        <td>${money(tx.balanceAfter)}</td>
        <td>${escapeHtml(statementReceivedBy(tx) || '—')}</td>
        <td>${escapeHtml(tx.postedBy || tx.postedById || '—')}</td>
        <td>${escapeHtml(tx.approvedBy || '—')}</td>
      </tr>`).join('');
      statementHtml = `
        <div class="record-card statement-record-minimal" id="statementPrintArea">
          <div class="lookup-card statement-lookup-minimal">
            <div class="stack">
              <div class="info-grid">
                <div class="info-item"><div class="k">A/C Name</div><div class="v">${escapeHtml(customer.name || customer.full_name || customer.display_name || '')}</div></div>
                <div class="info-item"><div class="k">Account Number</div><div class="v">${customer.accountNumber || '—'}</div></div>
                <div class="info-item"><div class="k">Phone No</div><div class="v">${escapeHtml(customer.phone || '—')}</div></div>
                <div class="info-item"><div class="k">Available Balance</div><div class="v">${money(customer.balance)}</div></div>
              </div>
            </div>
          </div>
          <div class="table-wrap" style="margin-top:16px">
            <table class="table">
              <thead><tr><th>S/N</th><th>Date</th><th>Details</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Received/Paid By</th><th>Posted By</th><th>Approved By</th></tr></thead>
              <tbody>${rows || '<tr><td colspan="9">No entries in range</td></tr>'}</tbody>
            </table>
          </div>
        </div>
        <div class="action-row compact-action-row" style="margin-top:10px">
          <button class="secondary tiny-btn" id="stmtPrintBtn">Print Statement</button>
        </div>`;
    }

    return `
      <div class="stack">
        <div class="form-card">
          <h3>Statement of Account</h3>
          ${customer ? `
          <div class="info-grid" style="margin-bottom:10px">
            <div class="info-item"><div class="k">A/C Name</div><div class="v">${escapeHtml(customer.name || customer.full_name || customer.display_name || '')}</div></div>
            <div class="info-item"><div class="k">Account Number</div><div class="v">${customer.accountNumber || '—'}</div></div>
          </div>` : `<div class="note">No customer selected. Go to Check Balance, search an account, then open Statement from there.</div>`}
          <div class="form-grid two account-statement-filter-grid polished-statement-grid">
            <div class="field stmt-field stmt-date-field"><label>From Date</label><input id="stmtFrom" class="entry-input stmt-date-input polished-date-input" type="date" lang="en-GB" value="${escapeHtml(filter.from || '')}"></div>
            <div class="field stmt-field stmt-date-field"><label>To Date</label><input id="stmtTo" class="entry-input stmt-date-input polished-date-input" type="date" lang="en-GB" value="${escapeHtml(filter.to || '')}"></div>
          </div>
          <div class="action-row compact-action-row">
            <button id="stmtGenerate" class="tiny-btn" ${customer ? '' : 'disabled'}>Generate Statement</button>
          </div>
        </div>
        <div id="statementArea">${statementHtml}</div>
      </div>`;
  }

  // SURGICAL ADDITION 2026-09-14 (client-confirmed design): every Journal now
  // gets a permanent, referenceable Journal Number. One global sequence
  // (JN1, JN2, JN3...), never reused, regardless of who created it or
  // whether it's a Credit or Debit journal.
  // ===== 2026-11-03: journals are stored in the database =====
  // state.journals stays as the in-memory working copy so every screen keeps
  // working; the database (public.journals) is the source of truth. If the SQL
  // script has not been run yet, or the app is in local mode, everything falls
  // back to the old browser-only behaviour.
  let journalsDbUnavailable = false;
  let journalsLastSync = 0;
  const journalsInDb = () => !journalsDbUnavailable && isSupabaseApprovalMode() && !!gateway.journals?.list;

  // Journals must not debit an account that cannot cover it, and the user is told
  // why. Rows are totalled per account, so two rows can't together overdraw it.
  const NON_MONEY_ACCOUNT_TYPES = ['expense', 'income', 'staff_operational'];
  function journalDebitShortfall(rowList) {
    const need = new Map();
    (rowList || []).forEach(r => need.set(r.customerId, (need.get(r.customerId) || 0) + Number(r.amount || 0)));
    for (const [cid, amt] of need) {
      const c = (state.customers || []).find(x => x.id === cid);
      if (!c || NON_MONEY_ACCOUNT_TYPES.includes(String(c.accountType || 'customer'))) continue;
      if (amt > Number(c.balance || 0) + 0.01) return `Insufficient funds — ${c.name} (${c.accountNumber}) balance is ${money(c.balance || 0)}`;
    }
    return '';
  }

  async function reserveJournalNumber() {
    if (!journalsInDb()) return { ok: true, number: nextJournalNumber() };
    const res = await gateway.journals.nextNumber();
    if (res?.ok) return { ok: true, number: res.data };
    if (res?.error?.code === 'TABLE_MISSING') { journalsDbUnavailable = true; return { ok: true, number: nextJournalNumber() }; }
    return { ok: false, message: res?.error?.message || 'Could not get a Journal Number — check your connection and try again.' };
  }

  async function persistJournal(record) {
    if (!record || !journalsInDb()) return;
    const res = await gateway.journals.save(record);
    if (res?.ok) return;
    if (res?.error?.code === 'TABLE_MISSING') { journalsDbUnavailable = true; return; }
    showToast('Journal kept on this device only — could not save it to the database. Try again shortly.');
  }

  // The list never carries the field-note photo; fetch it when a journal is opened or sent.
  async function ensureJournalFull(record) {
    if (!record || record.fieldNote || !record.hasFieldNote || !journalsInDb()) return record;
    const res = await gateway.journals.get(record.id);
    if (res?.ok && res.data) record.fieldNote = res.data.fieldNote || null;
    return record;
  }

  async function syncJournalsFromGateway() {
    if (!journalsInDb()) return false;
    // A wipe changes the database's data epoch. A browser that sees a different
    // epoch than the one it last knew drops its saved journals and uploads nothing.
    try {
      const ep = await gateway.journals.epoch();
      if (ep?.ok && ep.data) {
        if (state.journalsEpoch && state.journalsEpoch !== ep.data) {
          state.journals = []; state.journalsSyncedAt = ''; state.journalsMigrated = true;
        }
        state.journalsEpoch = ep.data;
      }
    } catch (_e) {}
    const since = state.journalsSyncedAt || '';
    let res = await gateway.journals.list(since ? { since } : { windowDays: 45 });
    if (!res?.ok) { if (res?.error?.code === 'TABLE_MISSING') journalsDbUnavailable = true; return false; }
    const local = state.journals || [];
    // One-time upload of whatever this browser already holds.
    if (!state.journalsMigrated) {
      const known = new Set(res.data.map(j => j.id));
      const toSend = local.filter(j => j && j.id && j.journalNumber && !known.has(j.id));
      if (toSend.length) {
        const imp = await gateway.journals.importLocal(toSend);
        if (imp?.ok) {
          if (imp.data.imported) showToast(`${imp.data.imported} saved journal(s) from this device moved to the database`);
          if (imp.data.skipped?.length) showToast(`Not moved (number already used): ${imp.data.skipped.join(', ')}`);
        } else if (imp?.error?.code === 'TABLE_MISSING') { journalsDbUnavailable = true; return false; }
      }
      state.journalsMigrated = true;
    }
    // Merge by id: database rows win, a locally held photo is kept.
    const byId = new Map(local.map(j => [j.id, j]));
    let newest = since;
    res.data.forEach(r => {
      const l = byId.get(r.id);
      byId.set(r.id, l && l.fieldNote ? { ...r, fieldNote: l.fieldNote } : r);
      if (r.updatedAt && r.updatedAt > newest) newest = r.updatedAt;
    });
    // Anything this browser holds that the database lacks (first load only, when
    // the list is a window): try to store it. Never deletes anything.
    if (!since) {
      const dbIds = new Set(res.data.map(j => j.id));
      local.forEach(l => { if (l && l.id && l.journalNumber && !dbIds.has(l.id) && l.status === 'draft') persistJournal(l); });
    }
    const merged = Array.from(byId.values()).sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || '')));
    const sig = (arr) => arr.map(j => `${j.id}:${j.status}:${j.date}:${(j.rows || []).length}:${j.formAmount}`).join('|');
    const changed = sig(merged) !== sig(local);
    state.journals = merged;
    if (newest && newest !== since) state.journalsSyncedAt = newest;
    else if (!since) state.journalsSyncedAt = new Date().toISOString();
    if (changed || state.journalsSyncedAt !== since) save();
    journalsLastSync = Date.now();
    return changed;
  }

  function journalsVisibleToCurrentStaff(list) {
    const me = currentStaff();
    const role = me ? staffRoleCode(me) : '';
    if (!me || ['admin_officer', 'approving_officer', 'report_officer'].includes(role)) return list;
    return list.filter(j => !j.staffId || j.staffId === me.id);
  }

  function nextJournalNumber() {
    let max = 0;
    (state.journals || []).forEach(j => {
      const m = /^JN(\d+)$/.exec(String(j.journalNumber || ''));
      if (m) max = Math.max(max, parseInt(m[1], 10));
    });
    return `JN${max + 1}`;
  }

  // Shared by the live "Submit Journal" button and the Journal Register's
  // "Send for Approval" action, so a saved draft is sent through the exact
  // same approval path as one typed and submitted in one sitting — no
  // parallel/duplicate logic to keep in sync.
  // 2026-11-02 (client): the journal date is typed by the teller (may be a past
  // date); the business date is system-set and not editable. Returns an error
  // message or ''.
  function validateJournalDate(value) {
    const v = String(value || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return 'Enter the Journal Date';
    if (v > businessDate()) return 'Journal Date cannot be after the business date';
    return '';
  }
  async function submitJournalRows(kind, staffId, staffName, formAmount, formPaymentMode, rows, fieldNote, journalNumber, funding, meta) {
    const type = kind === 'credit' ? 'customer_credit_journal' : 'customer_debit_journal';
    // SURGICAL PATCH 2026-09-22 (client-confirmed design, cont'd): the
    // performing teller can fund a journal from ANY account, not just a
    // staff operational one. `funding` (when passed) is the resolved
    // customer record chosen at posting time: { id, accountNumber,
    // accountType, name, linkedStaffId }. A staff_operational account (or
    // no funding chosen at all, i.e. the old default) still goes through
    // the staff cash ledger via fundingStaffId; anything else goes through
    // fundingLeg, which the gateway posts as an ordinary customer
    // transaction (opposite direction from the journal's rows) against
    // that account instead. staffId above always stays the performing
    // teller for audit/attribution either way.
    const isFundingStaffAccount = !funding || funding.accountType === 'staff_operational';
    return await submitApprovalThroughGateway(type, {
      staffId, staffName, date: businessDate(), formAmount, formPaymentMode, journalNumber,
      journalDate: meta?.journalDate || '', confirmedBy: meta?.confirmedBy || '', description: meta?.description || '', counterparty: meta?.counterparty || '',
      fundingStaffId: isFundingStaffAccount ? (funding?.linkedStaffId || staffId) : null,
      fundingLeg: isFundingStaffAccount ? null : { accountId: funding.id, accountNumber: funding.accountNumber, accountType: funding.accountType, name: funding.name },
      rows: (rows || []).map(row => ({
        customerId: row.customerId, customerName: row.customerName, accountNumber: row.accountNumber,
        accountType: row.accountType || 'customer', staffAccountId: row.staffAccountId || '', staffAccountUuid: row.staffAccountUuid || '',
        amount: row.amount, customerCreditAmount: row.customerCreditAmount, chargeBreakdown: row.chargeBreakdown,
        totalChargeAmount: row.totalChargeAmount, commissionAmount: row.commissionAmount,
        chargeTraceId: row.chargeTraceId || row.commissionTraceId, commissionTraceId: row.commissionTraceId,
        details: (meta?.description || row.details || ''), receivedOrPaidBy: row.receivedOrPaidBy || meta?.counterparty || '', payoutSource: row.payoutSource, paymentMode: row.paymentMode
      })),
      fieldNote: fieldNote || null
    });
  }

  // A saved draft's effective status is computed live from state.approvals
  // rather than stored — sidesteps ever needing to know exactly which id
  // shape a given gateway mode hands back, and self-heals if an approval's
  // status changes after the fact.
  function journalEffectiveStatus(record) {
    if (record.status === 'draft') return 'draft';
    const linked = (state.approvals || []).find(r => r.payload?.journalNumber === record.journalNumber);
    return linked?.status || record.status || 'sent';
  }

  // SURGICAL ADDITION 2026-09-17 (client-confirmed design): this replicates
  // the "CREDIT JOURNAL POSTING" / "DEBIT JOURNAL POSTING" screen from the
  // client's reference sheet — a two-panel preview (the acting staff's own
  // account on one side, the Journal's own details on the other) shown
  // right before actually sending a saved journal for approval. Clicking
  // "Post" here IS what sends it — functionally identical to what
  // "Send for Approval" already did, just with this specific layout in
  // front of it first, matching the reference sheet exactly.
  function openJournalPostModal(record, presetAccountNumber) {
    const st = (state.staff || []).find(s => s.id === record.staffId);
    const defaultAccount = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === record.staffId);
    // SURGICAL FIX 2026-09-24 (client-reported bug): the "Search" button
    // here only did a silent exact-match lookup on whatever was already
    // typed — unlike every other "Search" button in the app (Direct
    // Posting, the journal row-add form), which opens a browsable customer
    // picker. presetAccountNumber lets the picker "return" to this modal
    // with the chosen account already filled in, since picking from a
    // separate modal has to close this one first.
    const initialAccount = presetAccountNumber ? (getCustomerByAccountNo(presetAccountNumber) || defaultAccount) : defaultAccount;
    const isCredit = record.kind === 'credit';
    const accountPanelTitle = isCredit ? 'Debit Account' : 'Credit Account';
    const journalPanelTitle = isCredit ? 'Credit Journal' : 'Debit Journal';
    const row = (label, value, label2, value2) => `<div class="cs2-row"><div class="cs2-label">${label}</div><div class="display-field">${value}</div>${label2 ? `<div class="cs2-label" style="margin-left:10px">${label2}</div><div class="display-field">${value2}</div>` : ''}</div>`;
    const accountTypeLabel = (t) => t === 'staff_operational' ? 'Teller' : (t === 'staff_salary' ? 'Staff Salary' : (t === 'expense' ? 'Expense' : (t === 'income' ? 'Income' : (t === 'treasury' ? 'Treasury' : 'Customer'))));
    const balanceFor = (c) => c ? (c.accountType === 'staff_operational' ? tellerTillBalance(c.linkedStaffId) : (c.balance || 0)) : 0;
    // SURGICAL PATCH 2026-09-22 (client-confirmed design, cont'd 2): the
    // performing teller can fund a journal from ANY account — not
    // restricted to staff operational. Whichever account is chosen still
    // gets the actual debit/credit (via the staff cash ledger if it's a
    // staff operational account, or an ordinary customer transaction
    // otherwise — see submitJournalRows/gateway). Defaults to the
    // performing teller's own account, but is a live search field.
    const accountPanelHtml = `
        <div class="journal-post-panel">
          <div class="cs2-title" style="text-align:center;margin-bottom:8px;">${accountPanelTitle}</div>
          <div class="cs2-row">
            <div class="cs2-label">Account Number</div>
            <div class="cs2-input-wrap" style="display:flex;gap:6px;align-items:center;">
              <input id="jpmFundAcc" class="entry-input" style="width:110px;" maxlength="12" value="${escapeHtml(String(initialAccount?.accountNumber || ''))}">
              <button id="jpmFundSearchBtn" type="button" class="sheet-btn tiny-btn ultra-compact-btn">Search</button>
            </div>
            <div class="cs2-label" style="margin-left:10px">Teller ID</div><div class="display-field" id="jpmFundTellerId">${escapeHtml(tellerIdForAccount(initialAccount))}</div>
          </div>
          ${row('Account Name', `<span id="jpmFundName">${escapeHtml(initialAccount?.name || st?.name || '—')}</span>`)}
          ${row('Account Balance', `<span id="jpmFundBalance">${money(balanceFor(initialAccount))}</span>`)}
          ${row('Description', escapeHtml(`Bng amount ${isCredit ? 'creditted to' : 'Debited from'} Journal NO ${record.journalNumber}`))}
          ${row('Paid By', escapeHtml(record.counterparty || '—'), 'Account Status', accountStatusChip(initialAccount, 'jpmFundStatus'))}
          ${row(`Amount ${isCredit ? 'Received' : 'Paid'}`, money(record.formAmount || 0), 'Account Type', `<span id="jpmFundType">${initialAccount ? accountTypeLabel(initialAccount.accountType) : '—'}</span>`)}
        </div>`;
    const journalPanelHtml = `
        <div class="journal-post-panel">
          <div class="cs2-title" style="text-align:center;margin-bottom:8px;">${journalPanelTitle}</div>
          ${row('Journal Number', escapeHtml(record.journalNumber))}
          ${row('Journal Name', escapeHtml(st?.name || record.staffName || '—'))}
          ${row('Description', escapeHtml(record.counterparty || '—'))}
          ${row(isCredit ? 'Received By' : 'Paid By', escapeHtml(record.staffName || '—'))}
          ${row('Journal Value', money(record.formAmount || 0))}
          ${row('Journal Review', '—')}
        </div>`;
    // Account panel is always first (left), journal panel always second
    // (right) — the debit/credit terminology in the panel TITLES already
    // flips correctly with kind; the panel POSITIONS don't swap.
    const body = `
      <div class="spec-color-scheme journal-post-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start;">
        ${accountPanelHtml}
        ${journalPanelHtml}
      </div>`;
    openModal(`${record.journalNumber} — ${journalPanelTitle} Posting`, body, [
      { label: 'Cancel', className: 'secondary', onClick: closeModal },
      {
        label: 'Post',
        onClick: async () => {
          const typedAcc = String(byId('jpmFundAcc')?.value || '').trim();
          const fundingAccount = typedAcc ? getCustomerByAccountNo(typedAcc) : initialAccount;
          if (!fundingAccount) return showToast('Enter a valid account number to fund this journal');
          if (isCustomerFrozen(fundingAccount) || fundingAccount.active === false) return showToast('That account is frozen');
          // Debit journal: the rows are debited. Credit journal: the funding account is debited.
          if (record.kind === 'debit') {
            const shortfall = journalDebitShortfall(record.rows);
            if (shortfall) return showToast(shortfall);
          } else if (!NON_MONEY_ACCOUNT_TYPES.includes(String(fundingAccount.accountType || 'customer')) && Number(record.formAmount || 0) > Number(fundingAccount.balance || 0) + 0.01) {
            return showToast(`Insufficient funds — ${fundingAccount.name} (${fundingAccount.accountNumber}) balance is ${money(fundingAccount.balance || 0)}`);
          }
          closeModal();
          showProcessing('Sending journal...'); await nextPaint();
          try {
            // Frozen at Save time: the rows were balanced against
            // formAmount as it stood then — re-checking against whatever
            // the balance is NOW would risk rejecting a journal that was
            // already valid when saved, so we send exactly what was saved.
            await ensureJournalFull(record);
            const funding = { id: fundingAccount.id, accountNumber: fundingAccount.accountNumber, accountType: fundingAccount.accountType, name: fundingAccount.name, linkedStaffId: fundingAccount.linkedStaffId };
            const result = await submitJournalRows(record.kind, record.staffId, record.staffName, record.formAmount, record.formPaymentMode, record.rows, record.fieldNote, record.journalNumber, funding, { journalDate: record.journalDate || '', confirmedBy: record.confirmedBy || '', description: record.description || '', counterparty: record.counterparty || '' });
            if (!result?.ok) return showToast(result?.error?.message || 'Unable to send journal');
            // Business date is captured here, at actual posting time — not
            // when the draft was merely saved.
            record.date = businessDate();
            record.status = 'sent';
            save();
            await persistJournal(record);
            showToast(`${record.journalNumber} sent for approval`);
            renderWorkspace();
          } finally { hideProcessing(); }
        }
      }
    ]);
    // Live-refresh the funding-account display fields for a typed-and-
    // Enter'd exact account number (matches the app-wide convention: Enter
    // does a quick exact lookup, the Search BUTTON opens the full picker —
    // see openJournalFundSearchModal below).
    const refreshFundDisplay = () => {
      const typedAcc = String(byId('jpmFundAcc')?.value || '').trim();
      const found = typedAcc ? getCustomerByAccountNo(typedAcc) : null;
      if (byId('jpmFundName')) byId('jpmFundName').textContent = found?.name || '—';
      if (byId('jpmFundTellerId')) byId('jpmFundTellerId').textContent = tellerIdForAccount(found);
      setAccountStatusChip(byId('jpmFundStatus'), found);
      if (byId('jpmFundBalance')) byId('jpmFundBalance').textContent = money(balanceFor(found));
      if (byId('jpmFundType')) byId('jpmFundType').textContent = found ? accountTypeLabel(found.accountType) : '—';
      if (!found) showToast('Account not found');
    };
    if (byId('jpmFundSearchBtn')) byId('jpmFundSearchBtn').onclick = () => {
      const currentTyped = String(byId('jpmFundAcc')?.value || '').trim();
      openJournalFundSearchModal(state.customers, record, currentTyped);
    };
    if (byId('jpmFundAcc')) byId('jpmFundAcc').onkeyup = (e) => { if (e.key === 'Enter') refreshFundDisplay(); };
  }

  // SURGICAL ADDITION 2026-09-24 (client-reported bug fix): a browsable
  // customer picker for the Journal Posting funding-account field, matching
  // every other "Search" button in the app (openCustomerSearchModal,
  // openJournalCustomerSearchModal) instead of the silent exact-match-only
  // lookup it had before. Picking a customer here has to close this modal
  // and re-open the posting modal with that account preset, since only one
  // modal can be shown at a time.
  function openJournalFundSearchModal(list, record, currentTyped) {
    const renderRows = arr => arr.map(c=>`<tr class="customer-search-row" data-pick-fund-row="${c.id}"><td>${escapeHtml(c.accountNumber || '')}</td><td><button type="button" class="customer-name-pick" data-pick-fund="${c.id}">${escapeHtml(c.name || '')}</button></td><td>${escapeHtml(c.phone || '')}</td><td class="customer-search-action-cell"><button type="button" class="secondary tiny-btn customer-pick-btn" data-pick-fund="${c.id}">Select</button></td></tr>`).join('');
    openModal('Customer Search', `<div class="stack customer-search-modal"><input id="modalFundCustomerSearch" class="entry-input"><div class="table-wrap customer-search-table-wrap"><table class="table customer-search-table"><thead><tr><th>Account Number</th><th>Name</th><th>Phone</th><th class="customer-search-action-head">Action</th></tr></thead><tbody id="modalFundCustomerRows">${renderRows(list)}</tbody></table></div></div>`, [
      { label: 'Cancel', className: 'secondary', onClick: () => openJournalPostModal(record, currentTyped) }
    ]);
    const pickFundCustomer = (id) => {
      const c = state.customers.find(x => x.id === id);
      if (!c) return showToast('Customer not found');
      openJournalPostModal(record, c.accountNumber);
    };
    const bindPicks = () => {
      qq('[data-pick-fund]').forEach(el => el.onclick = (event) => { event.stopPropagation(); pickFundCustomer(el.dataset.pickFund); });
      qq('[data-pick-fund-row]').forEach(row => row.onclick = () => pickFundCustomer(row.dataset.pickFundRow));
    };
    bindPicks();
    const search = byId('modalFundCustomerSearch');
    if (search) search.oninput = () => {
      const qv = search.value.trim().toLowerCase();
      const filtered = !qv ? list : list.filter(c => String(c.accountNumber).includes(qv) || String(c.name || '').toLowerCase().includes(qv));
      byId('modalFundCustomerRows').innerHTML = renderRows(filtered); bindPicks();
    };
  }

  // SURGICAL ADDITION 2026-09-14 (client-confirmed design): every Journal is
  // now listed here — draft, sent, approved, or rejected — filterable by
  // date and searchable by Journal Number. Replaces the journal-sourced
  // rows that used to blend into Statement of Account (moved because it's
  // the STAFF's own record of what they posted, not the customer's).
  // 2026-11-02 (client): saved journals live in this browser only, so a journal
  // sent from another device (or one whose local copy is gone) never showed up
  // in the Register. Every journal approval request the app can see is now also
  // listed, built from the request itself, unless the local record exists.
  function allJournalRecords() {
    const local = journalsVisibleToCurrentStaff(state.journals || []);
    const known = new Set((state.journals || []).map(j => String(j.journalNumber || '')));
    const fromApprovals = [];
    (state.approvals || []).forEach(req => {
      if (req.type !== 'customer_credit_journal' && req.type !== 'customer_debit_journal') return;
      const p = req.payload || {};
      const jn = String(p.journalNumber || '');
      if (!jn || known.has(jn)) return;
      known.add(jn);
      fromApprovals.push({
        id: `ap_${req.id}`, fromApproval: true, journalNumber: jn,
        kind: req.type === 'customer_credit_journal' ? 'credit' : 'debit',
        date: p.date || '', journalDate: p.journalDate || '', confirmedBy: p.confirmedBy || '',
        description: p.description || '', counterparty: p.counterparty || '',
        staffId: p.staffId || '', staffName: p.staffName || req.requestedByName || '',
        formAmount: Number(p.formAmount || 0), rows: Array.isArray(p.rows) ? p.rows : [],
        fieldNote: p.fieldNote || null, status: 'sent', createdAt: req.requestedAt || req.createdAt || ''
      });
    });
    return local.concat(fromApprovals);
  }

  function journalDetailBody(record) {
    const status = journalEffectiveStatus(record);
    const statusLabel = { draft: 'Draft', pending: 'Pending Approval', approved: 'Approved', rejected: 'Rejected', sent: 'Pending Approval' }[status] || status;
    const rowsHtml = (record.rows || []).map((r, i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.accountNumber||'')}</td><td>${escapeHtml(r.customerName||'')}</td><td>${money(r.amount||0)}</td></tr>`).join('');
    const kv = (k, v) => `<div class="info-item"><div class="k">${k}</div><div class="v">${escapeHtml(v || '—')}</div></div>`;
    return `<div class="stack">
        <div class="info-grid">
          ${kv('Journal Number', record.journalNumber)}${kv('Type', record.kind === 'credit' ? 'Credit Journal' : 'Debit Journal')}
          ${kv('Business Date', record.date ? fmtDate(record.date) : '')}${kv('Journal Date', record.journalDate ? fmtDate(record.journalDate) : '')}
          ${kv('Journal Name', record.counterparty)}${kv('Confirmed By', record.confirmedBy)}
          ${kv('Description', record.description)}${kv('Journal Value', money(record.formAmount || 0))}
          ${kv('Prepared By', record.staffName)}${kv('Status', statusLabel)}
        </div>
        <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Account No.</th><th>Name</th><th>Amount</th></tr></thead><tbody>${rowsHtml || '<tr><td colspan="4">No rows</td></tr>'}</tbody></table></div>
        ${record.fieldNote && record.fieldNote.dataUrl ? (String(record.fieldNote.type||'').startsWith('image/') ? `<img src="${record.fieldNote.dataUrl}" style="max-width:100%;border-radius:8px;border:1px solid var(--line)">` : `<a href="${record.fieldNote.dataUrl}" target="_blank" rel="noopener">📄 ${escapeHtml(record.fieldNote.name||'Field note')}</a>`) : ''}
      </div>`;
  }

  function renderJournalRegister() {
    const filter = state.ui.journalRegisterFilter || { preset: 'all', from: '', to: '' };
    const presets = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['all','All']];
    const searchNumber = (state.ui.journalRegisterSearch || '').trim().toUpperCase();
    // 2026-11-02 (client): oldest first, newest at the bottom.
    let list = allJournalRecords().slice().sort((a, b) => (a.createdAt || '').localeCompare(b.createdAt || ''));
    if (searchNumber) {
      // SURGICAL FIX 2026-09-24 (client-reported bug): the search box had no
      // label and only ever matched Journal Number — searching by an
      // account number involved in the journal silently returned nothing,
      // which read as "broken". Now matches either.
      // 2026-10-26 (client): also matches the performing teller's name, and
      // the search now combines with the date filter above it (From/To or
      // Daily/Weekly/Monthly) instead of replacing it. 'All' (the default)
      // keeps searching every date, exactly as before.
      list = list.filter(j =>
        String(j.journalNumber || '').toUpperCase().includes(searchNumber) ||
        String(j.staffName || '').toUpperCase().includes(searchNumber) ||
        String(j.counterparty || '').toUpperCase().includes(searchNumber) ||
        (j.rows || []).some(r => String(r.accountNumber || '').toUpperCase().includes(searchNumber) || String(r.customerName || '').toUpperCase().includes(searchNumber))
      );
    }
    list = filterByDate(list, filter);
    // 2026-10-27 (client): pick a teller from a list instead of typing.
    const tellerPick = state.ui.journalRegisterTeller || '';
    const tellerNames = Array.from(new Set(allJournalRecords().map(j => String(j.staffName || '').trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b));
    if (tellerPick) list = list.filter(j => String(j.staffName || '').trim() === tellerPick);
    const rows = list.map((j, i) => {
      const status = journalEffectiveStatus(j);
      const statusLabel = { draft: 'Draft', pending: 'Pending Approval', approved: 'Approved', rejected: 'Rejected', sent: 'Pending Approval' }[status] || status;
      const canAct = status === 'draft';
      return `<tr>
        <td>${i+1}</td>
        <td><strong>${escapeHtml(j.journalNumber)}</strong></td>
        <td>${j.date ? fmtDate(j.date) : ''}</td>
        <td>${j.journalDate ? fmtDate(j.journalDate) : ''}</td>
        <td>${j.kind === 'credit' ? 'Credit' : 'Debit'}</td>
        <td>${escapeHtml(j.staffName || '')}</td>
        <td>${money(j.formAmount || 0)}</td>
        <td><span class="status-pill status-${status}">${statusLabel}</span></td>
        <td>${canAct ? `<button class="secondary tiny-btn" data-journal-resume="${j.id}">Resume</button> <button class="tiny-btn" data-journal-send="${j.id}">Send for Approval</button>` : `<button class="secondary tiny-btn" data-journal-view="${j.id}">View</button>`}</td>
      </tr>`;
    }).join('');
    return `
      <div class="table-card">
        <div class="action-inline"><h3 style="margin:0">Journal Register</h3></div>
        <div class="note" style="margin:6px 0">Every Journal ever saved or sent, by Journal Number — draft journals here haven't been sent for approval yet.</div>
        <div class="action-inline balance-filters-row">${presets.map(([k,l])=>`<button class="filter-chip ${filter.preset===k?'active':'secondary'}" data-journal-register-preset="${k}">${l}</button>`).join('')}<label class="inline-field"><span>From</span><input id="journalRegisterFrom" type="date" lang="en-GB" value="${filter.from||''}"></label><label class="inline-field"><span>To</span><input id="journalRegisterTo" type="date" lang="en-GB" value="${filter.to||''}"></label><button class="secondary" id="journalRegisterCustomApply">Apply Custom</button></div>
        <div class="action-inline" style="margin-top:8px"><label class="inline-field"><span>Search by Journal Number, Teller Name or Account Number</span><input id="journalRegisterSearch" class="entry-input" value="${escapeHtml(searchNumber)}" placeholder="Type, then press Enter" style="max-width:260px"></label><button id="journalRegisterSearchBtn" class="secondary">Search</button><label class="inline-field"><span>Teller</span><select id="journalRegisterTeller" class="entry-input" style="max-width:220px"><option value="">All Tellers</option>${tellerNames.map(n => `<option value="${escapeHtml(n)}" ${n === tellerPick ? 'selected' : ''}>${escapeHtml(n)}</option>`).join('')}</select></label></div>
        <div class="table-wrap" style="margin-top:10px"><table class="table"><thead><tr><th>S/N</th><th>Journal No.</th><th>Business Date</th><th>Journal Date</th><th>Kind</th><th>Staff</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows || '<tr><td colspan="9">No journals found</td></tr>'}</tbody></table></div>
      </div>`;
  }

  function bindJournalRegister() {
    // 2026-11-03: refresh from the database each time the Register opens
    // (at most every 4 seconds), re-drawing only if something changed.
    if (journalsInDb() && Date.now() - journalsLastSync > 4000) {
      journalsLastSync = Date.now();
      syncJournalsFromGateway().then(changed => { if (changed && state.ui.tool === 'journal_register') renderWorkspace(); }).catch(() => {});
    }
    qq('[data-journal-register-preset]').forEach(btn => btn.onclick = () => {
      state.ui.journalRegisterFilter = { preset: btn.dataset.journalRegisterPreset, from: '', to: '' };
      save(); renderWorkspace();
    });
    if (byId('journalRegisterCustomApply')) byId('journalRegisterCustomApply').onclick = () => {
      state.ui.journalRegisterFilter = { preset: 'custom', from: byId('journalRegisterFrom')?.value || '', to: byId('journalRegisterTo')?.value || '' };
      save(); renderWorkspace();
    };
    const searchInput = byId('journalRegisterSearch');
    if (searchInput) {
      searchInput.onkeyup = (e) => {
        if (e.key !== 'Enter') return;
        state.ui.journalRegisterSearch = searchInput.value;
        save(); renderWorkspace();
      };
      // 2026-11-02 (client): search as you type (account number, customer name,
      // journal number, teller) — Enter/button still work.
      let regTimer = null;
      searchInput.oninput = () => {
        clearTimeout(regTimer);
        regTimer = setTimeout(() => {
          state.ui.journalRegisterSearch = searchInput.value;
          save(); renderWorkspace();
          const again = byId('journalRegisterSearch');
          if (again) { again.focus(); const n = again.value.length; try { again.setSelectionRange(n, n); } catch (_e) {} }
        }, 350);
      };
    }
    if (byId('journalRegisterSearchBtn')) byId('journalRegisterSearchBtn').onclick = () => {
      state.ui.journalRegisterSearch = byId('journalRegisterSearch')?.value || '';
      save(); renderWorkspace();
    };
    if (byId('journalRegisterTeller')) byId('journalRegisterTeller').onchange = (e) => {
      state.ui.journalRegisterTeller = e.target.value || '';
      save(); renderWorkspace();
    };
    qq('[data-journal-resume]').forEach(btn => btn.onclick = async () => {
      const record = (state.journals || []).find(j => j.id === btn.dataset.journalResume);
      if (!record) return showToast('Journal not found');
      await ensureJournalFull(record);
      const staff = currentStaff();
      // Resuming loads the draft's rows into TODAY's working journal slot
      // for this staff/kind, and remembers the draft's id so Save/Submit
      // update THIS record instead of minting a new Journal Number.
      state.ui.journalStandaloneKind = record.kind;
      state.ui.tool = record.kind === 'debit' ? 'journal_debit' : 'journal_credit';
      const visibilityKey = `${staff.id}:${businessDate()}:${record.kind}`;
      state.ui.staffJournals ||= {};
      state.ui.staffJournalAttachments ||= {};
      state.ui.generatedJournals ||= {};
      state.ui.staffJournals[visibilityKey] = record.rows.map(r => ({ ...r }));
      state.ui.staffJournalAttachments[visibilityKey] = { fieldNote: record.fieldNote || null, loading: false };
      state.ui.generatedJournals[visibilityKey] = record.rows.length > 0;
      state.ui.resumingJournalId = record.id;
      state.ui.telleringDrafts ||= {};
      const resumeDraft = state.ui.telleringDrafts[visibilityKey] ||= { singleCharges: { apply: false, checked: {}, values: {} }, journalCharges: { apply: false, checked: {}, values: {} } };
      resumeDraft.journalFormAmount = record.formAmount ? String(record.formAmount) : '';
      resumeDraft.journalFormMode = record.formPaymentMode || 'cash';
      resumeDraft.journalDescription = record.description || '';
      resumeDraft.journalConfirmedBy = record.confirmedBy || '';
      resumeDraft.journalDate = record.journalDate || '';
      state.ui.journalCounterpartyDraft = record.counterparty || '';
      save();
      renderWorkspace();
    });
    qq('[data-journal-send]').forEach(btn => btn.onclick = () => {
      const record = (state.journals || []).find(j => j.id === btn.dataset.journalSend);
      if (!record) return showToast('Journal not found');
      if (isBusinessDateClosed(businessDate())) return showToast(businessDateClosedMessage(businessDate()));
      openJournalPostModal(record);
    });
    qq('[data-journal-view]').forEach(btn => btn.onclick = async () => {
      const record = allJournalRecords().find(j => j.id === btn.dataset.journalView);
      if (!record) return showToast('Journal not found');
      await ensureJournalFull(record);
      openModal(`${record.journalNumber}`, journalDetailBody(record), [{ label: 'Close', className: 'secondary', onClick: closeModal }]);
    });
  }


  function renderJournalTool(kind) {
    const title = kind === 'credit' ? 'Credit' : 'Debit';
    const st = currentStaff();
    // REDESIGN 2026-08-19: replaced the Cash/Posting Cash/Variance tiles with
    // a more direct till reconciliation view. Opening Cash is literally the
    // teller's operational account balance (same figure Teller Balances
    // shows); Cash Received/Withdrawal are today's approved CASH-mode
    // transactions only (reusing the exact helpers Close of Day already uses
    // for this, so the numbers stay consistent across screens); Till is what
    // should physically be in the drawer right now.
    const tillBreakdown = (() => {
      // SURGICAL FIX 2026-09-04: Opening Cash here must exclude today's own
      // customer postings — they're already added back below as Cash
      // Received/Cash Withdrawal (cash-mode only). Passing businessDate()
      // gives "balance as of the start of today," so the Till math below
      // adds today's activity exactly once (client-confirmed: at a new
      // business date, Till = Opening Cash, then adjusts from there).
      return getTillBreakdown(st?.id, businessDate());
    })();
    state.ui.generatedJournals ||= {};
    state.ui.collapsedJournals ||= {};
    const journalKey = `${st?.id || 'staff'}:${businessDate()}:${kind}`;
    state.ui.telleringDrafts ||= {};
    const telleringDraft = state.ui.telleringDrafts[journalKey] ||= { singleCharges: { apply: false, checked: {}, values: {} }, journalCharges: { apply: false, checked: {}, values: {} } };
    telleringDraft.singleCharges ||= { apply: false, checked: {}, values: {} };
    telleringDraft.singleCharges.checked ||= {};
    telleringDraft.singleCharges.values ||= {};
    telleringDraft.journalCharges ||= { apply: false, checked: {}, values: {} };
    telleringDraft.journalCharges.checked ||= {};
    telleringDraft.journalCharges.values ||= {};
    const isCreditKind = kind === 'credit';
    // SURGICAL FIX 2026-09-29 (client-confirmed paper design): Direct
    // Posting laid out as the client's sheet — same grid as Non Cash, with
    // the till breakdown (values over labels) and the red Post button at
    // the foot. Element ids are unchanged, so bindJournal keeps working.
    return `
      <div class="tellering-stack spec-color-scheme">
        <div class="nc-sheet dp-sheet">
          <div class="nc-form">
            <div class="nc-grid">
              <div class="nc-head">${title} Entry <span class="nc-head-date">Business Date: ${fmtDate(businessDate())}</span></div>
              <div class="nc-label">Account Number</div>
              <div class="nc-cell"><input id="txAcc" class="entry-input" maxlength="12" value="${escapeHtml(String(state.ui.txAccDraft || ''))}" autocomplete="off"></div>
              <div class="nc-cell"><button id="txSearch" class="nc-mini-btn">Search</button></div>
              <div class="nc-cell nc-tag">Teller ID</div>
              <div class="nc-cell"><div class="display-field" id="txTellerId">${escapeHtml(tellerIdLabel(st))}</div></div>

              <div class="nc-label">Account Name</div>
              <div class="nc-cell nc-span-4"><div class="display-field" id="txName">—</div></div>

              <div class="nc-label">Account Balance</div>
              <div class="nc-cell nc-span-2"><div class="display-field" id="txBalance">—</div></div>
              <div class="nc-cell nc-span-2"></div>

              <div class="nc-label">Description</div>
              <div class="nc-cell nc-span-4"><input id="txDetails" class="entry-input" value="${escapeHtml(String(state.ui.txDetailsDraft || ''))}"></div>

              <div class="nc-label nc-label-grey">${isCreditKind ? 'Received By' : 'Paid By'}</div>
              <div class="nc-cell"><input id="txCounterparty" class="entry-input" value="${escapeHtml(String(state.ui.txCounterpartyDraft || ''))}"></div>
              <div class="nc-cell nc-tag">Account Status</div>
              <div class="nc-cell nc-status-cell nc-span-2"><span class="acct-status-chip" id="txAccountStatus">—</span></div>

              <div class="nc-label nc-label-grey">${isCreditKind ? 'Amount Received' : 'Amount Paid'}</div>
              <div class="nc-cell"><input id="txAmount" class="entry-input" type="number" value="${escapeHtml(String(state.ui.txAmountDraft || ''))}"></div>
              <div class="nc-cell nc-tag">Account Type</div>
              <div class="nc-cell nc-span-2"><div class="display-field" id="txAccountType">—</div></div>

              <div class="nc-cell nc-till-val"><span id="postingOpeningCash">${money(tillBreakdown.openingCash)}</span></div>
              <div class="nc-cell nc-till-val"><span id="postingCashReceived">${money(tillBreakdown.cashReceived)}</span></div>
              <div class="nc-cell nc-till-val"><span id="postingCashWithdrawal">${money(tillBreakdown.cashWithdrawal)}</span></div>
              <div class="nc-cell nc-till-val"><span class="${tillBreakdown.till < 0 ? 'balance-negative' : ''}" id="postingTill">${money(tillBreakdown.till)}</span></div>
              <div class="nc-cell nc-post-cell"><button id="txPostSingle" class="nc-post-btn">Post</button></div>
              <div class="nc-till-label">Opening Cash</div>
              <div class="nc-till-label">Cash Received</div>
              <div class="nc-till-label">Cash Withdrawal</div>
              <div class="nc-till-label">Till</div>
            </div>
          </div>
        </div>
      </div>`;
  }

  function renderJournalPaneMarkup(kind) {
    const st = currentStaff();
    state.ui.generatedJournals ||= {};
    state.ui.collapsedJournals ||= {};
    const journalKey = `${st?.id || 'staff'}:${businessDate()}:${kind}`;
    const journalVisible = !!state.ui.generatedJournals[journalKey];
    const journalCollapsed = !!state.ui.collapsedJournals[journalKey];
    state.ui.telleringDrafts ||= {};
    const telleringDraft = state.ui.telleringDrafts[journalKey] ||= { singleCharges: { apply: false, checked: {}, values: {} }, journalCharges: { apply: false, checked: {}, values: {} } };
    telleringDraft.journalCharges ||= { apply: false, checked: {}, values: {} };
    telleringDraft.journalCharges.checked ||= {};
    telleringDraft.journalCharges.values ||= {};
    if (!journalVisible) {
      // SURGICAL PATCH 2026-09-22 (client-confirmed design): a Journal is now
      // disconnected from the teller's operational balance entirely — the
      // Journal Value is typed out by the staff on the Journal form itself
      // (see journalFormAmount below), not derived from/limited by their
      // current operational balance. So journal creation is never gated on
      // balance here; the operational account only gets called up later, at
      // Journal Posting time (openJournalPostModal), when a specific saved
      // journal is actually sent for approval.
      return `<div class="tellering-sheet journal-start-sheet form-card spec-color-scheme"><div class="action-row" style="justify-content:center;padding:24px 0"><button id="genJournalStartBtn" class="sheet-btn">Generate ${kind === 'credit' ? 'Credit' : 'Debit'} Journal</button></div></div>`;
    }
    const isCreditKind = kind === 'credit';
    const resumingRecord = state.ui.resumingJournalId ? (state.journals || []).find(j => j.id === state.ui.resumingJournalId) : null;
    const journalNumberText = resumingRecord ? resumingRecord.journalNumber : `${nextJournalNumber()} (assigned on Save)`;
    // SURGICAL FIX 2026-09-29 (client-confirmed paper design): Journal
    // laid out as the client's sheet — header block (Journal Number/Date,
    // Name/Confirmed By, Description/Value), the S/N table with Edit/Delete
    // and a Total + Save Journal row, then the single-entry form with its
    // red Post button. Element ids are unchanged, so bindJournal keeps
    // working; the extra controls (balance/variance,
    // charges, submit/clear/collapse, field note) are kept below.
    return `<div class="journal-center-wrap spec-color-scheme jr-sheet" id="journalPaneWrap">
        <div class="journal-pane" id="journalPane">
          <div class="nc-form">
            <div class="jr-grid">
              <div class="nc-head">${isCreditKind ? 'Credit' : 'Debit'} Entries</div>
              <div class="jr-label">Journal Number</div>
              <div class="jr-cell"><div class="display-field" id="journalNumberPreview">${escapeHtml(journalNumberText)}</div></div>
              <div class="jr-label">Business Date</div>
              <div class="jr-cell"><div class="display-field" id="journalBusinessDate">${fmtDate(businessDate())}</div></div>

              <div class="jr-label">Journal Name</div>
              <div class="jr-cell"><input id="journalCounterparty" class="entry-input" placeholder="${isCreditKind ? 'e.g. Received By Daniel' : 'e.g. Paid By Daniel'}" value="${escapeHtml(String(state.ui.journalCounterpartyDraft || ''))}"></div>
              <div class="jr-label">Confirmed By</div>
              <div class="jr-cell"><input id="journalConfirmedBy" class="entry-input" value="${escapeHtml(String(telleringDraft.journalConfirmedBy || ''))}"></div>

              <div class="jr-label">Journal Date</div>
              <div class="jr-cell"><input id="journalDate" class="entry-input" type="date" lang="en-GB" max="${escapeHtml(businessDate())}" value="${escapeHtml(String(telleringDraft.journalDate || ''))}"></div>
              <div class="jr-label">Journal Description</div>
              <div class="jr-cell"><input id="journalDescription" class="entry-input" value="${escapeHtml(String(telleringDraft.journalDescription || ''))}"></div>
              <div class="jr-label">Journal Value</div>
              <div class="jr-cell"><input id="journalFormAmount" class="entry-input" type="text" inputmode="decimal" value="${escapeHtml(String(telleringDraft.journalFormAmount || ''))}"></div>

              <div class="jr-label">Balance / Variance</div>
              <div class="jr-cell jr-kpis" style="grid-column:span 3"><span id="journalFormRunning">${money(0)}</span><span class="jr-variance balance-negative" id="journalFormVariance">${money(0)}</span></div>
            </div>
            <div class="journal-pane-actions ${journalCollapsed ? '' : 'journal-pane-actions-hidden'}"><button id="journalCollapseTopBtn" class="secondary">${journalCollapsed ? 'Expand Journal' : 'Collapse Journal'}</button></div>
            <div class="journal-pane-body ${journalCollapsed ? 'hidden' : ''}" id="journalPaneBody">
              <table class="jr-table"><thead><tr><th>S/N</th><th>Account Number</th><th>Account Name</th><th>${isCreditKind ? 'Amount Received' : 'Amount Paid'}</th><th>Action</th></tr></thead><tbody id="journalRows"></tbody>
                <tfoot><tr><td colspan="3" class="jr-total-label">Total</td><td class="jr-total-value" id="journalTotalPosted">${money(0)}</td><td class="jr-save-cell"><button id="journalSaveDraft" class="nc-post-btn">Save Journal</button></td></tr></tfoot>
              </table>

              <div class="nc-grid jr-entry-grid">
                <div class="nc-head">${isCreditKind ? 'Credit' : 'Debit'} Entry</div>
                <div class="nc-label">Account Number</div>
                <div class="nc-cell"><input id="journalAcc" class="entry-input" maxlength="12" value="${escapeHtml(String(state.ui.journalAccDraft || ''))}" autocomplete="off"></div>
                <div class="nc-cell"><button id="journalSearchBtn" type="button" class="nc-mini-btn">Search</button></div>
                <div class="nc-cell nc-tag">Account Status</div>
                <div class="nc-cell nc-status-cell"><span class="acct-status-chip" id="journalAccountStatus">—</span></div>

                <div class="nc-label">Account Name</div>
                <div class="nc-cell nc-span-4"><div class="display-field" id="journalName">—</div></div>

                <div class="nc-label">Account Balance</div>
                <div class="nc-cell"><div class="display-field" id="journalAccBalance">—</div></div>
                <div class="nc-cell nc-tag">Teller ID</div>
                <div class="nc-cell"><div class="display-field" id="journalRowTellerId">—</div></div>
                <div class="nc-cell nc-post-cell"><button id="journalAddRow" type="button" class="nc-post-btn">Post</button></div>

                <div class="nc-label nc-label-grey">${isCreditKind ? 'Amount Received' : 'Amount Paid'}</div>
                <div class="nc-cell"><input id="journalAmount" class="entry-input" type="text" inputmode="decimal" value="${escapeHtml(String(telleringDraft.journalAmount || ''))}"></div>
                <div class="nc-cell nc-tag">Account Type</div>
                <div class="nc-cell"><div class="display-field" id="journalAccountType">—</div></div>
              </div>
              <div class="action-row journal-submit-row nc-extra-row"><button id="journalSubmit" class="secondary">Submit Journal</button><button class="secondary" id="journalClear">Clear Journal</button><button id="journalCollapseBtn" class="secondary">${journalCollapsed ? 'Expand Journal' : 'Collapse Journal'}</button></div>
            </div>
          </div>
        </div>
        </div>`;
  }

  function renderJournalStandalone() {
    // SURGICAL PATCH 2026-09-23 (client-confirmed design): the Credit/Debit
    // choice is now made by which sidebar item was clicked ("Debit Entry" /
    // "Credit Entry" under Journal Posting, mirroring Direct Posting) — no
    // more in-page toggle to switch it after the fact.
    const kind = state.ui.journalStandaloneKind === 'debit' ? 'debit' : 'credit';
    return `<div class="tellering-stack">
        ${renderJournalPaneMarkup(kind)}
      </div>`;
  }

  const APPROVAL_REVIEW_LOCK_MS = 60 * 1000;

  function normalizeApprovalLock(lock) {
    if (!lock) return null;
    const startedAt = typeof lock.startedAt === 'number' ? lock.startedAt : new Date(lock.startedAt || 0).getTime();
    if (!startedAt || Date.now() - startedAt > APPROVAL_REVIEW_LOCK_MS) return null;
    return {
      staffId: lock.staffId || lock.staff_id || '',
      staffName: lock.staffName || lock.staff_name || 'Staff',
      startedAt
    };
  }

  function cleanupApprovalReviewLocks() {
    state.ui ||= {};
    state.ui.approvalReviewLocks ||= {};
    Object.keys(state.ui.approvalReviewLocks).forEach(id => {
      if (!normalizeApprovalLock(state.ui.approvalReviewLocks[id])) delete state.ui.approvalReviewLocks[id];
    });
  }

  function getApprovalReviewLock(id) {
    cleanupApprovalReviewLocks();
    const approval = (state.approvals || []).find(a => a.id === id);
    return normalizeApprovalLock(approval?.payload?.__reviewLock) || normalizeApprovalLock(state.ui.approvalReviewLocks?.[id]);
  }

  function setApprovalReviewLock(id) {
    if (!id) return Promise.resolve(defaultResultErr('APPROVAL_LOCK_INVALID', 'Approval request id is required'));
    cleanupApprovalReviewLocks();
    const staff = currentStaff();
    state.ui.approvalReviewLocks[id] = {
      staffId: staff?.id || '',
      staffName: staff?.name || 'Staff',
      startedAt: Date.now()
    };
    save();
    if (isSupabaseApprovalMode() && gateway.approvals?.setReviewLock) {
      return gateway.approvals.setReviewLock({
        requestId: id,
        staffId: getStaffBackendId(staff),
        staffName: staff?.name || 'Staff',
        ttlMs: APPROVAL_REVIEW_LOCK_MS
      }).then(async (result) => {
        if (result?.ok) {
          await syncApprovalsByIdFromGateway([id]);
          return result;
        }
        if (result?.error?.code === 'APPROVAL_LOCKED') {
          delete state.ui.approvalReviewLocks[id];
          state.ui.selectedApprovalIds = (state.ui.selectedApprovalIds || []).filter(x => x !== id);
          save();
          showToast(result.error.message || 'This request is being reviewed by another staff');
          await syncApprovalsByIdFromGateway([id]);
          renderWorkspace();
          return result;
        }
        return result;
      }).catch((error) => {
        delete state.ui.approvalReviewLocks[id];
        state.ui.selectedApprovalIds = (state.ui.selectedApprovalIds || []).filter(x => x !== id);
        save();
        return defaultResultErr('APPROVAL_LOCK_FAILED', 'Could not mark this request as being reviewed.', error);
      });
    }
    return Promise.resolve(defaultResultOk(state.ui.approvalReviewLocks[id]));
  }

  function isApprovalLockedByOther(id) {
    // Timer-based review locking removed per client request — routing a
    // request to a specific approving officer (plus admin, who can always
    // approve) is the intended safeguard against double-approval now, not
    // a countdown lock.
    return false;
  }

  function approvalReviewIndicator(approval) {
    return '—';
  }

  function renderApprovals() {
    if (!state.ui.codAdminDate) {
      const lastClosed = latestClosedBusinessDay();
      state.ui.codAdminDate = lastClosed?.date || businessDate();
    }
    state.ui.selectedApprovalIds ||= [];
    cleanupApprovalReviewLocks();
    const categories = { customer_service: ['account_opening','account_maintenance','account_reactivation','account_block','account_closure'], tellering: ['cash_receipt','inter_staff_credit','customer_credit','customer_debit','customer_credit_journal','customer_debit_journal'], non_cash: ['intra_bank_transfer'], others: ['float_topup','operational_entry','create_operational_account','close_of_day','temp_grant','wallet_fund','debt_repayment'] };
    reconcileBusinessDateFromClosures();
    const openDate = businessDate();
    const currentSection = state.ui.approvalsSection || 'tellering';
    const viewer = currentStaff();
    // A sidebar sub-item (e.g. "Approve Journals") narrows the queue to its
    // own request types; the plain section tabs keep their whole category.
    const subTool = APPROVAL_SUB_TOOLS[state.ui.tool];
    const allRows = state.approvals.filter(a => {
      // 2026-10-26 (client): Income & Expense postings are approved with the
      // other postings, by the method used: a transfer/non-cash method goes to
      // Non Cash Postings, anything else to Direct Postings.
      const opEntryHere = a.type === 'operational_entry' && (state.ui.tool === 'appr_direct' || state.ui.tool === 'appr_non_cash')
        && ((/transfer|non.?cash|bank|pos|cheque/i.test(String(a.payload?.paymentMode || a.payload?.paymentMethod || a.payload?.method || a.payload?.mode || ''))) === (state.ui.tool === 'appr_non_cash'));
      if (!(subTool ? (subTool.types.includes(a.type) || opEntryHere) : categories[currentSection].includes(a.type))) return false;
      if (a.status !== 'pending') return false; // decided items live in Approval History now
      const reqDate = approvalBusinessDate(a.type, a.payload || {});
      // Approval Queue belongs to the CURRENT OPEN business date only.
      // Closed dates belong to COD Resolution/history and must not remain
      // mixed with actionable approval work.
      if (reqDate !== openDate || isBusinessDateClosed(reqDate)) return false;
      // Officer routing: approving officers only see requests sent to them.
      // Admin always sees everything, regardless of routing.
      if (isApprovalRoutedAway(a, viewer)) return false;
      return true;
    });
    const limit = state.ui.approvalsLimit || 20;
    const approvals = allRows.slice(0, limit);
    const rows = approvals.map((a, i) => {
      const lockedByOther = isApprovalLockedByOther(a.id);
      const canSelect = a.status === 'pending' && !lockedByOther;
      const checked = state.ui.selectedApprovalIds.includes(a.id) ? 'checked' : '';
      const disabledAttr = canSelect ? '' : 'disabled';
      const actionDisabled = lockedByOther ? 'disabled' : '';
      const pendingActions = a.status === 'pending' ? `<div class="inline-actions"><button type="button" data-approve="${a.id}" class="success" ${actionDisabled}>Approve</button><button type="button" data-reject="${a.id}" class="danger" ${actionDisabled}>Reject</button></div>` : '';
      const journalActions = a.type.includes('_journal') ? `<div class="stack-actions"><button type="button" data-inspect-journal="${a.id}" class="secondary">Inspect</button>${pendingActions}</div>` : '';
      const normalActions = !a.type.includes('_journal') ? (a.status === 'pending' ? pendingActions : a.approvedBy || '—') : '';
      // View removed: the open account's own headings are shown inline below instead of a separate modal.
      const detailCell = ['account_opening','account_maintenance','account_reactivation'].includes(a.type)
        ? approvalAccountHeadingsInline(a)
        : approvalDetails(a);
      return `<tr><td><input type="checkbox" class="approval-select-checkbox" data-approval-select="${a.id}" ${checked} ${disabledAttr}></td><td>${i+1}</td><td>${prettyApprovalType(a.type)}</td><td>${approvalSubmittedBy(a)}</td><td>${detailCell}</td><td>${fmtDate(approvalDisplayDate(a))}</td><td><span class="badge ${a.status}">${a.status}</span></td><td>${journalActions}${normalActions}</td></tr>`;
    }).join('');
    state.ui.codResolutionLimit ||= 10;
    const codRows=(state.cod||[]).filter(c=>{
      const codDate = String(c.date || c.businessDate || '').slice(0,10);
      // COD Resolution visibility must be controlled by the COD record itself,
      // not by the current open date. If one device has not advanced yet, using
      // openDate here hides the closed-day evidence and makes resolution vanish.
      if (!/^\d{4}-\d{2}-\d{2}$/.test(codDate)) return false;
      // Once a COD record has entered the resolution lifecycle, its own
      // status controls visibility. Do not re-hide it because a later live
      // balance recalculation temporarily reads zero/stale values. Resolution
      // records must remain visible until they are explicitly resolved.
      if (c.status === 'resolved' || c.status === 'draft') return false;
      return true;
    }).slice(0, state.ui.codResolutionLimit || 10).map((c,i)=>{
      const creditCash = Number(c.totalCreditCash ?? approvedCreditTotalForDateByMode(c.staffId, c.date, 'cash'));
      const creditTransfer = Number(c.totalCreditTransfer ?? approvedCreditTotalForDateByMode(c.staffId, c.date, 'transfer'));
      const debitCash = Number(c.totalDebitCash ?? approvedDebitTotalForDateByMode(c.staffId, c.date, 'cash'));
      const debitTransfer = Number(c.totalDebitTransfer ?? approvedDebitTotalForDateByMode(c.staffId, c.date, 'transfer'));
      const formAmount = Number(c.formAmount ?? c.openingBalance ?? getStaffOperationalBalance(c.staffId));
      const remaining = Number(c.remainingBalance ?? c.runningFloat ?? codRemainingBalance(formAmount, creditCash + creditTransfer, debitCash + debitTransfer));
      const variance = Number(c.variance ?? Math.abs(remaining));
      const overdraw = Number(c.overdraw ?? Math.max(0, -remaining));
      const recomputedVariance = Math.abs(remaining);
      const recomputedOverdraw = Math.max(0, -remaining);
      const codResolveId = c.id || c.codSubmissionId || c.cod_submission_id || '';
      const isAnomaly = remaining < 0;
      const statusBadge = isAnomaly
        ? `<span class="badge flagged">Anomaly</span>`
        : (recomputedVariance > 0 ? `<span class="badge">Variance</span>` : `<span class="badge balanced">Balanced</span>`);
      return `<tr><td>${i+1}</td><td>${fmtDate(c.date)}</td><td>${escapeHtml(c.staffName || '')}</td><td>${money(formAmount)}</td><td>${money(creditCash + creditTransfer)}</td><td>${money(debitCash + debitTransfer)}</td><td class="${remaining<0?'balance-negative':''}">${money(remaining)}</td><td class="${recomputedVariance>0?'balance-negative':''}">${money(recomputedVariance)}</td><td class="${recomputedOverdraw>0?'balance-negative':''}">${money(recomputedOverdraw)}</td><td>${statusBadge}</td><td>${escapeHtml(c.resolutionNote || c.note || '—')}</td><td>${(canCloseBusinessDay())?`<button data-cod-resolve="${codResolveId}" class="warning">Resolve</button>`:'Awaiting Resolution'}</td></tr>`;
    }).join('');
    const selected = state.ui.codAdminDate;
    const codStatusRows = state.staff.filter(s => (staffPermsOf(s)).includes('credit') || (staffPermsOf(s)).includes('debit') || (state.cod||[]).some(c=>c.staffId===s.id && c.date===selected)).map((s,i)=>{ const rec=(state.cod||[]).find(c=>c.staffId===s.id && c.date===selected); const status=rec?(rec.status==='resolved'?'Resolved':rec.status==='flagged'?'Anomaly':'Submitted'):'Missing'; const opBalance = rec ? Number(rec.formAmount ?? rec.openingBalance ?? getStaffOperationalBalance(rec.staffId)) : null; const remaining = rec ? Number(rec.remainingBalance ?? rec.runningFloat ?? 0) : null; return `<tr><td>${i+1}</td><td>${escapeHtml(s.name || '')}</td><td>${staffRoleLabels(s)}</td><td>${status}</td><td>${rec?money(opBalance):'—'}</td><td>${rec?money(remaining):'—'}</td></tr>`; }).join('');
    const codResolutionAllCount = (state.cod||[]).filter(c=>{ const d=String(c.date||c.businessDate||'').slice(0,10); return /^\d{4}-\d{2}-\d{2}$/.test(d) && c.status!=='resolved' && c.status!=='draft'; }).length;
    const codResolutionMoreLess = codResolutionAllCount > 0 ? ('<div class="action-row" style="margin-top:8px">' + (codResolutionAllCount > (state.ui.codResolutionLimit||10) ? '<button id="codResolutionMore" class="secondary">Show More</button>' : '') + ((state.ui.codResolutionLimit||10) > 10 ? '<button id="codResolutionLess" class="secondary">Show Less</button>' : '') + '</div>') : '';
    const moreLess = `<div class="action-row">${allRows.length > limit ? `<button id="approvalsMore" class="secondary">Show More</button>`:''}${limit > 20 ? `<button id="approvalsLess" class="secondary">Show Less</button>`:''}</div>`;
    return `<div class="stack">${codRows?`<div class="table-card"><h3>COD Resolution Queue</h3><div class="note">Any teller who closes the day with a negative operational balance shows here as an <strong>Anomaly</strong> — Treasury/Admin resolves it directly with the staff involved.</div><div class="table-wrap cod-resolution-table-wrap"><table class="table cod-resolution-table"><thead><tr><th>S/N</th><th>Date</th><th>Staff</th><th>Form</th><th>Total Credits</th><th>Total Debits</th><th>Remaining Balance</th><th>Variance</th><th>Overdraw</th><th>Status</th><th>Note</th><th>Action</th></tr></thead><tbody>${codRows}</tbody></table></div>${codResolutionMoreLess}</div>`:''}${subTool ? '' : `<div class="approvals-top-controls"><div class="tool-tabs approvals-sections" id="approvalsSectionTabs">${[['customer_service','Customer Service'],['tellering','Teller'],['non_cash','Non Cash'],['others','Administration']].map(([k,l])=>`<button class="tool-tab ${currentSection===k?'active':''}" data-approval-section="${k}">${l}</button>`).join('')}</div></div>`}<div class="table-card" id="approvalsQueueCard"><div class="action-row" style="justify-content:space-between;align-items:center"><h3>${subTool ? escapeHtml(subTool.label) : 'Approval Queue'}</h3><div class="inline-actions"><button type="button" id="approvalSelectAll" class="secondary tiny-btn">Select Visible Pending</button><button type="button" id="approvalClearSelection" class="secondary tiny-btn">Clear</button><button type="button" id="approvalBulkApprove" class="success tiny-btn">Approve Selected</button><button type="button" id="approvalBulkReject" class="danger tiny-btn">Reject Selected</button></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Select</th><th>S/N</th><th>Request</th><th>Submitted By</th><th>Details</th><th>Date</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows || '<tr><td colspan="8" class="muted">No requests yet</td></tr>'}</tbody></table></div>${moreLess}</div>${canCloseBusinessDay()?`<div class="table-card"><h3>COD Daily Submission Status</h3><div class="action-inline"><div class="inline-field compact"><span>COD Date</span><input type="date" lang="en-GB" id="codAdminDate" value="${selected}"></div></div><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Staff</th><th>Office</th><th>Status</th><th>Form</th><th>Remaining Balance</th></tr></thead><tbody>${codStatusRows}</tbody></table></div></div>`:''}</div>`;
  }

  function renderApprovalHistory() {
    const allTypes = ['account_opening','account_maintenance','account_reactivation','cash_receipt','inter_staff_credit','customer_credit','customer_debit','customer_credit_journal','customer_debit_journal','intra_bank_transfer','float_topup','operational_entry','create_operational_account','close_of_day','temp_grant','wallet_fund','debt_repayment'];
    const decided = (state.approvals || [])
      .filter(a => allTypes.includes(a.type) && a.status !== 'pending' && !isApprovalRoutedAway(a))
      .sort((a, b) => new Date(approvalDisplayDate(b) || 0) - new Date(approvalDisplayDate(a) || 0));
    const limit = state.ui.approvalHistoryLimit || 30;
    const rows = decided.slice(0, limit).map((a, i) => {
      const detailCell = ['account_opening','account_maintenance','account_reactivation'].includes(a.type)
        ? approvalAccountHeadingsInline(a)
        : approvalDetails(a);
      return `<tr><td>${i+1}</td><td>${prettyApprovalType(a.type)}</td><td>${approvalSubmittedBy(a)}</td><td>${detailCell}</td><td>${fmtDate(approvalDisplayDate(a))}</td><td><span class="badge ${a.status}">${a.status}</span></td><td>${escapeHtml(a.approvedBy || a.approvedByName || '—')}</td></tr>`;
    }).join('');
    const moreLess = `<div class="action-row">${decided.length > limit ? `<button id="approvalHistoryMore" class="secondary">Show More</button>`:''}${limit > 30 ? `<button id="approvalHistoryLess" class="secondary">Show Less</button>`:''}</div>`;
    return `<div class="stack"><div class="table-card"><h3>Approval History</h3><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Request</th><th>Submitted By</th><th>Details</th><th>Date</th><th>Status</th><th>Decided By</th></tr></thead><tbody>${rows || '<tr><td colspan="7" class="muted">No decided requests yet</td></tr>'}</tbody></table></div>${moreLess}</div></div>`;
  }

  function approvalSubmittedBy(a) {
    const p = a.payload || {};
    const staffId = p.staffId || a.requestedBy;
    const staff = (state.staff || []).find(s => s.id === staffId) || {};
    const roleLabel = staffRoleLabels(staff);
    const name = a.requestedByName || staffName(staffId);
    const routedNote = p.assignedApproverName ? `<div class="muted" style="font-size:0.85em">→ ${escapeHtml(p.assignedApproverName)}</div>` : '';
    if (a.type === 'customer_credit_journal' || a.type === 'customer_debit_journal') return `${escapeHtml(name)} • ${roleLabel || 'Staff'} • Journal${routedNote}`;
    return `${escapeHtml(name)} • ${roleLabel || 'Staff'}${routedNote}`;
  }
  function approvalDetails(a) {
    const p = a.payload || {};
    if (a.type === 'customer_credit') return `${money(p.amount)} to ${escapeHtml(customerName(p.customerId) || p.accountNumber || '')}${chargeSummaryText(p)}${p.details ? ' • ' + escapeHtml(p.details) : ''}`;
    if (a.type === 'customer_debit') return `${money(p.amount)} from ${escapeHtml(customerName(p.customerId) || p.accountNumber || '')}${p.details ? ' • ' + escapeHtml(p.details) : ''}`;
    if (a.type === 'customer_credit_journal' || a.type === 'customer_debit_journal') { const rows = p.rows || p.entries || []; const total = rows.reduce((s,r)=>s+Number(r.amount||0),0); const totalCharges = rows.reduce((s,r)=>s+getTotalChargeAmount(r),0); const attachmentTag = p.fieldNote ? ' • Note attached' : ''; const chargeTag = a.type === 'customer_credit_journal' && totalCharges > 0 ? ` • Total Charge ${money(totalCharges)}` : ''; const formTag = ` • Form ${money(p.formAmount || 0)}`; return `${rows.length} item${rows.length===1?'':'s'} • Total ${money(total)}${formTag}${chargeTag}${attachmentTag}`; }
    if (a.type === 'wallet_fund') return `${escapeHtml(staffName(p.staffId) || '')} • Wallet fund • ${money(p.amount)}`;
    if (a.type === 'debt_repayment') return `${escapeHtml(staffName(p.staffId) || '')} • Debt repayment • ${money(p.amount)}`;
    return requestSummary(a);
  }

  function approvalAccountHeadingsInline(a) {
    const p = a.payload || {};
    const esc = (v) => String(v ?? '—').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
    const line = (label, value) => value ? `<span class="approval-heading-item"><strong>${label}:</strong> ${esc(value)}</span>` : '';
    if (a.type === 'account_opening') {
      const acctType = p.accountType || 'customer';
      const isCustomer = acctType === 'customer';
      const acctTypeLabels = { customer: 'Customer Account', staff_operational: 'Teller Account', staff_salary: 'Staff Salary Account', expense: 'Expense Account', income: 'Income Account' };
      // SURGICAL PATCH 2026-08-14: Customer Service now assigns the account
      // number at Account Opening (required, not optional) — the approving
      // officer only SEES it here, never assigns or edits it. Previously a
      // pending customer request showed an editable input letting the
      // approver type/overwrite the number themselves.
      // SURGICAL PATCH 2026-08-24: system-assigned types (Teller/Staff
      // Salary/Expense/Income) now also get their number at creation time,
      // same as customer accounts — so the approver sees the real number
      // here too, not a "generated on approval" placeholder.
      const assignInput = line('Account Number', p.generatedAccountNumber || (isCustomer ? 'Not assigned — return to Customer Service' : 'Not yet assigned — return to Customer Service'));
      return `<div class="approval-heading-inline">
        ${line('Type', acctTypeLabels[acctType] || acctType)}
        ${line('Name', p.fullName || p.name)}
        ${isCustomer ? line('Phone', p.phone) : ''}
        ${isCustomer ? line('Address', p.address) : ''}
        ${isCustomer ? line('NIN', p.nin) : ''}
        ${isCustomer ? line('BVN', p.bvn) : ''}
        ${acctType === 'staff_operational' ? line('Linked Staff', p.linkedStaffName || p.linkedStaffId) : ''}
        ${assignInput}
      </div>`;
    }
    if (a.type === 'account_maintenance') {
      const patch = p.patch || {};
      const customer = state.customers.find(c => c.id === p.customerId);
      return `<div class="approval-heading-inline">
        ${line('Account Number', p.accountNumber)}
        ${line('Current Name', customer?.name)}
        ${line('Updated Name', patch.name)}
        ${line('Updated Phone', patch.phone)}
        ${line('Updated Address', patch.address)}
        ${line('Updated NIN', patch.nin)}
        ${line('Updated BVN', patch.bvn)}
        ${line('Old A/N', patch.oldAccountNumber)}
      </div>`;
    }
    if (a.type === 'account_reactivation') {
      const customer = state.customers.find(c => c.id === p.customerId);
      return `<div class="approval-heading-inline">
        ${line('Account Number', p.accountNumber)}
        ${line('Name', customer?.name)}
        ${line('Current Status', customerStatusLabel(customer))}
      </div>`;
    }
    return approvalDetails(a);
  }

  function prettyApprovalType(type) {
    return {
      account_opening:'Account Opening', account_maintenance:'Account Maintenance', account_reactivation:'Account Reactivation', account_block:'Account Block', account_closure:'Account Closure',
      customer_credit:'Credit', customer_debit:'Debit', customer_credit_journal:'Credit Journal', customer_debit_journal:'Debit Journal', cash_receipt:'Cash Receipt', inter_staff_credit:'Staff Account Credit', intra_bank_transfer:'Non Cash Transaction', float_topup:'Float Top-Up', operational_entry:'Operational Entry',
      create_operational_account:'Operational Account', close_of_day:'Close of Day', temp_grant:'Temporary Grant', wallet_fund:'Wallet Funding', debt_repayment:'Debt Repayment'
    }[type] || type;
  }

  function requestSummary(a) {
    const p = a.payload || {};
    if (a.type === 'intra_bank_transfer') return `Non cash: ${money(p.amount)} from ${escapeHtml(p.sourceAccountName||p.sourceAccountNumber||'—')} → ${escapeHtml(p.destAccountName||p.destAccountNumber||'—')} • ${p.date}`;
    if (a.type === 'cash_receipt') return `${money(p.amount)} received by ${escapeHtml(p.staffName || 'Treasury')}${p.treasuryAccountName || p.treasuryAccountNumber ? ` into ${escapeHtml(p.treasuryAccountName || p.treasuryAccountNumber)}` : ''} • ${p.date}`;
    if (a.type === 'inter_staff_credit') return `${money(p.amount)} to ${escapeHtml(p.targetAccountName || p.targetAccountNumber || 'staff account')}${p.collectorName ? ` • Received from ${escapeHtml(p.collectorName)}` : ''} • ${p.date}`;
    if (a.type === 'float_topup') return `${money(p.amount)} to ${escapeHtml(p.staffName || 'staff')} for ${p.date}`;
    if (a.type === 'customer_credit' || a.type === 'customer_debit') return `${escapeHtml(p.accountNumber || '')} • ${money(p.amount)}${a.type === 'customer_credit' ? chargeSummaryText(p) : ''}`;
    if (a.type === 'account_opening') return `${escapeHtml(p.name || '')} • Phone ${escapeHtml(p.phone || '—')} • NIN ${escapeHtml(p.nin || '—')} • BVN ${escapeHtml(p.bvn || '—')}`;
    if (a.type === 'account_maintenance') return `${escapeHtml(p.accountNumber || '')} • update`;
    if (a.type === 'account_reactivation') return `${escapeHtml(p.accountNumber || '')} • reactivate`;
    if (a.type === 'account_block') return `${escapeHtml(p.accountNumber || '')} • block (freeze)`;
    if (a.type === 'account_closure') return `${escapeHtml(p.accountNumber || '')} • close account`;
    if (a.type === 'operational_entry') return `${escapeHtml(p.accountName || '')} • ${money(p.amount)}`;
    if (a.type === 'create_operational_account') return `${escapeHtml(p.category || '')} • ${escapeHtml(p.name || '')}`;
    if (a.type === 'close_of_day') return `${escapeHtml(p.staffName || '')} • ${p.date} • Form ${money(p.formAmount ?? p.openingBalance ?? 0)} • Remaining ${money(p.remainingBalance ?? p.runningFloat ?? 0)}`;
    if (a.type === 'temp_grant') return `${escapeHtml(staffName(p.staffId) || '')} • ${TOOL_LABELS[p.tool]} = ${p.enabled ? 'ON' : 'OFF'}`;
    if (a.type === 'wallet_fund') return `${escapeHtml(staffName(p.staffId) || '')} • Wallet fund • ${money(p.amount)}`;
    if (a.type === 'debt_repayment') return `${escapeHtml(staffName(p.staffId) || '')} • Debt repayment • ${money(p.amount)}`;
    return '—';
  }

  function normalizeCommissionAmount(value) {
    const num = Number(value);
    return Number.isFinite(num) ? num : 0;
  }

  async function openRequestDetailModal(reqId) {
  let req = state.approvals.find(r => r.id === reqId);
  if (!req) return;

  // SURGICAL FIX 2026-08-22: the routine list/poll sync now reads from a
  // stripped-down view (egress fix) that replaces photo/field-note bytes
  // with lightweight placeholders — the in-memory copy from state.approvals
  // may not carry the real image data. Fetch the single full record fresh
  // before showing details/wiring the Approve action, so the photo preview
  // AND the actual payload used to approve are always complete — this is
  // also what keeps the approve flow from ever posting a stripped photo to
  // a customer record. Scoped to only the request types that can actually
  // carry these heavy fields, so other types don't pay an extra round trip.
  if (gateway.approvals?.getApprovalRequestById && (req.type === 'account_opening' || req.type === 'customer_credit_journal' || req.type === 'customer_debit_journal')) {
    try {
      const full = await gateway.approvals.getApprovalRequestById(reqId);
      if (full?.ok && full.data) {
        req = { ...req, ...full.data };
        const idx = state.approvals.findIndex(r => r.id === reqId);
        if (idx !== -1) state.approvals[idx] = req;
      }
    } catch (err) {
      console.warn('[DUCESS] Full request fetch failed, showing list-level data', err);
    }
  }

  const p = req.payload || {};
  const esc = (v) => String(v ?? '—')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const field = (label, value, cls = '') =>
    `<div class="field ${cls}"><label>${label}</label><div class="display-field">${esc(value)}</div></div>`;

  const customer = state.customers.find(c => c.id === p.customerId);
  const photoSrc = p.photo || p.photoRef || p.photo_path || '';
  const photoBlock = `<div class="approval-photo-stack"><button type="button" class="secondary" id="approvalPhotoToggle">Display Picture</button><div class="approval-photo-panel hidden" id="approvalPhotoPanel"><div class="photo-box approval-photo-box">${photoSrc ? `<img src="${photoSrc}" alt="customer photo">` : '<span>No Photo</span>'}</div></div></div>`;

  let html = '';

  if (req.type === 'account_opening') {
    const acctType = p.accountType || 'customer';
    const isCustomer = acctType === 'customer';
    const acctTypeLabels = { customer: 'Customer Account', staff_operational: 'Teller Account', staff_salary: 'Staff Salary Account', expense: 'Expense Account', income: 'Income Account' };
    // SURGICAL PATCH 2026-08-14: same change as approvalAccountHeadingsInline
    // above — approver sees the number Customer Service already assigned,
    // never types or edits it here.
    // SURGICAL PATCH 2026-08-24: system-assigned types now get their number
    // at creation time too, same as customer accounts.
    const assignBlock = field('Account Number', p.generatedAccountNumber || 'Not assigned — return to Customer Service', 'field-account');

    html = `<div class="stack approval-opening-linear">
      ${field('Account Type', acctTypeLabels[acctType] || acctType, 'field-wide')}
      ${field('Name / Display Name', p.fullName || p.name, 'field-wide')}
      ${isCustomer ? field('Phone', p.phone, 'field-phone') : ''}
      ${isCustomer ? field('Address', p.address, 'field-wide') : ''}
      ${isCustomer ? field('NIN', p.nin, 'field-id') : ''}
      ${isCustomer ? field('BVN', p.bvn, 'field-bvn') : ''}
      ${acctType === 'staff_operational' ? field('Linked Staff', p.linkedStaffName || p.linkedStaffId || '—', 'field-wide') : ''}
      ${assignBlock}
      ${isCustomer ? photoBlock : ''}
    </div>`;
  } else if (req.type === 'account_maintenance') {
    const patch = p.patch || {};
    html = `<div class="stack"><div class="form-grid two modal-cs-grid">
      ${field('Customer Name', customer?.name || patch.name, 'field-wide')}
      ${field('Account Number', p.accountNumber, 'field-account')}
      ${field('Current Status', customerStatusLabel(customer), 'field-status')}
      ${field('Old Account Number', patch.oldAccountNumber, 'field-account')}
      ${field('Updated Name', patch.name, 'field-wide')}
      ${field('Updated Phone', patch.phone, 'field-phone')}
      ${field('Updated Address', patch.address, 'field-wide')}
      ${field('Updated NIN', patch.nin, 'field-id')}
      ${field('Updated BVN', patch.bvn, 'field-bvn')}
    </div>${photoBlock}</div>`;
  } else if (req.type === 'customer_credit_journal' || req.type === 'customer_debit_journal') {
    const rows = Array.isArray(p.rows) ? p.rows : Array.isArray(p.entries) ? p.entries : [];
    const total = rows.reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const totalCharges = rows.reduce((sum, row) => sum + getTotalChargeAmount(row), 0);
    const rowHtml = rows.map((row, idx) => {
      const chargeText = req.type === 'customer_credit_journal' ? chargeInlineMeta(row) : '';
      const detailsText = [row.details || '', chargeText].filter(Boolean).join(' • ');
      return `<tr>
        <td>${idx + 1}</td>
        <td>${esc(row.customerName || customerName(row.customerId) || '—')}</td>
        <td>${esc(row.accountNumber || '—')}</td>
        <td>${money(row.amount)}</td>
        <td>${esc(row.receivedOrPaidBy || row.paidTo || '')}</td>
        <td>${esc(detailsText || '—')}</td>
      </tr>`;
    }).join('');
    const note = p.fieldNote;
    const noteBlock = note ? (note.dataUrl && String(note.type || '').startsWith('image/')
      ? `<div class="note">Field note: ${esc(note.name || 'Attached file')}</div><img src="${note.dataUrl}" style="max-width:100%;border-radius:8px;border:1px solid var(--line)">`
      : `<div class="note">Field note attached: ${esc(note.name || 'Attached file')}</div>`) : '';
    html = `<div class="stack">
      <div class="form-grid three modal-cs-grid">
        ${field('Journal Number', p.journalNumber || '—', 'field-account')}
        ${field('Business Date', p.date || p.businessDate || '—', 'field-date')}
        ${field('Journal Date', p.journalDate || '—', 'field-date')}
        ${field('Journal Name', p.counterparty || '—', 'field-wide')}
        ${field('Confirmed By', p.confirmedBy || '—', 'field-wide')}
        ${field('Description', p.description || '—', 'field-wide')}
        ${field('Items', rows.length, 'field-account')}
        ${field('Total Amount', money(total), 'field-account')}
        ${field('Journal Form Amount', money(p.formAmount || 0), 'field-account')}
        ${req.type === 'customer_credit_journal' ? field('Total Charges', money(totalCharges), 'field-account') : ''}
      </div>
      <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Account Name</th><th>Account Number</th><th>Amount</th><th>${req.type === 'customer_credit_journal' ? 'Received By' : 'Paid By'}</th><th>Details</th></tr></thead><tbody>${rowHtml || '<tr><td colspan="6" class="muted">No journal entries</td></tr>'}</tbody></table></div>
      ${noteBlock}
    </div>`;
  } else if (req.type === 'account_block' || req.type === 'account_closure') {
    html = `<div class="stack"><div class="form-grid two modal-cs-grid">
      ${field('Customer Name', customer?.name || p.accountName, 'field-wide')}
      ${field('Account Number', p.accountNumber, 'field-account')}
      ${field('Current Status', customerStatusLabel(customer), 'field-status')}
      ${field('Balance', money(customer?.balance || 0), 'field-account')}
      ${field('Requested Action', req.type === 'account_block' ? 'Block (freeze) Account' : 'Close Account — customer removed, records kept', 'field-submit')}
      ${p.reason ? field('Reason', p.reason, 'field-wide') : ''}
    </div>${photoBlock}</div>`;
  } else if (req.type === 'account_reactivation') {
    html = `<div class="stack"><div class="form-grid two modal-cs-grid">
      ${field('Customer Name', customer?.name, 'field-wide')}
      ${field('Account Number', p.accountNumber, 'field-account')}
      ${field('Current Status', customerStatusLabel(customer), 'field-status')}
      ${field('Requested Action', 'Reactivate Account', 'field-submit')}
    </div>${photoBlock}</div>`;
  } else if (req.type === 'intra_bank_transfer') {
    html = `<div class="stack"><div class="form-grid three modal-cs-grid">
      ${field('Teller', p.staffName || '—', 'field-wide')}
      ${field('Date', p.date || '—', 'field-date')}
      ${field('Amount', money(p.amount || 0), 'field-account')}
      ${field('From — Debit', `${p.sourceAccountName || '—'} (${p.sourceAccountNumber || '—'})`, 'field-wide')}
      ${field('To — Credit', `${p.destAccountName || '—'} (${p.destAccountNumber || '—'})`, 'field-wide')}
      ${p.details ? field('Narration', p.details, 'field-wide') : ''}
    </div></div>`;
  } else if (req.type === 'cash_receipt') {
    html = `<div class="stack"><div class="form-grid three modal-cs-grid">
      ${field('Treasury', p.staffName || '—', 'field-wide')}
      ${p.treasuryAccountId ? field('Treasury Account', `${p.treasuryAccountName || '—'} (${p.treasuryAccountNumber || '—'})`, 'field-wide') : ''}
      ${field('Date', p.date || '—', 'field-date')}
      ${field('Amount', money(p.amount || 0), 'field-account')}
      ${p.note ? field('Note', p.note, 'field-wide') : ''}
    </div></div>`;
  } else if (req.type === 'inter_staff_credit') {
    html = `<div class="stack"><div class="form-grid three modal-cs-grid">
      ${field('By', p.staffName || '—', 'field-wide')}
      ${p.sourceAccountId ? field('From (Account)', `${p.sourceAccountName || '—'} (${p.sourceAccountNumber || '—'})`, 'field-wide') : ''}
      ${field('To (Account)', `${p.targetAccountName || '—'} (${p.targetAccountNumber || '—'})`, 'field-wide')}
      ${field('Date', p.date || '—', 'field-date')}
      ${field('Amount', money(p.amount || 0), 'field-account')}
      ${p.note ? field('Note', p.note, 'field-wide') : ''}
    </div></div>`;
  } else {
    html = `<pre>${esc(JSON.stringify(p, null, 2))}</pre>`;
  }

  const actions = [{ label: 'Close', className: 'secondary', onClick: closeModal }];

  if (req.status === 'pending') {
    actions.unshift({
      label: 'Reject',
      className: 'danger',
      onClick: async () => {
        closeModal();
        showProcessing('Rejecting request...');
        await nextPaint();

        try {
          if (isApprovalLockedByOther(req.id)) {
            hideProcessing();
            showToast('This request is being reviewed by another staff');
            return;
          }
          const result = await rejectRequestRemote(req.id);

          if (result?.ok === false) {
            hideProcessing();
            showToast(result?.error?.message || 'Unable to reject request');
            return;
          }
          showToast('Request rejected');
        } finally {
          hideProcessing();
        }
      }
    });

    actions.unshift({
      label: 'Approve',
      className: 'success',
      onClick: async () => {
        if (req.type === 'account_opening') {
          const acctType = req.payload?.accountType || 'customer';
          // SURGICAL PATCH 2026-08-14: the approver used to be able to type
          // in the account number themselves via #approvalAssignAccount if
          // Customer Service left it blank. That input no longer exists —
          // Customer Service must assign it at Account Opening. If it's
          // somehow still missing here, block the approval instead of
          // silently letting it through unassigned.
          if (acctType === 'customer' && !String(req.payload?.generatedAccountNumber || '').trim()) {
            return showToast('No account number assigned. Return this request to Customer Service.');
          }
          // staff_operational, staff_salary, expense, income — system-assigned via RPC
        }

        closeModal();
        showProcessing('Approving request...');
        await nextPaint();

        try {
          if (isApprovalLockedByOther(req.id)) {
            hideProcessing();
            showToast('This request is being reviewed by another staff');
            return;
          }
          const result = await approveRequestRemote(req.id, req.payload);

          if (result?.ok === false) {
            hideProcessing();
            showToast(result?.error?.message || 'Unable to approve request');
            return;
          }
          showToast('Request approved');
        } finally {
          hideProcessing();
        }
      }
    });
  }

  openModal(prettyApprovalType(req.type), html, actions);

  const btn = byId('approvalPhotoToggle');
  if (btn) btn.onclick = () => byId('approvalPhotoPanel')?.classList.toggle('hidden');
}


function nextPaint() {
  return new Promise(resolve =>
    requestAnimationFrame(() =>
      requestAnimationFrame(() => resolve())
    )
  );
}

  function renderPermissions() {
    const tools = ['check_balance','account_opening','account_maintenance','account_reactivation','account_statement','credit','debit','approval_queue','business_balance'];
    return `
      <div class="stack">
        <div class="table-card">
          <h3>Administrative Working Tools</h3>
          <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Staff</th><th>Office</th>${tools.map(t=>`<th>${TOOL_LABELS[t]}</th>`).join('')}</tr></thead>
          <tbody>${state.staff.map((s,i)=>`<tr><td>${i+1}</td><td>${escapeHtml(s.name || '')}</td><td>${staffRoleLabels(s)}</td>${tools.map(t=>`<td>${hasPermission(t,s)?'YES':'NO'}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
        </div>
        <div class="form-card">
          <h3>Temporary Access Grant</h3>
          <div class="form-grid three">
            <div class="field"><label>Staff</label><select id="grantStaff" class="entry-input">${state.staff.map(s=>`<option value="${s.id}">${escapeHtml(s.name || '')}</option>`).join('')}</select></div>
            <div class="field"><label>Tool</label><select id="grantTool" class="entry-input">${Object.keys(TOOL_LABELS).map(t=>`<option value="${t}">${TOOL_LABELS[t]}</option>`).join('')}</select></div>
            <div class="field"><label>Switch</label><select id="grantEnabled" class="entry-input"><option value="true">Grant Access</option><option value="false">Switch Off</option></select></div>
          </div>
          <div class="action-row"><button id="grantSubmit">Send Grant Request</button></div>
        </div>
      </div>`;
  }

  function renderOperationalPosting() {
    const allAccts = [
      ...state.operations.incomeAccounts.map(a=>({...a,category:'income'})),
      ...state.operations.expenseAccounts.map(a=>({...a,category:'expense'}))
    ];
    return `
      <div class="stack">
        <div class="form-card">
          <h3>Income & Expense Posting</h3>
          <div class="form-grid three">
            <div class="field"><label>Account</label><select id="oeAccount" class="entry-input">${allAccts.map(a=>`<option value="${a.id}">${escapeHtml(a.accountNumber || '')} — ${escapeHtml(a.name || '')}</option>`).join('')}</select></div>
            <div class="field"><label>Amount</label><input id="oeAmount" class="entry-input" type="number"></div>
            <div class="field"><label>Date</label><input id="oeDate" class="entry-input" type="date" lang="en-GB" value="${businessDate()}"></div>
            <div class="field"><label>Note</label><input id="oeNote" class="entry-input"></div>
            <div class="field"><label>Type</label><div class="display-field" id="oeKindDisplay">Auto from account</div></div>
          </div>
          <div class="action-row compact-action-row"><button id="oeSubmit" class="tiny-btn">Submit for Approval</button></div>
        </div>
      </div>`;
  }

  function operationalAccountTotals(a) {
    const entries = state.operations.entries.filter(e => e.accountId === a.id);
    const totalCredit = entries.filter(e => e.kind === 'income').reduce((s,e)=>s+Number(e.amount||0),0);
    const totalDebit = entries.filter(e => e.kind === 'expense').reduce((s,e)=>s+Number(e.amount||0),0);
    return { totalDebit, totalCredit, balance: totalCredit - totalDebit };
  }

  function operationalBalanceTable(title, accounts) {
    const sorted = [...accounts].sort((a,b)=> String(a.accountNumber||'').localeCompare(String(b.accountNumber||''), undefined, {numeric:true}));
    let grandBalance = 0, grandDebit = 0, grandCredit = 0;
    const rows = sorted.map((a,i) => {
      const t = operationalAccountTotals(a);
      grandDebit += t.totalDebit; grandCredit += t.totalCredit; grandBalance += t.balance;
      return `<tr><td>${i+1}</td><td>${escapeHtml(a.name)}</td><td>${money(t.totalDebit)}</td><td>${money(t.totalCredit)}</td><td>${money(t.balance)}</td><td>${fmtDate(a.createdAt)}</td></tr>`;
    }).join('');
    return `<div class="table-card"><h3>${title}</h3><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Account Name</th><th>Total Debit</th><th>Total Credit</th><th>Balance</th><th>Start Date</th></tr></thead><tbody>${rows || `<tr><td colspan="6">No accounts</td></tr>`}<tr class="total-row"><td colspan="2"><strong>Total</strong></td><td><strong>${money(grandDebit)}</strong></td><td><strong>${money(grandCredit)}</strong></td><td><strong>${money(grandBalance)}</strong></td><td></td></tr></tbody></table></div></div>`;
  }

  function renderOperationalAccounts() {
    const allAccts = [
      ...state.operations.incomeAccounts.map(a=>({...a,category:'income'})),
      ...state.operations.expenseAccounts.map(a=>({...a,category:'expense'}))
    ];
    return `
      <div class="stack">
        <div class="layout-grid two">
          ${staffHasRole(currentStaff(), 'admin_officer') ? `<div class="form-card">
            <h3>Create Account</h3>
            <div class="form-grid three">
              <div class="field"><label>Category</label><select id="oaCategory" class="entry-input"><option value="income">Income</option><option value="expense">Expense</option></select></div>
              <div class="field"><label>Account Name</label><input id="oaName" class="entry-input"></div>
              <div class="field"><label>Account Number</label><div class="display-field" id="oaNumberPreview">I1</div></div>
            </div>
            <div class="action-row compact-action-row"><button id="oaCreate" class="tiny-btn">Submit for Approval</button></div>
          </div>` : ''}
          <div class="form-card">
            <h3>Post into Account</h3>
            <div class="form-grid three">
              <div class="field"><label>Account</label><select id="oeAccount" class="entry-input">${allAccts.map(a=>`<option value="${a.id}">${escapeHtml(a.accountNumber || '')} — ${escapeHtml(a.name || '')}</option>`).join('')}</select></div>
              <div class="field"><label>Amount</label><input id="oeAmount" class="entry-input" type="number"></div>
              <div class="field"><label>Date</label><input id="oeDate" class="entry-input" type="date" lang="en-GB" value="${businessDate()}"></div>
              <div class="field"><label>Note</label><input id="oeNote" class="entry-input"></div>
              <div class="field"><label>Type</label><div class="display-field" id="oeKindDisplay">Auto from account</div></div>
            </div>
            <div class="action-row compact-action-row"><button id="oeSubmit" class="tiny-btn">Submit for Approval</button></div>
          </div>
        </div>
        ${operationalBalanceTable("All Income Balance", state.operations.incomeAccounts)}
        ${operationalBalanceTable("All Expense Balance", state.operations.expenseAccounts)}
      </div>`;
  }

  function renderCustomerDirectory() {
    const search = String(state.ui.customerDirectorySearch || '').trim().toLowerCase();
    const customers = [...accountsInSegment('customer')]
      .sort((a,b)=> String(a.accountNumber||'').localeCompare(String(b.accountNumber||''), undefined, {numeric:true}));
    const filteredCustomers = search
      ? customers.filter(c => [c.name, c.accountNumber, c.phone, c.email].some(value => String(value || '').toLowerCase().includes(search)))
      : customers;
    const totalCustomers = customers.length;
    let grandBalance = 0, grandDebit = 0, grandCredit = 0;
    const bodyRows = filteredCustomers.map((c,i)=>{
      const credits = (c.transactions || []).filter(tx => tx.type === 'credit').reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
      const debits = (c.transactions || []).filter(tx => tx.type === 'debit').reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
      grandCredit += credits; grandDebit += debits; grandBalance += Number(c.balance || 0);
      const frozen = isCustomerFrozen(c);
      const inactive = c.active === false;
      const statusLabel = c.closed ? 'Closed' : inactive ? 'Removed' : frozen ? 'Frozen' : 'Active';
      const statusColor = inactive ? '#fee2e2' : frozen ? '#fef9c3' : '#d1fae5';
      const statusText = inactive ? '#991b1b' : frozen ? '#854d0e' : '#065f46';
      return `<tr style="${inactive ? 'opacity:0.5' : ''}"><td>${i+1}</td><td>${escapeHtml(c.name)}</td><td>${c.accountNumber || '—'}</td><td>${money(debits)}</td><td>${money(credits)}</td><td>${money(Number(c.balance || 0))}</td><td>${fmtDate(c.createdAt)}</td><td><span style="padding:1px 6px;border-radius:8px;font-size:0.8em;background:${statusColor};color:${statusText}">${statusLabel}</span></td><td>${!inactive ? `<button class="secondary" style="font-size:10px;padding:3px 8px" data-remove-customer="${c.id}">Remove</button>` : '<span style="font-size:10px;color:var(--muted)">Removed</span>'}</td></tr>`;
    }).join('');
    return `
      <div class="stack">
        <div class="kpi-row balance-kpi-row">
          <div class="kpi"><div class="label">Total Customers</div><div class="number">${totalCustomers}</div></div>
        </div>
        <div class="table-card">
          <div class="action-inline"><h3 style="margin:0">All Customers' Balance</h3></div>
          <div class="form-grid one" style="margin-top:12px">
            <div class="field"><label>Search Customer</label><input id="customerDirectorySearch" class="entry-input" value="${escapeHtml(state.ui.customerDirectorySearch || '')}"></div>
          </div>
          <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Account Name</th><th>Account Number</th><th>Total Debit</th><th>Total Credit</th><th>Balance</th><th>Start Date</th><th>Status</th><th>Action</th></tr></thead><tbody>${bodyRows || '<tr><td colspan="9">No matching customers</td></tr>'}${filteredCustomers.length ? `<tr class="total-row"><td colspan="3"><strong>Total</strong></td><td><strong>${money(grandDebit)}</strong></td><td><strong>${money(grandCredit)}</strong></td><td><strong>${money(grandBalance)}</strong></td><td colspan="3"></td></tr>` : ''}</tbody></table></div>
          <div class="action-row" style="margin-top:14px"><button id="customerDirectoryCloseBtn" class="secondary">Collapse Directory</button></div>
        </div>
      </div>`;
  }

  function renderStaffRoster() {
    state.ui.staffDirectorySearch = state.ui.staffDirectorySearch || '';
    const search = String(state.ui.staffDirectorySearch || '').trim().toLowerCase();
    const filtered = state.staff.filter((s) => {
      const staffCode = String(s.staffCode || s.staff_code || s.staffId || s.id || '').toLowerCase();
      const staffName = String(s.name || s.full_name || '').toLowerCase();
      return !search || staffName.includes(search) || staffCode.includes(search);
    }).sort((a,b) => String(a.name || a.full_name || '').localeCompare(String(b.name || b.full_name || '')));
    const bodyRows = filtered.map((s, i) => {
      const staffCode = s.staffCode || s.staff_code || s.staffId || s.id || '—';
      const staffName = s.name || s.full_name || '—';
      const staffRole = s.role || s.role_code || '';
      const isActive = s.active !== false && s.is_active !== false;
      const acc = ensureStaffAccount(s.id);
      // SURGICAL ADDITION 2026-09-08 (client-facing diagnostic gap): this
      // "Account Number" column has always been the legacy wallet number
      // (ensureStaffAccount), NOT the real T#### operational account used
      // by Cash Receipt/Fund Account/Till — there was previously no way to
      // see whether that real account actually exists for a given staff
      // member without checking Supabase directly. Shown here now.
      const opAccount = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === s.id);
      return `<tr><td>${i+1}</td><td>${escapeHtml(staffName)}</td><td><code style="font-size:0.85em">${escapeHtml(String(staffCode))}</code> <button class="secondary tiny-btn" data-staff-edit-code="${s.id}" title="Staff ID is manager-assigned — must stay unique">Edit ID</button></td><td><code style="font-size:0.85em">${escapeHtml(String(acc.accountNumber || '—'))}</code></td><td>${opAccount ? `<code style="font-size:0.85em">${escapeHtml(String(opAccount.accountNumber || opAccount.account_number || ''))}</code>` : `<span style="color:var(--text-muted)">— none —</span>`}</td><td>${hasAssignedRole(s) ? escapeHtml(roleLabelOf(staffRoleCode(s))) : '<span style="color:var(--text-muted);font-style:italic">Unassigned</span>'}</td><td><span style="padding:2px 8px;border-radius:10px;font-size:0.8em;background:${isActive?'#d1fae5':'#fee2e2'};color:${isActive?'#065f46':'#991b1b'}">${isActive ? 'Active' : 'Inactive'}</span></td><td><button class="secondary" data-staff-ledger="${s.id}">Ledger</button>${isAdminStaff() ? `<button class="secondary" data-staff-assign-role="${s.id}">${hasAssignedRole(s) ? 'Reassign' : 'Assign Role'}</button>` : ''}<button class="secondary" data-staff-role-history="${s.id}">Role History</button>${isAdminStaff() ? `<button class="secondary" data-staff-reset-password="${s.id}">Reset Password</button>` : ''}<button class="secondary" data-staff-toggle="${s.id}">${isActive ? 'Deactivate' : 'Reactivate'}</button></td></tr>`;
    }).join('');
    return `
      <div class="table-card">
        <div class="action-inline"><h3 style="margin:0">Staff Directory</h3><button id="adminRecoveryKeyBtn" class="secondary tiny-btn" title="Generate or regenerate Admin recovery key">Recovery Key</button>${isSupabaseApprovalMode() ? `<button id="backfillTreasuryAccountsBtn" class="secondary tiny-btn" title="One-time: opens an ADMIN operational account for any Admin staff who doesn't have one yet">Backfill Operational Accounts</button>` : ''}<button id="addStaffBtn">ADD STAFF</button></div>
        ${isAdminStaff() ? `<div class="note" style="display:flex;align-items:center;gap:8px;justify-content:space-between;margin:6px 0;padding:7px 10px"><span><strong>Admin Security:</strong> Generate or regenerate the Admin Recovery Key for password recovery.</span><button id="adminRecoveryKeyInlineBtn" class="secondary tiny-btn">Generate / Regenerate Recovery Key</button></div>` : ''}
        <div class="action-row" style="justify-content:flex-start;gap:6px;align-items:center;margin:6px 0">
          <input id="staffDirectorySearch" class="entry-input" value="${escapeHtml(state.ui.staffDirectorySearch || '')}" style="height:24px;max-width:160px;font-size:0.78em;padding:2px 8px">
        </div>
        <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Full Name</th><th>Staff ID</th><th>Account Number</th><th>Op. Account (Cash Receipt/Fund Account)</th><th>Role</th><th>Status</th><th>Action</th></tr></thead><tbody>${bodyRows || '<tr><td colspan="8">No staff found</td></tr>'}</tbody></table></div>
      </div>`;
  }

  // REDESIGN 2026-08-14: "All Staff Balance" (wallet/float balance for every
  // staff regardless of role) and the separate "Staff Salary Balance" report
  // were two different balance views under confusingly similar names. Staff
  // management actions (Add Staff, Ledger, Reset Password, Deactivate,
  // Recovery Key) already live on "Staff Directory" (renderStaffRoster,
  // above) — nothing unique here needed preserving except the wallet balance
  // table, which is exactly the source of the confusion. So this tool is now
  // fully repurposed: it shows ONLY staff_salary account balances. Role
  // classification was removed 2026-08-14 (client didn't need the filter) —
  // search by account number instead.
  // "Teller Balances" remains its own separate, unambiguous report for
  // operational T#### accounts only.
  function renderStaffDirectory() {
    state.ui.staffSalarySearch = state.ui.staffSalarySearch || '';
    const search = String(state.ui.staffSalarySearch || '').trim();
    const loading = state.ui.staffSalaryBalanceLoading;
    const rows = state.ui.staffSalaryAccountsCache || [];
    const filtered = rows.filter(r => !search || String(r.accountNumber||'').includes(search) || String(r.name||'').toLowerCase().includes(search.toLowerCase()));
    const grandBalance = filtered.reduce((s, r) => s + Number(r.balance || 0), 0);
    const bodyRows = filtered.map((r, i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.name || '—')}</td><td><code style="font-size:0.85em">${escapeHtml(String(r.accountNumber || '—'))}</code></td><td>${money(r.balance)}</td><td>${fmtDate(r.createdAt)}</td><td><span style="padding:2px 8px;border-radius:10px;font-size:0.8em;background:${r.active?'#d1fae5':'#fee2e2'};color:${r.active?'#065f46':'#991b1b'}">${r.active ? 'Active' : 'Inactive'}</span></td></tr>`).join('');
    return `
      <div class="table-card">
        <div class="action-inline"><h3 style="margin:0">Staff Salary Balance</h3></div>
        <div class="note" style="margin:6px 0">Shows Staff Salary account balances. Teller operational balances are on the separate "Teller Balances" report.</div>
        <div class="action-row" style="justify-content:flex-start;gap:6px;align-items:center;margin:6px 0">
          <input id="staffSalarySearch" class="entry-input" value="${escapeHtml(state.ui.staffSalarySearch || '')}" style="height:24px;max-width:220px;font-size:0.78em;padding:2px 8px">
          ${loading ? '<span class="muted" style="font-size:0.8em">Loading…</span>' : ''}
        </div>
        <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Account Name</th><th>Account Number</th><th>Balance</th><th>Opened</th><th>Status</th></tr></thead><tbody>${bodyRows || `<tr><td colspan="6">${loading ? 'Loading…' : 'No staff salary accounts found'}</td></tr>`}${filtered.length ? `<tr class="total-row"><td colspan="3"><strong>Total</strong></td><td><strong>${money(grandBalance)}</strong></td><td colspan="2"></td></tr>` : ''}</tbody></table></div>
      </div>`;
  }

  // ===== PERIOD BALANCES (Approval -> Daily/Weekly/Monthly/Yearly) =====
  // Period boundaries use the open business date as "today", exactly like
  // the existing balance filters (filterByDate): weekly = last 7 days,
  // monthly/yearly = the business date's month/year, custom = From..To.
  function balancePeriodRange(f) {
    const r = balancePeriodRangeOf(f);
    historyCovers(r.start || null);
    return r;
  }
  function balancePeriodRangeOf(f) {
    const ref = dateOnly(businessDate()) || '';
    const preset = f?.preset || 'daily';
    if (preset === 'all') return { start: '', end: '', preset };
    if (preset === 'custom') return { start: f.from || '', end: f.to || '', preset };
    if (preset === 'daily') return { start: ref, end: ref, preset };
    const d = new Date(`${ref}T12:00:00`);
    const iso = (x) => `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`;
    if (preset === 'weekly') { const st = new Date(d); st.setDate(d.getDate() - 6); return { start: iso(st), end: ref, preset }; }
    if (preset === 'monthly') return { start: `${ref.slice(0,7)}-01`, end: iso(new Date(d.getFullYear(), d.getMonth()+1, 0)), preset };
    return { start: `${ref.slice(0,4)}-01-01`, end: `${ref.slice(0,4)}-12-31`, preset };
  }
  const inPeriod = (iso, r) => !!iso && (!r.start || iso >= r.start) && (!r.end || iso <= r.end);
  const afterPeriod = (iso, r) => !!iso && !!r.end && iso > r.end;
  const beforePeriod = (iso, r) => !!iso && !!r.start && iso < r.start;

  // Debit/credit inside the period, plus opening/closing balances worked
  // back from the account's CURRENT balance (so they always agree with it).
  function periodFigures(currentBalance, items, r) {
    let debit = 0, credit = 0, netAfter = 0, netFrom = 0;
    items.forEach(({ iso, amount, isCredit }) => {
      const signed = isCredit ? amount : -amount;
      if (inPeriod(iso, r)) { if (isCredit) credit += amount; else debit += amount; }
      if (afterPeriod(iso, r)) netAfter += signed;
      if (!r.start || !beforePeriod(iso, r)) netFrom += signed;
    });
    const closing = Number(currentBalance || 0) - netAfter;
    const opening = Number(currentBalance || 0) - netFrom;
    return { opening, debit, credit, closing };
  }
  const txItems = (c) => (c?.transactions || []).filter(tx => tx.type === 'credit' || tx.type === 'debit').map(tx => ({ iso: filterRowDate(tx), amount: Number(tx.amount || 0), isCredit: tx.type === 'credit' }));
  const opItems = (accountId) => (state.operations.entries || []).filter(e => e.accountId === accountId).map(e => ({ iso: filterRowDate(e), amount: Number(e.amount || 0), isCredit: e.kind === 'income' }));

  function renderPeriodBar() {
    const f = state.ui.balancePeriodFilter || { preset: 'daily', from: '', to: '' };
    const r = balancePeriodRange(f);
    const presets = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['yearly','Yearly'],['all','All']];
    const label = r.preset === 'all' ? 'All dates' : `${r.start ? fmtDate(r.start) : '…'} – ${r.end ? fmtDate(r.end) : '…'}`;
    return `<div class="form-card balance-filters-card"><div class="action-inline balance-filters-row">${presets.map(([k,l]) => `<button class="filter-chip ${f.preset===k?'active':'secondary'}" data-period-preset="${k}">${l}</button>`).join('')}<label class="inline-field"><span>From</span><input id="balPeriodFrom" type="date" lang="en-GB" value="${escapeHtml(f.from || '')}"></label><label class="inline-field"><span>To</span><input id="balPeriodTo" type="date" lang="en-GB" value="${escapeHtml(f.to || '')}"></label><button id="balPeriodApply" class="secondary">Apply Custom</button></div><div class="note" style="margin-top:6px">Period: <strong>${label}</strong></div></div>`;
  }

  function periodAccountsTable(title, accounts, r, opts = {}) {
    let tO = 0, tD = 0, tC = 0, tB = 0;
    const rows = accounts.map((a, i) => {
      const fig = opts.figures ? opts.figures(a) : periodFigures(a.balance, txItems(a), r);
      tO += fig.opening; tD += fig.debit; tC += fig.credit; tB += fig.closing;
      return `<tr><td>${i+1}</td><td>${escapeHtml(a.name || '—')}</td><td>${escapeHtml(String(a.accountNumber || '—'))}</td><td>${money(fig.opening)}</td><td>${money(fig.debit)}</td><td>${money(fig.credit)}</td><td class="${fig.closing<0?'balance-negative':''}">${money(fig.closing)}</td></tr>`;
    }).join('');
    const total = accounts.length ? `<tr class="total-row"><td colspan="3"><strong>Total</strong></td><td><strong>${money(tO)}</strong></td><td><strong>${money(tD)}</strong></td><td><strong>${money(tC)}</strong></td><td><strong>${money(tB)}</strong></td></tr>` : '';
    return `<div class="table-card"><h3>${escapeHtml(title)}</h3>${opts.extra || ''}<div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Account Name</th><th>Account Number</th><th>Opening Balance</th><th>Total Debit</th><th>Total Credit</th><th>Closing Balance</th></tr></thead><tbody>${rows || `<tr><td colspan="7">${opts.empty || 'No accounts found'}</td></tr>`}${total}</tbody></table></div></div>`;
  }

  // Teller figures are rebuilt from approved requests up to a date, using the
  // same operational-balance rules as the Till box.
  function withApprovalsUpTo(iso, fn) {
    if (!iso) return fn();
    const saved = state.approvals;
    try {
      state.approvals = (saved || []).filter(a => approvalBusinessDate(a.type, a.payload || {}) <= iso);
      return fn();
    } finally { state.approvals = saved; }
  }
  const dayBefore = (iso) => { const d = new Date(`${iso}T12:00:00`); d.setDate(d.getDate() - 1); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };

  // One teller's period figures — the same rules the Teller Balances report uses.
  function tellerFigures(staffId, r) {
    const opening = r.start ? withApprovalsUpTo(dayBefore(r.start), () => getStaffOperationalBalance(staffId)) : 0;
    const closing = withApprovalsUpTo(r.end, () => getStaffOperationalBalance(staffId));
    const mine = (state.approvals || []).filter(a => a.status === 'approved' && a.payload?.staffId === staffId && inPeriod(approvalBusinessDate(a.type, a.payload || {}), r));
    const amt = (a) => a.type.endsWith('_journal') ? Number(a.payload?.formAmount || 0) : Number(a.payload?.amount || 0);
    const credit = mine.filter(a => a.type === 'customer_credit' || a.type === 'customer_credit_journal').reduce((t, a) => t + amt(a), 0);
    const debit = mine.filter(a => a.type === 'customer_debit' || a.type === 'customer_debit_journal').reduce((t, a) => t + amt(a), 0);
    return { opening, debit, credit, closing };
  }

  function renderPeriodBalance(def) {
    const r = balancePeriodRange(state.ui.balancePeriodFilter || { preset: def.preset });
    const head = renderPeriodBar();
    if (def.report === 'overall') {
      const sumGroup = (accts, itemsOf, balOf) => accts.reduce((acc, a) => { const f = periodFigures(balOf(a), itemsOf(a), r); acc.opening += f.opening; acc.debit += f.debit; acc.credit += f.credit; acc.closing += f.closing; return acc; }, { opening: 0, debit: 0, credit: 0, closing: 0 });
      const addFig = (x, y) => ({ opening: x.opening + y.opening, debit: x.debit + y.debit, credit: x.credit + y.credit, closing: x.closing + y.closing });
      const staffWallets = sumGroup((state.staff || []).map(st => { const acc = ensureStaffAccount(st.id); return { acc, wallet: (state.customers || []).find(c => c.id === acc.linkedCustomerId) }; }), x => txItems(x.wallet), x => x.acc.balance);
      const tellerSeg = accountsInSegment('tellerng').reduce((t, c) => addFig(t, tellerFigures(c.linkedStaffId, r)), { opening: 0, debit: 0, credit: 0, closing: 0 });
      const cats = [
        ["All Customers' Balance", sumGroup(accountsInSegment('customer'), txItems, c => c.balance)],
        ['All Staff Balance', addFig(staffWallets, sumGroup(accountsInSegment('staff'), txItems, c => c.balance))],
        ['Income Balance', sumGroup(state.operations.incomeAccounts || [], a => opItems(a.id), a => operationalAccountTotals(a).balance)],
        ['Expense Balance', sumGroup(state.operations.expenseAccounts || [], a => opItems(a.id), a => operationalAccountTotals(a).balance)],
        ['Tellerng Balance', tellerSeg],
        ['Treasury Balance', sumGroup(accountsInSegment('treasury'), txItems, c => c.balance)],
      ];
      const g = cats.reduce((t, [, f]) => ({ opening: t.opening + f.opening, debit: t.debit + f.debit, credit: t.credit + f.credit, closing: t.closing + f.closing }), { opening: 0, debit: 0, credit: 0, closing: 0 });
      const rows = cats.map(([n, f], i) => `<tr><td>${i+1}</td><td>${escapeHtml(n)}</td><td>${money(f.opening)}</td><td>${money(f.debit)}</td><td>${money(f.credit)}</td><td>${money(f.closing)}</td></tr>`).join('');
      return `<div class="stack">${head}<div class="table-card"><h3>${escapeHtml(def.label)}</h3><div class="note">The company's entire truth — every balance category rolled up into one business total, for the selected period.</div><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Balance Category</th><th>Opening Balance</th><th>Total Debit</th><th>Total Credit</th><th>Closing Balance</th></tr></thead><tbody>${rows}<tr class="total-row"><td colspan="2"><strong>Overall Balance of the Business</strong></td><td><strong>${money(g.opening)}</strong></td><td><strong>${money(g.debit)}</strong></td><td><strong>${money(g.credit)}</strong></td><td><strong>${money(g.closing)}</strong></td></tr></tbody></table></div></div></div>`;
    }
    const sortAccSeg = (list) => [...(list || [])].sort((x, y) => String(x.accountNumber || '').localeCompare(String(y.accountNumber || ''), undefined, { numeric: true }));
    const opFigSeg = (a) => periodFigures(operationalAccountTotals(a).balance, opItems(a.id), r);
    if (def.report === 'income' || def.report === 'expense') {
      const isInc = def.report === 'income';
      return `<div class="stack">${head}${periodAccountsTable(isInc ? 'All Income Balance' : 'All Expense Balance', sortAccSeg(isInc ? state.operations.incomeAccounts : state.operations.expenseAccounts), r, { figures: opFigSeg, empty: isInc ? 'No income accounts' : 'No expense accounts' })}</div>`;
    }
    if (def.report === 'treasury') {
      return `<div class="stack">${head}${periodAccountsTable('All Treasury Balance', sortAccSeg(accountsInSegment('treasury')), r, { empty: 'No treasury accounts' })}</div>`;
    }
    if (def.report === 'all') {
      const segs = [
        ['Customers', sortAccSeg(accountsInSegment('customer')), undefined, 'No customer accounts'],
        ['Staff', sortAccSeg(accountsInSegment('staff')), undefined, 'No staff accounts'],
        ['Income', sortAccSeg(state.operations.incomeAccounts), opFigSeg, 'No income accounts'],
        ['Expenses', sortAccSeg(state.operations.expenseAccounts), opFigSeg, 'No expense accounts'],
        ['Tellerng', sortAccSeg(accountsInSegment('tellerng')), (c) => tellerFigures(c.linkedStaffId, r), 'No teller accounts'],
        ['Treasury', sortAccSeg(accountsInSegment('treasury')), undefined, 'No treasury accounts'],
      ];
      const figOf = (list, fn) => list.reduce((t, a) => { const f = fn ? fn(a) : periodFigures(a.balance, txItems(a), r); return { opening: t.opening + f.opening, debit: t.debit + f.debit, credit: t.credit + f.credit, closing: t.closing + f.closing }; }, { opening: 0, debit: 0, credit: 0, closing: 0 });
      const totals = segs.map(([n, list, fn]) => [n, list.length, figOf(list, fn)]);
      const grand = totals.reduce((t, [, c, f]) => ({ count: t.count + c, opening: t.opening + f.opening, debit: t.debit + f.debit, credit: t.credit + f.credit, closing: t.closing + f.closing }), { count: 0, opening: 0, debit: 0, credit: 0, closing: 0 });
      const sumRows = totals.map(([n, c, f], i) => `<tr><td>${i+1}</td><td>${escapeHtml(n)}</td><td>${c}</td><td>${money(f.opening)}</td><td>${money(f.debit)}</td><td>${money(f.credit)}</td><td class="${f.closing<0?'balance-negative':''}">${money(f.closing)}</td></tr>`).join('');
      const summary = `<div class="table-card"><h3>${escapeHtml(def.label)}</h3><div class="note">Every account in its own segment, each with its own total, and all of them together below.</div><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Segment</th><th>Accounts</th><th>Opening Balance</th><th>Total Debit</th><th>Total Credit</th><th>Closing Balance</th></tr></thead><tbody>${sumRows}<tr class="total-row"><td colspan="2"><strong>All Accounts</strong></td><td><strong>${grand.count}</strong></td><td><strong>${money(grand.opening)}</strong></td><td><strong>${money(grand.debit)}</strong></td><td><strong>${money(grand.credit)}</strong></td><td><strong>${money(grand.closing)}</strong></td></tr></tbody></table></div></div>`;
      return `<div class="stack">${head}${summary}${segs.map(([n, list, fn, empty]) => periodAccountsTable(n, list, r, { figures: fn, empty })).join('')}</div>`;
    }
    if (def.report === 'customers' || def.report === 'salary') {
      const search = String(state.ui.periodBalanceSearch || '').trim().toLowerCase();
      const accounts = (state.customers || [])
        .filter(c => def.report === 'salary' ? c.accountType === 'staff_salary' : accountSegmentOf(c) === 'customer')
        .filter(c => !search || [c.name, c.accountNumber, c.phone].some(v => String(v || '').toLowerCase().includes(search)))
        .sort((a, b) => String(a.accountNumber || '').localeCompare(String(b.accountNumber || ''), undefined, { numeric: true }));
      const extra = `<div class="form-grid one" style="margin:6px 0 10px"><div class="field"><label>Search Account</label><input id="periodBalanceSearch" class="entry-input" value="${escapeHtml(state.ui.periodBalanceSearch || '')}"></div></div>`;
      return `<div class="stack">${head}${periodAccountsTable(def.label, accounts, r, { extra, empty: def.report === 'salary' ? 'No staff salary accounts found' : 'No matching customers' })}</div>`;
    }
    if (def.report === 'tellers') {
      const rows = (state.staff || []).map(st => {
        const opAcc = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === st.id);
        const opening = r.start ? withApprovalsUpTo(dayBefore(r.start), () => getStaffOperationalBalance(st.id)) : 0;
        const closing = withApprovalsUpTo(r.end, () => getStaffOperationalBalance(st.id));
        const mine = (state.approvals || []).filter(a => a.status === 'approved' && a.payload?.staffId === st.id && inPeriod(approvalBusinessDate(a.type, a.payload || {}), r));
        const amt = (a) => a.type.endsWith('_journal') ? Number(a.payload?.formAmount || 0) : Number(a.payload?.amount || 0);
        const credits = mine.filter(a => a.type === 'customer_credit' || a.type === 'customer_credit_journal').reduce((t, a) => t + amt(a), 0);
        const debits = mine.filter(a => a.type === 'customer_debit' || a.type === 'customer_debit_journal').reduce((t, a) => t + amt(a), 0);
        return `<tr><td>${escapeHtml(st.name || '')}</td><td>${staffRoleLabels(st)}</td><td>${escapeHtml(opAcc?.accountNumber || '—')}</td><td>${money(opening)}</td><td>${money(credits)}</td><td>${money(debits)}</td><td class="${closing<0?'balance-negative':''}">${money(closing)}</td><td><button class="secondary" data-staff-ledger="${st.id}">Ledger</button></td></tr>`;
      }).join('');
      return `<div class="stack">${head}<div class="table-card"><h3>${escapeHtml(def.label)}</h3><div class="table-wrap"><table class="table"><thead><tr><th>Staff</th><th>Office</th><th>Op. Account</th><th>Opening Balance</th><th>Total Credit Received</th><th>Total Debits Paid</th><th>Closing Balance</th><th>Ledger</th></tr></thead><tbody>${rows || '<tr><td colspan="8">No staff</td></tr>'}</tbody></table></div></div></div>`;
    }
    // Income & Expense
    const opFig = (a) => periodFigures(operationalAccountTotals(a).balance, opItems(a.id), r);
    const sortAcc = (list) => [...(list || [])].sort((a, b) => String(a.accountNumber || '').localeCompare(String(b.accountNumber || ''), undefined, { numeric: true }));
    return `<div class="stack">${head}${periodAccountsTable('All Income Balance', sortAcc(state.operations.incomeAccounts), r, { figures: opFig, empty: 'No income accounts' })}${periodAccountsTable('All Expense Balance', sortAcc(state.operations.expenseAccounts), r, { figures: opFig, empty: 'No expense accounts' })}</div>`;
  }

  function bindPeriodBalance() {
    qq('[data-period-preset]').forEach(btn => btn.onclick = () => { state.ui.balancePeriodFilter = { preset: btn.dataset.periodPreset, from: '', to: '' }; save(); renderWorkspace(); });
    if (byId('balPeriodApply')) byId('balPeriodApply').onclick = () => { state.ui.balancePeriodFilter = { preset: 'custom', from: byId('balPeriodFrom')?.value || '', to: byId('balPeriodTo')?.value || '' }; save(); renderWorkspace(); };
    const search = byId('periodBalanceSearch');
    if (search) search.oninput = debounce(() => { state.ui.periodBalanceSearch = search.value; save(); renderWorkspace(); requestAnimationFrame(() => { const el = byId('periodBalanceSearch'); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } }); }, 300);
    qq('[data-staff-ledger]').forEach(btn => btn.onclick = () => openStaffLedgerModal(btn.dataset.staffLedger));
  }

  // ===== ADMINISTRATION (client sheet "Administrative / Audit & ICT Unit") =====
  const JOB_TITLES = ['Customer Service / Marketing','Tellering / Non-Tellering','Cash Office / Treasury','Approval / Operational Balances','Administrative / Audit & ICT Unit','Manager','Secretary','Security','Cleaner','Legal Office','Marketing'];
  const STAFF_PROFILE_FIELDS = [
    ['job_title','Job Title / Role','select'], ['phone','Phone Number','text'], ['gender','Gender','gender'],
    ['date_of_birth','Date of Birth','date'], ['residential_address','Residential Address','text'], ['email','Email Address','text'],
    ['qualification','Qualification','text'], ['date_of_employment','Date of Employment','date'], ['salary_account_number','Salary Account Number','text'],
    ['bvn','BVN','text'], ['nin','NIN','text'], ['guarantor','Guarantor','text'], ['referee','Referee','text'],
    ['next_of_kin','Next of Kin','text'], ['marital_status','Marital Status','marital'], ['initial_position','Initial Position','text'],
  ];
  const ICT_CHECKLISTS = {
    ict_security: ['Staff passwords reviewed', 'Inactive or departed staff blocked', 'Admin recovery key stored safely offline', 'Role permissions reviewed', 'Audit trail checked for unusual activity'],
    ict_network:  ['Internet working at every branch', 'Router / Wi-Fi passwords secured and changed when needed', 'Devices on the network reviewed', 'Backup internet available', 'Connection speed acceptable for posting'],
    ict_cyber:    ['Devices and browsers up to date', 'Antivirus active on every device', 'No shared logins between staff', 'Staff reminded about phishing / fake messages', 'Browser extensions reviewed'],
  };
  const ictCategory = (tool) => tool === 'ict_backup' ? 'backup' : tool.replace('ict_', '');

  // Profiles: Supabase table when available, otherwise kept in this browser.
  function localStaffProfiles() { state.localStaffProfiles ||= {}; return state.localStaffProfiles; }
  // Loaded-this-session flags live in memory only. They used to be saved
  // with the app state, so a "table missing" result stuck even after the
  // SQL script was run (2026-10-22 fix).
  const adminSessionLoaded = { profiles: false, ict: {} };
  async function loadStaffProfiles(force = false) {
    if (adminSessionLoaded.profiles && !force) return;
    adminSessionLoaded.profiles = true;
    const res = await gateway.adminx?.listStaffProfiles?.();
    if (res?.ok) { state.ui.staffProfiles = Object.fromEntries((res.data || []).map(p => [p.staff_id, p])); state.ui.staffProfilesSource = 'db'; }
    else { state.ui.staffProfiles = { ...localStaffProfiles() }; state.ui.staffProfilesSource = res?.error?.code === 'TABLE_MISSING' ? 'missing' : 'local'; }
    save(); renderWorkspace();
  }
  const profileOf = (staffId) => (state.ui.staffProfiles || {})[staffId] || null;

  function renderStaffManagement() {
    const staffList = [...(state.staff || [])].sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
    // Staff Information shows only after Open is clicked on a staff row.
    const selId = state.ui.admSelectedStaffId && staffList.some(s => s.id === state.ui.admSelectedStaffId) ? state.ui.admSelectedStaffId : '';
    const sel = staffList.find(s => s.id === selId);
    const prof = { ...(profileOf(selId) || {}), ...(state.ui.admProfileDraft?.staffId === selId ? state.ui.admProfileDraft.data : {}) };
    const rows = staffList.map((s, i) => `<tr class="${s.id === selId ? 'adm-selected' : ''}"><td>${i+1}</td><td>${escapeHtml(s.name || '—')}</td><td>${escapeHtml(staffRoleLabels(s))}</td><td>${escapeHtml(profileOf(s.id)?.job_title || '—')}</td><td><code>${escapeHtml(String(s.staffId || s.staffCode || '—'))}</code></td><td>${s.active === false ? 'Blocked' : 'Active'}</td><td><button class="secondary tiny-btn" data-adm-staff="${s.id}">Open</button> <button class="secondary tiny-btn" data-adm-extra-roles="${s.id}">Extra Roles</button></td></tr>`).join('');
    const opAcc = sel ? staffOperationalAccountNumber(sel.id) : '';
    const fieldHtml = ([key, label, kind]) => {
      const v = escapeHtml(String(prof[key] || ''));
      let input;
      if (kind === 'select') input = `<select class="entry-input" data-prof="${key}"><option value="">— Select —</option>${JOB_TITLES.map(t => `<option ${prof[key] === t ? 'selected' : ''}>${escapeHtml(t)}</option>`).join('')}</select>`;
      else if (kind === 'gender') input = `<select class="entry-input" data-prof="${key}"><option value="">—</option>${['Male','Female'].map(t => `<option ${prof[key] === t ? 'selected' : ''}>${t}</option>`).join('')}</select>`;
      else if (kind === 'marital') input = `<select class="entry-input" data-prof="${key}"><option value="">—</option>${['Single','Married','Divorced','Widowed'].map(t => `<option ${prof[key] === t ? 'selected' : ''}>${t}</option>`).join('')}</select>`;
      else input = `<input class="entry-input" data-prof="${key}" type="${kind === 'date' ? 'date' : 'text'}" ${kind === 'date' ? 'lang="en-GB"' : ''} value="${v}">`;
      return `<div class="cs2-row"><div class="cs2-label">${label}</div><div class="cs2-input-wrap cs2-wide">${input}</div></div>`;
    };
    const sourceNote = state.ui.staffProfilesSource === 'missing'
      ? `<div class="note" style="border-left-color:#c00000 !important">Staff profiles table not set up yet — run the staff_profiles SQL script in Supabase. Until then details are kept in this browser only.</div>`
      : (state.ui.staffProfilesSource === 'local' ? `<div class="note">Details are kept in this browser (offline mode).</div>` : '');
    return `<div class="adm-staff-layout">
      <div class="table-card">
        <div class="action-row"><h3>Staff Management and Roles</h3><div class="inline-actions"><button id="addStaffBtn" class="tiny-btn">Add Staff</button><button id="admRolesBtn" class="secondary tiny-btn">Roles</button></div></div>
        ${sourceNote}
        <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Staff</th><th>App Role</th><th>Job Title</th><th>Staff ID</th><th>Status</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="7">No staff</td></tr>'}</tbody></table></div>
      </div>
      ${sel ? `<div class="form-card cs2-card">
        <div class="cs2-title">Staff Information — ${escapeHtml(sel.name || '')}</div>
        <div class="cs2-stack">
          <div class="cs2-row"><div class="cs2-label">App Role</div><div class="display-field cs2-wide">${escapeHtml(staffRoleLabels(sel))}</div></div>
          <div class="cs2-row"><div class="cs2-label">Full Name</div><div class="display-field cs2-wide">${escapeHtml(sel.name || '—')}</div></div>
          <div class="cs2-row"><div class="cs2-label">Login ID</div><div class="display-field cs2-wide">${escapeHtml(String(sel.staffId || sel.staffCode || '—'))}</div></div>
          <div class="cs2-row"><div class="cs2-label">Operational A/C No</div><div class="display-field cs2-wide">${escapeHtml(opAcc || '—')}</div></div>
          <div class="cs2-row"><div class="cs2-label">Photo</div><div class="cs2-input-wrap cs2-wide" style="display:flex;gap:8px;align-items:center">${prof.photo ? `<img src="${prof.photo}" alt="Staff photo" style="width:64px;height:64px;object-fit:cover;border:1px solid #d8c896">` : '<span class="muted">No photo</span>'}<label class="sheet-btn secondary file-trigger-btn" for="admPhotoInput">Upload Photo</label><input id="admPhotoInput" type="file" accept="image/*" class="visually-hidden-file-input"></div></div>
          ${STAFF_PROFILE_FIELDS.map(fieldHtml).join('')}
          <div class="cs2-button-row"><button id="admProfileSave" class="sheet-btn cs2-btn cs2-btn-solid">Save Staff Information</button><button id="admProfileClose" class="sheet-btn cs2-btn cs2-btn-ghost secondary">Close</button></div>
        </div>
      </div>` : ''}
    </div>`;
  }

  function auditCountsByType(r) {
    const staffRole = (id) => (state.staff || []).find(s => s.id === id)?.role || '';
    const groups = [
      ['Customer Account', (state.customers || []).filter(c => String(c.accountType || 'customer') === 'customer'), 'aud_customers'],
      ['Staff Account', (state.customers || []).filter(c => c.accountType === 'staff_salary'), 'aud_types'],
      ['Income Account', state.operations.incomeAccounts || [], 'operational_accounts'],
      ['Expenses Account', state.operations.expenseAccounts || [], 'operational_accounts'],
      ['Teller Account', (state.customers || []).filter(c => c.accountType === 'staff_operational'), 'aud_tellers'],
      ['Treasury Account', (state.customers || []).filter(c => c.accountType === 'treasury'), 'aud_customers:treasury'],
    ];
    return groups.map(([label, list, review]) => {
      const iso = (a) => dateOnly(a.createdAt || a.created_at || '') || '';
      const before = list.filter(a => r.start && iso(a) && iso(a) < r.start).length;
      const fresh = list.filter(a => inPeriod(iso(a), r)).length;
      const total = list.filter(a => !r.end || !iso(a) || iso(a) <= r.end).length;
      return { label, before: r.start ? before : 0, fresh: r.start ? fresh : total, total, review };
    });
  }

  function tellerPeriodRow(st, r) {
    const opening = r.start ? withApprovalsUpTo(dayBefore(r.start), () => getStaffOperationalBalance(st.id)) : 0;
    const closing = withApprovalsUpTo(r.end, () => getStaffOperationalBalance(st.id));
    const mine = (state.approvals || []).filter(a => a.status === 'approved' && a.payload?.staffId === st.id && inPeriod(approvalBusinessDate(a.type, a.payload || {}), r));
    const amt = (a) => a.type.endsWith('_journal') ? Number(a.payload?.formAmount || 0) : Number(a.payload?.amount || 0);
    const received = mine.filter(a => a.type === 'customer_credit' || a.type === 'customer_credit_journal').reduce((t, a) => t + amt(a), 0);
    const withdrawn = mine.filter(a => a.type === 'customer_debit' || a.type === 'customer_debit_journal').reduce((t, a) => t + amt(a), 0);
    // Client rule: Opening Cash + Cash Received - Cash Withdrawal = Balance,
    // with every transfer into the teller's account counted in Opening Cash
    // (the same as the Till box) — so Opening Cash is worked back from the
    // closing balance rather than taken as the previous day's figure.
    return { openingRaw: closing - received + withdrawn, carried: opening, received, withdrawn, closing };
  }

  function renderAdminSub(tool) {
    const r = balancePeriodRange(state.ui.balancePeriodFilter || { preset: 'daily' });
    const bar = renderPeriodBar();
    if (tool === 'adm_staff') return renderStaffManagement();
    if (tool === 'adm_balance') return renderPeriodBalance({ report: 'overall', label: 'Account Balance', preset: 'daily' });
    if (tool === 'aud_cs') {
      const rows = auditCountsByType(r);
      const t = rows.reduce((a, x) => ({ before: a.before + x.before, fresh: a.fresh + x.fresh, total: a.total + x.total }), { before: 0, fresh: 0, total: 0 });
      return `<div class="stack">${bar}<div class="table-card"><h3>Customer Service / Marketing</h3><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Type of Account</th><th>No. of Accounts Before</th><th>New Accounts</th><th>Total</th><th>Action</th></tr></thead><tbody>${rows.map((x, i) => `<tr><td>${i+1}</td><td>${x.label}</td><td>${x.before}</td><td>${x.fresh}</td><td>${x.total}</td><td><button class="secondary tiny-btn" data-adm-review="${x.review}">Review</button></td></tr>`).join('')}<tr class="total-row"><td colspan="2"><strong>Total</strong></td><td><strong>${t.before}</strong></td><td><strong>${t.fresh}</strong></td><td><strong>${t.total}</strong></td><td></td></tr></tbody></table></div></div></div>`;
    }
    if (tool === 'aud_tellers') {
      let T = { opening: 0, received: 0, withdrawn: 0, closing: 0 };
      const rows = (state.staff || []).filter(st => staffOperationalAccountNumber(st.id)).map((st, i) => {
        const x = tellerPeriodRow(st, r);
        T.opening += x.openingRaw; T.received += x.received; T.withdrawn += x.withdrawn; T.closing += x.closing;
        return `<tr><td>${i+1}</td><td>${escapeHtml(st.name || '')} <span class="muted">(${escapeHtml(staffOperationalAccountNumber(st.id))})</span></td><td>${money(x.openingRaw)}</td><td>${money(x.received)}</td><td>${money(x.withdrawn)}</td><td class="${x.closing<0?'balance-negative':''}">${money(x.closing)}</td><td><button class="secondary tiny-btn" data-staff-ledger="${st.id}">Review</button></td></tr>`;
      }).join('');
      return `<div class="stack">${bar}<div class="table-card"><h3>Tellering / Non-Tellering</h3><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Teller</th><th>Opening Cash</th><th>Cash Received</th><th>Cash Withdrawal</th><th>Balance</th><th>Action</th></tr></thead><tbody>${rows || '<tr><td colspan="7">No staff with an operational account</td></tr>'}${rows ? `<tr class="total-row"><td colspan="2"><strong>Total</strong></td><td><strong>${money(T.opening)}</strong></td><td><strong>${money(T.received)}</strong></td><td><strong>${money(T.withdrawn)}</strong></td><td><strong>${money(T.closing)}</strong></td><td></td></tr>` : ''}</tbody></table></div></div></div>`;
    }
    if (tool === 'aud_types') {
      const staffRole = (id) => (state.staff || []).find(s => s.id === id)?.role || '';
      const acctSum = (list) => list.reduce((a, c) => { const f = periodFigures(c.balance, txItems(c), r); return { dr: a.dr + f.debit, cr: a.cr + f.credit, bal: a.bal + f.closing }; }, { dr: 0, cr: 0, bal: 0 });
      const opSum = (list) => list.reduce((a, acc) => { const f = periodFigures(operationalAccountTotals(acc).balance, opItems(acc.id), r); return { dr: a.dr + f.debit, cr: a.cr + f.credit, bal: a.bal + f.closing }; }, { dr: 0, cr: 0, bal: 0 });
      const tellerSum = (list) => list.reduce((a, c) => {
        const ev = staffLedgerEvents(c.linkedStaffId).filter(e => inPeriod(String(e.date || '').slice(0,10), r));
        return { dr: a.dr + ev.filter(e => e.side === 'debit').reduce((t, e) => t + Number(e.amount || 0), 0), cr: a.cr + ev.filter(e => e.side === 'credit').reduce((t, e) => t + Number(e.amount || 0), 0), bal: a.bal + withApprovalsUpTo(r.end, () => getStaffOperationalBalance(c.linkedStaffId)) };
      }, { dr: 0, cr: 0, bal: 0 });
      const ops = (state.customers || []).filter(c => c.accountType === 'staff_operational' && c.linkedStaffId);
      const rows = [
        ['Customer Account', acctSum((state.customers || []).filter(c => String(c.accountType || 'customer') === 'customer')), 'aud_customers'],
        ['Staff Account', acctSum((state.customers || []).filter(c => c.accountType === 'staff_salary')), 'aud_types'],
        ['Income Account', opSum(state.operations.incomeAccounts || []), 'operational_accounts'],
        ['Expenses Account', opSum(state.operations.expenseAccounts || []), 'operational_accounts'],
        ['Teller Account', tellerSum(ops), 'aud_tellers'],
        ['Treasury Account', acctSum((state.customers || []).filter(c => c.accountType === 'treasury')), 'aud_customers:treasury'],
      ];
      const T = rows.reduce((a, [, x]) => ({ dr: a.dr + x.dr, cr: a.cr + x.cr, bal: a.bal + x.bal }), { dr: 0, cr: 0, bal: 0 });
      return `<div class="stack">${bar}<div class="table-card"><h3>Account Types</h3><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Type of Account</th><th>Total DR</th><th>Total CR</th><th>Total Balance</th><th>Action</th></tr></thead><tbody>${rows.map(([l, x, rv], i) => `<tr><td>${i+1}</td><td>${l}</td><td>${money(x.dr)}</td><td>${money(x.cr)}</td><td>${money(x.bal)}</td><td><button class="secondary tiny-btn" data-adm-review="${rv}">Review</button></td></tr>`).join('')}<tr class="total-row"><td colspan="2"><strong>Total</strong></td><td><strong>${money(T.dr)}</strong></td><td><strong>${money(T.cr)}</strong></td><td><strong>${money(T.bal)}</strong></td><td></td></tr></tbody></table></div></div></div>`;
    }
    if (tool === 'aud_customers') {
      const search = String(state.ui.periodBalanceSearch || '').trim().toLowerCase();
      const kind = state.ui.audAccountKind === 'treasury' ? 'treasury' : 'customer';
      const list = (state.customers || []).filter(c => String(c.accountType || 'customer') === kind)
        .filter(c => !search || [c.name, c.accountNumber, c.phone].some(v => String(v || '').toLowerCase().includes(search)))
        .sort((a, b) => String(a.accountNumber || '').localeCompare(String(b.accountNumber || ''), undefined, { numeric: true }));
      let T = { dr: 0, cr: 0, bal: 0 };
      const rows = list.map((c, i) => { const f = periodFigures(c.balance, txItems(c), r); T.dr += f.debit; T.cr += f.credit; T.bal += f.closing; return `<tr><td>${i+1}</td><td>${escapeHtml(c.name || '—')}${c.closed ? ' <span class="badge rejected">Closed</span>' : ''}</td><td>${escapeHtml(String(c.accountNumber || '—'))}</td><td>${money(f.debit)}</td><td>${money(f.credit)}</td><td>${money(f.closing)}</td></tr>`; }).join('');
      return `<div class="stack">${bar}<div class="table-card"><h3>${kind === 'treasury' ? 'Treasury Account' : 'Customer Account'}</h3><div class="form-grid one" style="margin:6px 0 10px"><div class="field"><label>Search Account</label><input id="periodBalanceSearch" class="entry-input" value="${escapeHtml(state.ui.periodBalanceSearch || '')}"></div></div><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>A/C Name</th><th>A/C No</th><th>DR</th><th>CR</th><th>Balance</th></tr></thead><tbody>${rows || `<tr><td colspan="6">No ${kind === 'treasury' ? 'Treasury' : 'customer'} accounts</td></tr>`}${rows ? `<tr class="total-row"><td colspan="3"><strong>Total</strong></td><td><strong>${money(T.dr)}</strong></td><td><strong>${money(T.cr)}</strong></td><td><strong>${money(T.bal)}</strong></td></tr>` : ''}</tbody></table></div></div></div>`;
    }
    if (tool === 'ict_access') return renderStaffRoster();
    // ICT: backup + checklists
    const cat = ictCategory(tool);
    const logs = (state.ui.ictLogs || {})[cat];
    const logRows = (logs || []).map((l, i) => `<tr><td>${i+1}</td><td>${fmtDate(l.created_at)}</td><td>${escapeHtml(l.staff_name || '—')}</td><td>${tool === 'ict_backup' ? 'Backup downloaded' : `${(l.checked_items || []).length} of ${(ICT_CHECKLISTS[tool] || []).length} checked`}</td><td>${escapeHtml(l.note || '')}</td></tr>`).join('');
    const history = `<div class="table-card"><h3>History</h3>${state.ui.ictSource === 'missing' ? `<div class="note" style="border-left-color:#c00000 !important">ICT records table not set up yet — run the ict_logs SQL script in Supabase. Until then records are kept in this browser only.</div>` : ''}<div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Date</th><th>By</th><th>Result</th><th>Note</th></tr></thead><tbody>${logs ? (logRows || '<tr><td colspan="5">No records yet</td></tr>') : '<tr><td colspan="5">Loading…</td></tr>'}</tbody></table></div></div>`;
    if (tool === 'ict_backup') {
      const gauge = DATA_BACKUP_ACTIVE ? storageGaugeHtml() : '';
      const backupHtml = `<div class="stack"><div class="form-card cs2-card"><div class="cs2-title">Data Backup</div><div class="note">Downloads a snapshot of the data this app holds — staff, customer accounts and balances, transactions, approval requests (photos excluded), journals, income &amp; expense accounts, close-of-day records. Store the file somewhere safe and offline. Supabase's free plan keeps no automatic backups of the database, so download this regularly (weekly is a good habit).</div><div class="cs2-row"><div class="cs2-label">Note</div><div class="cs2-input-wrap cs2-wide"><input id="ictNote" class="entry-input" placeholder="e.g. Weekly backup, saved to office drive"></div></div><div class="cs2-button-row"><button id="ictBackupBtn" class="sheet-btn cs2-btn cs2-btn-solid">Download Backup</button></div></div>${gauge}${history}</div>`;
      return DATA_BACKUP_ACTIVE ? backupHtml : `<div class="backup-locked-wrap"><div class="backup-locked-msg" id="backupLockMsg">Data Backup is a premium service.<br><span>It will be available once it is activated for this business.</span></div><div class="backup-locked-overlay" id="backupLockOverlay"></div><div class="backup-locked" aria-disabled="true" inert>${backupHtml}</div></div>`;
    }
    const items = ICT_CHECKLISTS[tool] || [];
    return `<div class="stack"><div class="form-card cs2-card"><div class="cs2-title">${escapeHtml(TOOL_LABELS[tool])} Check</div><div class="note">Tick what has been checked today and add a note, then Save Check. Each check is recorded with your name and the date.</div><div class="stack" style="gap:6px;margin:8px 0">${items.map((it, i) => `<label class="ict-item"><input type="checkbox" data-ict-item="${i}"><span>${escapeHtml(it)}</span></label>`).join('')}</div><div class="cs2-row"><div class="cs2-label">Note</div><div class="cs2-input-wrap cs2-wide"><input id="ictNote" class="entry-input"></div></div><div class="cs2-button-row"><button id="ictSaveBtn" class="sheet-btn cs2-btn cs2-btn-solid">Save Check</button></div></div>${history}</div>`;
  }

  // 2026-10-23: database space gauge (Free plan limit 500 MB). Read once per
  // session (tiny request); admins are warned at login when it is high.
  const STORAGE_LIMIT_BYTES = 500 * 1024 * 1024;
  let storageUsage = null;
  async function loadStorageUsage(force = false) {
    if (!isSupabaseApprovalMode() || !gateway.adminx?.storageUsage) return null;
    if (storageUsage && !force) return storageUsage;
    const res = await gateway.adminx.storageUsage();
    storageUsage = res?.ok ? { ...res.data, ok: true } : { ok: false, code: res?.error?.code };
    return storageUsage;
  }
  function storageGaugeHtml() {
    if (!isSupabaseApprovalMode()) return '';
    if (!storageUsage) { loadStorageUsage().then(() => { if (state.ui.tool === 'ict_backup') renderWorkspace(); }); return `<div class="form-card"><div class="note">Checking database space…</div></div>`; }
    if (!storageUsage.ok) return `<div class="form-card"><div class="cs2-title">Database Space</div><div class="note">${storageUsage.code === 'FUNCTION_MISSING' ? 'Run sql/2026-10-23-storage-gauge.sql in Supabase to see database space here.' : 'Could not read database space right now.'}</div></div>`;
    const mb = (b) => (Number(b || 0) / 1048576).toFixed(1);
    const pct = Math.min(100, Math.round(Number(storageUsage.database_bytes || 0) / STORAGE_LIMIT_BYTES * 100));
    const color = pct >= 80 ? '#c62828' : pct >= 60 ? '#e09b00' : '#2e7d32';
    const advice = pct >= 80 ? 'Space is running out — plan the yearly archive (old records to backup files, balances brought forward) or a paid plan now.' : pct >= 60 ? 'Over half used — start planning the yearly archive.' : 'Plenty of room.';
    return `<div class="form-card"><div class="cs2-title">Database Space</div>
      <div style="margin:8px 0 6px"><strong>${mb(storageUsage.database_bytes)} MB</strong> of 500 MB used (${pct}%) — Supabase free plan</div>
      <div style="height:14px;border:1px solid #999;background:#eee"><div style="height:100%;width:${Math.max(pct, 1)}%;background:${color}"></div></div>
      <div class="note" style="margin-top:6px">${advice} Requests: ${mb(storageUsage.approvals_bytes)} MB · Transactions: ${mb(storageUsage.transactions_bytes)} MB · Audit log: ${mb(storageUsage.audit_bytes)} MB · Customers: ${mb(storageUsage.customers_bytes)} MB. About 15 MB is Supabase's own fixed overhead.</div></div>`;
  }

  async function loadIctLogs(cat, force = false) {
    state.ui.ictLogs ||= {};
    if (adminSessionLoaded.ict[cat] && !force) return;
    adminSessionLoaded.ict[cat] = true;
    const res = await gateway.adminx?.listIctLogs?.(cat);
    if (res?.ok) { state.ui.ictLogs[cat] = res.data || []; state.ui.ictSource = 'db'; }
    else { state.localIctLogs ||= {}; state.ui.ictLogs[cat] = state.localIctLogs[cat] || []; state.ui.ictSource = res?.error?.code === 'TABLE_MISSING' ? 'missing' : 'local'; }
    save(); renderWorkspace();
  }
  async function recordIctLog(cat, checkedItems, note) {
    const st = currentStaff();
    const entry = { category: cat, checkedItems, note, staffId: st?.id || null, staffName: st?.name || '' };
    const res = await gateway.adminx?.addIctLog?.(entry);
    if (!res?.ok) {
      state.localIctLogs ||= {};
      (state.localIctLogs[cat] ||= []).unshift({ id: uid('ict'), category: cat, checked_items: checkedItems, note, staff_name: entry.staffName, created_at: new Date().toISOString() });
    }
    await loadIctLogs(cat, true);
  }

  function bindAdminSub(tool) {
    qq('[data-adm-review]').forEach(btn => btn.onclick = () => { const [tool, kind] = btn.dataset.admReview.split(':'); state.ui.tool = tool; state.ui.audAccountKind = kind || ''; save(); renderWorkspace(); });
    if (['adm_balance','aud_cs','aud_tellers','aud_types','aud_customers'].includes(tool)) bindPeriodBalance();
    if (tool === 'ict_access') { bindStaffDirectory(); return; }
    if (tool === 'adm_staff') {
      if (!adminSessionLoaded.profiles) { loadStaffProfiles(); }
      bindStaffDirectory();
      qq('[data-adm-extra-roles]').forEach(btn => btn.onclick = () => openExtraRolesModal(btn.dataset.admExtraRoles));
      qq('[data-adm-staff]').forEach(btn => btn.onclick = async () => {
        state.ui.admSelectedStaffId = btn.dataset.admStaff; state.ui.admProfileDraft = null; save(); renderWorkspace();
        requestAnimationFrame(() => q('.adm-staff-layout .cs2-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
        const res = await gateway.adminx?.getStaffProfile?.(btn.dataset.admStaff);
        if (res?.ok && res.data) { state.ui.staffProfiles ||= {}; state.ui.staffProfiles[btn.dataset.admStaff] = res.data; save(); renderWorkspace(); }
      });
      if (byId('admRolesBtn')) byId('admRolesBtn').onclick = () => openModal('Roles', `<div class="stack"><div class="note">App roles decide what a staff member can use in DUCESS. Job titles are HR labels only and give no app access on their own.</div><div class="table-wrap"><table class="table"><thead><tr><th>App Role</th><th>What it can use</th></tr></thead><tbody>${ASSIGNABLE_ROLE_KEYS.map(k => `<tr><td>${escapeHtml(ROLE_LABELS[k])}</td><td>${(DEFAULT_PERMS[k] || []).length} tools</td></tr>`).join('')}</tbody></table></div><div class="table-wrap"><table class="table"><thead><tr><th>Job Titles</th></tr></thead><tbody>${JOB_TITLES.map(t => `<tr><td>${escapeHtml(t)}</td></tr>`).join('')}</tbody></table></div><div class="note">Change app roles and what each can access in Operations → Permissions Matrix.</div></div>`, [{ label: 'Close', className: 'secondary', onClick: closeModal }]);
      const selId = state.ui.admSelectedStaffId || '';
      if (byId('admProfileClose')) byId('admProfileClose').onclick = () => { state.ui.admSelectedStaffId = ''; state.ui.admProfileDraft = null; save(); renderWorkspace(); };
      const draftData = () => { state.ui.admProfileDraft ||= { staffId: selId, data: {} }; if (state.ui.admProfileDraft.staffId !== selId) state.ui.admProfileDraft = { staffId: selId, data: {} }; return state.ui.admProfileDraft.data; };
      qq('[data-prof]').forEach(el => { const upd = () => { draftData()[el.dataset.prof] = el.value; save(); }; el.oninput = upd; el.onchange = upd; });
      const photo = byId('admPhotoInput');
      if (photo) photo.onchange = async (e) => {
        const file = e.target.files?.[0]; if (!file) return;
        const img = await compressImageFile(file, { maxSide: 240, quality: 0.5 });
        draftData().photo = img.dataUrl; save(); renderWorkspace();
      };
      if (byId('admProfileSave')) byId('admProfileSave').onclick = async () => {
        if (!selId) return;
        const data = { ...(profileOf(selId) || {}), ...draftData() };
        delete data.staff_id; delete data.updated_at;
        showProcessing('Saving staff information...'); await nextPaint();
        try {
          const res = await gateway.adminx?.saveStaffProfile?.(selId, data);
          if (!res?.ok) { localStaffProfiles()[selId] = { ...data, staff_id: selId }; }
          state.ui.staffProfiles ||= {}; state.ui.staffProfiles[selId] = { ...data, staff_id: selId };
          state.ui.admProfileDraft = null; save();
          showToast(res?.ok ? 'Staff information saved' : (res?.error?.code === 'TABLE_MISSING' ? 'Saved in this browser — run the staff_profiles SQL to store it centrally' : 'Saved in this browser'));
          renderWorkspace();
        } finally { hideProcessing(); }
      };
      return;
    }
    if (tool.startsWith('ict_')) {
      const cat = ictCategory(tool);
      if (!adminSessionLoaded.ict[cat] && !(tool === 'ict_backup' && !DATA_BACKUP_ACTIVE)) loadIctLogs(cat);
      // Locked page: it shows normally, nothing on it responds, and a click
      // anywhere on it brings up the "premium service" message instead.
      if (tool === 'ict_backup' && !DATA_BACKUP_ACTIVE && byId('backupLockOverlay')) {
        byId('backupLockOverlay').onclick = () => {
          const msg = byId('backupLockMsg'); if (!msg) return;
          msg.classList.add('show');
          clearTimeout(window.__backupLockTimer);
          window.__backupLockTimer = setTimeout(() => msg.classList.remove('show'), 3500);
        };
      }
      if (byId('ictBackupBtn')) byId('ictBackupBtn').onclick = async () => {
        if (!DATA_BACKUP_ACTIVE) return showToast('Data Backup is not activated yet');
        // A backup must hold every record, not the recent part + summaries.
        if (!historyCovers(null)) {
          showProcessing('Loading all records for the backup...');
          try { const ok = await historyLoading; if (!ok) return showToast('Could not load all records — backup not downloaded.'); } finally { hideProcessing(); }
        }
        const stripApproval = (a) => { const p = { ...(a.payload || {}) }; ['photo','photoRef','fieldNote'].forEach(k => { if (p[k]) p[k] = '[omitted]'; }); return { ...a, payload: p }; };
        const snapshot = { app: 'DUCESS', exportedAt: new Date().toISOString(), businessDate: businessDate(), exportedBy: currentStaff()?.name || '',
          staff: state.staff, customers: (state.customers || []).map(c => ({ ...c, photo: c.photo ? '[omitted]' : '' })), approvals: (state.approvals || []).map(stripApproval),
          operations: state.operations, journals: (state.journals || []).map(j => ({ ...j, fieldNote: j.fieldNote ? '[omitted]' : null })), cod: state.cod, staffProfiles: state.ui.staffProfiles || {} };
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' }));
        a.download = `ducess-backup-${businessDate()}.json`; a.click();
        await recordIctLog('backup', [], byId('ictNote')?.value || '');
        showToast('Backup downloaded');
      };
      if (byId('ictSaveBtn')) byId('ictSaveBtn').onclick = async () => {
        const items = ICT_CHECKLISTS[tool] || [];
        const checked = qq('[data-ict-item]').filter(el => el.checked).map(el => items[Number(el.dataset.ictItem)]);
        if (!checked.length && !(byId('ictNote')?.value || '').trim()) return showToast('Tick at least one item or add a note');
        await recordIctLog(cat, checked, byId('ictNote')?.value || '');
        showToast('Check saved');
      };
    }
  }

  function renderOverallBalance() {
    // Overall Balance is a rollup of the OTHER balance categories — not another
    // per-account or staff-balance listing. Each row here is a category total.
    let customerDebit = 0, customerCredit = 0, customerBalance = 0;
    let treasuryDebit = 0, treasuryCredit = 0, treasuryBalance = 0;
    (state.customers || []).filter(c => String(c.accountType || '') === 'treasury').forEach(c => {
      treasuryCredit += (c.transactions || []).filter(tx => tx.type === 'credit').reduce((s,tx)=>s+Number(tx.amount||0),0);
      treasuryDebit += (c.transactions || []).filter(tx => tx.type === 'debit').reduce((s,tx)=>s+Number(tx.amount||0),0);
      treasuryBalance += Number(c.balance||0);
    });
    accountsInSegment('customer').forEach(c => {
      customerCredit += (c.transactions || []).filter(tx => tx.type === 'credit').reduce((s,tx)=>s+Number(tx.amount||0),0);
      customerDebit += (c.transactions || []).filter(tx => tx.type === 'debit').reduce((s,tx)=>s+Number(tx.amount||0),0);
      customerBalance += Number(c.balance||0);
    });
    let staffDebit = 0, staffCredit = 0, staffBalance = 0;
    (state.staff || []).forEach(s => {
      const acc = ensureStaffAccount(s.id);
      const wallet = (state.customers || []).find(c => c.id === acc.linkedCustomerId);
      staffCredit += (wallet?.transactions || []).filter(tx => tx.type === 'credit').reduce((s2,tx)=>s2+Number(tx.amount||0),0);
      staffDebit += (wallet?.transactions || []).filter(tx => tx.type === 'debit').reduce((s2,tx)=>s2+Number(tx.amount||0),0);
      staffBalance += Number(acc.balance||0);
    });
    accountsInSegment('staff').forEach(c => {
      staffCredit += (c.transactions || []).filter(tx => tx.type === 'credit').reduce((s2,tx)=>s2+Number(tx.amount||0),0);
      staffDebit += (c.transactions || []).filter(tx => tx.type === 'debit').reduce((s2,tx)=>s2+Number(tx.amount||0),0);
      staffBalance += Number(c.balance||0);
    });
    let tellerDebit = 0, tellerCredit = 0, tellerBalance = 0;
    accountsInSegment('tellerng').forEach(c => {
      const f = tellerFigures(c.linkedStaffId, { start: '', end: '' });
      tellerDebit += f.debit; tellerCredit += f.credit; tellerBalance += f.closing;
    });
    let incomeDebit = 0, incomeCredit = 0, incomeBalance = 0;
    (state.operations.incomeAccounts || []).forEach(a => {
      const t = operationalAccountTotals(a);
      incomeDebit += t.totalDebit; incomeCredit += t.totalCredit; incomeBalance += t.balance;
    });
    let expenseDebit = 0, expenseCredit = 0, expenseBalance = 0;
    (state.operations.expenseAccounts || []).forEach(a => {
      const t = operationalAccountTotals(a);
      expenseDebit += t.totalDebit; expenseCredit += t.totalCredit; expenseBalance += t.balance;
    });
    const categories = [
      { name: "All Customers' Balance", totalDebit: customerDebit, totalCredit: customerCredit, balance: customerBalance },
      { name: 'Treasury Balance', totalDebit: treasuryDebit, totalCredit: treasuryCredit, balance: treasuryBalance },
      { name: 'All Staff Balance', totalDebit: staffDebit, totalCredit: staffCredit, balance: staffBalance },
      { name: 'Income Balance', totalDebit: incomeDebit, totalCredit: incomeCredit, balance: incomeBalance },
      { name: 'Expense Balance', totalDebit: expenseDebit, totalCredit: expenseCredit, balance: expenseBalance },
      { name: 'Tellerng Balance', totalDebit: tellerDebit, totalCredit: tellerCredit, balance: tellerBalance }
    ];
    const grandDebit = categories.reduce((s,c)=>s+c.totalDebit,0);
    const grandCredit = categories.reduce((s,c)=>s+c.totalCredit,0);
    const grandBalance = categories.reduce((s,c)=>s+c.balance,0);
    const bodyRows = categories.map((c,i) =>
      `<tr><td>${i+1}</td><td>${escapeHtml(c.name)}</td><td>${money(c.totalDebit)}</td><td>${money(c.totalCredit)}</td><td>${money(c.balance)}</td></tr>`
    ).join('');
    return `<div class="stack"><div class="table-card"><h3>Overall Balance</h3><div class="note">The company's entire truth — the balance of every other balance category, rolled up into one business total.</div><div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Balance Category</th><th>Total Debit</th><th>Total Credit</th><th>Balance</th></tr></thead><tbody>${bodyRows}<tr class="total-row"><td colspan="2"><strong>Overall Balance of the Business</strong></td><td><strong>${money(grandDebit)}</strong></td><td><strong>${money(grandCredit)}</strong></td><td><strong>${money(grandBalance)}</strong></td></tr></tbody></table></div></div></div>`;
  }

  function renderBusinessBalance() {
    const rawBusiness = filterByDate(flattenBusinessEntries(), state.ui.businessFilter || { preset: 'daily', from: '', to: '' });
    const typeFilter = state.ui.businessType || 'all';
    const filtered = rawBusiness.filter(t => typeFilter==='all' ? true : t.kind===typeFilter);
    const credits = filtered.filter(t => t.kind === 'credit').reduce((s,t)=>s+Number(t.amount||0),0);
    const debits = filtered.filter(t => t.kind === 'debit').reduce((s,t)=>s+Number(t.amount||0),0);
    return `
      <div class="stack business-balance-stack">
        ${renderBalanceFilters('business')}
        <div class="kpi-row compact-page-kpi-row business-balance-kpis">
          <div class="kpi compact-page-kpi"><div class="label">Total Credit</div><div class="number">${money(credits)}</div></div>
          <div class="kpi compact-page-kpi"><div class="label">Total Debit</div><div class="number">${money(debits)}</div></div>
          <div class="kpi compact-page-kpi"><div class="label">Entries</div><div class="number">${filtered.length}</div></div>
          <div class="kpi compact-page-kpi"><div class="label">Net Book Balance</div><div class="number">${money(credits-debits)}</div></div>
        </div>
        <div class="table-card"><h3>Business Entries</h3><div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Account</th><th>Details</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Received/Paid By</th><th>Posted By</th><th>Approved By</th></tr></thead><tbody>${filtered.slice(0,state.ui.businessEntriesLimit || 20).map(t=>`<tr><td>${fmtDate(t.date)}</td><td>${escapeHtml(t.accountNumber || '—')}</td><td>${escapeHtml(t.details || '')}</td><td>${t.kind==='debit'?money(t.amount):''}</td><td>${t.kind==='credit'?money(t.amount):''}</td><td>${money(t.balanceAfter || 0)}</td><td>${escapeHtml(t.receivedOrPaidBy || '—')}</td><td>${escapeHtml(t.postedBy || '—')}</td><td>${escapeHtml(t.approvedBy || '—')}</td></tr>`).join('') || '<tr><td colspan="9">No entries</td></tr>'}</tbody></table></div><div class="action-row">${filtered.length > (state.ui.businessEntriesLimit || 20) ? `<button id="businessMore" class="secondary">Show More</button>` : ''}${(state.ui.businessEntriesLimit || 20) > 20 ? `<button id="businessLess" class="secondary">Show Less</button>` : ''}</div></div>
      </div>`;
  }

  function renderOperationalBalance() {
    const filtered = getOperationalFilteredRows();
    const income = filtered.filter(e=>e.kind==='income');
    const expense = filtered.filter(e=>e.kind==='expense');
    return `
      <div class="stack operational-balance-stack">
        ${renderBalanceFilters('operational')}
        <div class="kpi-row compact-page-kpi-row operational-balance-kpis">
          <div class="kpi compact-page-kpi"><div class="label">Total Income</div><div class="number">${money(income.reduce((s,e)=>s+Number(e.amount||0),0))}</div></div>
          <div class="kpi compact-page-kpi"><div class="label">Total Expense</div><div class="number">${money(expense.reduce((s,e)=>s+Number(e.amount||0),0))}</div></div>
          <div class="kpi compact-page-kpi"><div class="label">Net Operational</div><div class="number">${money(income.reduce((s,e)=>s+Number(e.amount||0),0)-expense.reduce((s,e)=>s+Number(e.amount||0),0))}</div></div>
          <div class="kpi compact-page-kpi"><div class="label">Entries</div><div class="number">${filtered.length}</div></div>
        </div>
        <div class="table-card"><h3>Operational Entries</h3><div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Account</th><th>Type</th><th>Amount</th><th>Note</th><th>Posted By</th><th>Approved By</th></tr></thead><tbody>${filtered.slice(0,state.ui.operationalEntriesLimit || 20).map(e=>`<tr><td>${fmtDate(e.date)}</td><td>${escapeHtml(e.accountName || '')}</td><td>${escapeHtml(e.kind || '')}</td><td>${money(e.amount)}</td><td>${escapeHtml(cleanOperationalNote(e.note || e.details) || '—')}</td><td>${escapeHtml(e.postedBy || '')}</td><td>${escapeHtml(e.approvedBy || '')}</td></tr>`).join('') || '<tr><td colspan="7">No entries</td></tr>'}</tbody></table></div><div class="action-row">${filtered.length > (state.ui.operationalEntriesLimit || 20) ? `<button id="operationalMore" class="secondary">Show More</button>` : ''}${(state.ui.operationalEntriesLimit || 20) > 20 ? `<button id="operationalLess" class="secondary">Show Less</button>` : ''}</div></div>
      </div>`;
  }

  
  function getOperationalFilteredRows() {
    const rawOperational = filterByDate(state.operations.entries || [], state.ui.operationalFilter || { preset: 'daily', from: '', to: '' });
    const kindFilter = state.ui.operationalType || 'all';
    return rawOperational.filter(e => kindFilter==='all' ? true : e.kind===kindFilter);
  }

  function buildOperationalStatementRows() {
    const filtered = [...getOperationalFilteredRows()].sort((a,b)=>new Date(a.date)-new Date(b.date));
    let runningBalance = 0;
    return filtered.map((e, idx) => {
      const amount = Number(e.amount || 0);
      const type = String(e.kind || e.type || '').toLowerCase();
      runningBalance += type === 'income' ? amount : -amount;
      return {
        sn: idx + 1,
        date: fmtDate(e.date),
        type,
        accountName: e.accountName || e.account || '—',
        amount,
        note: cleanOperationalNote(e.note || e.details) || '',
        details: cleanOperationalNote(e.details || e.note) || '',
        balanceAfter: runningBalance,
        receivedOrPaidBy: e.receivedOrPaidBy || e.postedBy || '—',
        postedBy: e.postedBy || '—',
        approvedBy: e.approvedBy || '—'
      };
    });
  }

  function getOperationalStatementSummary(rows) {
    const totalIncome = rows.filter(r=>r.type==='income').reduce((s,r)=>s+Number(r.amount||0),0);
    const totalExpense = rows.filter(r=>r.type==='expense').reduce((s,r)=>s+Number(r.amount||0),0);
    return {
      totalIncome,
      totalExpense,
      netOperationalBalance: totalIncome - totalExpense,
      totalAmount: rows.reduce((s,r)=>s+Number(r.amount||0),0)
    };
  }

  
  function exportOperationalStatementCsv() {
    const rows = buildOperationalStatementRows();
    const summary = getOperationalStatementSummary(rows);
    const activeFilter = String(state.ui.operationalType || 'all').toLowerCase();

    const csvRows = [
      ['S/N','DATE','TYPE','ACCOUNT NAME','AMOUNT','DETAILS','BALANCE AFTER','POSTED BY','APPROVED BY'],
      ...rows.map(r => [
        r.sn,
        `‌${r.date || ''}`,
        String(r.type || '').toUpperCase(),
        r.accountName,
        Number(r.amount || 0),
        r.details || r.note || '',
        Number(r.balanceAfter || 0),
        r.postedBy || '',
        r.approvedBy || ''
      ]),
      []
    ];

    if (activeFilter === 'all') {
      csvRows.push(['', '', '', 'TOTAL INCOME', Number(summary.totalIncome || 0), '', '', '', '']);
      csvRows.push(['', '', '', 'TOTAL EXPENSE', Number(summary.totalExpense || 0), '', '', '', '']);
      csvRows.push(['', '', '', 'NET BALANCE', Number(summary.netOperationalBalance || 0), '', '', '', '']);
    } else {
      csvRows.push(['', '', '', 'TOTAL AMOUNT', Number(summary.totalAmount || 0), '', '', '', '']);
    }

    exportCsv(csvRows, 'operational_balance.csv', true);
  }


  
  function printOperationalStatement() {
    const rows = buildOperationalStatementRows();
    const summary = getOperationalStatementSummary(rows);

    const bodyRows = rows.map(r => `
      <tr>
        <td>${r.sn}</td>
        <td>${r.date}</td>
        <td>${escapeHtml(String(r.type || '').toUpperCase())}</td>
        <td>${escapeHtml(r.accountName || '')}</td>
        <td>${money(r.amount)}</td>
        <td>${escapeHtml(r.note || '')}</td>
        <td>${money(r.balanceAfter)}</td>
        <td>${escapeHtml(r.postedBy || '')}</td>
        <td>${escapeHtml(r.approvedBy || '—')}</td>
      </tr>
    `).join('');

    const html = `
      <div class="statement-sheet operational-statement-sheet">
        <div class="statement-title">Operational Balance Statement</div>
        <div class="statement-summary-grid">
          <div class="statement-summary-item"><span>Total Income:</span> ${money(summary.totalIncome)}</div>
          <div class="statement-summary-item"><span>Total Expense:</span> ${money(summary.totalExpense)}</div>
          <div class="statement-summary-item"><span>Net Operational Balance:</span> ${money(summary.netOperationalBalance)}</div>
        </div>
        <div class="statement-rule"></div>
        <table class="statement-table operational-statement-table">
          <thead>
            <tr>
              <th>S/N</th>
              <th>Date</th>
              <th>Type</th>
              <th>Account Name</th>
              <th>Amount</th>
              <th>Note</th>
              <th>Balance After</th>
              <th>Posted By</th>
              <th>Approved By</th>
            </tr>
          </thead>
          <tbody>
            ${bodyRows || '<tr><td colspan="9">No entries</td></tr>'}
          </tbody>
        </table>
        <div class="statement-total"><strong>Total Amount:</strong> ${money(summary.totalAmount)}</div>
      </div>
    `;
    printHtml(html, true);
  }

  
  function getBusinessFilteredRows() {
    const rawBusiness = filterByDate(flattenBusinessEntries(), state.ui.businessFilter || { preset: 'daily', from: '', to: '' });
    const typeFilter = String(state.ui.businessType || 'all').toLowerCase();
    return rawBusiness.filter(e => {
      const rowType = String(e.type || e.kind || '').toLowerCase();
      return typeFilter === 'all' ? true : rowType === typeFilter;
    });
  }

  function buildBusinessStatementRows() {
    const filtered = [...getBusinessFilteredRows()].sort((a,b)=>new Date(a.date)-new Date(b.date));
    return filtered.map((e, idx) => {
      const txType = String(e.type || e.kind || '').toLowerCase();
      const normalizedType = txType === 'credit' || txType === 'debit'
        ? txType.toUpperCase()
        : (Number(e.delta || 0) >= 0 ? 'CREDIT' : 'DEBIT');
      return {
        sn: idx + 1,
        date: fmtDate(e.date),
        type: normalizedType,
        accountName: e.customer?.name || e.accountName || e.customerName || e.accountNumber || '—',
        amount: Number(e.amount || 0),
        details: cleanOperationalNote(e.details || e.note) || '',
        balanceAfter: Number(e.balanceAfter || 0),
        receivedOrPaidBy: e.receivedBy || e.receivedOrPaidBy || e.postedBy || '',
        postedBy: e.postedBy || '',
        approvedBy: e.approvedBy || ''
      };
    });
  }

  function getBusinessStatementSummary(rows) {
    const totalCredit = rows.filter(r => String(r.type).toLowerCase() === 'credit').reduce((s,r)=>s+Number(r.amount||0),0);
    const totalDebit = rows.filter(r => String(r.type).toLowerCase() === 'debit').reduce((s,r)=>s+Number(r.amount||0),0);
    return {
      totalCredit,
      totalDebit,
      netBookBalance: totalCredit - totalDebit,
      totalAmount: rows.reduce((s,r)=>s+Number(r.amount||0),0)
    };
  }

  function exportBusinessStatementCsv() {
    const rows = buildBusinessStatementRows();
    const summary = getBusinessStatementSummary(rows);
    const activeFilter = String(state.ui.businessType || 'all').toLowerCase();

    const csvRows = [
      ['S/N','DATE','TYPE','ACCOUNT NAME','AMOUNT','DETAILS','BALANCE AFTER','RECEIVED OR PAID BY','POSTED BY','APPROVED BY'],
      ...rows.map(r => [
        r.sn,
        `‌${r.date || ''}`,
        r.type,
        r.accountName,
        Number(r.amount || 0),
        r.details || '',
        Number(r.balanceAfter || 0),
        r.receivedOrPaidBy || '',
        r.postedBy || '',
        r.approvedBy || ''
      ]),
      []
    ];

    if (activeFilter === 'all') {
      csvRows.push(['', '', '', 'TOTAL CREDIT', Number(summary.totalCredit || 0), '', '', '', '', '']);
      csvRows.push(['', '', '', 'TOTAL DEBIT', Number(summary.totalDebit || 0), '', '', '', '', '']);
      csvRows.push(['', '', '', 'NET BALANCE', Number(summary.netBookBalance || 0), '', '', '', '', '']);
    } else {
      csvRows.push(['', '', '', 'TOTAL AMOUNT', Number(summary.totalAmount || 0), '', '', '', '', '']);
    }

    exportCsv(csvRows, 'business_balance.csv', true);
  }

  function printBusinessStatement() {
    const rows = buildBusinessStatementRows();
    const summary = getBusinessStatementSummary(rows);
    const bodyRows = rows.map(r => `
      <tr>
        <td>${r.sn}</td>
        <td>${r.date}</td>
        <td>${escapeHtml(r.type || '')}</td>
        <td>${escapeHtml(r.accountName || '')}</td>
        <td>${money(r.amount)}</td>
        <td>${escapeHtml(r.details || '')}</td>
        <td>${money(r.balanceAfter)}</td>
        <td>${escapeHtml(r.receivedOrPaidBy || '')}</td>
        <td>${escapeHtml(r.postedBy || '')}</td>
        <td>${escapeHtml(r.approvedBy || '—')}</td>
      </tr>
    `).join('');
    const html = `
      <div class="statement-sheet business-statement-sheet">
        <div class="statement-title">Business Balance Statement</div>
        <div class="statement-summary-grid">
          <div class="statement-summary-item"><span>Total Credit:</span> ${money(summary.totalCredit)}</div>
          <div class="statement-summary-item"><span>Total Debit:</span> ${money(summary.totalDebit)}</div>
          <div class="statement-summary-item"><span>Net Book Balance:</span> ${money(summary.netBookBalance)}</div>
        </div>
        <div class="statement-rule"></div>
        <table class="statement-table business-statement-table">
          <thead>
            <tr>
              <th>S/N</th>
              <th>Date</th>
              <th>Type</th>
              <th>Account Name</th>
              <th>Amount</th>
              <th>Details</th>
              <th>Balance After</th>
              <th>Received Or Paid By</th>
              <th>Posted By</th>
              <th>Approved By</th>
            </tr>
          </thead>
          <tbody>
            ${bodyRows || '<tr><td colspan="10">No entries</td></tr>'}
          </tbody>
        </table>
        <div class="statement-total"><strong>Total Amount:</strong> ${money(summary.totalAmount)}</div>
      </div>
    `;
    printHtml(html, true);
  }

  // Debit / Credit columns for the teller statement (see staffLedgerEvents).
  function tellerStatementCells(row) {
    const amt = money(row.amount);
    return `<td>${row.side === 'debit' ? amt : ''}</td><td>${row.side === 'credit' ? amt : ''}</td><td class="${Number(row.runningBalance || 0) < 0 ? 'balance-negative' : ''}">${money(row.runningBalance)}</td>`;
  }
  function staffOperationalAccountNumber(staffId) {
    return (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === staffId)?.accountNumber || '';
  }

function staffLedgerEvents(staffId) {
    const staff = staffById(staffId) || {};
    const acc = ensureStaffAccount(staffId);
    const events = [];
    const seen = new Set();
    let ctxReq = null;
    const addEvent = (event) => {
      const key = event.key || `${event.date}|${event.type}|${event.amount}|${event.details}`;
      if (seen.has(key)) return;
      if (ctxReq) {
        const rp = ctxReq.payload || {};
        event.receivedOrPaidBy = event.receivedOrPaidBy || rp.receivedOrPaidBy || rp.receivedBy || rp.paidBy || rp.paidTo || rp.receivedFromName || rp.collectorName || '';
        event.postedBy = event.postedBy || ctxReq.requestedByName || staffName(ctxReq.requestedBy) || '';
        event.approvedBy = event.approvedBy || ctxReq.approvedBy || ctxReq.approvedByName || '';
      }
      seen.add(key);
      events.push(event);
    };
    (acc.entries || []).forEach(entry => {
      const type = String(entry.type || '').toLowerCase();
      const amount = Number(entry.amount || 0);
      const date = entry.formDate || entry.floatDate || String(entry.date || '').slice(0,10) || businessDate();
      if (['approved_form','approved_float'].includes(type)) addEvent({ key: entry.id || `form-${date}-${amount}`, date, type: 'FORM', amount, delta: amount, details: entry.note || `Approved FORM for ${date}`, runningType: 'form' });
      // SURGICAL FIX 2026-09-04 (client-confirmed bug): a customer_credit
      // (deposit — cash coming IN) was given the same negative delta as a
      // customer_debit (withdrawal — cash going OUT), so deposits silently
      // reduced this running balance instead of increasing it.
      else if (['customer_credit'].includes(type)) addEvent({ key: entry.id || `credit-${date}-${amount}`, date, type: 'Credit Impact', amount, delta: amount, details: entry.note || 'Customer credit', runningType: 'credit' });
      else if (['customer_debit'].includes(type)) addEvent({ key: entry.id || `debit-${date}-${amount}`, date, type: 'Debit Impact', amount, delta: -amount, details: entry.note || 'Customer debit', runningType: 'debit' });
      else if (['customer_credit_journal'].includes(type)) addEvent({ key: entry.id || `credit-journal-${date}-${amount}`, date, type: 'Journal Form', amount, delta: amount, details: entry.note || 'Credit journal form', runningType: 'credit' });
      else if (['customer_debit_journal'].includes(type)) addEvent({ key: entry.id || `debit-journal-${date}-${amount}`, date, type: 'Journal Form', amount, delta: -amount, details: entry.note || 'Debit journal form', runningType: 'debit' });
      else if (['debt_repayment','wallet_fund','wallet_funding'].includes(type)) addEvent({ key: entry.id || `${type}-${date}-${amount}`, date, type: type === 'debt_repayment' ? 'Debt Repayment' : 'Wallet', amount, delta: 0, details: entry.note || type.replace(/_/g,' '), runningType: 'other' });
    });
    (state.approvals || []).filter(r => String(r.status || '').toLowerCase() === 'approved').forEach(req => {
      const payload = req.payload || {};
      ctxReq = req;
      const date = payload.date || payload.float_date || String(req.approvedAt || req.requestedAt || '').slice(0,10) || businessDate();
      // Cash receipt: Cash Officer funded their own operational account.
      // 2026-10-24: receipts now go into a business Treasury account, which
      // has its own statement — the officer gets a note-only line.
      if (req.type === 'cash_receipt' && payload.staffId === staffId) {
        const amount = Number(payload.amount || 0);
        const ownOp = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === staffId);
        if (!payload.treasuryAccountId && ownOp && (!payload.operationalAccountId || payload.operationalAccountId === ownOp.id)) addEvent({ key: req.id || `cash-receipt-${date}-${amount}`, date, type: 'Cash Receipt', amount, delta: amount, details: 'Cash received', runningType: 'form' });
        else addEvent({ key: req.id || `cash-receipt-${date}-${amount}`, date, type: 'Cash Receipt', amount, delta: 0, details: `Cash received into ${payload.treasuryAccountName || payload.treasuryAccountNumber || 'Treasury'}`, runningType: 'other' });
      }
      // Inter-staff credit: operational account topped up by Cash Officer
      if (req.type === 'inter_staff_credit') {
        const opAccount = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === staffId);
        if (opAccount && (payload.targetAccountId === opAccount.id || payload.operationalAccountId === opAccount.id)) {
          const amount = Number(payload.amount || 0);
          addEvent({ key: req.id || `inter-credit-${date}-${amount}`, date, type: 'Operational Credit', amount, delta: amount, details: `Credited by ${payload.staffName || 'Treasury'}${(payload.note || payload.details) ? ' • ' + (payload.note || payload.details) : ''}`, runningType: 'form' });
        }
        // SURGICAL ADDITION 2026-09-09: the ACTING staff who issued this
        // funding (via Non Cash, locked to their own account — see
        // applyStaffAccountLock) needs it on their own statement too — a
        // non-balance-affecting audit line ("I funded this account"), not
        // just visible on the receiving side above. This is what makes the
        // acting staff's own My Statement actually diverge from anyone
        // else's based on what THEY did, instead of staying silent on
        // every Non Cash action they perform.
        // SURGICAL FIX 2026-10-22 (client): money the teller sends OUT of
        // their own operational account (e.g. the Till handed to Treasury)
        // was only a zero-amount note here, so the statement balance never
        // dropped. It now reduces the balance exactly as the Till does.
        if (opAccount && payload.sourceAccountId === opAccount.id) {
          const amount = Number(payload.amount || 0);
          addEvent({ key: `${req.id || 'inter-credit'}-out`, date, type: 'Transfer Out', amount, delta: -amount, details: `To ${payload.targetAccountName || payload.targetAccountNumber || 'staff account'}${(payload.note || payload.details) ? ' • ' + (payload.note || payload.details) : ''}`, runningType: 'form' });
        } else if (payload.staffId === staffId) {
          const amount = Number(payload.amount || 0);
          addEvent({ key: `${req.id || 'inter-credit'}-issued`, date, type: 'Non Cash (Issued)', amount, delta: 0, details: `Funded ${payload.targetAccountName || 'staff account'} from ${payload.sourceAccountName || 'your account'}`, runningType: 'other' });
        }
      }
      // SURGICAL ADDITION 2026-09-09: ordinary Non Cash (account-to-account,
      // neither side a staff operational account) — the staff member who
      // performed it gets a non-balance-affecting audit line on their own
      // statement. Accountability for "who did this", same principle as
      // the "Issued" line above, just for the non-staff-funding case.
      if (req.type === 'intra_bank_transfer' && payload.staffId === staffId) {
        const amount = Number(payload.amount || 0);
        const route = `${payload.sourceAccountName || payload.sourceAccountNumber || ''} → ${payload.destAccountName || payload.destAccountNumber || ''}`.trim();
        addEvent({ key: req.id || `nc-${date}-${amount}`, date, type: 'Non Cash', amount, delta: 0, details: `${route}${payload.details ? ' • ' + payload.details : ''}`, runningType: 'other' });
      }
      if (req.type === 'float_declaration' && (payload.staffId === staffId || payload.staff_id === staffId)) {
        const amount = Number(payload.amount || payload.floatAmount || 0);
        addEvent({ key: req.id || `form-approval-${date}-${amount}`, date, type: 'FORM', amount, delta: amount, details: `Approved FORM for ${date}`, runningType: 'form' });
      }
      // SURGICAL FIX 2026-09-04 (client-confirmed bug): see the matching
      // comment above — customer_credit / customer_credit_journal now
      // correctly add to the running balance instead of subtracting.
      if (req.type === 'customer_credit' && payload.staffId === staffId) {
        const amount = Number(payload.amount || 0);
        addEvent({ key: req.id || `credit-approval-${date}-${amount}`, date, type: 'Customer Credit', amount, delta: amount, details: `${payload.accountNumber || ''} ${payload.customerName || ''} ${payload.details || ''}`.trim() || 'Customer credit', runningType: 'credit' });
      }
      if (req.type === 'customer_debit' && payload.staffId === staffId) {
        const amount = Number(payload.amount || 0);
        addEvent({ key: req.id || `debit-approval-${date}-${amount}`, date, type: 'Customer Debit', amount, delta: -amount, details: `${payload.accountNumber || ''} ${payload.customerName || ''} ${payload.details || ''}`.trim() || 'Customer debit', runningType: 'debit' });
      }
      if (req.type === 'customer_credit_journal' && payload.staffId === staffId) {
        const formAmount = Number(payload.formAmount || 0);
        addEvent({ key: req.id || `credit-journal-${date}`, date, type: 'Credit Journal', amount: formAmount, delta: formAmount, details: `Credit journal (${(payload.rows || payload.entries || []).length} entries)`, runningType: 'credit' });
      }
      if (req.type === 'customer_debit_journal' && payload.staffId === staffId) {
        const formAmount = Number(payload.formAmount || 0);
        addEvent({ key: req.id || `debit-journal-${date}`, date, type: 'Debit Journal', amount: formAmount, delta: -formAmount, details: `Debit journal (${(payload.rows || payload.entries || []).length} entries)`, runningType: 'debit' });
      }
    });
    ctxReq = null;
    (state.cod || []).filter(cod => cod.staffId === staffId).forEach(cod => {
      const date = cod.date || String(cod.submittedAt || cod.resolvedAt || '').slice(0,10) || businessDate();
      addEvent({ key: cod.id || `cod-${date}`, date, type: `COD ${String(cod.status || 'Submitted').toUpperCase()}`, amount: Number(cod.remainingBalance ?? cod.runningFloat ?? cod.actualCash ?? 0), delta: 0, details: `Op. Balance ${money(getStaffOperationalBalance(staffId))} • Remaining ${money(cod.remainingBalance ?? cod.runningFloat ?? 0)} • Variance ${money(cod.variance || 0)}`, runningType: 'cod' });
    });
    // SURGICAL CHANGE 2026-10-22 (client): the teller's statement records
    // the teller's crediting/debiting operations as the mirror of the
    // customer's entry (see the side rules below).
    let running = 0;
    return events.sort((a,b)=> new Date(`${a.date}T12:00:00Z`) - new Date(`${b.date}T12:00:00Z`)).map(event => {
      const affects = ['form','credit','debit'].includes(event.runningType) && Number(event.delta || 0) !== 0;
      if (affects) running += Number(event.delta || 0);
      // Client (2026-10-22): funding moves between staff accounts are shown
      // like a customer account's — money received from Treasury is a
      // CREDIT, money sent out (e.g. Till to Treasury) a DEBIT — while the
      // teller's own customer work is the mirror of the customer's entry
      // (a customer credit is a DEBIT here, a customer debit a CREDIT).
      // The balance column is unaffected: it is always the teller's real
      // balance, the same as the Till.
      const isFunding = event.runningType === 'form';
      const side = !affects ? '' : (isFunding ? (Number(event.delta) > 0 ? 'credit' : 'debit') : (Number(event.delta) > 0 ? 'debit' : 'credit'));
      return { ...event, side, runningBalance: running, staffName: staff.name || staffId };
    }).map((event, seq) => ({ ...event, seq })).reverse(); // newest first; seq keeps same-day order
  }

  // SURGICAL ADDITION 2026-09-04 (client request): "every staff will have
  // account statement listing their transactions and balances with
  // appropriate filters" — a self-service version of the Staff Ledger
  // modal above, reusing the exact same staffLedgerEvents() data, but as
  // a proper filterable screen every role can reach for their OWN account
  // (see hasPermission's free-tool list and the customer_service module).
  function renderMyStatement() {
    const st = currentStaff();
    if (!st) return `<div class="form-card"><div class="note">No staff session found.</div></div>`;
    const acc = ensureStaffAccount(st.id);
    const filter = state.ui.myStatementFilter || { preset: 'daily', from: '', to: '' };
    const presets = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['all','All']];
    const events = filterByDate(staffLedgerEvents(st.id), filter);
    const rows = events.map((row, i) => {
      const displayDate = String(row.businessDate || row.date || businessDate()).slice(0,10);
      return `<tr><td>${i+1}</td><td>${fmtDate(`${displayDate}T12:00:00.000Z`)}</td><td>${escapeHtml(row.type || '')}</td>${tellerStatementCells(row)}<td>${escapeHtml(row.details || '—')}</td></tr>`;
    }).join('');
    return `
      <div class="stack">
        <div class="form-card">
          <h3>My Statement</h3>
          <div class="kpi-row wrap">
            <div class="kpi"><div class="label">Staff</div><div class="number">${escapeHtml(st.name || '')}</div></div>
            <div class="kpi"><div class="label">Office</div><div class="number">${staffRoleLabels(st)}</div></div>
            <div class="kpi"><div class="label">Account No.</div><div class="number">${escapeHtml(staffOperationalAccountNumber(st.id) || acc.accountNumber || '—')}</div></div>
            <div class="kpi"><div class="label">Op. Balance</div><div class="number">${money(getStaffOperationalBalance(st.id))}</div></div>
          </div>
          <div class="action-inline balance-filters-row" style="margin-top:10px">${presets.map(([k,l])=>`<button class="filter-chip ${filter.preset===k?'active':'secondary'}" data-my-statement-preset="${k}">${l}</button>`).join('')}<label class="inline-field"><span>From</span><input id="myStatementFrom" type="date" lang="en-GB" value="${filter.from||''}"></label><label class="inline-field"><span>To</span><input id="myStatementTo" type="date" lang="en-GB" value="${filter.to||''}"></label><button class="secondary" id="myStatementCustomApply">Apply Custom</button>
          <!-- SURGICAL MOVE 2026-09-14 (client-confirmed design): "Field Note
               (Form)" used to sit on Check Balance, next to a CUSTOMER
               lookup — but the field note is something the STAFF member
               uploaded (the one who carried out the transaction), so it
               belongs on their own statement, not a customer's context.
               Individual journals also keep their own attached note in the
               Journal Register — this is just a "what did I upload most
               recently" shortcut. -->
          </div>
          <div class="table-wrap" style="margin-top:10px"><table class="table"><thead><tr><th>S/N</th><th>Date</th><th>Entry</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Details</th></tr></thead><tbody>${rows || '<tr><td colspan="7" class="muted">No entries in range</td></tr>'}</tbody></table></div>
        </div>
      </div>`;
  }

  function bindMyStatement() {
    qq('[data-my-statement-preset]').forEach(btn => btn.onclick = () => {
      state.ui.myStatementFilter = { preset: btn.dataset.myStatementPreset, from: '', to: '' };
      save(); renderWorkspace();
    });
    if (byId('myStatementCustomApply')) byId('myStatementCustomApply').onclick = () => {
      state.ui.myStatementFilter = { preset: 'custom', from: byId('myStatementFrom')?.value || '', to: byId('myStatementTo')?.value || '' };
      save(); renderWorkspace();
    };
    const fieldNoteBtn = byId('openFieldNoteBtn'); if (fieldNoteBtn) fieldNoteBtn.onclick = () => {
      const staff = currentStaff();
      const note = staff ? getLatestFieldNoteForStaff(staff.id) : null;
      if (!note) return showToast('No field note uploaded yet — upload one from Generate Journal');
      const isImage = String(note.type || '').startsWith('image/');
      const body = `<div class="stack">
        <div class="note">${String(note.uploadedAt || '').slice(0,10) === businessDate() ? "Today's field note" : `Last uploaded field note (${fmtDate(note.uploadedAt)})`}</div>
        ${isImage
          ? `<img src="${note.dataUrl}" alt="Field note" style="max-width:100%;border-radius:8px;border:1px solid var(--line)">`
          : `<a href="${note.dataUrl}" target="_blank" rel="noopener" class="field-note-pdf-link">📄 ${escapeHtml(note.name || 'Field note.pdf')}</a>`}
      </div>`;
      openModal('Field Note (Form)', body, [{ label: 'Close', className: 'secondary', onClick: closeModal }]);
    };
  }

  // SURGICAL ADDITION 2026-09-07 (client request): "My Approvals" — an
  // Approving Officer's own unique totals view. They never hold a cash
  // account, so a cash statement doesn't apply to them; this shows how
  // much THEY have approved instead, same date-filter pattern as everywhere
  // else. Attribution is by name (state.approvals only tracks approvedBy as
  // a name string, not a staff id — matches how Approval History already
  // displays "approved by" everywhere else in the app). Rejections aren't
  // broken out per-officer here since who rejected a request isn't tracked
  // locally at all yet (only sent to the gateway, never stored back).
  const APPROVAL_TYPE_LABELS = {
    customer_credit: 'Customer Credit', customer_debit: 'Customer Debit',
    customer_credit_journal: 'Credit Journal', customer_debit_journal: 'Debit Journal',
    intra_bank_transfer: 'Non Cash', account_opening: 'Account Opening',
    account_maintenance: 'Account Maintenance', account_block: 'Account Block', account_closure: 'Account Closure', cash_receipt: 'Cash Receipt',
    inter_staff_credit: 'Fund Account', operational_entry: 'Income/Expense Posting',
    float_declaration: 'Float Declaration'
  };

  function renderMyApprovals() {
    const st = currentStaff();
    if (!st) return `<div class="form-card"><div class="note">No staff session found.</div></div>`;
    const filter = state.ui.myApprovalsFilter || { preset: 'daily', from: '', to: '' };
    const presets = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['all','All']];
    const mine = (state.approvals || []).filter(r => r.status === 'approved' && r.approvedBy === st.name);
    const filtered = filterByDate(mine, filter);
    const totalValue = filtered.reduce((s, r) => s + Number(r.payload?.amount || r.payload?.formAmount || 0), 0);
    const byType = {};
    filtered.forEach(r => {
      const label = APPROVAL_TYPE_LABELS[r.type] || r.type;
      byType[label] ||= { count: 0, value: 0 };
      byType[label].count += 1;
      byType[label].value += Number(r.payload?.amount || r.payload?.formAmount || 0);
    });
    const rows = Object.entries(byType).map(([label, v], i) =>
      `<tr><td>${i+1}</td><td>${escapeHtml(label)}</td><td>${v.count}</td><td>${money(v.value)}</td></tr>`
    ).join('');
    return `
      <div class="stack">
        <div class="form-card">
          <h3>My Approvals</h3>
          <div class="kpi-row wrap">
            <div class="kpi"><div class="label">Officer</div><div class="number">${escapeHtml(st.name || '')}</div></div>
            <div class="kpi"><div class="label">Total Approved</div><div class="number">${filtered.length}</div></div>
            <div class="kpi"><div class="label">Total Value</div><div class="number">${money(totalValue)}</div></div>
          </div>
          <div class="action-inline balance-filters-row" style="margin-top:10px">${presets.map(([k,l])=>`<button class="filter-chip ${filter.preset===k?'active':'secondary'}" data-my-approvals-preset="${k}">${l}</button>`).join('')}<label class="inline-field"><span>From</span><input id="myApprovalsFrom" type="date" lang="en-GB" value="${filter.from||''}"></label><label class="inline-field"><span>To</span><input id="myApprovalsTo" type="date" lang="en-GB" value="${filter.to||''}"></label><button class="secondary" id="myApprovalsCustomApply">Apply Custom</button></div>
          <div class="table-wrap" style="margin-top:10px"><table class="table"><thead><tr><th>S/N</th><th>Request Type</th><th>Count</th><th>Total Value</th></tr></thead><tbody>${rows || '<tr><td colspan="4" class="muted">No approvals in range</td></tr>'}</tbody></table></div>
        </div>
      </div>`;
  }

  function bindMyApprovals() {
    qq('[data-my-approvals-preset]').forEach(btn => btn.onclick = () => {
      state.ui.myApprovalsFilter = { preset: btn.dataset.myApprovalsPreset, from: '', to: '' };
      save(); renderWorkspace();
    });
    if (byId('myApprovalsCustomApply')) byId('myApprovalsCustomApply').onclick = () => {
      state.ui.myApprovalsFilter = { preset: 'custom', from: byId('myApprovalsFrom')?.value || '', to: byId('myApprovalsTo')?.value || '' };
      save(); renderWorkspace();
    };
  }

  // ===== 2026-11-09 (client): Work / Tellerng / Approval / Treasury Review =====
  // A personal activity log: each person sees ONLY what they did themselves,
  // for one day (date picker) or for a past range (From / To). Read-only —
  // it reads the same requests, close-of-day records and audit trail the rest
  // of the app already keeps, and changes nothing.
  const STAFF_REVIEW_DEFS = {
    work_review:     { title: 'Work Review',     mode: 'submitted', cod: false },
    teller_review:   { title: 'Tellerng Review', mode: 'submitted', cod: true },
    treasury_review: { title: 'Treasury Review', mode: 'submitted', cod: true },
    approval_review: { title: 'Approval Review', mode: 'decided',   cod: false }
  };
  function reviewFilterFor(tool) {
    state.ui.reviewFilters ||= {};
    return (state.ui.reviewFilters[tool] ||= { mode: 'today', date: '', from: '', to: '' });
  }
  function reviewRangeOf(f) {
    if (f.mode === 'range') return { from: f.from || '', to: f.to || '' };
    const d = f.mode === 'day' && f.date ? f.date : businessDate();
    return { from: d, to: d };
  }
  function staffReviewRows(tool, st) {
    const def = STAFF_REVIEW_DEFS[tool];
    const backendId = getStaffBackendId(st);
    const isMe = (id) => !!id && (id === st.id || id === backendId);
    const rows = [];
    const reqDetail = (r) => {
      try {
        return ['account_opening','account_maintenance','account_reactivation'].includes(r.type) ? approvalAccountHeadingsInline(r) : approvalDetails(r);
      } catch (_e) { return '—'; }
    };
    const reqAmount = (r) => { const p = r.payload || {}; return Number(p.amount || p.formAmount || 0); };
    (state.approvals || []).forEach(r => {
      if (def.mode === 'submitted') {
        const mine = isMe(r.requestedBy) || isMe(r.requestedByStaffId) || (!r.requestedBy && r.requestedByName && r.requestedByName === st.name);
        if (!mine) return;
        const at = r.requestedAt || '';
        rows.push({ at, date: dateOnly(at), activity: prettyApprovalType(r.type), details: reqDetail(r), amount: reqAmount(r), status: r.status || 'pending', other: r.status === 'pending' ? '—' : (r.approvedBy || r.approvedByName || '—') });
      } else {
        if (!['approved', 'rejected'].includes(String(r.status || ''))) return;
        const mine = (r.approvedBy && r.approvedBy === st.name) || isMe(r.approvedByStaffId);
        if (!mine) return;
        const at = r.approvedAt || r.requestedAt || '';
        rows.push({ at, date: dateOnly(at), activity: prettyApprovalType(r.type), details: reqDetail(r), amount: reqAmount(r), status: r.status, other: r.requestedByName || staffName(r.requestedBy) || '—' });
      }
    });
    if (def.cod) {
      (state.cod || []).filter(c => isMe(c.staffId)).forEach(c => {
        const at = c.submittedAt || c.resolvedAt || c.createdAt || '';
        rows.push({ at: at || `${c.date}T23:59:00`, date: String(c.date || dateOnly(at) || '').slice(0, 10), activity: 'Close of Day', details: `Remaining ${money(c.remainingBalance ?? c.runningFloat ?? 0)} • Variance ${money(c.variance || 0)}`, amount: Number(c.remainingBalance ?? c.runningFloat ?? c.actualCash ?? 0), status: String(c.status || 'submitted').toLowerCase(), other: '—' });
      });
    }
    (state.audit || []).filter(a => isMe(a.actorId) && !['request_created', 'request_approved', 'request_rejected'].includes(a.action)).forEach(a => {
      rows.push({ at: a.at || '', date: dateOnly(a.at), activity: String(a.action || 'activity').replace(/_/g, ' ').replace(/^./, ch => ch.toUpperCase()), details: escapeHtml(String(a.details || '').replace(/<[^>]*>/g, '')) || '—', amount: 0, status: 'done', other: '—' });
    });
    return rows.sort((a, b) => new Date(b.at || 0) - new Date(a.at || 0));
  }
  function renderStaffReview(tool) {
    const st = currentStaff();
    const def = STAFF_REVIEW_DEFS[tool];
    if (!st || !def) return `<div class="form-card"><div class="note">No staff session found.</div></div>`;
    const f = reviewFilterFor(tool);
    const range = reviewRangeOf(f);
    historyCovers(range.from || null);
    const inRange = staffReviewRows(tool, st).filter(r => r.date && (!range.from || r.date >= range.from) && (!range.to || r.date <= range.to));
    const count = (k) => inRange.filter(r => r.status === k).length;
    const value = inRange.filter(r => r.status === 'approved').reduce((t, r) => t + r.amount, 0);
    const decided = def.mode === 'decided';
    const body = inRange.map((r, i) => `<tr><td>${i + 1}</td><td>${r.date ? fmtDate(`${r.date}T12:00:00.000Z`) : '—'}</td><td>${r.at ? TIME_FMT.format(new Date(r.at)) : '—'}</td><td>${escapeHtml(r.activity)}</td><td>${r.details || '—'}</td><td>${r.amount ? money(r.amount) : ''}</td><td><span class="badge ${escapeHtml(r.status)}">${escapeHtml(r.status)}</span></td><td>${escapeHtml(r.other)}</td></tr>`).join('');
    const label = f.mode === 'range' ? `${range.from ? fmtDate(`${range.from}T12:00:00.000Z`) : 'Start'} – ${range.to ? fmtDate(`${range.to}T12:00:00.000Z`) : 'Today'}` : fmtDate(`${range.from}T12:00:00.000Z`);
    const showTeller = def.cod || tool === 'teller_review';
    return `
      <div class="stack">
        <div class="form-card">
          <h3>${def.title}</h3>
          ${showTeller ? tellerBannerHtml(st) : ''}
          <div class="kpi-row wrap">
            <div class="kpi"><div class="label">Staff</div><div class="number">${escapeHtml(st.name || '')}</div></div>
            <div class="kpi"><div class="label">Period</div><div class="number">${label}</div></div>
            <div class="kpi"><div class="label">${decided ? 'Decisions' : 'Activities'}</div><div class="number">${inRange.length}</div></div>
            <div class="kpi"><div class="label">Approved</div><div class="number">${count('approved')}</div></div>
            ${decided ? '' : `<div class="kpi"><div class="label">Pending</div><div class="number">${count('pending')}</div></div>`}
            <div class="kpi"><div class="label">Rejected</div><div class="number">${count('rejected')}</div></div>
            <div class="kpi"><div class="label">Approved Value</div><div class="number">${money(value)}</div></div>
          </div>
          <div class="action-inline balance-filters-row" style="margin-top:10px">
            <button class="filter-chip ${f.mode === 'today' ? 'active' : 'secondary'}" id="reviewToday">Today</button>
            <div class="inline-field review-business-date"><span>Business Date</span><strong>${fmtDate(businessDate())}</strong></div>
            <label class="inline-field"><span>From</span><input id="reviewFrom" type="date" lang="en-GB" value="${escapeHtml(f.from || '')}"></label>
            <label class="inline-field"><span>To</span><input id="reviewTo" type="date" lang="en-GB" value="${escapeHtml(f.to || '')}"></label>
            <button class="filter-chip ${f.mode === 'range' ? 'active' : 'secondary'}" id="reviewApplyRange">Apply Range</button>
          </div>
          <div class="table-wrap" style="margin-top:10px"><table class="table"><thead><tr><th>S/N</th><th>Date</th><th>Time</th><th>Activity</th><th>Details</th><th>Amount</th><th>Status</th><th>${decided ? 'Submitted By' : 'Decided By'}</th></tr></thead><tbody>${body || '<tr><td colspan="8" class="muted">No activity in this period</td></tr>'}</tbody></table></div>
        </div>
      </div>`;
  }
  function bindStaffReview() {
    const tool = state.ui.tool;
    const f = reviewFilterFor(tool);
    const todayBtn = byId('reviewToday');
    if (todayBtn) todayBtn.onclick = () => { f.mode = 'today'; f.date = ''; save(); renderWorkspace(); };
    // Tapping anywhere on a date field opens the calendar (the field itself is an invisible
    // layer over the dd/mm/yyyy display, so the browser's own tiny icon is not reachable).
    ['reviewFrom', 'reviewTo'].forEach(id => {
      const el = byId(id);
      if (!el) return;
      el.addEventListener('click', () => { try { el.showPicker && el.showPicker(); } catch (_e) { /* browser without showPicker: native behaviour */ } });
      el.addEventListener('change', () => {
        const from = byId('reviewFrom')?.value || '';
        const to = byId('reviewTo')?.value || '';
        if (from && to && from <= to) { f.mode = 'range'; f.from = from; f.to = to; save(); renderWorkspace(); }
      });
    });
    const applyBtn = byId('reviewApplyRange');
    if (applyBtn) applyBtn.onclick = () => {
      const from = byId('reviewFrom')?.value || '';
      const to = byId('reviewTo')?.value || '';
      if (!from && !to) return showToast('Pick a From or To date');
      if (from && to && from > to) return showToast('From date must not be after To date');
      f.mode = 'range'; f.from = from; f.to = to; save(); renderWorkspace();
    };
  }

  async function openStaffLedgerModal(staffId) {
    const staff = staffById(staffId);
    if (!staff) return showToast('Staff not found');
    const acc = ensureStaffAccount(staffId);
    const staffName = staff.name || staff.full_name || staffId;
    const staffRole = staffRoleLabels(staff);
    // SURGICAL ADDITION 2026-09-04 (client request): admins asked to be
    // able to see/filter every staff's statement from here. One shared
    // filter (Daily/Weekly/Monthly/All/Custom, same pattern as My
    // Statement/Collector Totals) — persisted per staffId so switching
    // staff doesn't carry over someone else's date range.
    state.ui.staffLedgerFilters ||= {};
    const filter = state.ui.staffLedgerFilters[staffId] ||= { preset: 'all', from: '', to: '' };
    const presets = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['all','All']];

    // Show modal immediately with local data, then upgrade with Supabase data
    function cleanStaffLedgerDetails(value) {
      return String(value || '—')
        .replace(/\s+posted from approval\s+[0-9a-f-]{12,}/ig, '')
        .replace(/\s+from approval\s+[0-9a-f-]{12,}/ig, '')
        .replace(/approval\s+[0-9a-f-]{12,}/ig, 'approval')
        .replace(/\s{2,}/g, ' ')
        .trim() || '—';
    }

    function staffLedgerDisplayDate(row) {
      return String(row.businessDate || row.business_date || row.floatDate || row.float_date || row.date || businessDate()).slice(0,10);
    }

    function buildRows(events) {
      return events.map((row, i) => {
        const displayDate = staffLedgerDisplayDate(row);
        return `<tr><td>${i+1}</td><td>${fmtDate(`${displayDate}T12:00:00.000Z`)}</td><td>${escapeHtml(row.type)}</td>${tellerStatementCells(row)}<td>${escapeHtml(cleanStaffLedgerDetails(row.details || row.note || '—'))}</td></tr>`;
      }).join('');
    }

    function buildModal(rows, loading) {
      const cod = staffCODRecords(staffId).slice().sort((a,b)=>new Date(b.submittedAt||b.resolvedAt||b.date)-new Date(a.submittedAt||a.resolvedAt||a.date))[0];
      return `
      <div class="stack staff-ledger-modal">
        <div class="kpi-row wrap staff-ledger-kpis">
          <div class="kpi"><div class="label">Staff</div><div class="number">${escapeHtml(staffName)}</div></div>
          <div class="kpi"><div class="label">Office</div><div class="number">${escapeHtml(staffRole)}</div></div>
          <div class="kpi"><div class="label">Account No.</div><div class="number">${escapeHtml(staffOperationalAccountNumber(staffId) || acc.accountNumber || '—')}</div></div>
          <div class="kpi"><div class="label">Op. Balance</div><div class="number">${money(getStaffOperationalBalance(staffId))}</div></div>
          <div class="kpi"><div class="label">Debt</div><div class="number ${Number(acc.debtBalance||0)>0 ? 'balance-negative' : ''}">${money(acc.debtBalance||0)}</div></div>
        </div>
        ${cod ? `<div class="note">Latest COD: <strong>${fmtDate(`${cod.date || cod.submittedAt}T12:00:00.000Z`)}</strong> • ${escapeHtml(cod.status || 'submitted')} • Remaining ${money(cod.remainingBalance ?? cod.runningFloat ?? cod.actualCash ?? 0)}</div>` : '<div class="note">No COD record yet for this staff.</div>'}
        ${loading ? '<div class="note" style="color:var(--text-muted)">Loading ledger from server…</div>' : ''}
        <div class="action-inline balance-filters-row">${presets.map(([k,l])=>`<button class="filter-chip ${filter.preset===k?'active':'secondary'}" data-staff-ledger-preset="${k}">${l}</button>`).join('')}<label class="inline-field"><span>From</span><input id="staffLedgerFrom" type="date" lang="en-GB" value="${filter.from||''}"></label><label class="inline-field"><span>To</span><input id="staffLedgerTo" type="date" lang="en-GB" value="${filter.to||''}"></label><button class="secondary" id="staffLedgerCustomApply">Apply Custom</button><button class="secondary" id="staffLedgerPrintBtn">Print</button></div>
        <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Date</th><th>Entry</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Details</th></tr></thead><tbody>${rows || '<tr><td colspan="7" class="muted">No ledger entries in range</td></tr>'}</tbody></table></div>
      </div>`;
    }

    function bindModalControls(allEvents) {
      qq('[data-staff-ledger-preset]').forEach(btn => btn.onclick = () => {
        state.ui.staffLedgerFilters[staffId] = { preset: btn.dataset.staffLedgerPreset, from: '', to: '' };
        save();
        const modalBody = document.querySelector('.modal-body');
        if (modalBody) modalBody.innerHTML = buildModal(buildRows(filterByDate(allEvents, state.ui.staffLedgerFilters[staffId])), false);
        bindModalControls(allEvents);
      });
      if (byId('staffLedgerCustomApply')) byId('staffLedgerCustomApply').onclick = () => {
        state.ui.staffLedgerFilters[staffId] = { preset: 'custom', from: byId('staffLedgerFrom')?.value || '', to: byId('staffLedgerTo')?.value || '' };
        save();
        const modalBody = document.querySelector('.modal-body');
        if (modalBody) modalBody.innerHTML = buildModal(buildRows(filterByDate(allEvents, state.ui.staffLedgerFilters[staffId])), false);
        bindModalControls(allEvents);
      };
      if (byId('staffLedgerPrintBtn')) byId('staffLedgerPrintBtn').onclick = () => {
        const filtered = filterByDate(allEvents, state.ui.staffLedgerFilters[staffId]);
        const printRows = filtered.map((row, i) => `<tr><td>${i+1}</td><td>${fmtDate(`${staffLedgerDisplayDate(row)}T12:00:00.000Z`)}</td><td>${escapeHtml(row.type)}</td><td>${row.side === 'debit' ? money(row.amount) : ''}</td><td>${row.side === 'credit' ? money(row.amount) : ''}</td><td>${money(row.runningBalance)}</td><td>${escapeHtml(cleanStaffLedgerDetails(row.details || row.note || '—'))}</td></tr>`).join('');
        printHtml(`<div class="record-card"><h3>Statement — ${escapeHtml(staffName)} (${escapeHtml(acc.accountNumber || '—')})</h3><table class="table"><thead><tr><th>S/N</th><th>Date</th><th>Entry</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Details</th></tr></thead><tbody>${printRows || '<tr><td colspan="6">No entries in range</td></tr>'}</tbody></table></div>`, true);
      };
    }

    // Show immediately with local data
    const localEvents = staffLedgerEvents(staffId);
    openModal(`Staff Ledger — ${escapeHtml(staffName)}`, buildModal(buildRows(filterByDate(localEvents, filter)), false), [{ label:'Close', className:'secondary', onClick: closeModal }]);
    bindModalControls(localEvents);

    // SURGICAL CHANGE 2026-10-22: no longer swapped for the Supabase
    // staff_cash_ledger rows — that table only holds funding entries, not
    // the teller's customer credits/debits, so the swap hid them. The local
    // events above are built from every approved request (the same source
    // as the Till and operational balance), so they're complete.
    if (false && isSupabaseApprovalMode() && gateway.staff?.listStaffLedger) {
      try {
        const supabaseStaffId = staff.uuid || staff.auth_user_id || staffId;
        const result = await gateway.staff.listStaffLedger(supabaseStaffId);
        if (result?.ok && Array.isArray(result.data) && result.data.length > 0) {
          // Normalize Supabase ledger rows into the same format as local events
          let running = 0;
          const sbEvents = result.data.map((row, i) => {
            const entryType = String(row.entry_type || '').toLowerCase();
            const amount = Number(row.amount || 0);
            const delta = Number(row.delta || 0);
            let type = 'Entry';
            let runningType = 'other';
            if (['approved_form','approved_float'].includes(entryType)) { type = 'FORM'; runningType = 'form'; }
            else if (['customer_credit','credit'].includes(entryType)) { type = 'Credit Impact'; runningType = 'credit'; }
            else if (['customer_debit','debit'].includes(entryType)) { type = 'Debit Impact'; runningType = 'debit'; }
            else if (entryType === 'debt_repayment') { type = 'Debt Repayment'; }
            else if (['wallet_fund','wallet_funding'].includes(entryType)) { type = 'Wallet'; }
            else { type = entryType.replace(/_/g,' ').replace(/\w/g,c=>c.toUpperCase()); }
            // SURGICAL FIX 2026-09-04 (client-confirmed bug, same as the
            // gateway delta fix): this fallback — only used when a row's
            // stored delta is 0/missing — treated credit the same as debit
            // (both -amount). Credit now correctly falls back to +amount.
            // Note: historical rows that already have a nonzero (wrong-
            // signed) delta from before the gateway fix still display with
            // their old stored value — this only affects rows without one.
            if (['form','credit','debit'].includes(runningType)) running += delta || (runningType === 'debit' ? -amount : amount);
            return {
              date: String(row.business_date || row.float_date || '').slice(0,10),
              businessDate: row.business_date || row.float_date || null,
              floatDate: row.float_date || null,
              createdAt: row.created_at || null,
              type,
              amount,
              runningBalance: running,
              details: row.note || '—'
            };
          }).sort((a,b)=> new Date(`${staffLedgerDisplayDate(b)}T12:00:00Z`) - new Date(`${staffLedgerDisplayDate(a)}T12:00:00Z`));

          // Update modal content
          const modalBody = document.querySelector('.modal-body, .modal .stack')?.closest('.modal-body') || document.querySelector('.modal-body');
          if (modalBody) modalBody.innerHTML = buildModal(buildRows(filterByDate(sbEvents, state.ui.staffLedgerFilters[staffId] || filter)), false);
          bindModalControls(sbEvents);
        } else {
          // No Supabase data — remove loading indicator
          const modalBody = document.querySelector('.modal-body');
          if (modalBody) modalBody.innerHTML = buildModal(buildRows(filterByDate(localEvents, state.ui.staffLedgerFilters[staffId] || filter)), false);
          bindModalControls(localEvents);
        }
      } catch (err) {
        console.warn('[DUCESS] Staff ledger Supabase fetch failed:', err);
      }
    }
  }

function normalizeStaffLedgerEntryType(row) {
    return String(row?.entry_type || row?.type || row?.entryType || '').toLowerCase();
  }

  function summarizeStaffLedgerRows(rows = []) {
    const sorted = [...rows].sort((a,b)=>new Date(a.created_at || a.createdAt || a.float_date || a.floatDate || a.date || 0) - new Date(b.created_at || b.createdAt || b.float_date || b.floatDate || b.date || 0));
    let balance = 0;
    let totalCreditReceived = 0;
    let totalDebitsPaid = 0;
    sorted.forEach(row => {
      const type = normalizeStaffLedgerEntryType(row);
      const amount = Number(row.amount || 0);
      const delta = Number(row.delta || 0);
      if (Number.isFinite(delta) && delta !== 0) balance += delta;
      else if (['approved_form','approved_float','approved_float_topup','wallet_fund','wallet_funding'].includes(type)) balance += amount;
      // SURGICAL FIX 2026-09-04 (client-confirmed bug): fallback path (used
      // only when a row has no delta) treated credit and debit identically
      // as reductions. Credit (deposit) now correctly adds.
      else if (['customer_credit','customer_credit_journal','credit'].includes(type)) balance += amount;
      else if (['customer_debit','customer_debit_journal','debit'].includes(type)) balance -= amount;
      if (['customer_credit','customer_credit_journal','credit'].includes(type)) totalCreditReceived += amount;
      if (['customer_debit','customer_debit_journal','debit'].includes(type)) totalDebitsPaid += amount;
    });
    const debtBalance = balance < 0 ? balance : 0;
    return { balance, debtBalance, totalCreditReceived, totalDebitsPaid };
  }

  function localTellerBalanceSummary(staffId) {
    const acc = ensureStaffAccount(staffId);
    const rows = (acc.entries || []).map(e => ({
      type: e.type,
      entry_type: e.type,
      amount: e.amount,
      delta: e.delta,
      date: e.date || e.floatDate || e.formDate || e.createdAt
    }));
    const summary = summarizeStaffLedgerRows(rows);
    return {
      balance: Number(acc.balance || summary.balance || 0),
      debtBalance: Number(acc.balance || 0) < 0 ? Number(acc.balance || 0) : Number(acc.debtBalance || 0) > 0 ? -Number(acc.debtBalance || 0) : summary.debtBalance,
      totalCreditReceived: summary.totalCreditReceived,
      totalDebitsPaid: summary.totalDebitsPaid
    };
  }

  function getTellerBalanceSummary(staffId) {
    state.ui ||= {};
    state.ui.tellerLedgerSummaries ||= {};
    return state.ui.tellerLedgerSummaries[staffId] || localTellerBalanceSummary(staffId);
  }

  async function refreshTellerBalanceLedgerSummaries() {
    if (!isSupabaseApprovalMode() || !gateway.staff?.listStaffLedger) return;
    state.ui ||= {};
    if (state.ui.tellerLedgerLoading) return;
    state.ui.tellerLedgerLoading = true;
    try {
      state.ui.tellerLedgerSummaries ||= {};
      const visibleStaff = state.staff.slice(0, state.ui.tellerEntriesLimit || 20);
      let changed = false;
      for (const s of visibleStaff) {
        const supabaseStaffId = s.uuid || s.auth_user_id || s.authUserId || s.id;
        const result = await gateway.staff.listStaffLedger(supabaseStaffId);
        if (result?.ok && Array.isArray(result.data)) {
          state.ui.tellerLedgerSummaries[s.id] = summarizeStaffLedgerRows(result.data);
          changed = true;
        }
      }
      if (changed) {
        save();
        if (state.ui.tool === 'teller_balances') renderWorkspace();
      }
    } catch (err) {
      console.warn('[DUCESS] Teller balance ledger summary refresh failed:', err);
    } finally {
      state.ui.tellerLedgerLoading = false;
    }
  }

  function renderTellerBalances() {
    const rows = state.staff.slice(0, state.ui.tellerEntriesLimit || 20).map(s=>{
      const acc = ensureStaffAccount(s.id);
      const summary = getTellerBalanceSummary(s.id);
      const debtBalance = Number(summary.debtBalance || 0);
      const totalCreditReceived = Number(summary.totalCreditReceived || 0);
      const totalDebitsPaid = Number(summary.totalDebitsPaid || 0);
      const balance = Number(summary.balance ?? acc.balance ?? 0);
      // SURGICAL ADDITION 2026-09-04 (client request): show Collector totals
      // alongside every other staff total on this screen. All-time, no date
      // filter (this report has none) — 0 for every non-Collector, since
      // getCollectorTotal only ever matches inter_staff_credit rows tagged
      // with this staffId as collectorId.
      const totalCollected = getCollectorTotal(s.id);
      return `<tr><td>${escapeHtml(s.name || '')}</td><td>${staffRoleLabels(s)}</td><td>${escapeHtml(acc.accountNumber || '')}</td><td>${money(balance)}</td><td class="balance-negative">${debtBalance < 0 ? "-" + money(Math.abs(debtBalance)) : money(0)}</td><td>${money(totalCreditReceived)}</td><td>${money(totalDebitsPaid)}</td><td>${money(totalCollected)}</td><td><button class="secondary" data-staff-ledger="${s.id}">Ledger</button></td></tr>`;
    }).join('');
    return `<div class="table-card"><div class="action-row" style="justify-content:space-between;align-items:center"><h3>Teller and Posting Accounts</h3><div class="note" style="margin:0">Business Date: <strong>${businessDate()}</strong></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Staff</th><th>Office</th><th>Account Number</th><th>Balance</th><th>Debt Balance</th><th>Total Credit Received</th><th>Total Debits Paid</th><th>Total Collected</th><th>Ledger</th></tr></thead><tbody>${rows}</tbody></table></div><div class="action-row">${state.staff.length > (state.ui.tellerEntriesLimit || 20) ? `<button id="tellerMore" class="secondary">Show More</button>` : ''}${(state.ui.tellerEntriesLimit || 20) > 20 ? `<button id="tellerLess" class="secondary">Show Less</button>` : ''}</div></div>`;
  }

  function allApprovedCustomerTx(kind) {
    return flattenCustomerTx().filter(t => t.type === kind);
  }
  function flattenCustomerTx() {
    return state.customers.flatMap(customer => (customer.transactions||[]).map(tx => ({ ...tx, customer })) ).sort((a,b)=>new Date(b.date)-new Date(a.date));
  }

  
  function isTelleringDirectModalTool(tool) {
    return ['form', 'my_close_day'].includes(tool);
  }

  // SURGICAL FIX 2026-08-19: the previous version made the native input's
  // TEXT transparent and overlaid a mirror on top — but (1) it read the
  // overlay's color from the input's OWN computed style AFTER already
  // making that transparent, so the overlay copied the invisibility too
  // (zero-visibility bug), and (2) color:transparent only hides text, not
  // Chrome's internal focus-highlight box around the actively-edited date
  // segment, which kept showing through as a stray blue rectangle (overlap
  // bug). Replaced with the standard robust pattern instead: the native
  // input is made FULLY invisible (opacity:0, not just text-transparent, so
  // nothing internal can leak through) and stacked on top to catch every
  // click/keyboard interaction; a plain, fully-visible text input sits
  // underneath showing the formatted value. The native input keeps its
  // original id, so every existing byId('someDateField').value read/write
  // anywhere in the app continues to work completely unchanged.
  function overlayDateInputsWithDDMMYYYY(root = document) {
    root.querySelectorAll('input[type="date"]').forEach(input => {
      if (input.dataset.ddmmyyyyMirrored) {
        const display = input.parentElement?.querySelector('.date-mirror-display');
        if (display) display.value = input.value ? fmtDate(input.value) : (input.getAttribute('placeholder') || 'dd/mm/yyyy');
        // Self-heal: if the icon somehow didn't render on the first pass,
        // add it now rather than leaving the field looking unclickable.
        if (input.parentElement && !input.parentElement.querySelector('.date-mirror-icon')) {
          const icon = document.createElement('span');
          icon.className = 'date-mirror-icon';
          icon.textContent = '📅';
          input.parentElement.appendChild(icon);
        }
        return;
      }
      input.dataset.ddmmyyyyMirrored = '1';

      let wrap = input.parentElement;
      if (!wrap || !wrap.classList.contains('date-mirror-wrap')) {
        wrap = document.createElement('span');
        wrap.className = 'date-mirror-wrap';
        input.parentNode.insertBefore(wrap, input);
        wrap.appendChild(input);
      }

      // Copy the native input's own classes onto the display input so it
      // renders identically across the ~10 different screens/size variants
      // this is used on, rather than guessing one shared style.
      const display = document.createElement('input');
      display.type = 'text';
      display.readOnly = true;
      display.tabIndex = -1;
      display.className = input.className + ' date-mirror-display';
      display.value = input.value ? fmtDate(input.value) : 'dd/mm/yyyy';
      wrap.insertBefore(display, input);

      // Making the native input fully opacity:0 (needed to hide its internal
      // focus-highlight box — see 2026-08-19 fix note above) also hides its
      // calendar icon, removing any visible sign the field is clickable.
      // Add our own decorative icon back — pointer-events:none so clicks
      // still reach the native input underneath, not this icon.
      const icon = document.createElement('span');
      icon.className = 'date-mirror-icon';
      icon.textContent = '📅';
      wrap.appendChild(icon);

      input.classList.add('date-mirror-native');
      input.addEventListener('input', () => { display.value = input.value ? fmtDate(input.value) : 'dd/mm/yyyy'; });
      input.addEventListener('change', () => { display.value = input.value ? fmtDate(input.value) : 'dd/mm/yyyy'; });
    });
  }

  function bindToolHandlers() {
    if (APPROVAL_SUB_TOOLS[state.ui.tool]) { bindApprovals(); return; }
    if (ADMIN_SUB_TOOLS[state.ui.tool]) { bindAdminSub(state.ui.tool); return; }
    if (BALANCE_SUB_TOOLS[state.ui.tool]) { bindPeriodBalance(); return; }
    switch (state.ui.tool) {
      case 'check_balance': bindCheckBalance(); break;
      case 'my_statement': bindMyStatement(); break;
      case 'my_approvals': bindMyApprovals(); break;
      case 'work_review': case 'teller_review': case 'approval_review': case 'treasury_review': bindStaffReview(); break;
      case 'account_opening': bindAccountOpening(); break;
      case 'account_maintenance': bindMaintenance('maintenance'); break;
      case 'account_reactivation': bindMaintenance('reactivation'); break;
      case 'account_statement': bindStatement(); break;
      case 'staff_credit': bindStaffCredit(); break;
      case 'intra_transfer': bindIntraTransfer(); break;
      case 'transaction_summary': bindTransactionSummary(); break;
      case 'credit': bindJournal('credit'); break;
      case 'debit': bindJournal('debit'); break;
      case 'journal_debit': case 'journal_credit': bindJournalStandalone(); break;
      case 'journal_register': bindJournalRegister(); break;
      case 'central_close_day':
      case 'approval_queue':
      case 'approval_customer_service':
      case 'approval_tellering':
      case 'approval_non_cash':
      case 'approval_others':
      case 'approval_history': bindApprovals(); break;
      case 'permissions': bindPermissions(); break;
      case 'operational_posting': bindOperationalAccounts(); break;
      case 'operational_accounts': bindOperationalAccounts(); break;
      case 'staff_directory': bindStaffDirectory(); break;
      case 'staff_roster': bindStaffDirectory(); break;
      case 'customer_directory': bindCustomerDirectory(); break;
      case 'business_balance': bindBalanceFilters('business'); break;
      case 'operational_balance': bindBalanceFilters('operational'); break;
      case 'teller_balances': bindTellerBalances(); break;
      case 'collector_balance': bindCollectorBalance(); break;
    }
    overlayDateInputsWithDDMMYYYY(byId('workspace') || document);
  }

  function canAssignFloatTopUp(staff=currentStaff()) {
    return staffHasRole(staff, 'admin_officer') || staffHasRole(staff, 'approving_officer');
  }

  function bindTellerBalances() {
    const tellerMore = byId('tellerMore');
    if (tellerMore) tellerMore.onclick = () => { state.ui.tellerEntriesLimit = (state.ui.tellerEntriesLimit || 20) + 20; save(); renderWorkspace(); };
    const tellerLess = byId('tellerLess');
    if (tellerLess) tellerLess.onclick = () => { state.ui.tellerEntriesLimit = Math.max(20, (state.ui.tellerEntriesLimit || 20) - 20); save(); renderWorkspace(); };
    qq('[data-assign-topup]').forEach(btn => btn.onclick = () => openFloatTopUpModal(btn.dataset.assignTopup));
    qq('[data-staff-ledger]').forEach(btn => btn.onclick = () => openStaffLedgerModal(btn.dataset.staffLedger));
    refreshTellerBalanceLedgerSummaries();
  }

  // SURGICAL ADDITION 2026-09-04 (client request): dedicated "Collector
  // Totals" report — how much each Collector has brought to Treasury.
  // Entirely read-only: it only aggregates already-approved
  // inter_staff_credit rows via getCollectorTotal() above and posts
  // nothing of its own, so it has zero effect on Business Balance,
  // Overall Balance, or any other rollup.
  function renderCollectorBalance() {
    const filter = state.ui.collectorFilter || { preset: 'daily', from: '', to: '' };
    const presets = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['all','All']];
    // SURGICAL UPDATE 2026-09-09 (client-confirmed design): this rollup now
    // covers all "Received From" source types from Cash Receipt — Teller,
    // Admin (fixed staff rosters, listed even at zero so the roster stays
    // visible) and Customer (not a fixed roster — pulled from whichever
    // customers have actually been tagged on an approved cash receipt,
    // since listing every customer in the system would be pointless
    // noise). SURGICAL REMOVAL 2026-09-14 (client-confirmed design): the
    // "Collector" role is retired entirely — dropped from this roster.
    const staffSources = (state.staff || [])
      // Role/staff separation: a staff member who has since been reassigned
      // still appears (totals are tied to the person who handed the cash over).
      .filter(s => staffEverHeldRole(s.id, ['teller', 'admin_officer']))
      .map(s => {
        const cur = staffRoleCode(s);
        const heldBefore = ['teller', 'admin_officer'].filter(r => r !== cur && staffEverHeldRole(s.id, [r]));
        const label = roleLabelOf(cur) + (heldBefore.length && !['teller', 'admin_officer'].includes(cur) ? ` (formerly ${heldBefore.map(roleLabelOf).join(' / ')})` : '');
        return { id: s.id, name: s.name || '', role: label, ref: s.staffCode || s.staff_code || s.staffId || s.id || '—' };
      });
    const customerSourceIds = new Set();
    (state.approvals || []).forEach(r => {
      if (r.status === 'approved' && r.type === 'cash_receipt' && r.payload?.receivedFromType === 'customer' && r.payload?.receivedFromId) {
        customerSourceIds.add(r.payload.receivedFromId);
      }
    });
    const customerSources = Array.from(customerSourceIds)
      .map(id => (state.customers || []).find(c => c.id === id))
      .filter(Boolean)
      .map(c => ({ id: c.id, name: c.name || '', role: 'Customer', ref: c.accountNumber || c.account_number || '—' }));
    const allSources = [...staffSources, ...customerSources];
    const rows = allSources.map((s, i) => {
      const periodTotal = getCollectorTotal(s.id, filter);
      const allTimeTotal = getCollectorTotal(s.id, { preset: 'all' });
      return `<tr><td>${i+1}</td><td>${escapeHtml(s.name)}</td><td>${escapeHtml(s.role)}</td><td><code style="font-size:0.85em">${escapeHtml(String(s.ref))}</code></td><td>${money(periodTotal)}</td><td>${money(allTimeTotal)}</td></tr>`;
    }).join('');
    const grandPeriod = allSources.reduce((sum, s) => sum + getCollectorTotal(s.id, filter), 0);
    return `
      <div class="table-card">
        <div class="action-inline"><h3 style="margin:0">Received-From Totals</h3></div>
        <div class="note" style="margin:6px 0">How much each Teller, Admin, or Customer has brought in and handed to Treasury — a read-only summary of already-approved Cash Receipt entries tagged "Received From" them. Posts nothing of its own and does not affect Business Balance.</div>
        <div class="action-inline balance-filters-row">${presets.map(([k,l])=>`<button class="filter-chip ${filter.preset===k?'active':'secondary'}" data-collector-filter-preset="${k}">${l}</button>`).join('')}<label class="inline-field"><span>From</span><input id="collectorFrom" type="date" lang="en-GB" value="${filter.from||''}"></label><label class="inline-field"><span>To</span><input id="collectorTo" type="date" lang="en-GB" value="${filter.to||''}"></label><button class="secondary" id="collectorCustomApply">Apply Custom</button></div>
        <div class="table-wrap"><table class="table"><thead><tr><th>S/N</th><th>Name</th><th>Role</th><th>Reference</th><th>Total Collected (Period)</th><th>Total Collected (All-Time)</th></tr></thead><tbody>${rows || '<tr><td colspan="6">No sources found</td></tr>'}${allSources.length ? `<tr class="total-row"><td colspan="4"><strong>Total (Period)</strong></td><td><strong>${money(grandPeriod)}</strong></td><td></td></tr>` : ''}</tbody></table></div>
      </div>`;
  }

  function bindCollectorBalance() {
    qq('[data-collector-filter-preset]').forEach(btn => btn.onclick = () => {
      state.ui.collectorFilter = { preset: btn.dataset.collectorFilterPreset, from: '', to: '' };
      save(); renderWorkspace();
    });
    if (byId('collectorCustomApply')) byId('collectorCustomApply').onclick = () => {
      state.ui.collectorFilter = { preset: 'custom', from: byId('collectorFrom')?.value || '', to: byId('collectorTo')?.value || '' };
      save(); renderWorkspace();
    };
  }

  function openFloatTopUpModal(staffId=null) {
    if (!canAssignFloatTopUp()) return showToast('Only Approval Officer or Admin can assign float');
    const postingStaff = state.staff.filter(x => hasPermission('credit', x) || hasPermission('debit', x));
    const defaultStaff = state.staff.find(x => x.id === staffId) || postingStaff[0];
    if (!defaultStaff) return showToast('No eligible staff found');
    openModal('Assign Float Top-Up', `
      <div class="form-grid three">
        <div class="field"><label>Staff</label><select id="floatTopupStaff" class="entry-input">${postingStaff.map(st => `<option value="${st.id}" ${st.id===defaultStaff.id?'selected':''}>${escapeHtml(st.name || '')} — ${staffRoleLabels(st)}</option>`).join('')}</select></div>
        <div class="field"><label>Date</label><div class="display-field">${businessDate()}</div></div>
        <div class="field"><label>Amount</label><input id="floatTopupAmount" class="entry-input" type="number"></div>
      </div>
      <div class="form-grid one">
        <div class="field"><label>Note</label><input id="floatTopupNote" class="entry-input"></div>
      </div>
      <div class="note">This request goes to Approvals → Others. Once approved, it increases the available form immediately for the selected staff on the current business date.</div>
    </div>`, [
      { label: 'Cancel', className: 'secondary', onClick: closeModal },
      { label: 'Submit', onClick: () => {
          const selectedStaff = state.staff.find(x => x.id === byId('floatTopupStaff').value);
          const amount = Number(byId('floatTopupAmount').value || 0);
          const note = byId('floatTopupNote').value.trim();
          if (!selectedStaff) return showToast('Staff not found');
          if (!(amount > 0)) return showToast('Enter valid float top-up');
          createRequest('float_topup', { staffId: selectedStaff.id, staffName: selectedStaff.name, amount, date: businessDate(), note });
          closeModal();
          render();
          showToast('Float top-up sent for approval');
      }}
    ]);
  }

  function bindCheckBalance() {
    const hidePhoto = () => { const row = byId('checkBalancePhotoRow'); if (row) row.classList.add('hidden'); };
    const doLookup = (quiet=false) => {
      const val = (byId('lookupAcc')?.value || "").trim();
      hidePhoto();
      if (!val) { state.ui.checkBalanceLoaded = false; save(); return lookupFill(byId('workspace'), null); }
      const c = getCustomerByAccountNo(val);
      if (!c) { if (!quiet) showToast('Customer not found. Use name search.'); return; }
      // Clear any previously generated statement if switching to a different
      // customer, so Statement of Account never shows stale data.
      if (state.ui.selectedCustomerId !== c.id) state.ui.accountStatementGenerated = false;
      state.ui.selectedCustomerId = c.id;
      state.ui.checkBalanceLoaded = true;
      save();
      lookupFill(byId('workspace'), c);
    };
    byId('lookupBtn').onclick = () => openCustomerSearchModal(state.customers);
    // SURGICAL FIX 2026-09-03: client does not want the account fetched
    // live as-you-type or on blur/tab — only on explicit Enter. Typing now
    // only clears a stale display when the field is emptied; doLookup()
    // itself runs solely from the Enter keyup below.
    byId('lookupAcc').oninput = () => {
      const v = (byId('lookupAcc')?.value || '').trim();
      if (!v) doLookup(true);
    };
    byId('lookupAcc').onkeyup = (e) => { if (e.key === "Enter") doLookup(false); };
    byId('openStatementBtn').onclick = () => { state.ui.tool = 'account_statement'; renderWorkspace(); };
    const photoBtn = byId('searchPhotoBtn'); if (photoBtn) photoBtn.onclick = ()=> {
      const row = byId('checkBalancePhotoRow');
      const selected = getSelectedCustomer();
      if (!selected) return showToast('Search for customer first');
      if (row) row.classList.toggle('hidden');
      if (row && !row.classList.contains('hidden')) lookupFill(byId('workspace'), selected);
    };
    hidePhoto();
    const selected = state.ui.checkBalanceLoaded ? getSelectedCustomer() : null;
    if (selected && state.ui.selectedCustomerId) lookupFill(byId('workspace'), selected); else lookupFill(byId('workspace'), null);
  }

  function bindAccountOpening() {
    state.ui.accountOpeningDraft ||= {};
    const openingDraft = state.ui.accountOpeningDraft;

    // SURGICAL ADDITION 2026-08-26 (client correction): show the account
    // number preview inline on the form, before submission — using the
    // non-consuming peek RPC, never the real number-consuming generator.
    // Fetches fresh on every bind (i.e. every render/type-change) so the
    // preview stays current; harmless to call repeatedly since it never
    // reserves anything.
    const previewEl = byId('openAccountNumberPreview');
    if (previewEl) {
      const previewType = previewEl.dataset.previewType;
      (async () => {
        try {
          const result = await gateway.customers.peekSystemAccountNumber(previewType);
          const el = byId('openAccountNumberPreview');
          if (!el || el.dataset.previewType !== previewType) return; // form moved on since the fetch started
          el.innerHTML = result?.ok && result.data
            ? `Account Number:&nbsp;<strong>${escapeHtml(result.data)}</strong>`
            : `Account Number:&nbsp;<strong>assigned on submit</strong>`;
        } catch (err) {
          const el = byId('openAccountNumberPreview');
          if (el) el.innerHTML = `Account Number:&nbsp;<strong>assigned on submit</strong>`;
        }
      })();
    }

    // Account type picker (opens in place, covers nothing)
    const typeBtn = byId('openAccountTypeBtn'), typeOpts = byId('openAccountTypeOptions');
    if (typeBtn && typeOpts) typeBtn.onclick = () => {
      const open = typeOpts.classList.toggle('hidden') === false;
      typeBtn.setAttribute('aria-expanded', String(open));
      const caret = typeBtn.querySelector('.acct-type-caret'); if (caret) caret.textContent = open ? '▾' : '▸';
    };
    qq('[data-acct-type]').forEach(btn => btn.onclick = () => {
      const sel = byId('openAccountType'); if (!sel) return;
      typeOpts?.classList.add('hidden');
      if (sel.value === btn.dataset.acctType) { typeBtn?.setAttribute('aria-expanded', 'false'); const c = typeBtn?.querySelector('.acct-type-caret'); if (c) c.textContent = '▸'; return; }
      sel.value = btn.dataset.acctType;
      sel.dispatchEvent(new Event('change'));
    });

    // Re-render when account type changes
    const typeSelect = byId('openAccountType');
    if (typeSelect) typeSelect.onchange = () => {
      const v = typeSelect.value;
      if (v === 'teller_account') {
        openingDraft.accountType = 'staff_operational';
        openingDraft.opKind = 'teller';
      } else if (v === 'treasury_account') {
        openingDraft.accountType = 'treasury';
        openingDraft.opKind = '';
      } else {
        openingDraft.accountType = v;
        openingDraft.opKind = '';
      }
      openingDraft.name = '';
      openingDraft.linkedStaffId = '';
      openingDraft.accountNumber = '';
      save();
      renderWorkspace();
    };

    const photoInput = byId('openPhoto');
    const photoBtn = byId('openPhotoBtn');
    const photoStatus = byId('openPhotoStatus');

    const draftBindings = {
      openName: 'name',
      openAddress: 'address',
      openPhone: 'phone',
      openNin: 'nin',
      openBvn: 'bvn',
      openOldAccount: 'oldAccountNumber',
      openAccountNumber: 'accountNumber'
    };

    Object.entries(draftBindings).forEach(([id, key]) => {
      const input = byId(id);
      if (!input) return;
      input.addEventListener('input', () => { openingDraft[key] = input.value; });
      input.addEventListener('focus', () => { state.ui.accountOpeningFocusedField = id; });
    });

    const linkedStaffSelect = byId('openLinkedStaff');
    if (linkedStaffSelect) linkedStaffSelect.onchange = () => {
      openingDraft.linkedStaffId = linkedStaffSelect.value;
      if ((openingDraft.accountType || 'customer') === 'staff_operational') {
        const linkedStaff = (state.staff || []).find(s => s.id === linkedStaffSelect.value);
        openingDraft.name = linkedStaff ? `TELLER ${String(linkedStaff.name || '').toUpperCase()}` : '';
        save();
        renderWorkspace();
      }
    };

    const focusedField = byId(state.ui.accountOpeningFocusedField || '');
    if (focusedField) {
      requestAnimationFrame(() => {
        const cursorPosition = focusedField.value.length;
        focusedField.focus();
        if (focusedField.setSelectionRange) focusedField.setSelectionRange(cursorPosition, cursorPosition);
      });
    }
    if (photoBtn && photoInput) photoBtn.onclick = () => photoInput.click();
    if (photoInput) {
      if (openingDraft.photo) photoInput.dataset.base64 = openingDraft.photo;
      if (openingDraft.photoStatus && photoStatus) photoStatus.textContent = openingDraft.photoStatus;
    }
    if (photoInput) photoInput.onchange = async (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      try {
        const base64 = await toBase64(f);
        if (estimateDataUrlBytes(base64) > CUSTOMER_PHOTO_MAX_BYTES) {
          photoInput.value = ''; photoInput.dataset.base64 = '';
          openingDraft.photo = ''; openingDraft.photoStatus = 'No photo selected';
          if (photoStatus) photoStatus.textContent = 'No photo selected';
          return showToast('Photo must be 1 MB or less after compression');
        }
        photoInput.dataset.base64 = base64;
        openingDraft.photo = base64;
        const compressedLabel = `${formatFileSize(estimateDataUrlBytes(base64))}`;
        if (photoStatus) photoStatus.textContent = f.name.length > 18 ? `${f.name.slice(0,15)}... • ${compressedLabel}` : `${f.name} • ${compressedLabel}`;
        openingDraft.photoStatus = photoStatus?.textContent || 'No photo selected';
      } catch (error) {
        photoInput.value = ''; photoInput.dataset.base64 = '';
        openingDraft.photo = ''; openingDraft.photoStatus = 'No photo selected';
        if (photoStatus) photoStatus.textContent = 'No photo selected';
        showToast(error?.message || 'Unable to process selected photo');
      }
    };

    byId('submitOpening').onclick = async (e) => {
      const acctType = openingDraft.accountType || 'customer';
      const isCustomer = acctType === 'customer';
      const name = (byId('openName')?.value || '').trim();
      if (!name) return showToast('Account name is required');

      let payload;
      if (isCustomer) {
        const address = (byId('openAddress')?.value || '').trim();
        const phone = (byId('openPhone')?.value || '').trim();
        const nin = (byId('openNin')?.value || '').trim();
        const bvn = (byId('openBvn')?.value || '').trim();
        const accountNumber = (byId('openAccountNumber')?.value || '').trim();
        if (!address || !phone || !nin || !bvn) return showToast('Complete all required fields');
        // SURGICAL PATCH 2026-08-14: account number is now required at
        // opening (assigned by Customer Service), not optional/left for the
        // approving officer to fill in later.
        if (!accountNumber) return showToast('Account number is required');
        if (getCustomerByAccountNo(accountNumber)) return showToast('This account number is already in use');
        payload = {
          accountType: 'customer', name, address, phone, nin, bvn,
          accountNumber,
          oldAccountNumber: (byId('openOldAccount')?.value || '').trim(),
          generatedAccountNumber: accountNumber,
          photo: byId('openPhoto')?.dataset?.base64 || ''
        };
      } else if (acctType === 'staff_operational') {
        const linkedStaffId = (byId('openLinkedStaff')?.value || '').trim();
        if (!linkedStaffId) return showToast('Select a staff member to link this account to');
        const linkedStaff = (state.staff || []).find(s => s.id === linkedStaffId);
        const kind = 'teller';
        if (!linkedStaff || !isEligibleForOperationalAccount(linkedStaff, kind)) {
          return showToast(`${linkedStaff?.name || 'This staff member'} is not eligible — they are inactive, already have an operational account, or one is already pending`);
        }
        payload = {
          accountType: 'staff_operational', opKind: kind, name,
          linkedStaffId, linkedStaffName: linkedStaff?.name || '',
          systemAssigned: true, generatedAccountNumber: ''
        };
      } else if (acctType === 'staff_salary') {
        // No staff link — opens like a regular account with system-assigned number,
        // but collects the same identity details a customer account does.
        // Role classification removed 2026-08-14 — client only needs
        // account-number search on the Staff Salary Balance report.
        const address = (byId('openAddress')?.value || '').trim();
        const phone = (byId('openPhone')?.value || '').trim();
        const nin = (byId('openNin')?.value || '').trim();
        const bvn = (byId('openBvn')?.value || '').trim();
        if (!address || !phone || !nin || !bvn) return showToast('Complete all required fields');
        payload = {
          accountType: 'staff_salary', name,
          address, phone, nin, bvn,
          oldAccountNumber: (byId('openOldAccount')?.value || '').trim(),
          photo: byId('openPhoto')?.dataset?.base64 || '',
          systemAssigned: true, generatedAccountNumber: ''
        };
      } else {
        // expense, income or treasury — fully system-assigned, name only
        payload = { accountType: acctType, name, systemAssigned: true, generatedAccountNumber: '' };
      }

      // SURGICAL FIX 2026-08-26 (client correction): the real, number-
      // CONSUMING generator used to be called right here, before the user
      // had even confirmed — every click (including cancelled ones) burned
      // a real sequence value, which is exactly why testing produced
      // numbers like "I3008" instead of starting at 1. The number is now
      // only generated AFTER the user clicks Confirm below. They've already
      // seen the (non-consuming) preview inline on the form before this
      // point, so the confirm prompt itself can stay plain.
      const confirmMessage = acctType === 'staff_operational'
        ? `Open a Teller account for ${payload.linkedStaffName}? The account will be permanently linked to this staff member.`
        : `Submit ${acctType.replace('_',' ')} account opening request?`;

      confirmAction(confirmMessage, async () => {
        showProcessing(payload.systemAssigned ? 'Assigning account number...' : 'Sending request...'); await nextPaint();
        try {
          if (payload.systemAssigned) {
            const numResult = await gateway.customers.generateSystemAccountNumber(acctType);
            if (!numResult?.ok || !numResult.data) {
              return showToast(numResult?.error?.message || 'Could not assign an account number — try again');
            }
            payload.generatedAccountNumber = numResult.data;
          }
          const result = await submitApprovalThroughGateway('account_opening', payload);
          if (!result?.ok) return showToast(result?.error?.message || 'Unable to submit request');
          state.ui.accountOpeningDraft = {};
          state.ui.accountOpeningFocusedField = '';
          render();
          showToast(payload.systemAssigned ? `Account opening sent for approval — account number ${payload.generatedAccountNumber}` : 'Account opening sent for approval');
        } finally { hideProcessing(); }
      });
    };
  }

  function bindStaffCredit() {
    const draft = state.ui.staffCreditDraft ||= {};
    const amtInput = byId('staffCreditAmount');
    const noteInput = byId('staffCreditNote');
    if (amtInput) amtInput.oninput = () => { draft.amount = amtInput.value; };
    if (noteInput) noteInput.oninput = () => { draft.note = noteInput.value; };
    qq('input[name="staffCreditMode"]').forEach(r => r.onchange = () => { if (r.checked) draft.mode = r.value; });
    // SURGICAL REWRITE 2026-09-06: the target account now decides the whole
    // shape of the form (see renderStaffCredit) — picking it re-renders so
    // the right fields (My Treasury Balance vs Admin/Debit-an-Account) show.
    const accountSelect = byId('staffCreditAccount');
    if (accountSelect) {
      accountSelect.value = draft.accountId || '';
      accountSelect.onchange = () => {
        draft.accountId = accountSelect.value || '';
        draft.source = ''; draft.sourceAcct = ''; draft.sourceName = ''; draft.sourceId = ''; draft.sourceBalance = 0;
        save();
        renderWorkspace();
      };
    }
    qq('input[name="staffCreditSource"]').forEach(r => r.onchange = () => {
      if (!r.checked) return;
      draft.source = r.value;
      if (r.value !== 'account') { draft.sourceAcct = ''; draft.sourceName = ''; draft.sourceId = ''; draft.sourceBalance = 0; }
      save();
      renderWorkspace();
    });
    const sourceAccInput = byId('staffCreditSourceAcc');
    if (sourceAccInput) {
      const lookupSourceAcct = (quiet = false) => {
        const v = (byId('staffCreditSourceAcc')?.value || '').trim();
        // Funding source is limited to accounts that actually live in
        // state.customers (customers, staff_wallet, staff_operational,
        // etc.) — the same set the approval-time debit above can act on.
        const match = (state.customers || []).find(c => String(c.accountNumber || '') === v);
        if (!match) {
          draft.sourceName = ''; draft.sourceId = ''; draft.sourceBalance = 0;
          if (byId('staffCreditSourceInfo')) byId('staffCreditSourceInfo').innerHTML = v ? `<span style="color:var(--accent-red)">Account not found</span>` : '';
          if (!quiet && v) showToast('Account not found');
          return;
        }
        draft.sourceId = match.id;
        draft.sourceName = match.name || '';
        draft.sourceBalance = Number(match.balance || 0);
        if (byId('staffCreditSourceInfo')) byId('staffCreditSourceInfo').innerHTML = `<strong>${escapeHtml(draft.sourceName)}</strong> <span class="journal-cell-label">Balance: </span>${balanceHtml(draft.sourceBalance)}`;
      };
      // Enter-to-fetch only, same as every other account number field.
      sourceAccInput.oninput = () => {
        draft.sourceAcct = sourceAccInput.value; draft.sourceName = ''; draft.sourceId = ''; draft.sourceBalance = 0;
        if (byId('staffCreditSourceInfo')) byId('staffCreditSourceInfo').innerHTML = '';
      };
      sourceAccInput.onkeyup = (e) => { if (e.key === 'Enter') lookupSourceAcct(); };
      if (byId('staffCreditSourceSearch')) byId('staffCreditSourceSearch').onclick = () => { state.ui.nonCashSearchTarget = 'staffCreditSource'; openCustomerSearchModal(state.customers); };
    }
    const submitBtn = byId('submitStaffCredit');
    if (!submitBtn) return;
    submitBtn.onclick = async () => {
      const accountId = byId('staffCreditAccount')?.value;
      if (!accountId) return showToast('Select a staff account');
      const amount = Number(byId('staffCreditAmount')?.value || 0);
      if (!(amount > 0)) return showToast('Enter a valid amount');
      if (isBusinessDateClosed(businessDate())) return showToast(businessDateClosedMessage(businessDate()));
      const note = (byId('staffCreditNote')?.value || '').trim();
      const targetAccount = (state.customers || []).find(c => c.id === accountId);
      const targetStaff = (state.staff || []).find(s => s.id === targetAccount?.linkedStaffId);
      const st = currentStaff();
      let sourceAccount = null;
      let fundingSource;
      // SURGICAL REWRITE 2026-09-06 (client-confirmed design): funding a
      // Teller is now ALWAYS a real debit against the acting officer's own
      // Treasury balance — no injection option, no arbitrary source account,
      // enforced here, not left to whatever radio the person left checked.
      if (staffHasRole(targetStaff, 'teller')) {
        sourceAccount = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === st.id);
        if (!sourceAccount) return showToast('You have no Treasury account — ask Admin to open one before funding a Teller');
        if (sourceAccount.id === targetAccount.id) return showToast('Source and destination cannot be the same account');
        const myBalance = getStaffOperationalBalance(st.id);
        if (amount > myBalance + 0.01) return showToast(`Amount exceeds your Treasury balance (${money(myBalance)})`);
        fundingSource = 'treasury_balance';
      } else {
        // Funding Treasury's own account: Admin injection (unlimited) or a
        // real debit from any other account.
        fundingSource = draft.source === 'account' ? 'account' : 'admin_injection';
        if (fundingSource === 'admin_injection' && !staffHasRole(st, 'admin_officer')) {
          return showToast('Only Admin can inject cash — otherwise use Debit an Account');
        }
        if (fundingSource === 'account') {
          if (!draft.sourceId) return showToast('Look up the source account first');
          sourceAccount = (state.customers || []).find(c => c.id === draft.sourceId);
          if (!sourceAccount) return showToast('Source account not found — look it up again');
          if (sourceAccount.id === targetAccount?.id) return showToast('Source and destination cannot be the same account');
          if (amount > Number(sourceAccount.balance || 0) + 0.01) return showToast(`Amount exceeds the source account's balance (${money(sourceAccount.balance || 0)})`);
        }
      }
      const paymentMode = 'cash';
      const confirmMessage = fundingSource === 'treasury_balance'
        ? `Debit your Treasury balance ${money(amount)} to fund ${targetAccount?.name || 'this Teller'}?`
        : fundingSource === 'account'
        ? `Debit ${sourceAccount.name} ${money(amount)} to fund ${targetAccount?.name || 'staff account'}?`
        : `Credit ${targetAccount?.name || 'staff account'} ${money(amount)}?`;
      confirmAction(confirmMessage, async () => {
        showProcessing('Sending for approval...'); await nextPaint();
        try {
          const result = await submitApprovalThroughGateway('inter_staff_credit', {
            staffId: st.id, staffName: st.name,
            targetAccountId: accountId,
            targetAccountNumber: targetAccount?.accountNumber || targetAccount?.account_number,
            targetAccountName: targetAccount?.name || targetAccount?.displayName || targetAccount?.display_name,
            amount, paymentMode, date: businessDate(), note,
            fundingSource,
            sourceAccountId: sourceAccount?.id || '',
            sourceAccountNumber: sourceAccount?.accountNumber || '',
            sourceAccountName: sourceAccount?.name || ''
          });
          if (!result?.ok) return showToast(result?.error?.message || 'Unable to submit');
          state.ui.staffCreditDraft = {};
          render();
          showToast('Sent for approval');
        } finally { hideProcessing(); }
      });
    };
  }

  // SURGICAL ADDITION 2026-09-09 (client-confirmed design): "Credit Staff
  // Account" (Fund Account) is dissolved into Non Cash. Whenever the Credit
  // (destination) side resolves to a staff operational account (Teller or
  // Treasury), the Debit (source) side is force-locked to the ACTING
  // staff's own operational account — nobody can fund a staff account from
  // an arbitrary source anymore. To fund a Teller with a customer's money,
  // the acting officer now has to do it in two real, separately-attributed
  // steps: pull it into their own account first (an ordinary Non Cash
  // entry), then disburse from their own real balance (this locked case).
  // That two-step is what keeps the acting staff as the accountable
  // issuer instead of letting money jump straight from an arbitrary
  // account into a staff account with nobody's name on it.
  // Returns the staff's own operational account record, or null if they
  // don't have one. 2026-10-24 (client): staff without one (Treasury
  // officers) fund a staff account from a business Treasury account instead
  // — the Debit side stays open and is checked to be a Treasury account.
  function applyStaffAccountLock(draft) {
    const dest = draft.destId ? (state.customers || []).find(c => c.id === draft.destId) : null;
    if (!dest || dest.accountType !== 'staff_operational') return null;
    const st = currentStaff();
    const mine = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === st?.id);
    if (!mine) return null;
    draft.sourceId = mine.id;
    draft.sourceAcct = mine.accountNumber || mine.account_number || '';
    draft.sourceName = mine.name || mine.displayName || mine.display_name || '';
    // A staff operational account's real spendable balance is NOT its
    // customer.balance field (that only tracks real debits ever posted to
    // it) — it's the live aggregate from getStaffOperationalBalance (same
    // figure shown everywhere else as Till/Treasury/Teller balance).
    draft.sourceBalance = getStaffOperationalBalance(st.id);
    return mine;
  }

  // SURGICAL ADDITION 2026-10-01 (client-reported "Admin does not exist in
  // Supabase"): staff wallets (the 4000-series accounts) live only inside
  // the app, not in the Supabase customers table, so a Non Cash to/from
  // one passed submission and then failed at approval. Blocked up front
  // with a clear pointer to the real account to use.
  const STAFF_WALLET_NON_CASH_MSG = 'That is an internal staff wallet, not a bank account — use the staff member\'s Teller (T) account. Open one via Account Opening if they don\'t have it.';
  const isLocalOnlyStaffAccount = (c) => !!c && (c.accountType === 'staff_wallet' || c.accountType === 'staff');

  function renderIntraTransfer() {
    const draft = state.ui.intraTransferDraft ||= {};
    const sourceAccount = draft.sourceId ? (state.customers || []).find(c => c.id === draft.sourceId) : null;
    const destAccount = draft.destId ? (state.customers || []).find(c => c.id === draft.destId) : null;
    const st = currentStaff();
    const sourceLocked = !!(destAccount && destAccount.accountType === 'staff_operational' && (state.customers || []).some(c => c.accountType === 'staff_operational' && c.linkedStaffId === st?.id));
    const myTellerId = tellerIdLabel(st);
    const typeOf = (c) => c ? (c.accountType === 'staff_operational' ? 'Teller' : (c.accountType === 'staff_salary' ? 'Staff Salary' : (c.accountType === 'expense' ? 'Expense' : (c.accountType === 'income' ? 'Income' : (c.accountType === 'treasury' ? 'Treasury' : 'Customer'))))) : '—';
    const amountVal = escapeHtml(String(draft.amount || ''));
    // SURGICAL FIX 2026-09-28 (client-confirmed paper design): laid out as
    // the client's sheet — the two top-level headings of the form are Debit
    // and Credit. The sheet's side column ("Non Cash Posting / Debit To
    // Credit Entry") IS the app sidebar (styled to match, see
    // .tellering-tool-tabs .tool-group-* in app.css), so it isn't repeated
    // here. Element ids are unchanged, so bindIntraTransfer and the
    // customer picker keep working as before.
    return `
      <div class="nc-sheet spec-color-scheme">
        <div class="nc-form">
          <div class="nc-grid">
            <div class="nc-head">Debit</div>
            <div class="nc-label">Account Number</div>
            <div class="nc-cell"><input id="itrSourceAcct" class="entry-input" maxlength="12" value="${escapeHtml(String(draft.sourceAcct || ''))}" autocomplete="off" ${sourceLocked ? 'disabled' : ''}></div>
            <div class="nc-cell"><button id="itrLookupSource" class="nc-mini-btn" ${sourceLocked ? 'disabled' : ''}>Search</button></div>
            <div class="nc-cell nc-tag">Teller ID</div>
            <div class="nc-cell"><div class="display-field" id="itrTellerId">${escapeHtml(myTellerId)}</div></div>

            <div id="itrSourceLockNote" class="note nc-span-all" style="${sourceLocked ? '' : 'display:none'}">Crediting a staff account always debits <strong>your own</strong> operational account — locked so you stay the accountable issuer. To fund it with someone else's money, first move that money into your own account with a separate Non Cash entry, then fund the staff account from there.</div>

            <div class="nc-label">Account Name</div>
            <div class="nc-cell nc-span-4"><div id="itrSourceName" class="display-field">${draft.sourceName ? `<strong>${escapeHtml(draft.sourceName)}</strong>` : ''}</div></div>

            <div class="nc-label">Account Balance</div>
            <div class="nc-cell nc-span-2"><div id="itrSourceBalance" class="display-field">${draft.sourceId ? balanceHtml(draft.sourceBalance || 0) : ''}</div></div>
            <div class="nc-cell nc-span-2"></div>

            <div class="nc-label">Description</div>
            <div class="nc-cell nc-span-4"><input id="itrDetails" class="entry-input" value="${escapeHtml(String(draft.details || ''))}"></div>

            <div class="nc-label nc-label-grey">Paid By</div>
            <div class="nc-cell"><input id="itrPaidBy" class="entry-input" value="${escapeHtml(String(draft.paidBy || ''))}"></div>
            <div class="nc-cell nc-tag">Account Status</div>
            <div class="nc-cell nc-status-cell nc-span-2">${accountStatusChip(sourceAccount, 'itrSourceStatus')}</div>

            <div class="nc-label nc-label-grey">Amount Paid</div>
            <div class="nc-cell"><input id="itrAmount" class="entry-input" type="text" inputmode="decimal" value="${amountVal}"></div>
            <div class="nc-cell nc-tag">Account Type</div>
            <div class="nc-cell nc-span-2"><div class="display-field" id="itrSourceType">${typeOf(sourceAccount)}</div></div>

            <div class="nc-head">Credit</div>
            <div class="nc-label">Account Number</div>
            <div class="nc-cell"><input id="itrDestAcct" class="entry-input" maxlength="12" value="${escapeHtml(String(draft.destAcct || ''))}" autocomplete="off"></div>
            <div class="nc-cell"><button id="itrLookupDest" class="nc-mini-btn">Search</button></div>
            <div class="nc-cell nc-tag">Teller ID</div>
            <div class="nc-cell"><div class="display-field" id="itrDestTellerId">${escapeHtml(myTellerId)}</div></div>

            <div class="nc-label">Account Name</div>
            <div class="nc-cell nc-span-4"><div id="itrDestName" class="display-field">${draft.destName ? `<strong>${escapeHtml(draft.destName)}</strong>` : ''}</div></div>

            <div class="nc-label">Account Balance</div>
            <div class="nc-cell nc-span-2"><div id="itrDestBalance" class="display-field">${draft.destId ? balanceHtml(draft.destBalance || 0) : ''}</div></div>
            <div class="nc-cell nc-span-2"></div>

            <div class="nc-label">Description</div>
            <div class="nc-cell nc-span-4"><input id="itrDestDetails" class="entry-input" value="${escapeHtml(String(draft.destDetails || ''))}"></div>

            <div class="nc-label nc-label-grey">Received By</div>
            <div class="nc-cell"><input id="itrReceivedBy" class="entry-input" value="${escapeHtml(String(draft.receivedBy || ''))}"></div>
            <div class="nc-cell nc-tag">Account Status</div>
            <div class="nc-cell nc-status-cell">${accountStatusChip(destAccount, 'itrDestStatus')}</div>
            <div class="nc-cell nc-post-cell"><button id="submitIntraTransfer" class="nc-post-btn">Post</button></div>

            <div class="nc-label nc-label-grey">Amount Received</div>
            <div class="nc-cell"><div class="display-field" id="itrAmountReceived">${escapeHtml(formatAmountText(draft.amount || ''))}</div></div>
            <div class="nc-cell nc-tag">Account Type</div>
            <div class="nc-cell"><div class="display-field" id="itrDestType">${typeOf(destAccount)}</div></div>
          </div>
        </div>
      </div>`;
  }

  function bindIntraTransfer() {
    const draft = state.ui.intraTransferDraft ||= {};
    const sourceInput = byId('itrSourceAcct');
    const destInput = byId('itrDestAcct');
    const amtInput = byId('itrAmount');
    const detailsInput = byId('itrDetails');
    const paidByInput = byId('itrPaidBy');
    if (paidByInput) paidByInput.oninput = () => { draft.paidBy = paidByInput.value; };
    const receivedByInput = byId('itrReceivedBy');
    if (receivedByInput) receivedByInput.oninput = () => { draft.receivedBy = receivedByInput.value; };
    const lookupAcct = async (acctNum, nameElId, idKey, nameKey, balanceElId, balanceKey, isDest) => {
      const match = (state.customers || []).find(c => c.accountNumber === acctNum || c.account_number === acctNum);
      if (isLocalOnlyStaffAccount(match)) {
        if (byId(nameElId)) byId(nameElId).innerHTML = `<span style="color:var(--accent-red)">Staff wallet — not allowed in Non Cash</span>`;
        return showToast(STAFF_WALLET_NON_CASH_MSG);
      }
      const statusElId = isDest ? 'itrDestStatus' : 'itrSourceStatus';
      const typeElId = isDest ? 'itrDestType' : 'itrSourceType';
      const typeLabel = (c) => c.accountType === 'staff_operational' ? 'Teller' : (c.accountType === 'staff_salary' ? 'Staff Salary' : (c.accountType === 'expense' ? 'Expense' : (c.accountType === 'income' ? 'Income' : (c.accountType === 'treasury' ? 'Treasury' : 'Customer'))));
      if (match) {
        draft[idKey] = match.id;
        draft[nameKey] = match.name || match.full_name || match.display_name || acctNum;
        // A staff operational account's spendable balance is its live
        // operational balance, not the customer balance field.
        draft[balanceKey] = match.accountType === 'staff_operational' ? getStaffOperationalBalance(match.linkedStaffId) : Number(match.balance || 0);
        // A destination that turns out to be a staff operational account
        // force-locks the Debit side to the acting staff's own account —
        // that changes the shape of the form (disabled field + note), so
        // it needs a full re-render, not just the two DOM boxes below.
        if (isDest && match.accountType === 'staff_operational') {
          applyStaffAccountLock(draft);
          save();
          renderWorkspace();
          return;
        }
        if (byId(nameElId)) byId(nameElId).innerHTML = `<strong>${escapeHtml(draft[nameKey])}</strong>`;
        if (byId(balanceElId)) byId(balanceElId).innerHTML = balanceHtml(draft[balanceKey]);
        setAccountStatusChip(byId(statusElId), match);
        if (byId(typeElId)) byId(typeElId).textContent = typeLabel(match);
      } else {
        if (byId(nameElId)) byId(nameElId).innerHTML = `<span style="color:var(--accent-red)">Account not found</span>`;
        if (byId(balanceElId)) byId(balanceElId).innerHTML = '';
        setAccountStatusChip(byId(statusElId), null);
        if (byId(typeElId)) byId(typeElId).textContent = '—';
      }
    };

    // SURGICAL FIX 2026-09-03 (client correction, supersedes the 2026-08-28
    // addition below): client does not want the account fetched live as
    // you type — only on explicit Enter, same as every other account
    // number field in the app. Typing now only persists the draft and
    // clears the stale name/id/balance when the number is edited;
    // lookupAcct() runs solely from the Enter keyup handlers below.
    if (sourceInput) sourceInput.oninput = () => {
      draft.sourceAcct = sourceInput.value; draft.sourceName = ''; draft.sourceId = ''; draft.sourceBalance = 0;
      if (byId('itrSourceName')) byId('itrSourceName').innerHTML = '';
      if (byId('itrSourceBalance')) byId('itrSourceBalance').innerHTML = '';
    };
    if (destInput) destInput.oninput = () => {
      draft.destAcct = destInput.value; draft.destName = ''; draft.destId = ''; draft.destBalance = 0;
      if (byId('itrDestName')) byId('itrDestName').innerHTML = '';
      if (byId('itrDestBalance')) byId('itrDestBalance').innerHTML = '';
      // The destination just changed, so any staff-account lock from a
      // PREVIOUS destination is stale until the next lookup re-evaluates
      // it — release it now rather than leave a disabled Debit field
      // pointing at the wrong context.
      if (byId('itrSourceAcct')) byId('itrSourceAcct').disabled = false;
      if (byId('itrLookupSource')) byId('itrLookupSource').disabled = false;
      if (byId('itrSourceLockNote')) byId('itrSourceLockNote').style.display = 'none';
    };
    if (sourceInput) sourceInput.onkeyup = (e) => {
      if (e.key !== 'Enter') return;
      const v = sourceInput.value.trim();
      if (v) lookupAcct(v, 'itrSourceName', 'sourceId', 'sourceName', 'itrSourceBalance', 'sourceBalance', false);
    };
    if (destInput) destInput.onkeyup = (e) => {
      if (e.key !== 'Enter') return;
      const v = destInput.value.trim();
      if (v) lookupAcct(v, 'itrDestName', 'destId', 'destName', 'itrDestBalance', 'destBalance', true);
    };
    // Amount Received on the Credit side is always the same figure as
    // Amount Paid on the Debit side (one transfer), so it just mirrors it.
    if (amtInput) { bindAmountCommaFormatting('itrAmount'); amtInput.addEventListener('input', () => { draft.amount = amtInput.value; if (byId('itrAmountReceived')) byId('itrAmountReceived').textContent = formatAmountText(amtInput.value); }); }
    if (detailsInput) detailsInput.oninput = () => { draft.details = detailsInput.value; };
    const destDetailsInput = byId('itrDestDetails');
    if (destDetailsInput) destDetailsInput.oninput = () => { draft.destDetails = destDetailsInput.value; };

    // SURGICAL FIX 2026-08-28 (client correction): Search used to just
    // re-run the account-NUMBER lookup on whatever was already typed — no
    // way to find a customer by NAME when the number isn't known, unlike
    // Credit/Debit's Search which opens the picker. Now matches that
    // behavior. nonCashSearchTarget tells applySelectedCustomerToActiveTool
    // which of the two fields (source/dest) to fill when a customer is
    // picked, since Non Cash is the only screen with two account fields.
    if (byId('itrLookupSource')) byId('itrLookupSource').onclick = () => { state.ui.nonCashSearchTarget = 'source'; openCustomerSearchModal(state.customers); };
    if (byId('itrLookupDest')) byId('itrLookupDest').onclick = () => { state.ui.nonCashSearchTarget = 'dest'; openCustomerSearchModal(state.customers); };

    if (byId('submitIntraTransfer')) byId('submitIntraTransfer').onclick = async () => {
      const amount = parseAmountInput('itrAmount');
      if (!draft.destId) return showToast('Look up the destination account first');
      const destAccount = (state.customers || []).find(c => c.id === draft.destId);
      const isStaffFunding = destAccount?.accountType === 'staff_operational';
      // Re-apply the lock right before submit (not just on lookup) so a
      // stale draft — e.g. reloaded from a saved session — can never
      // slip an arbitrary source past this check.
      const lockedToOwn = isStaffFunding && !!applyStaffAccountLock(draft);
      if (!draft.sourceId) return showToast('Look up the source account first');
      const srcAccount = (state.customers || []).find(c => c.id === draft.sourceId);
      if (isStaffFunding && !lockedToOwn && srcAccount?.accountType !== 'treasury') return showToast('Fund a staff account from a Treasury account');
      // Money leaving a staff operational account (e.g. the Till handed to a
      // Treasury account) goes the same way as staff funding, so the staff
      // balance goes down with it.
      const viaStaffFunding = isStaffFunding || srcAccount?.accountType === 'staff_operational';
      if (srcAccount?.accountType === 'staff_operational') draft.sourceBalance = getStaffOperationalBalance(srcAccount.linkedStaffId);
      if (isLocalOnlyStaffAccount(srcAccount) || isLocalOnlyStaffAccount(destAccount)) return showToast(STAFF_WALLET_NON_CASH_MSG);
      if (draft.sourceId === draft.destId) return showToast('Source and destination must be different accounts');
      if (!(amount > 0)) return showToast('Enter a valid amount');
      if (isBusinessDateClosed(businessDate())) return showToast(businessDateClosedMessage(businessDate()));
      if (viaStaffFunding && amount > Number(draft.sourceBalance || 0) + 0.01) {
        return showToast(`Amount exceeds the available balance (${money(draft.sourceBalance || 0)})`);
      }
      const st = currentStaff();
      const details = (byId('itrDetails')?.value || '').trim();
      const paidBy = (byId('itrPaidBy')?.value || '').trim();
      const receivedBy = (byId('itrReceivedBy')?.value || '').trim();
      const destDetails = (byId('itrDestDetails')?.value || '').trim();
      confirmAction(`Debit To Credit Entry: ${money(amount)} from ${draft.sourceName} → ${draft.destName}?`, async () => {
        showProcessing('Submitting Debit To Credit Entry...'); await nextPaint();
        try {
          // Staff-account funding submits as 'inter_staff_credit' (not
          // 'intra_bank_transfer') so it stays wired into every existing
          // consumer of that type built for the old "Fund Account" screen:
          // getStaffOperationalBreakdown (Till, Journal Amount, COD, Teller
          // Balances), the Treasury Transactions category in Transaction
          // Summary, and the receiving staff's own "Operational Credit"
          // line in My Statement. SURGICAL ADDITION 2026-09-14
          // (client-confirmed design): this is also how Teller-to-Teller
          // funding works (any staff with an operational account can be
          // the source — this was already role-agnostic, not
          // Treasury-only) — it now gets a Journal Number too, so it's
          // listed and searchable in the Journal Register.
          let journalNumber = '';
          if (viaStaffFunding) {
            const reserved = await reserveJournalNumber();
            if (!reserved.ok) return showToast(reserved.message);
            journalNumber = reserved.number;
          }
          const result = viaStaffFunding
            ? await submitApprovalThroughGateway('inter_staff_credit', {
                staffId: st.id, staffName: st.name,
                targetAccountId: draft.destId, targetAccountNumber: draft.destAcct, targetAccountName: draft.destName,
                amount, paymentMode: 'transfer', date: businessDate(), note: details,
                fundingSource: srcAccount?.accountType === 'staff_operational' ? 'treasury_balance' : 'account',
                sourceAccountId: draft.sourceId, sourceAccountNumber: draft.sourceAcct, sourceAccountName: draft.sourceName,
                collectorId: '', collectorName: '', journalNumber, paidBy, receivedBy, destDetails
              })
            : await submitApprovalThroughGateway('intra_bank_transfer', {
                staffId: st.id, staffName: st.name, date: businessDate(),
                sourceAccountId: draft.sourceId, sourceAccountNumber: draft.sourceAcct, sourceAccountName: draft.sourceName,
                destAccountId: draft.destId, destAccountNumber: draft.destAcct, destAccountName: draft.destName,
                amount, details, destDetails, paidBy, receivedBy
              });
          if (!result?.ok) return showToast(result?.error?.message || 'Unable to submit non cash transaction');
          if (viaStaffFunding) {
            state.journals.push({
              id: uid('jn'), journalNumber, kind: 'transfer', date: businessDate(),
              staffId: st.id, staffName: st.name, counterparty: draft.destName || '',
              formAmount: amount, formPaymentMode: 'transfer',
              rows: [
                { accountNumber: draft.sourceAcct, customerName: `${draft.sourceName} (Debit)`, amount },
                { accountNumber: draft.destAcct, customerName: `${draft.destName} (Credit)`, amount }
              ],
              fieldNote: null, status: 'sent', createdAt: new Date().toISOString()
            });
            await persistJournal(state.journals[state.journals.length - 1]);
          }
          state.ui.intraTransferDraft = {};
          render();
          showToast(viaStaffFunding ? `Debit To Credit Entry sent for approval — ${journalNumber}` : 'Debit To Credit Entry sent for approval');
        } finally { hideProcessing(); }
      });
    };
  }

  function renderTransactionSummary() {
    const filter = state.ui.txSummaryFilter ||= { date: businessDate(), period: 'day' };
    const categories = [
      { key: 'teller', label: 'Teller Transactions', icon: '💳', types: ['customer_credit','customer_debit','customer_credit_journal','customer_debit_journal','intra_bank_transfer'] },
      { key: 'customer', label: 'Customer Transactions', icon: '🧾', types: ['customer_credit','customer_debit','customer_credit_journal','customer_debit_journal','intra_bank_transfer','account_opening','account_maintenance','account_reactivation'] },
      { key: 'cash_officer', label: 'Treasury Transactions', icon: '💰', types: ['cash_receipt','inter_staff_credit'] },
      { key: 'salary', label: 'Staff Salary Account Transactions', icon: '👤', types: ['account_opening'], acctType: 'staff_salary' },
      { key: 'income', label: 'Income Account Transactions', icon: '📈', types: ['operational_entry'], acctType: 'income' },
      { key: 'expense', label: 'Expense Account Transactions', icon: '📉', types: ['operational_entry'], acctType: 'expense' },
    ];
    // SURGICAL PATCH 2026-08-14: two bugs found together.
    // (1) acctType was defined on the salary/income/expense categories but
    // never actually checked in the filter below — so e.g. "Income" and
    // "Expense" both matched every operational_entry regardless of which
    // account it hit, and "Staff Salary" matched every account_opening
    // regardless of account type.
    // (2) Several real transaction types (wallet_fund, debt_repayment,
    // create_operational_account, and any future type) weren't in ANY
    // category's list, so approved admin transactions of those types
    // silently never appeared anywhere in this report. Added a catch-all
    // "Administration Transactions" category computed by EXCLUSION (not a
    // fixed list) so any current or future uncategorized type surfaces here
    // instead of disappearing again.
    const matchesCategory = (r, cat) => {
      if (!cat.types.includes(r.type)) return false;
      if (!cat.acctType) return true;
      const p = r.payload || {};
      if (r.type === 'operational_entry') return p.kind === cat.acctType;
      if (r.type === 'account_opening') return p.accountType === cat.acctType;
      return true;
    };
    const coveredTypes = new Set(categories.flatMap(c => c.types));
    categories.push({ key: 'admin', label: 'Administration Transactions', icon: '🛠️', types: [], isCatchAll: true });
    const matchesAny = (r, cat) => cat.isCatchAll ? !coveredTypes.has(r.type) : matchesCategory(r, cat);
    const approvals = state.approvals || [];
    const activeKey = filter.activeKey || null;
    const filterDate = filter.date || businessDate();
    historyCovers(filterDate);

    // Get filtered approvals for the selected category
    let detailRows = '';
    let detailTitle = '';
    if (activeKey) {
      const cat = categories.find(c => c.key === activeKey);
      detailTitle = cat?.label || '';
      const filtered = approvals.filter(r => {
        if (r.status !== 'approved') return false;
        const d = r.payload?.date || String(r.approvedAt||'').slice(0,10);
        if (d !== filterDate) return false;
        return cat && matchesAny(r, cat);
      });

      if (filtered.length === 0) {
        detailRows = `<tr><td colspan="7" style="text-align:center;color:var(--muted)">No transactions for this date</td></tr>`;
      } else if (activeKey === 'customer') {
        // For customer view: compute running balance per account
        // Build a map of all approved transactions per account (all time, sorted by date)
        const allApproved = approvals.filter(r => r.status === 'approved');
        const balanceMap = {}; // accountId -> running balance up to (not including) filterDate
        const todayTxMap = {}; // accountId -> [{amount, type, date, req}] for filterDate

        const affectsAccount = (r) => ['customer_credit','customer_debit','customer_credit_journal','customer_debit_journal','intra_bank_transfer'].includes(r.type);

        allApproved.filter(affectsAccount).forEach(r => {
          const p = r.payload || {};
          const d = p.date || String(r.approvedAt||'').slice(0,10);
          const processEntry = (accountId, amount, isCreditForAccount) => {
            if (!accountId) return;
            if (d < filterDate) {
              balanceMap[accountId] = (balanceMap[accountId] || 0) + (isCreditForAccount ? amount : -amount);
            } else if (d === filterDate) {
              todayTxMap[accountId] = todayTxMap[accountId] || [];
              todayTxMap[accountId].push({ amount, isCredit: isCreditForAccount, type: r.type, req: r, date: d, approvedAt: r.approvedAt });
            }
          };
          if (r.type === 'intra_bank_transfer') {
            processEntry(p.sourceAccountId, Number(p.amount||0), false);
            processEntry(p.destAccountId, Number(p.amount||0), true);
          } else if (r.type === 'customer_credit' || r.type === 'customer_credit_journal') {
            const rows = r.type.endsWith('_journal') ? (p.rows||[]) : [p];
            rows.forEach(row => processEntry(row.customerId || p.customerId, Number(row.amount||p.amount||0), true));
          } else if (r.type === 'customer_debit' || r.type === 'customer_debit_journal') {
            const rows = r.type.endsWith('_journal') ? (p.rows||[]) : [p];
            rows.forEach(row => processEntry(row.customerId || p.customerId, Number(row.amount||p.amount||0), false));
          }
        });

        // Now render today's transactions with running balance
        const rows = [];
        Object.entries(todayTxMap).forEach(([accountId, txList]) => {
          const customer = (state.customers||[]).find(c => c.id === accountId);
          const acctNum = customer?.accountNumber || customer?.account_number || accountId;
          const acctName = customer?.name || customer?.full_name || customer?.display_name || '—';
          let running = balanceMap[accountId] || 0;
          txList.forEach((tx, idx) => {
            running += tx.isCredit ? tx.amount : -tx.amount;
            rows.push(`<tr>
              <td>${acctNum}</td>
              <td>${escapeHtml(acctName)}</td>
              <td>${tx.type.replace(/_/g,' ')}</td>
              <td class="${tx.isCredit?'':'balance-negative'}">${tx.isCredit?'+':'-'}${money(tx.amount)}</td>
              <td class="${running<0?'balance-negative':''}">${money(running)}</td>
              <td style="white-space:nowrap">${fmtDateTime(tx.approvedAt) || tx.date}</td>
            </tr>`);
          });
        });
        detailRows = rows.length ? rows.join('') : `<tr><td colspan="6" style="text-align:center;color:var(--muted)">No customer transactions for this date</td></tr>`;
        if (rows.length) {
          const totalCredit = Object.values(todayTxMap).flat().filter(t=>t.isCredit).reduce((s,t)=>s+t.amount,0);
          const totalDebit = Object.values(todayTxMap).flat().filter(t=>!t.isCredit).reduce((s,t)=>s+t.amount,0);
          detailRows += `<tr class="total-row"><td colspan="3"><strong>Total</strong></td><td><strong>+${money(totalCredit)} / -${money(totalDebit)}</strong></td><td colspan="2"></td></tr>`;
        }
        // Override table header for customer view
        const tableHeader = `<thead><tr><th>A/N</th><th>Customer</th><th>Type</th><th>Amount</th><th>Running Balance</th><th>Date &amp; Time</th></tr></thead>`;
        // Wrap in special marker for template below
        detailRows = `__CUSTOMER_TABLE__${tableHeader}<tbody>${detailRows}</tbody>`;
      } else {
        detailRows = filtered.map((r,i) => {
          const p = r.payload || {};
          const amount = p.amount || p.formAmount || (p.rows||[]).reduce((s,x)=>s+Number(x.amount||0),0) || 0;
          const from = p.staffName || p.sourceAccountName || p.sourceName || '—';
          const to = p.customerName || p.destAccountName || p.targetAccountName || '—';
          return `<tr><td>${i+1}</td><td>${r.type.replace(/_/g,' ')}</td><td>${escapeHtml(String(from))}</td><td>${escapeHtml(String(to))}</td><td>${money(amount)}</td><td style="white-space:nowrap">${fmtDateTime(r.approvedAt) || '—'}</td></tr>`;
        }).join('');
        const grandTotal = filtered.reduce((s,r) => {
          const p = r.payload || {};
          return s + (p.amount || p.formAmount || (p.rows||[]).reduce((sx,x)=>sx+Number(x.amount||0),0) || 0);
        }, 0);
        detailRows += `<tr class="total-row"><td colspan="4"><strong>Total</strong></td><td><strong>${money(grandTotal)}</strong></td><td></td></tr>`;
      }
    }

    // REDESIGN 2026-08-14: the two-column layout (tall vertical card list next
    // to a short table) forced vertical scrolling on the left panel while the
    // right panel sat mostly empty, and the table got squeezed into a narrow
    // column. Switched to horizontal chips that wrap naturally, with the
    // table full-width underneath — no more mismatched-height columns.
    const catChips = categories.map(c => {
      const count = approvals.filter(r => r.status==='approved' && matchesAny(r, c) && (r.payload?.date||String(r.approvedAt||'').slice(0,10)) === filterDate).length;
      const isActive = filter.activeKey === c.key;
      return `<button type="button" class="summary-cat-chip ${isActive?'active':''}" data-cat="${c.key}" style="cursor:pointer;padding:8px 14px;border-radius:20px;border:1.5px solid ${isActive?'var(--brand)':'var(--line)'};background:${isActive?'var(--accent)':'var(--panel)'};color:var(--text);display:inline-flex;align-items:center;gap:8px;font:inherit;text-align:left">
        <span style="font-size:1.15em">${c.icon}</span>
        <span><span style="font-weight:700;font-size:0.88em;color:var(--text)">${c.label}</span><span style="font-size:0.78em;color:var(--muted);margin-left:6px">${count}</span></span>
      </button>`;
    }).join('');

    return `
      <div class="form-card cs2-card" style="max-width:1120px">
        <div class="cs2-title">Transaction Summary</div>
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:16px;flex-wrap:wrap">
          <label style="font-size:0.88em;font-weight:600">Date</label>
          <input id="txSummaryDate" type="date" lang="en-GB" class="entry-input" value="${filterDate}" style="width:160px">
          <button id="txSummaryToday" class="sheet-btn secondary tiny-btn">Today</button>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px">${catChips}</div>
        ${activeKey ? `
        <div style="min-width:0">
          <div style="font-weight:700;font-size:0.95em;margin-bottom:10px">${escapeHtml(detailTitle)} — ${filterDate}</div>
          <div class="table-wrap" style="max-width:100%;overflow-x:auto">
            ${detailRows.startsWith('__CUSTOMER_TABLE__')
              ? `<table class="table">${detailRows.replace('__CUSTOMER_TABLE__','')}</table>`
              : `<table class="table"><thead><tr><th>#</th><th>Type</th><th>Posted By</th><th>Account</th><th>Amount</th><th>Date</th></tr></thead><tbody>${detailRows}</tbody></table>`
            }
          </div>
        </div>` : `<div class="note">Select a category above to see its transactions for this date.</div>`}
        <!-- SURGICAL ADDITION 2026-09-04 (client request): "get statements for
             every staff, maybe from their transaction summary" — a direct
             jump from here into the same filterable Staff Ledger modal used
             from Staff Directory / Teller Balances, so an admin doesn't have
             to leave this screen to pull a specific staff member's statement. -->
        <div class="cs2-row" style="margin-top:18px;padding-top:14px;border-top:1px solid var(--line);align-items:center;gap:10px">
          <div class="cs2-label" style="margin:0">Staff Statements</div>
          <select id="txSummaryStaffPicker" class="entry-input" style="max-width:260px">
            <option value="">— Select a staff member —</option>
            ${(state.staff || []).map(s => `<option value="${s.id}">${escapeHtml(s.name || '')} (${staffRoleLabels(s)})</option>`).join('')}
          </select>
          <button id="txSummaryViewStatement" class="secondary">View Statement</button>
        </div>
      </div>`;
  }

  function bindTransactionSummary() {
    const filter = state.ui.txSummaryFilter ||= { date: businessDate() };
    const dateInput = byId('txSummaryDate');
    if (dateInput) dateInput.onchange = () => { filter.date = dateInput.value; filter.activeKey = null; save(); renderWorkspace(); };
    if (byId('txSummaryToday')) byId('txSummaryToday').onclick = () => { filter.date = businessDate(); filter.activeKey = null; save(); renderWorkspace(); };
    qq('.summary-cat-chip').forEach(card => {
      card.onclick = () => {
        filter.activeKey = filter.activeKey === card.dataset.cat ? null : card.dataset.cat;
        save(); renderWorkspace();
      };
    });
    if (byId('txSummaryViewStatement')) byId('txSummaryViewStatement').onclick = () => {
      const staffId = byId('txSummaryStaffPicker')?.value;
      if (!staffId) return showToast('Select a staff member first');
      openStaffLedgerModal(staffId);
    };
  }

  function bindMaintenance(prefix) {
    const draft = state.ui[`${prefix}Draft`] ||= {};
    const detailIds = [`${prefix}Name`, `${prefix}Address`, `${prefix}Phone`, `${prefix}Nin`, `${prefix}Bvn`, `${prefix}OldAccount`];
    const draftKeyOf = { [`${prefix}Name`]: 'name', [`${prefix}Address`]: 'address', [`${prefix}Phone`]: 'phone', [`${prefix}Nin`]: 'nin', [`${prefix}Bvn`]: 'bvn', [`${prefix}OldAccount`]: 'oldAccountNumber' };
    const clearFilledCustomer = () => {
      Object.keys(draft).forEach(k => delete draft[k]);
      state.ui.selectedCustomerId = null;
      save();
      renderWorkspace();
    };
    const setDetailsEditable = (editable) => {
      draft.editable = editable;
      save();
      detailIds.forEach(id => {
        const el = byId(id);
        if (!el) return;
        el.readOnly = !editable;
        el.classList.toggle('cs-readonly', !editable);
      });
    };
    const fillCustomer = (c) => {
      if (!c) return;
      if (prefix==='reactivation' && c.closed) return showToast('This account is closed — closed accounts cannot be reactivated');
      if (prefix==='reactivation' && !(isCustomerFrozen(c) || c.active === false)) return showToast('Account is not frozen');
      state.ui.selectedCustomerId = c.id;
      draft.accountNumber = c.accountNumber || '';
      draft.name = c.name || '';
      draft.address = c.address || '';
      draft.phone = c.phone || '';
      draft.nin = c.nin || '';
      draft.bvn = c.bvn || '';
      draft.oldAccountNumber = c.oldAccountNumber || '';
      draft.editable = false;
      save();
      renderWorkspace();
    };
    // Every detail field writes straight into the persisted draft on each
    // keystroke (save() only — no renderWorkspace() here, same as Account
    // Opening) so a deferred render after blur rehydrates from state instead
    // of wiping the form.
    detailIds.forEach(id => {
      const el = byId(id);
      if (!el) return;
      el.oninput = () => { draft[draftKeyOf[id]] = el.value; save(); };
    });
    const doLookup = (quiet=false) => {
      const accVal = (byId(`${prefix}Acc`)?.value || '').trim();
      if (!accVal) {
        clearFilledCustomer();
        return;
      }
      const c = getCustomerByAccountNo(accVal);
      if (!c) {
        if (!quiet) showToast('Customer not found. Use name search.');
        return;
      }
      fillCustomer(c);
    };
    const accInput = byId(`${prefix}Acc`);
    if (accInput) {
      // SURGICAL FIX 2026-09-03: client does not want the account fetched
      // live as-you-type — only on explicit Enter. oninput now only
      // persists the draft account number; doLookup() runs solely from
      // the Enter keyup below.
      accInput.oninput = () => {
        const v = (accInput.value || '').trim();
        draft.accountNumber = v;
        save();
      };
      accInput.onkeyup = (e) => { if (e.key === 'Enter') doLookup(false); };
    }
    const searchBtn = byId(`${prefix}Search`);
    if (searchBtn) searchBtn.onclick = () => openCustomerSearchModal(state.customers);
    const editBtn = byId(`${prefix}Edit`);
    if (editBtn) editBtn.onclick = () => {
      const c = getSelectedCustomer() || getCustomerByAccountNo(byId(`${prefix}Acc`).value);
      if (!c) return showToast('Search for an account first');
      setDetailsEditable(true);
      showToast(prefix === 'reactivation' ? 'Account details are now editable' : 'You can now edit and save the account details');
    };
    byId(`${prefix}Submit`).onclick = async () => {
  const c = getSelectedCustomer() || getCustomerByAccountNo(byId(`${prefix}Acc`).value);
  if (!c) return showToast('Search for an account first');

  let result;

  if (prefix === 'maintenance') {
    result = await submitApprovalThroughGateway('account_maintenance', {
      customerId: c.id,
      accountNumber: c.accountNumber,
      patch: {
        name: (draft.name || '').trim(),
        address: (draft.address || '').trim(),
        phone: (draft.phone || '').trim() || c.phone,
        nin: (draft.nin || '').trim() || c.nin,
        bvn: (draft.bvn || '').trim() || c.bvn,
        oldAccountNumber: (draft.oldAccountNumber || '').trim() || (c.oldAccountNumber || '')
      }
    });

    if (!result?.ok) return showToast(result?.error?.message || 'Unable to submit request');
    showToast('Maintenance request sent for approval');
  } else {
    result = await submitApprovalThroughGateway('account_reactivation', {
      customerId: c.id,
      accountNumber: c.accountNumber
    });

    if (!result?.ok) return showToast(result?.error?.message || 'Unable to submit request');
    showToast('Reactivation request sent for approval');
  }

  Object.keys(draft).forEach(k => delete draft[k]);
  save();
  render();
};

    // SURGICAL ADDITION 2026-10-21 (client): Account Block freezes the
    // account; Account Closure removes the customer from service but keeps
    // every record. Both go through approval like any other maintenance.
    const statusRequest = async (type) => {
      const c = getSelectedCustomer() || getCustomerByAccountNo(byId(`${prefix}Acc`)?.value || '');
      if (!c) return showToast('Search for an account first');
      if (c.closed) return showToast('This account is already closed');
      if (type === 'account_block' && isCustomerFrozen(c)) return showToast('This account is already frozen');
      if (type === 'account_closure' && Math.abs(Number(c.balance || 0)) > 0.009) return showToast(`Balance must be zero before closing (current balance ${money(c.balance)}) — pay out or transfer it first`);
      const pending = (state.approvals || []).some(a => a.status === 'pending' && a.type === type && a.payload?.customerId === c.id);
      if (pending) return showToast('A request like this is already waiting for approval');
      const what = type === 'account_block' ? 'Block (freeze)' : 'Close';
      confirmAction(`${what} account ${c.accountNumber} — ${c.name}? This goes to approval.`, async () => {
        const result = await submitApprovalThroughGateway(type, { customerId: c.id, accountNumber: c.accountNumber, accountName: c.name });
        if (!result?.ok) return showToast(result?.error?.message || 'Unable to submit request');
        showToast(type === 'account_block' ? 'Block request sent for approval' : 'Closure request sent for approval');
        Object.keys(draft).forEach(k => delete draft[k]);
        save();
        render();
      });
    };
    if (byId('maintenanceBlock')) byId('maintenanceBlock').onclick = () => statusRequest('account_block');
    if (byId('maintenanceClose')) byId('maintenanceClose').onclick = () => statusRequest('account_closure');

    // SURGICAL FIX 2026-10-21: fillCustomer() re-renders, and every render
    // re-runs this bind — so restoring the selected customer here looped
    // render -> bind -> fill -> render until the browser's stack overflowed.
    // Only fill when the form isn't already showing that customer.
    const selected = getSelectedCustomer();
    if (selected && draft.accountNumber !== (selected.accountNumber || '')) {
      const matchesTool = (accInput?.value || '').trim() ? (selected.accountNumber === (accInput?.value || '').trim()) : true;
      if (matchesTool) fillCustomer(selected);
    }
  }

  function bindStatement() {
    const filter = state.ui.accountStatementFilter ||= { from: '', to: '' };
    const stmtFrom = byId('stmtFrom');
    const stmtTo = byId('stmtTo');
    if (stmtFrom) stmtFrom.onchange = () => { filter.from = stmtFrom.value || ''; save(); };
    if (stmtTo) stmtTo.onchange = () => { filter.to = stmtTo.value || ''; save(); };

    const generateBtn = byId('stmtGenerate');
    if (generateBtn) generateBtn.onclick = () => {
      if (!getSelectedCustomer()) return showToast('No customer selected — go to Check Balance first');
      state.ui.accountStatementGenerated = true;
      save();
      renderWorkspace();
    };

    const printBtn = byId('stmtPrintBtn');
    if (printBtn) printBtn.onclick = () => {
      const area = byId('statementPrintArea')?.innerHTML;
      if (!area?.trim()) return showToast('Generate statement first');
      printHtml(`<h2>Customer Statement</h2>${area}</div>`);
    };
  }

  // SURGICAL ADDITION 2026-10-01 (client rule): Opening Cash + Cash
  // Received - Cash Withdrawal = Till. Transfers INTO the teller's account
  // only ever land in Opening Cash; Cash Received/Withdrawal are the
  // teller's own customer work for the day. At close of business the teller
  // transfers the Till to Treasury and ALL the boxes reset to zero — so once
  // the teller has sent money out today and that leaves the Till at zero,
  // every box shows zero (otherwise Opening would read negative next to
  // the day's Received/Withdrawal). Single source for both the first render
  // and the live refresh of the Till box.
  function getTillBreakdown(staffId, dateStr) {
    const openingCash = getStaffOperationalBalance(staffId, dateStr);
    const cashReceived = approvedCreditTotalForDateByMode(staffId, dateStr, 'cash');
    const cashWithdrawal = approvedDebitTotalForDateByMode(staffId, dateStr, 'cash');
    const till = openingCash + cashReceived - cashWithdrawal;
    const opAccount = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === staffId);
    const handedOverToday = !!opAccount && (state.approvals || []).some(r =>
      r.status === 'approved' && r.type === 'inter_staff_credit' &&
      r.payload?.sourceAccountId === opAccount.id && r.payload?.date === dateStr);
    if (handedOverToday && Math.abs(till) < 0.01) return { openingCash: 0, cashReceived: 0, cashWithdrawal: 0, till: 0 };
    return { openingCash, cashReceived, cashWithdrawal, till };
  }

  // 2026-11-02 (client): a Teller account's balance IS the Till
  // (Opening Cash + Cash Received - Cash Withdrawal), same figure everywhere.
  function tellerTillBalance(staffId) {
    return getTillBreakdown(staffId, businessDate()).till;
  }

  function getStaffOperationalBalance(staffId, excludeDateStr) {
    return getStaffOperationalBreakdown(staffId, excludeDateStr).variance;
  }

  function getStaffOperationalBreakdown(staffId, excludeDateStr) {
    // Cash = total funded to this teller's operational account by Treasury (approved credits).
    // Always all-time, regardless of excludeDateStr — Treasury can fund a teller multiple
    // times, on any date, and it always becomes part of opening balance (client-confirmed).
    //
    // Posting Cash = net effect of customer postings so far.
    // SURGICAL FIX 2026-09-04 (client-confirmed bug): customer_credit (a
    // deposit — cash/value coming IN) used to be added into this the same
    // way as customer_debit (a withdrawal — cash/value going OUT), so a
    // deposit silently REDUCED the teller's available balance instead of
    // increasing it — and, via the Till formula in renderJournalTool (which
    // adds today's cash credits back on top of this figure), deposits
    // netted to zero effect on Till while withdrawals got subtracted twice.
    // Credits now correctly add, debits subtract. This one place feeds
    // every consumer (Till, Journal Form Amount, COD, the debit-exceeds-
    // balance check, Teller Balances), so fixing it here fixes all of them.
    //
    // excludeDateStr (optional): when given, customer postings dated
    // exactly that business date are left out of this sum. Used by the
    // Till breakdown to get the balance as of the START of today, since
    // today's own cash-mode postings are already added back separately as
    // Cash Received / Cash Withdrawal — without this exclusion, today's
    // activity would be counted twice.
    const opAccount = (state.customers || []).find(c =>
      c.accountType === 'staff_operational' && c.linkedStaffId === staffId
    );
    if (!opAccount) return { cash: 0, postingCash: 0, variance: 0 };
    const cash = (state.approvals || [])
      .filter(r => r.status === 'approved' &&
        (r.type === 'cash_receipt' || r.type === 'inter_staff_credit') &&
        (r.payload?.operationalAccountId === opAccount.id || r.payload?.targetAccountId === opAccount.id))
      .reduce((s, r) => s + Number(r.payload?.amount || 0), 0)
      // SURGICAL FIX 2026-09-14 (client-confirmed design): "money moves
      // from a teller as debit and enters the other teller as credit" — the
      // GIVING staff's own balance must actually go down when their
      // account is the SOURCE of an approved inter_staff_credit (funding a
      // fellow Teller or Treasury via Non Cash/Journal). Previously this
      // only ever added inbound funding and never subtracted what a staff
      // member gave out of their own account — Treasury/Teller balances
      // could fund others indefinitely without ever depleting. Only
      // matches when the SOURCE is itself a staff account (Admin Injection
      // and Debit-an-Account sources are never a staff_operational
      // account, so this never double-subtracts a customer-sourced credit).
      - (state.approvals || [])
        .filter(r => r.status === 'approved' && r.type === 'inter_staff_credit' && r.payload?.sourceAccountId === opAccount.id)
        .reduce((s, r) => s + Number(r.payload?.amount || 0), 0);
    const postingCash = (state.approvals || [])
      .filter(r => r.status === 'approved' && r.payload?.staffId === staffId &&
        ['customer_credit','customer_debit','customer_credit_journal','customer_debit_journal'].includes(r.type) &&
        (!excludeDateStr || r.payload?.date !== excludeDateStr))
      .reduce((s, r) => {
        const amt = r.type.endsWith('_journal') ? Number(r.payload?.formAmount || 0) : Number(r.payload?.amount || 0);
        const isCredit = r.type === 'customer_credit' || r.type === 'customer_credit_journal';
        return s + (isCredit ? -amt : amt);
      }, 0);
    return { cash, postingCash, variance: cash - postingCash };
  }

  function hasApprovedFloat(staffId, dateStr) {
    return openingBalanceOnlyForDate(staffId, dateStr) > 0 || hasBaseOpeningBalanceForDate(staffId, dateStr);
  }

  // SURGICAL ADDITION 2026-09-04 (client request): read-only rollup of what
  // a Collector (or, since 2026-09-09, a Teller) has brought to Treasury.
  // SURGICAL UPDATE 2026-09-09 (client-confirmed design): "Received From"
  // moved from the now-dissolved "Credit Staff Account" screen onto Cash
  // Receipt itself (receivedFromId/receivedFromName on cash_receipt
  // records) — that's where all NEW attribution lives. The old
  // inter_staff_credit + collectorId form is kept here too, read-only, so
  // historical records tagged before this change still count. Pure
  // aggregation over already-approved data, same pattern as
  // getStaffOperationalBreakdown above — posts nothing, so it cannot
  // affect Business Balance/Overall Balance.
  function getCollectorTotal(staffId, filter) {
    const approved = (state.approvals || []).filter(r =>
      r.status === 'approved' && (
        (r.type === 'cash_receipt' && r.payload?.receivedFromId === staffId) ||
        (r.type === 'inter_staff_credit' && r.payload?.collectorId === staffId)
      )
    );
    const rows = filter ? filterByDate(approved.map(r => ({ ...r, date: r.payload?.date })), filter) : approved;
    return rows.reduce((sum, r) => sum + Number(r.payload?.amount || 0), 0);
  }


  function bindJournalStandalone() {
    const kind = state.ui.journalStandaloneKind === 'debit' ? 'debit' : 'credit';
    const startBtn = byId('genJournalStartBtn');
    if (startBtn) startBtn.onclick = () => {
      const staff = currentStaff();
      state.ui.generatedJournals ||= {};
      state.ui.collapsedJournals ||= {};
      const journalKey = `${staff?.id || 'staff'}:${businessDate()}:${kind}`;
      state.ui.generatedJournals[journalKey] = true;
      state.ui.collapsedJournals[journalKey] = false;
      save();
      renderWorkspace();
    };
    // All journal-builder wiring (search, add row, submit, charges, etc.) is
    // shared with the credit/debit screens — bindJournal() only touches
    // elements that exist on whichever screen is currently rendered.
    bindJournal(kind);
  }

  // SURGICAL ADDITION 2026-09-14 (client-confirmed design): Direct Posting
  // now shows Account Status/Account Type once a customer is found,
  // conforming to the client's reference screenshots. Read-only, decorative
  // only — never affects any balance or approval logic.
  function updateTxAccountMeta(customer) {
    const statusEl = byId('txAccountStatus');
    const typeEl = byId('txAccountType');
    setAccountStatusChip(statusEl, customer);
    if (!customer) {
      if (typeEl) typeEl.textContent = '—';
      return;
    }
    if (typeEl) typeEl.textContent = customer.accountType === 'staff_operational' ? 'Teller' : (customer.accountType === 'staff_salary' ? 'Staff Salary' : (customer.accountType === 'expense' ? 'Expense' : (customer.accountType === 'income' ? 'Income' : (customer.accountType === 'treasury' ? 'Treasury' : 'Customer'))));
  }

  function updateJournalAccountMeta(customer) {
    const statusEl = byId('journalAccountStatus');
    const typeEl = byId('journalAccountType');
    const tellerIdEl = byId('journalRowTellerId');
    setAccountStatusChip(statusEl, customer);
    if (!customer) {
      if (typeEl) typeEl.textContent = '—';
      if (tellerIdEl) tellerIdEl.textContent = '—';
      if (byId('journalAccBalance')) byId('journalAccBalance').textContent = '—';
      return;
    }
    if (byId('journalAccBalance')) byId('journalAccBalance').innerHTML = balanceHtml(customer.accountType === 'staff_operational' ? tellerTillBalance(customer.linkedStaffId) : (customer.balance || 0));
    if (typeEl) typeEl.textContent = customer.accountType === 'staff_operational' ? 'Teller' : (customer.accountType === 'staff_salary' ? 'Staff Salary' : (customer.accountType === 'expense' ? 'Expense' : (customer.accountType === 'income' ? 'Income' : (customer.accountType === 'treasury' ? 'Treasury' : 'Customer'))));
    // SURGICAL ADDITION 2026-09-22 (client-confirmed design): the account
    // being debited/credited for this journal row is looked up here — if
    // that account is itself a staff operational account, its owner's
    // first name IS its Teller ID (2026-09-28), so show it; otherwise
    // there's no Teller ID for an ordinary customer/expense/income account.
    if (tellerIdEl) tellerIdEl.textContent = tellerIdForAccount(customer);
  }

  function bindJournal(kind) {
    const staff = currentStaff();
    const journalBtn = byId('txJournalAdd');
    const postBtn = byId('txPostSingle');
    if (journalBtn && postBtn && postBtn.parentElement) postBtn.parentElement.appendChild(journalBtn);
    state.ui.staffJournals ||= {};
    state.ui.staffJournalAttachments ||= {};
    state.ui.generatedJournals ||= {};
    const visibilityKey = `${staff.id}:${businessDate()}:${kind}`;
    state.ui.collapsedJournals ||= {};
    state.ui.telleringDrafts ||= {};
    // Restore journalName display if customer was previously selected
    requestAnimationFrame(() => {
      if (byId('journalName') && state.ui.selectedJournalCustomerId) {
        const restoredCustomer = getCustomerByAccountNo(state.ui.journalAccDraft || byId('journalAcc')?.value || '');
        if (restoredCustomer && byId('journalName').textContent === '—') {
          byId('journalName').textContent = restoredCustomer.name;
        }
        if (restoredCustomer) updateJournalAccountMeta(restoredCustomer);
      }
    });
    const telleringDraft = state.ui.telleringDrafts[visibilityKey] ||= { singleCharges: { apply: false, checked: {}, values: {} }, journalCharges: { apply: false, checked: {}, values: {} } };
    telleringDraft.singleCharges ||= { apply: false, checked: {}, values: {} };
    telleringDraft.singleCharges.checked ||= {};
    telleringDraft.singleCharges.values ||= {};
    telleringDraft.journalCharges ||= { apply: false, checked: {}, values: {} };
    telleringDraft.journalCharges.checked ||= {};
    telleringDraft.journalCharges.values ||= {};
    const journal = state.ui.staffJournals[visibilityKey] ||= [];
    const attachmentState = state.ui.staffJournalAttachments[visibilityKey] ||= { fieldNote: null, loading: false };

    const selectedMode = () => q('input[name="txMode"]:checked')?.value || 'cash';
    const readChargePreview = (scope, amountValue) => {
      const amount = Number(amountValue || 0);
      const applyToggleId = scope === 'single' ? 'txApplyCharges' : 'journalApplyCharges';
      const rowId = scope === 'single' ? 'txChargesRow' : 'journalChargesRow';
      const totalId = scope === 'single' ? 'txTotalCharges' : 'journalTotalCharges';
      const customerId = scope === 'single' ? 'txCustomerGets' : 'journalCustomerGets';
      const toggle = byId(applyToggleId);
      const row = byId(rowId);
      const totalEl = byId(totalId);
      const customerEl = byId(customerId);
      const enabled = !!(toggle && toggle.checked);
      if (row) row.classList.toggle('hidden', !enabled);

      let totalCharges = 0;
      CHARGE_DEFS.forEach(def => {
        const check = q(`[data-charge-check="${def.key}"][data-charge-scope="${scope}"]`);
        const input = q(`[data-charge-input="${def.key}"][data-charge-scope="${scope}"]`);
        const checked = !!(enabled && check && check.checked);
        if (input) {
          input.classList.toggle('hidden', !checked);
          if (!checked) input.value = '';
        }
        if (checked && input) {
          const val = Math.max(0, Number(input.value || 0));
          totalCharges += val;
        }
      });

      totalCharges = Math.min(totalCharges, Math.max(0, amount));
      const customerGets = Math.max(0, amount - totalCharges);
      if (totalEl) totalEl.textContent = money(totalCharges);
      if (customerEl) customerEl.textContent = money(customerGets);
      return { amount, totalCharges, customerGets };
    };
    const updateSingleCommissionPreview = () => readChargePreview('single', byId('txAmount')?.value || 0);
    const updateJournalCommissionPreview = () => readChargePreview('journal', parseAmountInput('journalAmount'));
    const collectChargeBreakdownFromUi = (scope, amountValue) => {
      const amount = Math.max(0, Number(amountValue || 0));
      const toggleId = scope === 'single' ? 'txApplyCharges' : 'journalApplyCharges';
      const toggle = byId(toggleId);
      if (!(toggle && toggle.checked)) return [];
      let remaining = amount;
      const rows = [];
      CHARGE_DEFS.forEach(def => {
        const check = q(`[data-charge-check="${def.key}"][data-charge-scope="${scope}"]`);
        const input = q(`[data-charge-input="${def.key}"][data-charge-scope="${scope}"]`);
        if (!(check && check.checked && input)) return;
        const raw = Math.max(0, Number(input.value || 0));
        const amt = Math.min(raw, remaining);
        if (amt > 0) {
          rows.push({ key: def.key, label: def.label, amount: amt });
          remaining = Math.max(0, remaining - amt);
        }
      });
      return rows;
    };
    const resetFields = () => {
      ['txAcc','txAmount','txDetails','txCounterparty'].forEach(id=>{ if(byId(id)) byId(id).value=''; });
      state.ui.txAccDraft = '';
      state.ui.txAmountDraft = '';
      state.ui.txDetailsDraft = '';
      state.ui.txCounterpartyDraft = '';
      state.ui.txModeDraft = 'cash';
      telleringDraft.singleCharges = { apply: false, checked: {}, values: {} };
      if (byId('txApplyCharges')) byId('txApplyCharges').checked = false;
      CHARGE_DEFS.forEach(def => {
        const check = q(`[data-charge-check="${def.key}"][data-charge-scope="single"]`);
        const input = q(`[data-charge-input="${def.key}"][data-charge-scope="single"]`);
        if (check) check.checked = false;
        if (input) input.value = '';
      });
      if (byId('txName')) byId('txName').textContent='—';
      if (byId('txBalance')) byId('txBalance').innerHTML='—';
      updateTxAccountMeta(null);
      state.ui.selectedCustomerId=null;
      updateSingleCommissionPreview();
    };
    const resetJournalEntryFields = (clearAccount = false) => {
      // Always clear amount/details after each entry. journalCounterparty is
      // deliberately NOT cleared here — Received By/Paid To now applies to
      // the whole journal (set once above the table), not re-typed per row.
      ['journalAmount','journalDetails'].forEach(id=>{ if(byId(id)) byId(id).value=''; });
      telleringDraft.journalAmount = '';
      telleringDraft.journalCharges = { apply: false, checked: {}, values: {} };
      if (byId('journalApplyCharges')) byId('journalApplyCharges').checked = false;
      CHARGE_DEFS.forEach(def => {
        const check = q(`[data-charge-check="${def.key}"][data-charge-scope="journal"]`);
        const input = q(`[data-charge-input="${def.key}"][data-charge-scope="journal"]`);
        if (check) check.checked = false;
        if (input) input.value = '';
      });
      // Only clear account/name when explicitly requested (e.g. journal cleared/submitted)
      if (clearAccount) {
        if (byId('journalAcc')) byId('journalAcc').value = '';
        if (byId('journalName')) byId('journalName').textContent = '—';
        updateJournalAccountMeta(null);
        state.ui.journalAccDraft = '';
        state.ui.selectedJournalCustomerId = null;
      }
      updateJournalCommissionPreview();
    };

    const recalcPreview = () => {
      // SURGICAL PATCH 2026-09-22 (client-confirmed design): the Journal is
      // disconnected from the teller's operational balance — Journal Value
      // is whatever the staff has typed into the journalFormAmount input,
      // not a derived display of getStaffOperationalBalance(). Read it live
      // from the input (falling back to the saved draft value) so typing
      // updates the running/variance figures below as they go.
      const journalFormRaw = String(byId('journalFormAmount')?.value ?? telleringDraft.journalFormAmount ?? '');
      const journalForm = Number(journalFormRaw.replace(/,/g, '')) || 0;
      let jRunning = journalForm;
      const withBalances = journal.map((row) => {
        jRunning -= Number(row.amount||0);
        const remaining = jRunning;
        const variance = Math.max(0, -remaining);
        return { row, formBase: journalForm, remaining, variance };
      });
      // SURGICAL FIX 2026-09-29 (client-confirmed paper design): table is
      // S/N, Account Number, Account Name, Amount, Action (Edit / Delete).
      // SURGICAL FIX 2026-10-19 (client): the 1-10 numbering on the paper
      // design was only an example — no pre-numbered blank lines. The table
      // starts empty; each posted entry gets the next S/N (1, 2, 3, ...) and
      // numbers re-sequence if an entry is edited out or removed.
      // Per-row details/charges show as small meta under the name; the
      // running Balance/Variance stay in the header's Balance / Variance.
      const filledRows = withBalances.map(({ row }, displayIndex) => {
        const meta = [row.details ? escapeHtml(row.details) : '', getTotalChargeAmount(row) > 0 ? chargeInlineMeta(row) : ''].filter(Boolean).join(' • ');
        return `<tr><td class="jr-sn">${displayIndex+1}</td><td>${escapeHtml(row.accountNumber || '')}</td><td>${escapeHtml(row.customerName || '')}${meta ? `<div class="journal-inline-meta">${meta}</div>` : ''}</td><td class="jr-amt">${money(row.amount)}</td><td class="jr-actions"><button type="button" class="jr-act" data-edit-row="${row.id}">Edit</button><button type="button" class="jr-act jr-act-del" data-remove-row="${row.id}">Delete</button></td></tr>`;
      });
      const rows = filledRows.join('');
      if (byId('journalRows')) byId('journalRows').innerHTML = rows;
      const totalPosted = journal.reduce((sum, row) => sum + Number(row.amount || 0), 0);
      if (byId('journalTotalPosted')) byId('journalTotalPosted').textContent = money(totalPosted);
      // SURGICAL FIX 2026-09-28 (client: Opening Cash + Cash Received -
      // Cash Withdrawal = Till): Opening Cash must be the start-of-day
      // balance, exactly as in the initial render — the full balance
      // already includes today's postings, so they were counted twice.
      const { openingCash: openingCashLive, cashReceived: cashReceivedLive, cashWithdrawal: cashWithdrawalLive, till: tillLive } = getTillBreakdown(staff.id, businessDate());
      if (byId('postingOpeningCash')) byId('postingOpeningCash').textContent = money(openingCashLive);
      if (byId('postingCashReceived')) byId('postingCashReceived').textContent = money(cashReceivedLive);
      if (byId('postingCashWithdrawal')) byId('postingCashWithdrawal').textContent = money(cashWithdrawalLive);
      if (byId('postingTill')) {
        const el = byId('postingTill');
        el.textContent = money(tillLive);
        el.classList.toggle('balance-negative', tillLive < 0);
      }
      if (byId('journalFormRunning')) byId('journalFormRunning').textContent = money(Math.max(0, jRunning));
      if (byId('journalFormVariance')) byId('journalFormVariance').textContent = money(Math.max(0, -jRunning));
      const fileNameEl = byId('journalFieldNoteName');
      if (fileNameEl) fileNameEl.textContent = attachmentState.loading ? 'Reading file…' : (attachmentState.fieldNote?.name ? `${attachmentState.fieldNote.name} (${formatFileSize(attachmentState.fieldNote.size)})` : 'No file selected');
      const inputEl = byId('journalFieldNoteInput');
      if (inputEl) inputEl.disabled = attachmentState.loading;
      // SURGICAL ADDITION 2026-08-19: field note previously only showed its
      // filename after upload — no way to confirm the right document was
      // attached before submitting. Render an actual preview (thumbnail for
      // images, a named link for PDFs since those can't inline-preview).
      const previewEl = byId('journalFieldNotePreview');
      if (previewEl) {
        const fn = attachmentState.fieldNote;
        if (!fn || attachmentState.loading) {
          previewEl.classList.add('hidden');
          previewEl.innerHTML = '';
        } else {
          previewEl.classList.remove('hidden');
          previewEl.innerHTML = String(fn.type || '').startsWith('image/')
            ? `<img src="${fn.dataUrl}" alt="Field note preview">`
            : `<a href="${fn.dataUrl}" target="_blank" rel="noopener" class="field-note-pdf-link">📄 ${escapeHtml(fn.name || 'Field note.pdf')}</a>`;
        }
      }
      qq('[data-remove-row]').forEach(el => el.onclick = () => {
        const idx = journal.findIndex(r => r.id === el.dataset.removeRow);
        if (idx >= 0) {
          journal.splice(idx,1);
          save();
          recalcPreview();
        }
      });
      // Edit pulls the row back into the entry form below (account, amount,
      // details, charges) and takes it out of the list — press Post again
      // to put the corrected entry back.
      qq('[data-edit-row]').forEach(el => el.onclick = () => {
        const idx = journal.findIndex(r => r.id === el.dataset.editRow);
        if (idx < 0) return;
        const row = journal[idx];
        const customer = state.customers.find(c => c.id === row.customerId) || getCustomerByAccountNo(row.accountNumber);
        const charges = { apply: false, checked: {}, values: {} };
        (row.chargeBreakdown || []).forEach(ch => { charges.apply = true; charges.checked[ch.key] = true; charges.values[ch.key] = String(ch.amount); });
        restoreJournalEntrySnapshot({
          acc: String(row.accountNumber || ''),
          amount: String(row.amount || ''),
          counterparty: String(byId('journalCounterparty')?.value || ''),
          details: String(row.details || ''),
          name: row.customerName || '—',
          selectedJournalCustomerId: customer?.id || '',
          charges
        });
        state.ui.journalAccDraft = String(row.accountNumber || '');
        journal.splice(idx, 1);
        save();
        recalcPreview();
        requestAnimationFrame(() => byId('journalAmount')?.focus({ preventScroll: true }));
      });
    };

    const searchSingle = (opts = {}) => {
      const value = (byId('txAcc')?.value || '').trim();
      state.ui.txAccDraft = value;
      const c = getCustomerByAccountNo(value);
      if (!c) { if (!opts.quiet) showToast('Customer not found'); return null; }
      if (isCustomerFrozen(c) || c.active === false) {
        freezeInactiveCustomer(c);
        if (!opts.quiet) save();
        if (!opts.quiet) showToast(c.closed ? 'Account is closed' : 'Account is frozen');
        return null;
      }
      state.ui.selectedCustomerId = c.id;
      state.ui.generatedJournals ||= {};
      state.ui.collapsedJournals ||= {};
      state.ui.generatedJournals[visibilityKey] = false;
      state.ui.collapsedJournals[visibilityKey] = false;
      if (byId('txName')) byId('txName').textContent = c.name;
      if (byId('txBalance')) byId('txBalance').innerHTML = balanceHtml(c.accountType === 'staff_operational' ? tellerTillBalance(c.linkedStaffId) : c.balance);
      updateTxAccountMeta(c);
      // Quiet auto-lookup must not save/repaint while the user is moving from
      // Account Number into Amount. Journal was fixed the same way: keep the
      // in-memory selection and DOM update now; persist later on post/journal actions.
      if (!opts.quiet) save();
      return c;
    };

    const restoreSingleCustomerDisplay = () => {
      const value = String(byId('txAcc')?.value || state.ui.txAccDraft || '').trim();
      // Never restore when there is no account value — prevents stale data showing after clear
      if (!value) return;
      const selected = state.ui.selectedCustomerId ? state.customers.find(c => c.id === state.ui.selectedCustomerId) : null;
      const customer = selected && String(selected.accountNumber || '') === value ? selected : getCustomerByAccountNo(value);
      if (!customer) return;
      state.ui.selectedCustomerId = customer.id;
      state.ui.txAccDraft = customer.accountNumber || value;
      if (byId('txAcc') && String(byId('txAcc').value || '').trim() !== String(customer.accountNumber || '')) byId('txAcc').value = customer.accountNumber || value;
      if (byId('txName')) byId('txName').textContent = customer.name || '—';
      if (byId('txBalance')) byId('txBalance').innerHTML = balanceHtml(customer.accountType === 'staff_operational' ? tellerTillBalance(customer.linkedStaffId) : customer.balance);
      updateTxAccountMeta(customer);
    };

    const searchJournal = (opts = {}) => {
      const value = (byId('journalAcc')?.value || state.ui.journalAccDraft || '').trim();
      const c = getCustomerByAccountNo(value);
      if (!c) { if (!opts.quiet) showToast('Customer not found'); return null; }
      if (isCustomerFrozen(c) || c.active === false) { freezeInactiveCustomer(c); save(); if (!opts.quiet) showToast(c.closed ? 'Account is closed' : 'Account is frozen'); return null; }
      state.ui.selectedJournalCustomerId = c.id;
      state.ui.journalAccDraft = value;
      if (byId('journalAcc') && String(byId('journalAcc').value || '').trim() !== value) byId('journalAcc').value = value;
      if (byId('journalName')) byId('journalName').textContent = c.name || '—';
      updateJournalAccountMeta(c);
      // Journal lookup is deliberately DOM-only during entry. Saving here can cause
      // the journal entry row to repaint while the user is moving between Account
      // Number and Amount, which steals the first click/focus. The actual journal
      // state is persisted when adding/submitting/clearing the journal.
      return c;
    };

    if (byId('txSearch')) byId('txSearch').onclick = () => openCustomerSearchModal(state.customers);
    if (byId('txAcc')) {
      const clearSingleCustomer = () => {
        if (byId('txName')) byId('txName').textContent = '—';
        if (byId('txBalance')) byId('txBalance').innerHTML = '—';
        updateTxAccountMeta(null);
        state.ui.selectedCustomerId = null;
        state.ui.generatedJournals ||= {};
        state.ui.collapsedJournals ||= {};
        state.ui.generatedJournals[visibilityKey] = false;
        state.ui.collapsedJournals[visibilityKey] = false;
        save();
      };
      // SURGICAL FIX 2026-09-03: client does not want the account fetched
      // live as-you-type or on blur/tab — only on explicit Enter. oninput
      // and onchange now do draft persistence (and clearing when the field
      // is emptied) only; searchSingle() runs solely from the Enter keyup
      // below.
      byId('txAcc').oninput = () => {
        const v = (byId('txAcc').value || '').trim();
        state.ui.txAccDraft = v;
        if (!v) { clearSingleCustomer(); return; }
      };
      byId('txAcc').onchange = () => {
        const v = (byId('txAcc').value || '').trim();
        state.ui.txAccDraft = v;
        if (!v) { clearSingleCustomer(); return; }
      };
      byId('txAcc').onkeyup = e => { if(e.key==='Enter') searchSingle(); };
    }

    if (byId('txApplyCharges')) byId('txApplyCharges').onchange = () => {
      telleringDraft.singleCharges.apply = !!byId('txApplyCharges')?.checked;
      save();
      updateSingleCommissionPreview();
    };
    if (byId('txAmount')) {
      const amountInput = byId('txAmount');
      amountInput.oninput = () => {
        state.ui.txAmountDraft = amountInput.value || '';
        updateSingleCommissionPreview();
        // Do NOT call restoreSingleCustomerDisplay here — it was triggering
        // state mutations on every keystroke. The customer display is already
        // set when the account is searched; it only needs restoring on blur/change.
      };
      amountInput.onchange = () => { state.ui.txAmountDraft = amountInput.value || ''; save(); restoreSingleCustomerDisplay(); };
    }
    if (byId('txCounterparty')) {
      byId('txCounterparty').oninput = () => { state.ui.txCounterpartyDraft = byId('txCounterparty').value || ''; };
      byId('txCounterparty').onchange = () => { state.ui.txCounterpartyDraft = byId('txCounterparty').value || ''; };
    }
    if (byId('txDetails')) {
      byId('txDetails').oninput = () => { state.ui.txDetailsDraft = byId('txDetails').value || ''; };
      byId('txDetails').onchange = () => { state.ui.txDetailsDraft = byId('txDetails').value || ''; };
    }
    qq('input[name="txMode"]').forEach(radio => {
      radio.onchange = () => { state.ui.txModeDraft = radio.value; };
    });
    CHARGE_DEFS.forEach(def => {
      const check = q(`[data-charge-check="${def.key}"][data-charge-scope="single"]`);
      const input = q(`[data-charge-input="${def.key}"][data-charge-scope="single"]`);
      if (check) check.onchange = () => {
        telleringDraft.singleCharges.checked[def.key] = !!check.checked;
        if (!check.checked) telleringDraft.singleCharges.values[def.key] = '';
        save();
        updateSingleCommissionPreview();
      };
      if (input) input.oninput = () => {
        telleringDraft.singleCharges.values[def.key] = input.value || '';
        save();
        updateSingleCommissionPreview();
      };
    });

    const jumpToJournalPane = () => {
      requestAnimationFrame(() => {
        const pane = byId('journalPane') || q('#journalPane') || byId('journalPaneWrap');
        if (pane && pane.scrollIntoView) pane.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    };

    if (byId('txJournalAdd')) byId('txJournalAdd').onclick = () => {
      state.ui.generatedJournals[visibilityKey] = true;
      state.ui.collapsedJournals[visibilityKey] = false;
      save();
      renderWorkspace();
      jumpToJournalPane();
    };

    const toggleJournalCollapse = () => {
      const willExpand = !!state.ui.collapsedJournals[visibilityKey];
      state.ui.collapsedJournals[visibilityKey] = !state.ui.collapsedJournals[visibilityKey];
      save();
      renderWorkspace();
      if (willExpand) jumpToJournalPane();
    };

    if (byId('journalCollapseBtn')) byId('journalCollapseBtn').onclick = toggleJournalCollapse;
    if (byId('journalCollapseTopBtn')) byId('journalCollapseTopBtn').onclick = toggleJournalCollapse;

    if (byId('journalSearchBtn')) byId('journalSearchBtn').onclick = () => openJournalCustomerSearchModal(state.customers);
    if (byId('journalAcc')) {
      const clearJournalCustomer = () => {
        if (byId('journalName')) byId('journalName').textContent = '—';
        state.ui.selectedJournalCustomerId = null;
        updateJournalAccountMeta(null);
        // Do NOT call save() here — it can trigger re-renders that wipe the account field
      };
      // SURGICAL FIX 2026-09-03: client does not want the account fetched
      // live as-you-type or on blur/tab — only on explicit Enter. oninput
      // and onchange now do draft persistence (and clearing when the field
      // is emptied) only; searchJournal() runs solely from the Enter keyup
      // below.
      byId('journalAcc').oninput = () => {
        if (byId('journalAcc')?.dataset?.restoring === '1') return;
        const v = (byId('journalAcc').value || '').trim();
        // CRITICAL: set journalAccDraft immediately so any re-render restores this value
        state.ui.journalAccDraft = v;
        if (!v) { clearJournalCustomer(); return; }
        const selected = state.ui.selectedJournalCustomerId ? state.customers.find(c => c.id === state.ui.selectedJournalCustomerId) : null;
        if (selected && String(selected.accountNumber || '') !== v) {
          state.ui.selectedJournalCustomerId = null;
          if (byId('journalName')) byId('journalName').textContent = '—';
          updateJournalAccountMeta(null);
        }
      };
      byId('journalAcc').onchange = () => {
        if (byId('journalAcc')?.dataset?.restoring === '1') return;
        const v = (byId('journalAcc').value || '').trim();
        state.ui.journalAccDraft = v;
        if (!v) { clearJournalCustomer(); return; }
      };
      byId('journalAcc').onkeyup = e => { if(e.key==='Enter') searchJournal(); };
    }

    if (byId('journalApplyCharges')) byId('journalApplyCharges').onchange = () => {
      telleringDraft.journalCharges.apply = !!byId('journalApplyCharges')?.checked;
      save();
      updateJournalCommissionPreview();
    };
    if (byId('journalFormAmount')) {
      bindAmountCommaFormatting('journalFormAmount');
      const journalFormInput = byId('journalFormAmount');
      journalFormInput.oninput = () => {
        if (journalFormInput.dataset?.restoring === '1') return;
        telleringDraft.journalFormAmount = journalFormInput.value || '';
        recalcPreview();
      };
      journalFormInput.onchange = () => { telleringDraft.journalFormAmount = journalFormInput.value || ''; save(); };
    }
    qq('input[name="journalFormMode"]').forEach(radio => radio.onchange = () => {
      if (radio.checked) { telleringDraft.journalFormMode = radio.value; save(); recalcPreview(); }
    });
    if (byId('journalAmount')) {
      bindAmountCommaFormatting('journalAmount');
      const journalAmountInput = byId('journalAmount');
      const protectJournalAccountDraft = () => {
        const accountInput = byId('journalAcc');
        const currentValue = String(accountInput?.value || state.ui.journalAccDraft || '').trim();
        if (currentValue) state.ui.journalAccDraft = currentValue;
      };
      journalAmountInput.onfocus = protectJournalAccountDraft;
      journalAmountInput.oninput = () => {
        if (journalAmountInput.dataset?.restoring === '1') return;
        protectJournalAccountDraft();
        telleringDraft.journalAmount = journalAmountInput.value || '';
        updateJournalCommissionPreview();
      };
      journalAmountInput.onchange = () => { protectJournalAccountDraft(); telleringDraft.journalAmount = journalAmountInput.value || ''; };
    }
    if (byId('journalDescription')) byId('journalDescription').oninput = () => { telleringDraft.journalDescription = byId('journalDescription').value || ''; };
    if (byId('journalConfirmedBy')) byId('journalConfirmedBy').oninput = () => { telleringDraft.journalConfirmedBy = byId('journalConfirmedBy').value || ''; };
    if (byId('journalDate')) byId('journalDate').onchange = () => { telleringDraft.journalDate = byId('journalDate').value || ''; };
    if (byId('journalCounterparty')) {
      // SURGICAL FIX 2026-09-03: persist the whole-journal Received By/Paid
      // To value so it survives re-renders across multiple "Add to Journal"
      // clicks, same pattern as journalAccDraft/telleringDraft.journalAmount.
      byId('journalCounterparty').oninput = () => {
        if (byId('journalCounterparty')?.dataset?.restoring === '1') return;
        state.ui.journalCounterpartyDraft = byId('journalCounterparty').value || '';
      };
    }
    CHARGE_DEFS.forEach(def => {
      const check = q(`[data-charge-check="${def.key}"][data-charge-scope="journal"]`);
      const input = q(`[data-charge-input="${def.key}"][data-charge-scope="journal"]`);
      if (check) check.onchange = () => {
        telleringDraft.journalCharges.checked[def.key] = !!check.checked;
        if (!check.checked) telleringDraft.journalCharges.values[def.key] = '';
        save();
        updateJournalCommissionPreview();
      };
      if (input) input.oninput = () => {
        telleringDraft.journalCharges.values[def.key] = input.value || '';
        save();
        updateJournalCommissionPreview();
      };
    });

    const readJournalEntrySnapshot = () => ({
      acc: String(byId('journalAcc')?.value || ''),
      amount: String(byId('journalAmount')?.value || ''),
      counterparty: String(byId('journalCounterparty')?.value || ''),
      details: String(byId('journalDetails')?.value || ''),
      name: String(byId('journalName')?.textContent || '—'),
      selectedJournalCustomerId: state.ui.selectedJournalCustomerId || '',
      charges: {
        apply: !!telleringDraft.journalCharges?.apply,
        checked: { ...(telleringDraft.journalCharges?.checked || {}) },
        values: { ...(telleringDraft.journalCharges?.values || {}) }
      }
    });

    const restoreJournalEntrySnapshot = (snapshot) => {
      if (!snapshot) return;
      // Use a flag to suppress oninput/onchange handlers during restore
      const _restore = true;
      const setVal = (id, val) => {
        const el = byId(id);
        if (!el) return;
        el.dataset.restoring = '1';
        el.value = val;
        delete el.dataset.restoring;
      };
      setVal('journalAcc', snapshot.acc);
      setVal('journalAmount', snapshot.amount);
      setVal('journalCounterparty', snapshot.counterparty);
      setVal('journalDetails', snapshot.details);
      if (byId('journalName')) byId('journalName').textContent = snapshot.name || '—';
      state.ui.selectedJournalCustomerId = snapshot.selectedJournalCustomerId || state.ui.selectedJournalCustomerId || null;
      updateJournalAccountMeta(state.ui.selectedJournalCustomerId ? state.customers.find(c => c.id === state.ui.selectedJournalCustomerId) : null);
      telleringDraft.journalAmount = snapshot.amount;
      telleringDraft.journalCharges = {
        apply: !!snapshot.charges?.apply,
        checked: { ...(snapshot.charges?.checked || {}) },
        values: { ...(snapshot.charges?.values || {}) }
      };
      if (byId('journalApplyCharges')) byId('journalApplyCharges').checked = !!telleringDraft.journalCharges.apply;
      CHARGE_DEFS.forEach(def => {
        const check = q(`[data-charge-check="${def.key}"][data-charge-scope="journal"]`);
        const input = q(`[data-charge-input="${def.key}"][data-charge-scope="journal"]`);
        if (check) check.checked = !!telleringDraft.journalCharges.checked[def.key];
        if (input) {
          input.dataset.restoring = '1';
          input.value = telleringDraft.journalCharges.values[def.key] || '';
          input.classList.toggle('hidden', !telleringDraft.journalCharges.checked[def.key]);
          delete input.dataset.restoring;
        }
      });
      updateJournalCommissionPreview();
    };

    if (byId('journalAddRow')) byId('journalAddRow').onclick = (event) => {
      event?.preventDefault?.();
      event?.stopPropagation?.();
      const journalEntrySnapshot = readJournalEntrySnapshot();
      const journalAccValue = String(byId('journalAcc')?.value || state.ui.journalAccDraft || '').trim();
      const selectedJournalCustomer = state.ui.selectedJournalCustomerId ? state.customers.find(c => c.id === state.ui.selectedJournalCustomerId) : null;
      // Try to find customer: first by selected ID, then by account number lookup
      const customer = (selectedJournalCustomer && String(selectedJournalCustomer.accountNumber || '') === journalAccValue)
        ? selectedJournalCustomer
        : getCustomerByAccountNo(journalAccValue);
      // If still not found by account number alone, try matching against all customers
      const resolvedCustomer = customer || state.customers.find(c => String(c.accountNumber || '') === journalAccValue && c.active !== false);
      if (resolvedCustomer && !state.ui.selectedJournalCustomerId) {
        // Auto-resolve the customer if we found them by account number
        state.ui.selectedJournalCustomerId = resolvedCustomer.id;
        if (byId('journalName')) byId('journalName').textContent = resolvedCustomer.name || '—';
        updateJournalAccountMeta(resolvedCustomer);
      }
      if (!journalAccValue || !resolvedCustomer) return showToast('Enter a valid account number');
      if (isCustomerFrozen(resolvedCustomer) || resolvedCustomer.active === false) { freezeInactiveCustomer(resolvedCustomer); save(); return showToast(resolvedCustomer.closed ? 'Closed account cannot accept transactions' : 'Frozen account cannot accept transactions'); }
      const amount = parseAmountInput('journalAmount');
      if (!(amount > 0)) return showToast('Enter a valid amount');
      const mode = selectedMode();
      const chargeBreakdown = kind === 'credit' ? collectChargeBreakdownFromUi('journal', amount) : [];
      const totalChargeAmount = chargeBreakdown.reduce((sum, row) => sum + Number(row.amount || 0), 0);
      const customerCreditAmount = kind === 'credit' ? Math.max(0, amount - totalChargeAmount) : amount;
      if (kind === 'debit') {
        const shortfall = journalDebitShortfall([{ customerId: resolvedCustomer.id, amount }, ...journal]);
        if (shortfall) return showToast(shortfall);
      }
      journal.unshift({
        id: uid('jr'),
        customerId: resolvedCustomer.id,
        customerName: resolvedCustomer.name,
        accountNumber: resolvedCustomer.accountNumber,
        accountType: resolvedCustomer.accountType || 'customer',
        staffAccountId: (resolvedCustomer.accountType === 'staff' || resolvedCustomer.accountType === 'staff_wallet') ? (resolvedCustomer.staffId || resolvedCustomer.id) : '',
        staffAccountUuid: (resolvedCustomer.accountType === 'staff' || resolvedCustomer.accountType === 'staff_wallet') ? (resolvedCustomer.staffUuid || getStaffBackendId(state.staff?.find(s => s.id === resolvedCustomer.staffId)) || '') : '',
        amount,
        customerCreditAmount,
        chargeBreakdown,
        totalChargeAmount,
        commissionAmount: chargeBreakdown.find(row => row.key === 'commission')?.amount || 0,
        chargeTraceId: totalChargeAmount > 0 ? uid('ctr') : '',
        commissionTraceId: totalChargeAmount > 0 ? uid('ctr') : '',
        details: byId('journalDetails')?.value.trim() || '',
        receivedOrPaidBy: byId('journalCounterparty')?.value.trim() || '',
        payoutSource: mode,
        paymentMode: mode,
        date: businessDate()
      });
      // Clear the journal draft state before saving so the next render cannot restore old entry values.
      resetJournalEntryFields(true);
      state.ui.journalAccDraft = '';
      state.ui.selectedJournalCustomerId = null;
      telleringDraft.journalAmount = '';
      telleringDraft.journalCharges = { apply: false, checked: {}, values: {} };
      if (byId('journalAcc')) byId('journalAcc').value = '';
      if (byId('journalName')) byId('journalName').textContent = '—';
      recalcPreview();
      save();
      // Re-focus account for next entry
      requestAnimationFrame(() => byId('journalAcc')?.focus({ preventScroll: true }));
    };

    const fieldNoteInput = byId('journalFieldNoteInput');
    if (fieldNoteInput) {
      fieldNoteInput.value = '';
      fieldNoteInput.onchange = async (event) => {
        const file = event?.target?.files?.[0] || null;
        if (!file) { attachmentState.fieldNote = null; attachmentState.loading = false; save(); recalcPreview(); return; }
        if (!isSupportedFieldNoteFile(file)) { event.target.value = ''; attachmentState.fieldNote = null; attachmentState.loading = false; save(); recalcPreview(); return showToast('Only photo field notes are supported (PDFs are no longer accepted)'); }
        attachmentState.loading = true; save(); recalcPreview();
        try {
          attachmentState.fieldNote = await readFieldNoteFile(file);
          if (Number(attachmentState.fieldNote?.size || 0) > FIELD_NOTE_MAX_BYTES) {
            event.target.value = '';
            attachmentState.fieldNote = null;
            throw new Error('Field note must be 2 MB or less');
          }
        } catch (error) {
          attachmentState.fieldNote = null;
          showToast(error?.message || 'Unable to read selected file');
        } finally {
          attachmentState.loading = false;
          save();
          recalcPreview();
        }
      };
    }

    if (byId('journalClear')) byId('journalClear').onclick = () => {
      journal.splice(0);
      attachmentState.fieldNote = null;
      attachmentState.loading = false;
      state.ui.generatedJournals[visibilityKey] = false;
      state.ui.journalAccDraft = '';
      state.ui.journalCounterpartyDraft = '';
      state.ui.selectedJournalCustomerId = null;
      state.ui.resumingJournalId = '';
      telleringDraft.journalAmount = '';
      telleringDraft.journalFormAmount = '';
      telleringDraft.journalFormMode = 'cash';
      telleringDraft.journalDescription = '';
      telleringDraft.journalConfirmedBy = '';
      telleringDraft.journalDate = '';
      const input = byId('journalFieldNoteInput');
      if (input) input.value = '';
      save();
      renderWorkspace();
    };

    if (byId('txPostSingle')) byId('txPostSingle').onclick = () => {
      if (!hasPermission(kind)) return showToast('No access to post');
      if (isBusinessDateClosed(businessDate())) return showToast(businessDateClosedMessage(businessDate()));
      // SURGICAL FIX 2026-10-01 (client): a debit is paid out of the Till —
      // the teller's current balance (Opening Cash + Cash Received - Cash
      // Withdrawal) — not only out of Opening Cash/funding. Cash collected
      // from today's credits can be paid out on a debit.
      const tillNow = getTillBreakdown(staff.id, businessDate()).till;
      if (kind === 'debit' && tillNow <= 0) return showToast('No cash in your Till to pay out — post a credit or receive a transfer first');
      const accountNumberInput = String(byId('txAcc')?.value || '').trim();
      const customer = getCustomerByAccountNo(accountNumberInput);
      if (!accountNumberInput || !customer) return showToast('Search for customer first');
      if (isCustomerFrozen(customer) || customer.active === false) { freezeInactiveCustomer(customer); save(); return showToast(customer.closed ? 'Closed account cannot accept transactions' : 'Frozen account cannot accept transactions'); }
      const amount = Number(byId('txAmount').value || 0);
      if (!(amount > 0)) return showToast('Enter a valid amount');
      if (kind === 'debit' && amount > tillNow + 0.01) return showToast(`Debit exceeds your Till (${money(tillNow)})`);
      // 2026-11-02 (client): an account with no money must not be debited.
      if (kind === 'debit' && !['expense','income','staff_operational'].includes(String(customer.accountType || 'customer')) && amount > Number(customer.balance || 0) + 0.01) {
        return showToast(`Insufficient funds — account balance is ${money(customer.balance || 0)}`);
      }
      const mode = selectedMode();
      const chargeBreakdown = kind === 'credit' ? collectChargeBreakdownFromUi('single', amount) : [];
      const totalChargeAmount = chargeBreakdown.reduce((sum, row) => sum + Number(row.amount || 0), 0);
      const customerCreditAmount = kind === 'credit' ? Math.max(0, amount - totalChargeAmount) : amount;
      // Snapshot form values NOW before confirmAction closes the modal (blur events
      // can fire during modal close and re-populate state from DOM values).
      const _details = String(byId('txDetails')?.value || '').trim();
      const _counterparty = String(byId('txCounterparty')?.value || '').trim();
      confirmAction(`Submit single ${kind} request for approval?`, async () => {
        // Wipe state and DOM immediately — before the network call — so no interim
        // render (from realtime events etc.) can ever restore old values.
        state.ui.txAccDraft = '';
        state.ui.txAmountDraft = '';
        state.ui.txDetailsDraft = '';
        state.ui.txCounterpartyDraft = '';
        state.ui.selectedCustomerId = null;
        if (state.ui.telleringDrafts) {
          state.ui.telleringDrafts[visibilityKey] = {
            singleCharges: { apply: false, checked: {}, values: {} },
            journalCharges: { apply: false, checked: {}, values: {} }
          };
        }
        ['txAcc','txAmount','txDetails','txCounterparty'].forEach(id => { const el = byId(id); if (el) el.value = ''; });
        if (byId('txName')) byId('txName').textContent = '—';
        if (byId('txBalance')) byId('txBalance').innerHTML = '—';
        updateTxAccountMeta(null);
        save();
        showProcessing('Sending request...');
        await nextPaint();
        try {
          const result = await submitApprovalThroughGateway(kind === 'credit' ? 'customer_credit' : 'customer_debit', {
            customerId: customer.id,
            customerName: customer.name,
            accountNumber: customer.accountNumber,
            accountType: customer.accountType || 'customer',
            staffAccountId: customer.accountType === 'staff' ? customer.staffId : '',
            staffAccountUuid: customer.accountType === 'staff' ? customer.staffUuid : '',
            amount,
            customerCreditAmount,
            chargeBreakdown,
            totalChargeAmount,
            commissionAmount: chargeBreakdown.find(row => row.key === 'commission')?.amount || 0,
            chargeTraceId: totalChargeAmount > 0 ? uid('ctr') : '',
            commissionTraceId: totalChargeAmount > 0 ? uid('ctr') : '',
            details: _details,
            receivedOrPaidBy: _counterparty,
            payoutSource: mode,
            paymentMode: mode,
            staffId: staff.id,
            date: businessDate()
          });
          if (!result?.ok) {
            showToast(result?.error?.message || 'Unable to submit request');
            return;
          }
          showToast(`${kind === 'credit' ? 'Credit' : 'Debit'} request sent for approval`);
          renderWorkspace();
        } finally {
          hideProcessing();
        }
      });
    };

    if (byId('journalSaveDraft')) byId('journalSaveDraft').onclick = async () => {
      if (!journal.length) return showToast('Add at least one row before saving');
      if (attachmentState.loading) return showToast('Please wait for the field note to finish loading');
      const journalFormAmount = Number(String(byId('journalFormAmount')?.value ?? telleringDraft.journalFormAmount ?? '').replace(/,/g, '')) || 0;
      if (!(journalFormAmount > 0)) return showToast('Enter the Journal Value before saving');
      const journalFormMode = 'cash';
      const jDate = byId('journalDate')?.value || telleringDraft.journalDate || '';
      const jDateErr = validateJournalDate(jDate);
      if (jDateErr) return showToast(jDateErr);
      const jConfirmed = byId('journalConfirmedBy')?.value.trim() || '';
      const jDesc = byId('journalDescription')?.value.trim() || '';
      journal.forEach(r => { r.details = jDesc; });
      const fieldNoteSnapshot = attachmentState.fieldNote ? { name: attachmentState.fieldNote.name, type: attachmentState.fieldNote.type, size: attachmentState.fieldNote.size, dataUrl: attachmentState.fieldNote.dataUrl, uploadedAt: attachmentState.fieldNote.uploadedAt } : null;
      // If this draft was opened from the Journal Register ("Resume"), keep
      // updating THAT record and its Journal Number rather than minting a
      // new one every time it's re-saved.
      const resumingId = state.ui.resumingJournalId;
      const existing = resumingId ? (state.journals || []).find(j => j.id === resumingId) : null;
      let journalNumber;
      let reservedNumber = '';
      if (!existing) {
        const reserved = await reserveJournalNumber();
        if (!reserved.ok) return showToast(reserved.message);
        reservedNumber = reserved.number;
      }
      // SURGICAL PATCH 2026-09-22 (client-confirmed design): a saved draft
      // has no date yet — the business date is captured by the system only
      // at actual posting time (see openJournalPostModal's Post handler and
      // journalSubmit below), not when merely saved as a draft.
      if (existing) {
        journalNumber = existing.journalNumber;
        existing.date = existing.date || '';
        existing.counterparty = byId('journalCounterparty')?.value.trim() || '';
        existing.description = byId('journalDescription')?.value.trim() || '';
        existing.journalDate = jDate;
        existing.confirmedBy = jConfirmed;
        existing.formAmount = journalFormAmount;
        existing.formPaymentMode = journalFormMode;
        existing.rows = journal.map(row => ({ ...row }));
        existing.fieldNote = fieldNoteSnapshot;
      } else {
        journalNumber = reservedNumber;
        state.journals.push({
          id: uid('jn'),
          journalNumber,
          kind,
          date: '',
          staffId: staff.id,
          staffName: staff.name,
          counterparty: byId('journalCounterparty')?.value.trim() || '',
          description: byId('journalDescription')?.value.trim() || '',
          journalDate: jDate,
          confirmedBy: jConfirmed,
          formAmount: journalFormAmount,
          formPaymentMode: journalFormMode,
          rows: journal.map(row => ({ ...row })),
          fieldNote: fieldNoteSnapshot,
          status: 'draft',
          createdAt: new Date().toISOString()
        });
      }
      await persistJournal(existing || state.journals[state.journals.length - 1]);
      state.ui.resumingJournalId = '';
      journal.splice(0);
      attachmentState.fieldNote = null;
      attachmentState.loading = false;
      state.ui.generatedJournals[visibilityKey] = false;
      state.ui.journalCounterpartyDraft = '';
      telleringDraft.journalFormAmount = '';
      telleringDraft.journalFormMode = 'cash';
      telleringDraft.journalDescription = '';
      telleringDraft.journalConfirmedBy = '';
      telleringDraft.journalDate = '';
      const input = byId('journalFieldNoteInput');
      if (input) input.value = '';
      save();
      showToast(`Saved as ${journalNumber} — send it from the Journal Register when ready`);
      renderWorkspace();
    };

    if (byId('journalSubmit')) byId('journalSubmit').onclick = () => {
      if (!hasPermission(kind)) return showToast('No access to post');
      if (isBusinessDateClosed(businessDate())) return showToast(businessDateClosedMessage(businessDate()));
      // SURGICAL PATCH 2026-09-22 (client-confirmed design): Journal Value is
      // typed out by the staff on the form — disconnected from the teller's
      // operational balance. It's read from the input here, not derived.
      const journalFormAmount = Number(String(byId('journalFormAmount')?.value ?? telleringDraft.journalFormAmount ?? '').replace(/,/g, '')) || 0;
      if (!(journalFormAmount > 0)) return showToast('Enter the Journal Value before submitting');
      const alreadySubmitted = (state.approvals || []).some(r =>
        r.type === (kind === 'credit' ? 'customer_credit_journal' : 'customer_debit_journal') &&
        r.payload?.staffId === staff.id && r.payload?.date === businessDate() &&
        (r.status === 'pending' || r.status === 'approved')
      );
      if (alreadySubmitted) return showToast(`A ${kind} journal has already been submitted for today. Use direct ${kind} for any additions.`);
      if (!journal.length) return showToast('Generate journal first');
      // Journal must balance: sum of rows must exactly equal the journal form amount
      const rowTotal = journal.reduce((s, r) => s + Number(r.amount || 0), 0);
      if (Math.abs(rowTotal - journalFormAmount) > 0.01) return showToast(`Journal does not balance — row total ${money(rowTotal)} must equal the Journal Value ${money(journalFormAmount)}`);
      const journalFormMode = 'cash';
      const jDate = byId('journalDate')?.value || telleringDraft.journalDate || '';
      const jDateErr = validateJournalDate(jDate);
      if (jDateErr) return showToast(jDateErr);
      const jConfirmed = byId('journalConfirmedBy')?.value.trim() || '';
      const jDesc = byId('journalDescription')?.value.trim() || '';
      journal.forEach(r => { r.details = jDesc; });
      if (kind === 'debit') { const shortfall = journalDebitShortfall(journal); if (shortfall) return showToast(shortfall); }
      if (attachmentState.loading) return showToast('Please wait for the field note to finish loading');
      if (byId('journalSubmit')?.dataset?.submitting === '1') return;
      confirmAction(`Submit ${kind} journal for approval?`, async () => {
        const submitBtn = byId('journalSubmit');
        if (submitBtn) { submitBtn.dataset.submitting = '1'; submitBtn.disabled = true; }
        showProcessing('Sending journal...');
        await nextPaint();
        try {
          const resumingId = state.ui.resumingJournalId;
          const existing = resumingId ? (state.journals || []).find(j => j.id === resumingId) : null;
          let journalNumber = existing ? existing.journalNumber : '';
          if (!existing) {
            const reserved = await reserveJournalNumber();
            if (!reserved.ok) return showToast(reserved.message);
            journalNumber = reserved.number;
          }
          const fieldNoteSnapshot = attachmentState.fieldNote ? { name: attachmentState.fieldNote.name, type: attachmentState.fieldNote.type, size: attachmentState.fieldNote.size, dataUrl: attachmentState.fieldNote.dataUrl, uploadedAt: attachmentState.fieldNote.uploadedAt } : null;
          const rowsSnapshot = journal.map(row => ({ ...row }));
          const result = await submitJournalRows(kind, staff.id, staff.name, journalFormAmount, journalFormMode, rowsSnapshot, fieldNoteSnapshot, journalNumber, undefined, { journalDate: jDate, confirmedBy: jConfirmed, description: jDesc, counterparty: byId('journalCounterparty')?.value.trim() || '' });
          if (!result?.ok) return showToast(result?.error?.message || 'Unable to submit journal');
          // Every submitted journal is stored and referenceable — see
          // renderJournalRegister(). Status is computed live from
          // state.approvals (journalEffectiveStatus), so this 'sent' value
          // is just the initial state right after a successful submit.
          if (existing) {
            existing.date = businessDate();
            existing.journalDate = jDate;
            existing.confirmedBy = jConfirmed;
            existing.description = byId('journalDescription')?.value.trim() || existing.description || '';
            existing.formAmount = journalFormAmount;
            existing.formPaymentMode = journalFormMode;
            existing.rows = rowsSnapshot;
            existing.fieldNote = fieldNoteSnapshot;
            existing.status = 'sent';
          } else {
            state.journals.push({
              id: uid('jn'), journalNumber, kind, date: businessDate(),
              staffId: staff.id, staffName: staff.name,
              counterparty: byId('journalCounterparty')?.value.trim() || '',
              description: byId('journalDescription')?.value.trim() || '',
              journalDate: jDate, confirmedBy: jConfirmed,
              formAmount: journalFormAmount, formPaymentMode: journalFormMode,
              rows: rowsSnapshot, fieldNote: fieldNoteSnapshot,
              status: 'sent', createdAt: new Date().toISOString()
            });
          }
          await persistJournal(existing || state.journals[state.journals.length - 1]);
          state.ui.resumingJournalId = '';
          journal.splice(0);
          attachmentState.fieldNote = null;
          attachmentState.loading = false;
          state.ui.generatedJournals[visibilityKey] = false;
          state.ui.journalCounterpartyDraft = '';
          telleringDraft.journalFormAmount = '';
          telleringDraft.journalFormMode = 'cash';
          telleringDraft.journalDescription = '';
      telleringDraft.journalConfirmedBy = '';
      telleringDraft.journalDate = '';
          const input = byId('journalFieldNoteInput');
          if (input) input.value = '';
          save();
          showToast(`${kind === 'credit' ? 'Credit' : 'Debit'} journal sent for approval — ${journalNumber}`);
          renderWorkspace();
        } finally {
          hideProcessing();
          const submitBtn = byId('journalSubmit');
          if (submitBtn) { delete submitBtn.dataset.submitting; submitBtn.disabled = false; }
        }
      });
    };

    restoreSingleCustomerDisplay();
    updateSingleCommissionPreview();
    updateJournalCommissionPreview();
    recalcPreview();
  }

  function bindApprovals() {
    cleanupApprovalReviewLocks();
    state.ui.selectedApprovalIds ||= [];
    const refreshApprovalSelection = () => {
      state.ui.selectedApprovalIds = state.ui.selectedApprovalIds.filter(id => (state.approvals || []).some(a => a.id === id && a.status === 'pending') && !isApprovalLockedByOther(id));
      save();
    };
    refreshApprovalSelection();
    qq('[data-approval-select]').forEach(box => box.onchange = async () => {
      const id = box.dataset.approvalSelect;
      if (box.checked) {
        box.disabled = true;
        const lockResult = await setApprovalReviewLock(id);
        if (lockResult?.ok === false || isApprovalLockedByOther(id)) {
          box.checked = false;
          state.ui.selectedApprovalIds = state.ui.selectedApprovalIds.filter(x => x !== id);
        } else if (!state.ui.selectedApprovalIds.includes(id)) {
          state.ui.selectedApprovalIds.push(id);
        }
        box.disabled = false;
      } else {
        state.ui.selectedApprovalIds = state.ui.selectedApprovalIds.filter(x => x !== id);
      }
      save();
      renderWorkspace();
    });
    const visibleSelectable = () => qq('[data-approval-select]').filter(box => !box.disabled).map(box => box.dataset.approvalSelect);
    const selectAll = byId('approvalSelectAll');
    if (selectAll) selectAll.onclick = async () => {
      const ids = visibleSelectable();
      for (const id of ids) {
        if (isApprovalLockedByOther(id)) continue;
        const lockResult = await setApprovalReviewLock(id);
        if (lockResult?.ok !== false && !isApprovalLockedByOther(id) && !state.ui.selectedApprovalIds.includes(id)) {
          state.ui.selectedApprovalIds.push(id);
        }
      }
      save();
      renderWorkspace();
    };
    const clearSel = byId('approvalClearSelection');
    if (clearSel) clearSel.onclick = () => { state.ui.selectedApprovalIds = []; save(); renderWorkspace(); };
    const runBulk = (mode) => {
      if (!hasPermission('approval_queue')) return showToast('No approval rights');
      const ids = (state.ui.selectedApprovalIds || []).filter(id => !isApprovalLockedByOther(id) && !isApprovalRoutedAway((state.approvals || []).find(a => a.id === id)));
      if (!ids.length) return showToast('Select pending requests first');
      confirmAction(`${mode === 'approve' ? 'Approve' : 'Reject'} ${ids.length} selected request${ids.length === 1 ? '' : 's'}?`, async () => {
        showProcessing(mode === 'approve' ? 'Approving selected requests...' : 'Rejecting selected requests...');
        await nextPaint();
        try {
          for (const id of ids) {
            const result = mode === 'approve' ? await approveRequestRemote(id) : await rejectRequestRemote(id);
            if (result?.ok === false) showToast(result?.error?.message || `Unable to ${mode} one selected request`);
          }
          state.ui.selectedApprovalIds = [];
          save();
          renderWorkspace();
        } finally {
          hideProcessing();
        }
      });
    };
    const bulkApprove = byId('approvalBulkApprove');
    if (bulkApprove) bulkApprove.onclick = () => runBulk('approve');
    const bulkReject = byId('approvalBulkReject');
    if (bulkReject) bulkReject.onclick = () => runBulk('reject');
    const isRoutedAway = (req) => isApprovalRoutedAway(req);
    qq('[data-approve]').forEach(btn => btn.onclick = () => {
      if (!hasPermission('approval_queue')) return showToast('No approval rights');
      const reqId = btn.dataset.approve;
      if (isApprovalLockedByOther(reqId)) return showToast('This request is being reviewed by another staff');
      const req = state.approvals.find(r => r.id === reqId);
      if (isRoutedAway(req)) return showToast(`This request was sent to ${req?.payload?.assignedApproverName || 'another approving officer'} — only they or an Admin can approve it`);
      if (req && req.type === 'account_opening' && (req.payload?.accountType || 'customer') === 'customer') {
        // SURGICAL PATCH 2026-08-14: account number is now assigned by
        // Customer Service at Account Opening, not typed in by the approver
        // here — check the stored payload value directly instead of reading
        // a DOM input that no longer exists (which would otherwise block
        // every customer approval, correctly-assigned or not).
        if (!String(req.payload?.generatedAccountNumber || '').trim()) {
          return showToast('No account number assigned. Return this request to Customer Service.');
        }
      }
      confirmAction('Approve this request?', async () => {
        showProcessing('Approving request...');
        await nextPaint();
        try {
          const result = await approveRequestRemote(reqId);
          if (result?.ok === false) showToast(result?.error?.message || 'Unable to approve request');
        } finally {
          hideProcessing();
        }
      });
    });
    qq('[data-reject]').forEach(btn => btn.onclick = () => {
      if (!hasPermission('approval_queue')) return showToast('No approval rights');
      if (isApprovalLockedByOther(btn.dataset.reject)) return showToast('This request is being reviewed by another staff');
      const rejectReq = state.approvals.find(r => r.id === btn.dataset.reject);
      if (isRoutedAway(rejectReq)) return showToast(`This request was sent to ${rejectReq?.payload?.assignedApproverName || 'another approving officer'} — only they or an Admin can act on it`);
      confirmAction('Reject this request?', async () => {
        showProcessing('Rejecting request...');
        await nextPaint();
        try {
          const result = await rejectRequestRemote(btn.dataset.reject);
          if (result?.ok === false) showToast(result?.error?.message || 'Unable to reject request');
        } finally {
          hideProcessing();
        }
      });
    });
    qq('[data-cod-resolve]').forEach(btn => btn.onclick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      const codId = btn.dataset.codResolve || btn.getAttribute('data-cod-resolve') || '';
      openCODResolutionModal(codId);
    });
    const more = byId('approvalsMore');
    if (more) more.onclick = () => { state.ui.approvalsLimit = (state.ui.approvalsLimit || 20) + 20; save(); renderWorkspace(); };
    const less = byId('approvalsLess');
    if (less) less.onclick = () => { state.ui.approvalsLimit = Math.max(20, (state.ui.approvalsLimit || 20) - 20); save(); renderWorkspace(); };
    const historyMore = byId('approvalHistoryMore');
    if (historyMore) historyMore.onclick = () => { state.ui.approvalHistoryLimit = (state.ui.approvalHistoryLimit || 30) + 30; save(); renderWorkspace(); };
    const historyLess = byId('approvalHistoryLess');
    if (historyLess) historyLess.onclick = () => { state.ui.approvalHistoryLimit = Math.max(30, (state.ui.approvalHistoryLimit || 30) - 30); save(); renderWorkspace(); };
    const codDate = byId('codAdminDate');
    if (codDate) codDate.onchange = () => { state.ui.codAdminDate = codDate.value || businessDate(); save(); renderWorkspace(); };
    const codResolutionMore = byId('codResolutionMore');
    if (codResolutionMore) codResolutionMore.onclick = () => { state.ui.codResolutionLimit = (state.ui.codResolutionLimit||10)+10; save(); renderWorkspace(); };
    const codResolutionLess = byId('codResolutionLess');
    if (codResolutionLess) codResolutionLess.onclick = () => { state.ui.codResolutionLimit = Math.max(10,(state.ui.codResolutionLimit||10)-10); save(); renderWorkspace(); };
    const approvalsCentralCloseDayBtn = byId('approvalsCentralCloseDayBtn');
    if (approvalsCentralCloseDayBtn) approvalsCentralCloseDayBtn.onclick = () => openCODModal();
    qq('[data-approval-section]').forEach(btn => btn.onclick = ()=>{ state.ui.approvalsSection = btn.dataset.approvalSection; save(); renderWorkspace(); smoothScrollToOpenedSegment('#approvalsSectionTabs'); });
    const assignTopup = byId('assignFloatTopupFromApprovals');
    if (assignTopup) assignTopup.onclick = () => openFloatTopUpModal();
    qq('[data-inspect-journal]').forEach(btn => {
      btn.style.pointerEvents = 'auto';
      btn.style.position = 'relative';
      btn.style.zIndex = '10';
      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        setApprovalReviewLock(this.dataset.inspectJournal); renderWorkspace(); openRequestDetailModal(this.dataset.inspectJournal);
      }, true);
    });
    qq('[data-inspect-request]').forEach(btn => btn.onclick = ()=> { setApprovalReviewLock(btn.dataset.inspectRequest); renderWorkspace(); openRequestDetailModal(btn.dataset.inspectRequest); });
  }

  function bindPermissions() {
    byId('grantSubmit').onclick = () => {
      createRequest('temp_grant', {
        staffId: byId('grantStaff').value,
        tool: byId('grantTool').value,
        enabled: byId('grantEnabled').value === 'true'
      });
      showToast('Temporary grant request sent for approval');
      render();
    };
  }

  function nextOperationalNumber(category) {
    // SURGICAL PATCH 2026-08-21: simplified per client request — plain
    // single-letter-prefix + sequential number (I1, I2... / E1, E2...)
    // instead of the old INC-2000/EXP-3000 style. Still client-generated
    // (not a DB sequence, unlike Teller/Staff Salary) since this was
    // already just a local array-length counter.
    const list = category === 'income' ? state.operations.incomeAccounts : state.operations.expenseAccounts;
    const prefix = category === 'income' ? 'I' : 'E';
    return `${prefix}${list.length + 1}`;
  }

  function bindOperationalAccounts() {
    const updatePreview = () => {
      const cat = byId('oaCategory').value;
      byId('oaNumberPreview').textContent = nextOperationalNumber(cat);
    };
    if (byId('oaCategory')) { updatePreview(); byId('oaCategory').onchange = updatePreview; }
    if (byId('oaCreate')) byId('oaCreate').onclick = async () => {
      if (!staffHasRole(currentStaff(), 'admin_officer')) return showToast('Only admin can create operational accounts');
      const category = byId('oaCategory').value;
      const name = byId('oaName').value.trim();
      if (!name) return showToast('Enter account name');
      showProcessing('Submitting operational account...');
      await nextPaint();
      try {
        const result = await submitApprovalThroughGateway('create_operational_account', { category, name, accountNumber: nextOperationalNumber(category) });
        if (result?.ok === false) return showToast(result?.error?.message || 'Unable to submit operational account');
        showToast('Operational account request sent');
        render();
      } finally {
        hideProcessing();
      }
    };
    const syncKind = () => {
      const id = byId('oeAccount').value;
      const income = state.operations.incomeAccounts.find(a=>a.id===id);
      byId('oeKindDisplay').textContent = income ? 'Income' : 'Expense';
    };
    syncKind();
    byId('oeAccount').onchange = syncKind;
    byId('oeSubmit').onclick = async () => {
      const accountId = byId('oeAccount').value;
      const amount = Number(byId('oeAmount').value || 0);
      const date = byId('oeDate').value || today();
      const note = byId('oeNote').value.trim();
      if (isBusinessDateClosed(date)) return showToast(businessDateClosedMessage(date));
      if (!(amount > 0)) return showToast('Enter amount');
      const account = [...state.operations.incomeAccounts, ...state.operations.expenseAccounts].find(a=>a.id===accountId);
      if (!account) return showToast('Select account');
      const kind = state.operations.incomeAccounts.some(a=>a.id===accountId) ? 'income' : 'expense';
      showProcessing('Submitting operational posting...');
      await nextPaint();
      try {
        const result = await submitApprovalThroughGateway('operational_entry', { accountId, accountName: account.name, kind, amount, note, date });
        if (result?.ok === false) return showToast(result?.error?.message || 'Unable to submit operational posting');
        showToast('Operational posting sent for approval');
        render();
      } finally {
        hideProcessing();
      }
    };
  }

  function openCashReceiptModal() {
    const st = currentStaff();
    if (!hasPermission('cash_receipt')) return showToast('No access to cash receipt');
    // 2026-10-24 (client): cash received goes into a business Treasury
    // account (not linked to any staff member). With one Treasury account it
    // is used automatically; with several, the officer picks one.
    const treasuryAccounts = (state.customers || []).filter(c => c.accountType === 'treasury' && c.active !== false && !c.closed);
    // SURGICAL UPDATE 2026-09-09 (client-confirmed design): "Received From"
    // is required, not optional — "if you receive cash you have to know
    // the source." SURGICAL REMOVAL 2026-09-14 (client-confirmed design):
    // the "Collector" role/source-type is retired entirely — Teller,
    // Admin (pick a specific staff member from that role), or Customer
    // (looked up by account number) now cover every case.
    // Role/staff separation: someone reassigned away from Teller/Admin can
    // still hand over cash they were accountable for, so the pickers include
    // anyone who has held the role (still tied to the same staff id).
    const tellerStaff = (state.staff || []).filter(s => staffEverHeldRole(s.id, ['teller']));
    const adminStaff = (state.staff || []).filter(s => staffEverHeldRole(s.id, ['admin_officer']));
    let selectedStaffId = '';
    let selectedCustomer = null; // {id, name, accountNumber}
    openModal('Cash Receipt', `
      <div class="form-grid two compact-modal-grid">
        <div class="field"><label>Treasury Account</label>${treasuryAccounts.length > 1
          ? `<select id="cashReceiptTreasury" class="entry-input"><option value="">— Select —</option>${treasuryAccounts.map(c => `<option value="${c.id}">${escapeHtml(`${c.accountNumber || ''} ${c.name || ''}`.trim())}</option>`).join('')}</select>`
          : `<div class="display-field">${escapeHtml(treasuryAccounts[0] ? `${treasuryAccounts[0].accountNumber || ''} ${treasuryAccounts[0].name || ''}`.trim() : '—')}</div>`}</div>
        <div class="field"><label>Amount Received</label><input id="cashReceiptAmount" class="entry-input" type="number"></div>
      </div>
      <div class="form-grid two compact-modal-grid" style="margin-top:8px">
        <div class="field"><label>Note (optional)</label><input id="cashReceiptNote" class="entry-input" type="text"></div>
      </div>
      <div class="form-grid one compact-modal-grid" style="margin-top:8px">
        <div class="field"><label>Received From (required)</label>
          <select id="cashReceiptSourceType" class="entry-input">
            <option value="">— Select source —</option>
            <option value="teller">Teller</option>
            <option value="admin">Admin</option>
            <option value="customer">Customer</option>
          </select>
        </div>
      </div>
      <div id="cashReceiptStaffWrap" class="form-grid one compact-modal-grid" style="margin-top:8px; display:none">
        <div class="field"><label id="cashReceiptStaffLabel">Select</label>
          <select id="cashReceiptStaffPicker" class="entry-input"><option value="">— Select —</option></select>
        </div>
      </div>
      <div id="cashReceiptCustomerWrap" class="form-grid two compact-modal-grid" style="margin-top:8px; display:none">
        <div class="field"><label>Customer Account Number</label><input id="cashReceiptCustomerAcct" class="entry-input"></div>
        <div class="field"><label>&nbsp;</label><div id="cashReceiptCustomerInfo" class="cs2-note-box" style="min-height:24px"></div></div>
      </div>
      ${treasuryAccounts.length ? '' : '<div class="note warning-note">No Treasury account yet — open one in Account Opening.</div>'}
    `, [
      { label: 'Cancel', className: 'secondary', onClick: closeModal },
      {
        label: 'Submit for Approval',
        onClick: async () => {
          const amount = Number(byId('cashReceiptAmount')?.value || 0);
          if (!(amount > 0)) return showToast('Enter a valid amount');
          const treasury = treasuryAccounts.length > 1 ? treasuryAccounts.find(c => c.id === byId('cashReceiptTreasury')?.value) : treasuryAccounts[0];
          if (!treasury) return showToast(treasuryAccounts.length ? 'Select the Treasury account' : 'No Treasury account yet — open one in Account Opening');
          if (isBusinessDateClosed(businessDate())) return showToast(businessDateClosedMessage(businessDate()));
          const sourceType = byId('cashReceiptSourceType')?.value || '';
          if (!sourceType) return showToast('Select where this cash was received from');
          let receivedFromId = '', receivedFromName = '', receivedFromRole = '';
          if (sourceType === 'customer') {
            if (!selectedCustomer) return showToast('Look up the customer account first');
            receivedFromId = selectedCustomer.id;
            receivedFromName = selectedCustomer.name || '';
            receivedFromRole = 'customer';
          } else {
            if (!selectedStaffId) return showToast(`Select which ${sourceType} handed over this cash`);
            const staffMember = (state.staff || []).find(s => s.id === selectedStaffId);
            if (!staffMember) return showToast('Selected staff not found');
            receivedFromId = staffMember.id;
            receivedFromName = staffMember.name || '';
            // Recorded against the role they were acting in (the picked source type).
            receivedFromRole = sourceType === 'teller' ? 'teller' : 'admin_officer';
          }
          const paymentMode = q('input[name="cashReceiptMode"]:checked')?.value || 'cash';
          const note = byId('cashReceiptNote')?.value?.trim() || '';
          closeModal();
          showProcessing('Sending cash receipt for approval...');
          await nextPaint();
          try {
            const result = await submitApprovalThroughGateway('cash_receipt', {
              staffId: st.id,
              staffName: st.name,
              treasuryAccountId: treasury.id,
              treasuryAccountNumber: treasury.accountNumber || treasury.account_number || '',
              treasuryAccountName: treasury.name || '',
              amount,
              paymentMode,
              date: businessDate(),
              note,
              receivedFromType: sourceType,
              receivedFromId,
              receivedFromName,
              receivedFromRole
            });
            if (result?.ok === false) return showToast(result?.error?.message || 'Unable to submit cash receipt');
            render();
            showToast('Cash receipt sent for approval');
          } finally { hideProcessing(); }
        }
      }
    ]);
    const sourceTypeSelect = byId('cashReceiptSourceType');
    const staffWrap = byId('cashReceiptStaffWrap');
    const staffLabel = byId('cashReceiptStaffLabel');
    const staffPicker = byId('cashReceiptStaffPicker');
    const customerWrap = byId('cashReceiptCustomerWrap');
    const customerAcctInput = byId('cashReceiptCustomerAcct');
    const customerInfo = byId('cashReceiptCustomerInfo');
    const populateStaffPicker = (list, label) => {
      if (staffLabel) staffLabel.textContent = label;
      if (staffPicker) staffPicker.innerHTML = `<option value="">— Select ${label} —</option>` + list.map(s => `<option value="${s.id}">${escapeHtml(s.name || '')}</option>`).join('');
      selectedStaffId = '';
    };
    if (sourceTypeSelect) sourceTypeSelect.onchange = () => {
      const v = sourceTypeSelect.value;
      selectedStaffId = ''; selectedCustomer = null;
      if (staffWrap) staffWrap.style.display = 'none';
      if (customerWrap) customerWrap.style.display = 'none';
      if (v === 'teller') { populateStaffPicker(tellerStaff, 'Teller'); if (staffWrap) staffWrap.style.display = ''; }
      else if (v === 'admin') { populateStaffPicker(adminStaff, 'Admin'); if (staffWrap) staffWrap.style.display = ''; }
      else if (v === 'customer') {
        if (customerWrap) customerWrap.style.display = '';
        if (customerAcctInput) customerAcctInput.value = '';
        if (customerInfo) customerInfo.innerHTML = '';
      }
    };
    if (staffPicker) staffPicker.onchange = () => { selectedStaffId = staffPicker.value || ''; };
    if (customerAcctInput) {
      const lookupCustomer = () => {
        const v = customerAcctInput.value.trim();
        const match = (state.customers || []).find(c => c.accountNumber === v || c.account_number === v);
        if (match) {
          selectedCustomer = match;
          if (customerInfo) customerInfo.innerHTML = `<strong>${escapeHtml(match.name || '')}</strong>`;
        } else {
          selectedCustomer = null;
          if (customerInfo) customerInfo.innerHTML = v ? `<span style="color:var(--accent-red)">Account not found</span>` : '';
        }
      };
      customerAcctInput.oninput = () => { selectedCustomer = null; if (customerInfo) customerInfo.innerHTML = ''; };
      customerAcctInput.onkeyup = (e) => { if (e.key === 'Enter') lookupCustomer(); };
    }
  }


  function renderStaffCredit() {
    // SURGICAL REWRITE 2026-09-06 (client-confirmed design):
    // - Funding a TELLER must ALWAYS be a real debit against the acting
    //   Treasury officer's own operational balance — no more picking an
    //   arbitrary account or an unlimited "Treasury" injection here. If the
    //   money originally came from somewhere else, Treasury pulls it into
    //   their own account first (the second case below), then disburses
    //   from their own real balance — that's two separate, real postings,
    //   each fully attributed to whoever actually did it.
    // - Funding TREASURY's OWN account can come from Admin (unlimited
    //   injection — real cash entering the business) or from debiting any
    //   other account (customers or other staff).
    // SURGICAL REMOVAL 2026-09-14 (client-confirmed design): the
    // "Received From" (Collector) dropdown that used to live here is gone —
    // the "Collector" role is retired entirely, and "Received From"
    // attribution now lives solely on Cash Receipt (Teller/Admin/Customer).
    const staffOpAccounts = (state.customers || []).filter(c => c.accountType === 'staff_operational');
    const accountOptions = staffOpAccounts.map(a =>
      `<option value="${a.id}">${escapeHtml(a.name || a.displayName || a.display_name || '')} (${escapeHtml(a.accountNumber || a.account_number || '')})</option>`
    ).join('');
    const draft = state.ui.staffCreditDraft ||= {};
    const targetAccount = staffOpAccounts.find(a => a.id === draft.accountId);
    const targetStaff = targetAccount ? (state.staff || []).find(s => s.id === targetAccount.linkedStaffId) : null;
    const targetIsTeller = staffHasRole(targetStaff, 'teller');
    const targetIsTreasury = staffHasRole(targetStaff, 'cash_officer');
    const actingStaff = currentStaff();
    const myOpAccount = (state.customers || []).find(c => c.accountType === 'staff_operational' && c.linkedStaffId === actingStaff?.id);
    const myBalance = myOpAccount ? getStaffOperationalBalance(actingStaff.id) : 0;
    const fundingSource = draft.source === 'account' ? 'account' : 'admin_injection';
    return `
      <div class="form-card cs2-card opening-card">
        <div class="cs2-title">Fund Account</div>
        ${tellerBannerHtml()}
        <div class="cs2-stack">
          <div class="cs2-row">
            <div class="cs2-label">Staff Account</div>
            <div class="cs2-input-wrap cs2-wide">
              <select id="staffCreditAccount" class="entry-input cs2-input">
                <option value="">— Select Account —</option>
                ${accountOptions}
              </select>
            </div>
          </div>
          ${!targetAccount ? `<div class="note">Select a Teller or Treasury account to see how it can be funded.</div>` : ''}
          ${targetIsTeller ? `
          <div class="note">Funding a Teller always comes from <strong>your own</strong> Treasury balance — a real debit against your account, credited to theirs.</div>
          <div class="cs2-row">
            <div class="cs2-label">My Treasury Balance</div>
            <div class="cs2-input-wrap"><div class="display-field">${myOpAccount ? balanceHtml(myBalance) : '<span style="color:var(--accent-red)">You have no Treasury account — ask Admin to open one</span>'}</div></div>
          </div>
          ` : ''}
          ${targetIsTreasury ? `
          <div class="cs2-row">
            <div class="cs2-label">Funding Source</div>
            <div class="tx-mode-toggle">
              <label class="tx-toggle-pill"><input type="radio" name="staffCreditSource" value="admin_injection" ${fundingSource === 'admin_injection' ? 'checked' : ''}> <span>Admin Injection</span></label>
              <label class="tx-toggle-pill"><input type="radio" name="staffCreditSource" value="account" ${fundingSource === 'account' ? 'checked' : ''}> <span>Debit an Account</span></label>
            </div>
          </div>
          ${fundingSource === 'account' ? `
          <div class="cs2-row">
            <div class="cs2-label">Source Account</div>
            <div class="cs2-input-wrap cs2-wide"><input id="staffCreditSourceAcc" class="entry-input cs2-input" value="${escapeHtml(String(draft.sourceAcct || ''))}" autocomplete="off"></div>
            <button id="staffCreditSourceSearch" class="sheet-btn secondary tiny-btn">Search</button>
          </div>
          <div id="staffCreditSourceInfo" class="cs2-note-box" style="min-height:24px">${draft.sourceId ? `<strong>${escapeHtml(draft.sourceName || '')}</strong> <span class="journal-cell-label">Balance: </span>${balanceHtml(draft.sourceBalance || 0)}` : ''}</div>
          ` : ''}
          ` : ''}
          <div class="cs2-row">
            <div class="cs2-label">Amount</div>
            <div class="cs2-input-wrap cs2-medium"><input id="staffCreditAmount" class="entry-input cs2-input" type="number" value="${escapeHtml(String(draft.amount || ''))}"></div>
          </div>
          <div class="cs2-row">
            <div class="cs2-label">Note</div>
            <div class="cs2-input-wrap cs2-wide"><input id="staffCreditNote" class="entry-input cs2-input" value="${escapeHtml(String(draft.note || ''))}"></div>
          </div>
          <div class="cs2-button-row">
            <button id="submitStaffCredit" class="sheet-btn cs2-btn cs2-btn-solid" ${!targetAccount ? 'disabled' : ''}>Submit for Approval</button>
          </div>
        </div>
      </div>`;
  }



  function openCODModal() {
    reconcileBusinessDateFromClosures();
    if (!canCloseBusinessDay()) return showToast('Only Approval Officer or Admin can close day');
    if (isBusinessDateClosed(businessDate())) return showToast(`Business date ${businessDate()} is already closed`);
    const postingStaff = state.staff.filter(st => hasPermission('credit', st) || hasPermission('debit', st));
    const rows = postingStaff.map(st => {
      const opBalance = getStaffOperationalBalance(st.id);
      const creditCash = approvedCreditTotalForDateByMode(st.id, businessDate(), 'cash');
      const creditTransfer = approvedCreditTotalForDateByMode(st.id, businessDate(), 'transfer');
      const debitCash = approvedDebitTotalForDateByMode(st.id, businessDate(), 'cash');
      const debitTransfer = approvedDebitTotalForDateByMode(st.id, businessDate(), 'transfer');
      const credits = creditCash + creditTransfer;
      const debits = debitCash + debitTransfer;
      const netBook = credits - debits;
      const remaining = opBalance;
      const variance = Math.max(0, -remaining);
      return `<tr><td>${escapeHtml(st.name || '')}</td><td>${money(opBalance)}</td><td>${money(credits)}</td><td>${money(debits)}</td><td class="${netBook<0?'balance-negative':''}">${money(netBook)}</td><td class="${remaining<0?'balance-negative':''}">${money(remaining)}</td><td class="${variance>0?'balance-negative':''}">${money(variance)}</td><td><input class="entry-input" data-cod-note="${st.id}"></td></tr>`;
    }).join('');
    openModal('Central Close of Day', `<div class="stack"><div class="note">You are closing business date <strong>${businessDate()}</strong>. Closing opens the next business date immediately.</div><div class="note">Operational Balance is the total funded by Treasury. Remaining Balance reduces as staff disburse funds. Net Balance is Total Credits minus Total Debits.</div><div class="table-wrap"><table class="table"><thead><tr><th>Staff</th><th>Op. Balance</th><th>Total Credits</th><th>Total Debits</th><th>Net Balance</th><th>Remaining</th><th>Variance</th><th>Note</th></tr></thead><tbody>${rows}</tbody></table></div></div></div>`, [{label:'Cancel', className:'secondary', onClick: closeModal}, {label:'Close Business Day', onClick: async ()=> {
      closeModal();
      showProcessing('Closing business day...');
      await nextPaint();
      try {
      if (isSupabaseApprovalMode() && gateway.cod?.submitCod) {
        for (const st of postingStaff) {
          const opBalance = getStaffOperationalBalance(st.id);
          const creditCash = approvedCreditTotalForDateByMode(st.id, businessDate(), 'cash');
          const creditTransfer = approvedCreditTotalForDateByMode(st.id, businessDate(), 'transfer');
          const debitCash = approvedDebitTotalForDateByMode(st.id, businessDate(), 'cash');
          const debitTransfer = approvedDebitTotalForDateByMode(st.id, businessDate(), 'transfer');
          const credits = creditCash + creditTransfer;
          const debits = debitCash + debitTransfer;
          const netBook = credits - debits;
          const remaining = opBalance;
          const note=q(`[data-cod-note="${st.id}"]`)?.value?.trim()||'';
          const variance=Math.max(0,-remaining);
          const result = await gateway.cod.submitCod({
            staffId: st.id,
            staffUuid: getStaffBackendId(st),
            staffBackendId: getStaffBackendId(st),
            businessDate: businessDate(),
            actualCash: remaining,
            note,
            submittedByStaffId: currentStaff()?.id || st.id,
            submittedByStaffUuid: getStaffBackendId(currentStaff()),
            submittedByStaffBackendId: getStaffBackendId(currentStaff()),
            metrics: {
              openingBalance: opBalance,
              floatTopUps: 0,
              effectiveOpeningBalance: opBalance,
              totalCredits: credits,
              totalDebits: debits,
              netBookBalance: netBook,
              remainingBalance: remaining,
              expectedCash: remaining,
              variance
            }
          });
          if (result?.ok && result.data) {
            const existingIndex = (state.cod || []).findIndex(item => item.id === result.data.id);
            const nextRow = Object.assign({}, result.data, { staffName: st.name, formAmount: opBalance, openingBalance: opBalance, totalCreditCash: creditCash, totalCreditTransfer: creditTransfer, totalDebitCash: debitCash, totalDebitTransfer: debitTransfer, totalCredits: credits, totalDebits: debits, netBookBalance: netBook, actualCash: remaining, expectedCash: remaining, runningFloat: remaining, remainingBalance: remaining, variance, note });
            if (existingIndex >= 0) state.cod.splice(existingIndex, 1, nextRow); else state.cod.unshift(nextRow);
          } else if (result?.ok === false) { showToast(result.error?.message || 'Unable to submit close of day'); return; }
        }
      } else {
        postingStaff.forEach(st => {
          const opBalance = getStaffOperationalBalance(st.id);
          const creditCash = approvedCreditTotalForDateByMode(st.id, businessDate(), 'cash');
          const creditTransfer = approvedCreditTotalForDateByMode(st.id, businessDate(), 'transfer');
          const debitCash = approvedDebitTotalForDateByMode(st.id, businessDate(), 'cash');
          const debitTransfer = approvedDebitTotalForDateByMode(st.id, businessDate(), 'transfer');
          const credits=creditCash+creditTransfer;
          const debits=debitCash+debitTransfer;
          const netBook=credits-debits;
          const remaining=opBalance;
          const note=q(`[data-cod-note="${st.id}"]`)?.value?.trim()||'';
          const variance=Math.max(0,-remaining);
          state.cod.unshift({id:uid('cod'), staffId:st.id, staffName:st.name, date:businessDate(), formAmount:opBalance, openingBalance:opBalance, totalCreditCash:creditCash, totalCreditTransfer:creditTransfer, totalDebitCash:debitCash, totalDebitTransfer:debitTransfer, totalCredits:credits, totalDebits:debits, netBookBalance:netBook, actualCash:remaining, expectedCash:0, runningFloat:remaining, remainingBalance:remaining, variance, note, fieldPapers:[], status: variance===0 ? 'balanced':'flagged', approvedAt:new Date().toISOString(), approvedBy:currentStaff()?.name||''});
        });
      }
      const closingDate = businessDate();
      if (!finalizeBusinessDay(closingDate, postingStaff)) {
        showToast(`Business date ${closingDate} is already closed`);
        return;
      }
      save(); closeModal(); render(); showToast(`Business day closed. New open date: ${state.businessDate}`);
      } finally {
        hideProcessing();
      }
    }}]);
  }

  async function openAuditModal() {
    await syncStaffFromGateway();
    await syncAuditFromGateway();
    const st = currentStaff();
    const adminView = isAdminStaff(st);
    const audits = state.audit || [];
    const staffList = (state.staff || []).slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||'')));
    const getAuditActorStaff = (a) => {
      const actorId = a.actorId || a.actor_id || a.actorStaffId || a.actor_staff_id || '';
      const actorUuid = a.actorUuid || a.actor_uuid || a.actorUserId || a.actor_user_id || '';
      const actorName = String(a.actor || a.actorName || a.actor_name || '').trim().toLowerCase();
      return staffList.find(x => String(x.id || '') === String(actorId || ''))
        || staffList.find(x => String(x.uuid || x.authUserId || x.auth_user_id || '') && String(x.uuid || x.authUserId || x.auth_user_id || '') === String(actorUuid || ''))
        || staffList.find(x => String(x.name || '').trim().toLowerCase() === actorName)
        || null;
    };
    const isOwnAudit = (a) => {
      const actorStaff = getAuditActorStaff(a);
      return actorStaff?.id === st?.id
        || actorStaff?.uuid === st?.uuid
        || a.actorId === st?.id
        || a.actor_id === st?.id
        || a.actorUuid === st?.uuid
        || a.actor_uuid === st?.uuid
        || String(a.actor || '').trim() === String(st?.name || '').trim();
    };
    const baseAudit = adminView ? audits.slice() : audits.filter(isOwnAudit);
    const uniqueActions = Array.from(new Set(baseAudit.map(a => String(a.action || a.actionType || a.action_type || '').trim()).filter(Boolean))).sort();
    const roleOptions = Object.entries(ROLE_LABELS).map(([value,label]) => `<option value="${escapeHtml(value)}">${escapeHtml(label)}</option>`).join('');
    const staffOptions = staffList.map(x => `<option value="${escapeHtml(x.id)}">${escapeHtml(x.name)} — ${escapeHtml(staffRoleLabels(x))}</option>`).join('');
    const actionOptions = uniqueActions.map(x => `<option value="${escapeHtml(x)}">${escapeHtml(x)}</option>`).join('');
    const filterHtml = `<div class="audit-filter-row" style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0 10px;align-items:center;">
      ${adminView ? `<select id="auditRoleFilter" class="entry-input" style="width:auto;min-width:140px;"><option value="">All roles</option>${roleOptions}</select><select id="auditStaffFilter" class="entry-input" style="width:auto;min-width:170px;"><option value="">All staff</option>${staffOptions}</select>` : ''}
      <select id="auditActionFilter" class="entry-input" style="width:auto;min-width:150px;"><option value="">All actions</option>${actionOptions}</select>
      <input id="auditDateFrom" class="entry-input" type="date" lang="en-GB" style="width:auto;min-width:130px;" title="From date" value="">
      <span style="font-size:12px;color:var(--muted)">to</span>
      <input id="auditDateTo" class="entry-input" type="date" lang="en-GB" style="width:auto;min-width:130px;" title="To date" value="">
    </div>`;
    const formatActionType = (a) => {
      const raw = a.action || a.actionType || a.action_type || '';
      return raw.replace(/_/g, ' ').replace(/\w/g, c => c.toUpperCase());
    };
    const formatAuditDetail = (a) => {
      const parts = [];
      if (a.details || a.detail) parts.push(escapeHtml(a.details || a.detail));
      if (a.before != null || a.after != null) {
        const b = a.before != null ? JSON.stringify(a.before) : '—';
        const af = a.after != null ? JSON.stringify(a.after) : '—';
        if (b !== af) parts.push(`<span class="audit-change">Before: ${escapeHtml(b)} → After: ${escapeHtml(af)}</span>`);
      }
      return parts.join('<br>') || '—';
    };
    const actorName = (a) => {
      const actorStaff = getAuditActorStaff(a);
      return escapeHtml(actorStaff?.name || a.actor || a.actorName || a.actor_name || 'System');
    };
    // Role the actor held WHEN they acted (stamped on new entries; resolved
    // from role history for older/server entries).
    const actorRoleAt = (a) => {
      const actorStaff = getAuditActorStaff(a);
      const stamped = a.actorRole || a.actor_role || a.metadata?.actor_role || '';
      if (stamped) return stamped;
      return actorStaff ? getStaffRoleAt(actorStaff.id, a.at || a.timestamp || a.createdAt) : '';
    };
    const rowForAudit = (a) => `<tr><td style="white-space:nowrap">${fmtDateTime(a.at || a.timestamp || a.createdAt)}</td><td>${actorName(a)}${actorRoleAt(a) ? `<div style="font-size:11px;color:var(--text-muted)">${escapeHtml(roleLabelOf(actorRoleAt(a)))}</div>` : ''}</td><td><span class="audit-action-badge">${escapeHtml(formatActionType(a))}</span></td><td style="font-size:12px">${formatAuditDetail(a)}</td></tr>`;
    const scopeNote = adminView ? '<div class="note">Admin Global Audit View: showing all staff actions. Use role/staff filters to narrow the trail.</div>' : '<div class="note">Showing only your own audit trail.</div>';
    openModal('Audit Trail', `${scopeNote}${filterHtml}<div class="table-wrap"><table class="table"><thead><tr><th>Date &amp; Time</th><th>Actor</th><th>Action</th><th>Details</th></tr></thead><tbody id="auditTrailRows"></tbody></table></div>`, [{label:'Close', onClick: closeModal}]);
    const renderAuditRows = () => {
      const roleFilter = byId('auditRoleFilter')?.value || '';
      const staffFilter = byId('auditStaffFilter')?.value || '';
      const actionFilter = byId('auditActionFilter')?.value || '';
      const dateFrom = byId('auditDateFrom')?.value || '';
      const dateTo = byId('auditDateTo')?.value || '';
      const filtered = baseAudit.filter(a => {
        const actorStaff = getAuditActorStaff(a);
        const action = String(a.action || a.actionType || a.action_type || '').trim();
        const isoDate = String(a.at || a.timestamp || a.createdAt || '').slice(0,10);
        if (adminView && roleFilter && actorRoleAt(a) !== roleFilter) return false;
        if (adminView && staffFilter && actorStaff?.id !== staffFilter) return false;
        if (actionFilter && action !== actionFilter) return false;
        if (dateFrom && isoDate < dateFrom) return false;
        if (dateTo && isoDate > dateTo) return false;
        return true;
      });
      const tbody = byId('auditTrailRows');
      if (tbody) tbody.innerHTML = filtered.map(rowForAudit).join('') || '<tr><td colspan="4">No audit records</td></tr>';
    };
    ['auditRoleFilter','auditStaffFilter','auditActionFilter','auditDateFrom','auditDateTo'].forEach(id => {
      const el = byId(id);
      if (el) el.onchange = renderAuditRows;
    });
    // Clear date inputs in case browser auto-filled them
    const dfEl = byId('auditDateFrom'); if (dfEl) dfEl.value = '';
    const dtEl = byId('auditDateTo'); if (dtEl) dtEl.value = '';
    renderAuditRows();
  }

  function staffName(id) { return state.staff.find(s=>s.id===id)?.name || id; }
  function customerName(id) { return state.customers.find(c=>c.id===id)?.name || ''; }
  function getSelectedCustomer() { return state.customers.find(c => c.id === state.ui.selectedCustomerId) || null; }
  function balanceHtml(n){ return `<span class="${Number(n)<0 ? 'balance-negative' : ''}">${money(n)}</span>`; }
  // SURGICAL CHANGE 2026-10-21 (client): an account is Frozen (blocked)
  // when an approved Account Block says so, or automatically after 90 days
  // (3 months) with no activity. Activity = the latest transaction or the
  // latest approved Reactivation (so a reactivation actually sticks until
  // the next 3 months of inactivity). Only customer accounts auto-freeze —
  // staff/income/expense system accounts never do.
  function lastCustomerActivityTime(c) {
    let latest = 0;
    (c.transactions || []).forEach(tx => { const t = new Date(tx.date || tx.createdAt || tx.created_at || 0).getTime(); if (t > latest) latest = t; });
    (state.approvals || []).forEach(a => {
      if (a.type === 'account_reactivation' && a.status === 'approved' && a.payload?.customerId === c.id) {
        const t = new Date(a.approvedAt || a.requestedAt || 0).getTime(); if (t > latest) latest = t;
      }
    });
    if (!latest) latest = new Date(c.createdAt || 0).getTime() || 0;
    return latest;
  }
  function isCustomerFrozen(c){
    if (!c || c.closed) return false;
    if (c.frozen) return true;
    if (String(c.accountType || 'customer') !== 'customer') return false;
    const last = lastCustomerActivityTime(c);
    if (!last) return false;
    return (Date.now() - last) / 86400000 >= 90;
  }
  function customerStatusLabel(c){ if(!c) return '—'; if (c.closed) return 'Closed'; return (!c.active || isCustomerFrozen(c)) ? 'Frozen' : 'Active'; }
  function freezeInactiveCustomer(c){ if(!c) return; if(c.active === false) c.frozen = true; }

  function openCustomerSearchModal(list) {
    const renderRows = arr => arr.map(c=>`<tr class="customer-search-row" data-pick-row="${c.id}"><td>${escapeHtml(c.accountNumber || '')}</td><td><button type="button" class="customer-name-pick" data-pick="${c.id}">${escapeHtml(c.name || '')}</button>${c.closed ? ' <span class="badge rejected">Closed</span>' : ''}</td><td>${escapeHtml(c.phone || '')}</td><td class="customer-search-action-cell"><button type="button" class="secondary tiny-btn customer-pick-btn" data-pick="${c.id}">Select</button></td></tr>`).join('');
    openModal('Customer Search', `<div class="stack customer-search-modal"><input id="modalCustomerSearch" class="entry-input"><div class="table-wrap customer-search-table-wrap"><table class="table customer-search-table"><thead><tr><th>Account Number</th><th>Name</th><th>Phone</th><th class="customer-search-action-head">Action</th></tr></thead><tbody id="modalCustomerRows">${renderRows(list)}</tbody></table></div></div>`, [{label:'Close', className:'secondary', onClick: closeModal}]);
    const pickCustomer = (id) => { state.ui.selectedCustomerId = id; save(); closeModal(); applySelectedCustomerToActiveTool(); };
    const bindPicks = () => {
      qq('[data-pick]').forEach(el => el.onclick = (event) => { event.stopPropagation(); pickCustomer(el.dataset.pick); });
      qq('[data-pick-row]').forEach(row => row.onclick = () => pickCustomer(row.dataset.pickRow));
    };
    bindPicks();
    const search = byId('modalCustomerSearch');
    if (search) search.oninput = () => {
      const qv = search.value.trim().toLowerCase();
      const filtered = !qv ? list : list.filter(c => String(c.accountNumber).includes(qv) || c.name.toLowerCase().includes(qv));
      byId('modalCustomerRows').innerHTML = renderRows(filtered); bindPicks();
    };
  }


  function openJournalCustomerSearchModal(list) {
    const renderRows = arr => arr.map(c=>`<tr class="customer-search-row" data-pick-journal-row="${c.id}"><td>${escapeHtml(c.accountNumber || '')}</td><td><button type="button" class="customer-name-pick" data-pick-journal="${c.id}">${escapeHtml(c.name || '')}</button></td><td>${escapeHtml(c.phone || '')}</td><td class="customer-search-action-cell"><button type="button" class="secondary tiny-btn customer-pick-btn" data-pick-journal="${c.id}">Select</button></td></tr>`).join('');
    openModal('Customer Search', `<div class="stack customer-search-modal"><input id="modalJournalCustomerSearch" class="entry-input"><div class="table-wrap customer-search-table-wrap"><table class="table customer-search-table"><thead><tr><th>Account Number</th><th>Name</th><th>Phone</th><th class="customer-search-action-head">Action</th></tr></thead><tbody id="modalJournalCustomerRows">${renderRows(list)}</tbody></table></div></div>`, [{label:'Close', className:'secondary', onClick: closeModal}]);
    const pickJournalCustomer = (id) => {
      const c = state.customers.find(x => x.id === id);
      if (!c) return showToast('Customer not found');
      state.ui.selectedJournalCustomerId = c.id;
      state.ui.journalAccDraft = c.accountNumber || '';
      closeModal();
      if (byId('journalAcc')) byId('journalAcc').value = c.accountNumber || '';
      if (byId('journalName')) byId('journalName').textContent = c.name || '—';
      updateJournalAccountMeta(c);
    };
    const bindPicks = () => {
      qq('[data-pick-journal]').forEach(el => el.onclick = (event) => { event.stopPropagation(); pickJournalCustomer(el.dataset.pickJournal); });
      qq('[data-pick-journal-row]').forEach(row => row.onclick = () => pickJournalCustomer(row.dataset.pickJournalRow));
    };
    bindPicks();
    const search = byId('modalJournalCustomerSearch');
    if (search) search.oninput = () => {
      const qv = search.value.trim().toLowerCase();
      const filtered = !qv ? list : list.filter(c => String(c.accountNumber).includes(qv) || String(c.name || '').toLowerCase().includes(qv));
      byId('modalJournalCustomerRows').innerHTML = renderRows(filtered); bindPicks();
    };
  }

  async function toBase64(file) {
    if (!file) return '';
    if (!String(file.type || '').startsWith('image/')) return await fileToDataUrl(file);
    const compressed = await compressImageFile(file);
    return compressed.dataUrl;
  }


  function applyTheme(theme, persist=true) {
    state.ui.theme = theme || 'classic';
    document.body.setAttribute('data-theme', state.ui.theme === 'classic' ? '' : state.ui.theme);
    const b = byId('btnThemeCycle'); if (b) b.textContent = `Theme: ${THEME_LABELS[state.ui.theme] || 'Classic'}`;
    if (persist) save();
  }

  function hasFloatDeclaredOrPending(staffId, dateStr) {
  // Only block if actually approved — pending should not block re-declaration
  return hasBaseOpeningBalanceForDate(staffId, dateStr) ||
    state.approvals.some(r =>
      r.type === 'float_declaration' &&
      String(r.status || '').toLowerCase() === 'approved' &&
      (r.payload?.staffId === staffId || r.payload?.staff_id === staffId) &&
      (r.payload?.date === dateStr || r.payload?.float_date === dateStr)
    );
}

function syncApprovedFormFromApprovalRecord(approvalRecord) {
  const payload = approvalRecord?.payload || {};
  const staffId = payload.staffId || payload.staff_id || '';
  const date = payload.date || payload.float_date || businessDate();
  const amount = Number(payload.amount || payload.floatAmount || 0);

  if (!staffId || !(amount > 0)) return;

  const acc = ensureStaffAccount(staffId);
  const exists = (acc.entries || []).some(e =>
    (e.type === 'approved_form' || e.type === 'approved_float') &&
    (e.formDate === date || e.floatDate === date)
  );

  if (exists) return;

  addStaffEntry(
    staffId,
    'approved_form',
    amount,
    amount,
    `Approved form for ${date}`,
    { formDate: date, floatDate: date, approvalRequestId: approvalRecord.id }
  );
}


  function approvedFormTotalForDate(staffId, dateStr) {
    return (state.approvals || [])
      .filter(r => r.type === 'float_declaration'
        && String(r.status || '').toLowerCase() === 'approved'
        && (r.payload?.staffId === staffId || r.payload?.staff_id === staffId)
        && (r.payload?.date === dateStr || r.payload?.float_date === dateStr))
      .reduce((sum, r) => sum + Number(r.payload?.amount || r.payload?.floatAmount || 0), 0);
  }

  function hasBaseOpeningBalanceForDate(staffId, dateStr) {
    const acc = ensureStaffAccount(staffId);
    const localExists = acc.entries.some(e =>
      (e.type === 'approved_form' || e.type === 'approved_float') &&
      (e.formDate === dateStr || e.floatDate === dateStr) &&
      Number(e.amount || 0) > 0
    );
    return localExists || approvedFormTotalForDate(staffId, dateStr) > 0;
  }

  function hasOpeningBalanceForDate(staffId, dateStr) {
    return hasBaseOpeningBalanceForDate(staffId, dateStr);
  }

  function openingBalanceOnlyForDate(staffId, dateStr) {
    const acc = ensureStaffAccount(staffId);
    const localTotal = acc.entries
      .filter(e =>
        (e.type === 'approved_form' || e.type === 'approved_float') &&
        (e.formDate === dateStr || e.floatDate === dateStr)
      )
      .reduce((s, e) => s + Number(e.amount || 0), 0);
    const approvedTotal = approvedFormTotalForDate(staffId, dateStr);
    return Math.max(localTotal, approvedTotal);
  }

  function floatTopUpsForDate() {
    return 0;
  }

  function getOpeningBalanceForDate(staffId, dateStr) {
    return openingBalanceOnlyForDate(staffId, dateStr);
  }


  function normalizePaymentMode(mode) {
    return String(mode || '').trim().toLowerCase() === 'transfer' ? 'transfer' : 'cash';
  }

  // SURGICAL CHANGE 2026-10-01 (client request): the Cash/Transfer payment
  // mode is removed from the app entirely — every posting now counts as
  // cash, including older records that were tagged 'transfer'. So the
  // 'cash' total is the full amount and the 'transfer' total is always 0
  // (kept only so existing callers and stored COD fields stay valid).
  function approvalModeAmount(record, mode) {
    if (!record || record.status !== 'approved') return 0;
    if (normalizePaymentMode(mode) === 'transfer') return 0;
    if (record.type === 'customer_credit_journal' || record.type === 'customer_debit_journal') {
      return Number(record.payload?.formAmount || 0);
    }
    return Number(record.payload?.amount || 0);
  }

  function approvedCreditTotalForDateByMode(staffId, dateStr, mode) {
    return (state.approvals||[])
      .filter(r => ['customer_credit','customer_credit_journal'].includes(r.type) && r.status === 'approved' && r.payload?.staffId === staffId && r.payload?.date === dateStr)
      .reduce((sum, record) => sum + approvalModeAmount(record, mode), 0);
  }

  function approvedDebitTotalForDateByMode(staffId, dateStr, mode) {
    return (state.approvals||[])
      .filter(r => ['customer_debit','customer_debit_journal'].includes(r.type) && r.status === 'approved' && r.payload?.staffId === staffId && r.payload?.date === dateStr)
      .reduce((sum, record) => sum + approvalModeAmount(record, mode), 0);
  }

  function approvedCreditTotalForDate(staffId, dateStr) {
    return (state.approvals||[]).filter(r => ['customer_credit','customer_credit_journal'].includes(r.type) && r.status === 'approved' && r.payload?.staffId === staffId && r.payload?.date === dateStr).reduce((s,r)=> s + (r.type === 'customer_credit_journal' ? Number(r.payload?.formAmount || 0) : Number(r.payload?.amount || 0)), 0);
  }

  function approvedDebitTotalForDate(staffId, dateStr) {
    return (state.approvals||[]).filter(r => ['customer_debit','customer_debit_journal'].includes(r.type) && r.status === 'approved' && r.payload?.staffId === staffId && r.payload?.date === dateStr).reduce((s,r)=> s + (r.type === 'customer_debit_journal' ? Number(r.payload?.formAmount || 0) : Number(r.payload?.amount || 0)), 0);
  }

  function pendingPostedFloatImpactForDate(staffId, dateStr) {
    return (state.approvals||[])
      .filter(r => ['customer_credit','customer_debit','customer_credit_journal','customer_debit_journal'].includes(r.type)
        && r.status === 'pending'
        && r.payload?.staffId === staffId
        && r.payload?.date === dateStr)
      .reduce((s,r)=> s + (r.type.endsWith('_journal') ? Number(r.payload?.formAmount || 0) : Number(r.payload?.amount || 0)), 0);
  }

  function currentFloatAvailable(staffId, date = businessDate()) {
    const form = getOpeningBalanceForDate(staffId, date);
    const usedApproved = approvedCreditTotalForDate(staffId, date);
    const debitsApproved = approvedDebitTotalForDate(staffId, date);
    const pendingPosted = pendingPostedFloatImpactForDate(staffId, date);
    return form - usedApproved - debitsApproved - pendingPosted;
  }

  function currentFloatOverdraw(staffId, date = businessDate()) {
    return Math.max(0, -currentFloatAvailable(staffId, date));
  }

  function pendingJournalTotal(staffId, date=businessDate()) {
    // Sum of the FORM amount on any journal currently being drafted (not yet
    // submitted) for this staff/date — credit and debit drafts both count,
    // since both draw down the same daily FORM once approved.
    const drafts = state.ui?.telleringDrafts || {};
    const creditKey = `${staffId}:${date}:credit`;
    const debitKey = `${staffId}:${date}:debit`;
    const stripCommas = (v) => Number(String(v || '').replace(/,/g, '')) || 0;
    return stripCommas(drafts[creditKey]?.journalFormAmount) + stripCommas(drafts[debitKey]?.journalFormAmount);
  }

  function staffCODRecords(staffId) {
    return (state.cod || []).filter(c => c.staffId === staffId);
  }

  // REMOVED 2026-08-14: openMyBalanceModal() and its "Fund Wallet"/"Pay Debt"
  // buttons — the last live path that could submit new wallet_fund/
  // debt_repayment requests. This screen was already unreachable through
  // normal navigation (no menu ever set state.ui.tool to 'my_balance'), and
  // it belonged to the old design where a teller's wallet/debt were manually
  // funded and repaid. The current design lets a teller run a negative
  // balance until Treasury credits them (inter_staff_credit, already its own
  // report category), and staff-level balances now live on Staff Salary
  // Balance. Historical wallet_fund/debt_repayment records already approved
  // in the past are NOT touched — applyRequest() and the debt/wallet balance
  // calculations they feed are left exactly as they were, so old data keeps
  // rendering correctly. Only the ability to create NEW ones is removed.

  function openMyCODModal(selectedDate=null) {
    const st = currentStaff();
    state.ui.myCodDate = selectedDate || state.ui.myCodDate || businessDate();
    const c = staffCODRecords((st||{}).id).find(x => x.date === state.ui.myCodDate);
    const totalCreditCash = c ? Number(c.totalCreditCash ?? approvedCreditTotalForDateByMode(c.staffId, c.date, 'cash')) : 0;
    const totalCreditTransfer = c ? Number(c.totalCreditTransfer ?? approvedCreditTotalForDateByMode(c.staffId, c.date, 'transfer')) : 0;
    const totalDebitCash = c ? Number(c.totalDebitCash ?? approvedDebitTotalForDateByMode(c.staffId, c.date, 'cash')) : 0;
    const totalDebitTransfer = c ? Number(c.totalDebitTransfer ?? approvedDebitTotalForDateByMode(c.staffId, c.date, 'transfer')) : 0;
    const totalCredits = c ? Number(c.totalCredits ?? (totalCreditCash + totalCreditTransfer)) : 0;
    const totalDebits = c ? Number(c.totalDebits ?? (totalDebitCash + totalDebitTransfer)) : 0;
    const netBook = c ? Number(c.netBookBalance ?? (totalCredits - totalDebits)) : 0;
    const remainingBalance = c ? Number(c.remainingBalance ?? c.runningFloat ?? getStaffOperationalBalance((st||{}).id)) : 0;
    const varianceValue = c ? Number(c.variance ?? Math.max(0, -remainingBalance)) : 0;
    const summary = c ? `
      <div class="kpi-row wrap cod-summary-grid">
        <div class="kpi"><div class="label">Op. Balance</div><div class="number">${money(c.formAmount ?? c.openingBalance ?? getStaffOperationalBalance((st||{}).id))}</div></div>
        <div class="kpi"><div class="label">Total Credits</div><div class="number">${money(totalCredits)}</div></div>
        <div class="kpi"><div class="label">Total Debits</div><div class="number">${money(totalDebits)}</div></div>
        <div class="kpi"><div class="label">Net Balance</div><div class="number ${netBook<0?'balance-negative':''}">${money(netBook)}</div></div>
        <div class="kpi"><div class="label">Remaining Balance</div><div class="number ${remainingBalance<0?'balance-negative':''}">${money(remainingBalance)}</div></div>
        <div class="kpi"><div class="label">Variance</div><div class="number ${varianceValue>0?'balance-negative':''}">${money(varianceValue)}</div></div>
      </div>
      <div class="note">Operational Balance is the total funded by Treasury. Net Balance is Total Credits minus Total Debits. Remaining Balance reflects unaccounted funds.</div>
      <div class="note"><strong>Status:</strong> ${c.status === 'flagged' ? 'Anomaly' : (c.status || 'balanced')} • <strong>Manager Note:</strong> ${c.resolutionNote || c.note || '—'}</div>` : `<div class="note">No close-of-day record for selected date.</div>`;
    openModal('My Close of Day', `<div class="modal-sheet my-close-day-sheet"><div class="stack"><div class="action-inline"><div class="inline-field compact"><span>COD Date</span><input type="date" lang="en-GB" id="myCodDate" value="${state.ui.myCodDate}"></div></div>${summary}</div></div>`, [{label:'Close', className:'secondary', onClick: closeModal}]);
    const picker = byId('myCodDate');
    if (picker) picker.onchange = () => { state.ui.myCodDate = picker.value || businessDate(); save(); openMyCODModal(state.ui.myCodDate); };
  }


  function removeCodBusinessAdjustment(codId) {
    state.businessExtras ||= [];
    state.businessExtras = state.businessExtras.filter(e => !(e.type === 'cod_adjustment' && e.codId === codId));
  }

  function applyCodBusinessAdjustment(cod, adjustment, resolutionType, note) {
    state.businessExtras ||= [];
    removeCodBusinessAdjustment(cod.id);
    if (resolutionType === 'reversal_needed' || !adjustment) return;
    state.businessExtras.unshift({
      id: uid('bizcod'),
      date: cod.date || cod.businessDate || businessDate(),
      businessDate: cod.date || cod.businessDate || businessDate(),
      accountNumber: 'COD',
      accountName: cod.staffName || staffName(cod.staffId) || 'Staff',
      details: `COD final agreed adjustment for ${cod.staffName || staffName(cod.staffId) || 'staff'} (${cod.date || cod.businessDate || businessDate()})`,
      note: note || '',
      kind: adjustment > 0 ? 'credit' : 'debit',
      type: 'cod_adjustment',
      sourceType: 'cod_adjustment',
      delta: adjustment,
      amount: Math.abs(adjustment),
      balanceAfter: 0,
      receivedOrPaidBy: cod.staffName || staffName(cod.staffId) || '',
      postedBy: currentStaff()?.name || 'System',
      codId: cod.id
    });
  }

  function openCODResolutionModal(codId) {
    const cod = state.cod.find(c =>
      String(c.id || '') === String(codId || '') ||
      String(c.codSubmissionId || '') === String(codId || '') ||
      String(c.cod_submission_id || '') === String(codId || '')
    );
    if (!cod) return showToast('COD record not found. Please refresh and try again.');
    const formAmount = Number(cod.formAmount ?? cod.openingBalance ?? getStaffOperationalBalance(cod.staffId));
    const totalCreditCash = Number(cod.totalCreditCash ?? approvedCreditTotalForDateByMode(cod.staffId, cod.date, 'cash'));
    const totalCreditTransfer = Number(cod.totalCreditTransfer ?? approvedCreditTotalForDateByMode(cod.staffId, cod.date, 'transfer'));
    const totalDebitCash = Number(cod.totalDebitCash ?? approvedDebitTotalForDateByMode(cod.staffId, cod.date, 'cash'));
    const totalDebitTransfer = Number(cod.totalDebitTransfer ?? approvedDebitTotalForDateByMode(cod.staffId, cod.date, 'transfer'));
    const totalCredits = Number(cod.totalCredits ?? (totalCreditCash + totalCreditTransfer));
    const totalDebits = Number(cod.totalDebits ?? (totalDebitCash + totalDebitTransfer));
    const currentNetBookBalance = Number(cod.netBookBalance ?? (totalCredits - totalDebits));
    const currentRemainingBalance = formAmount - totalCredits - totalDebits;
    const currentVariance = Math.abs(currentRemainingBalance);
    const currentOverdraw = Math.max(0, -currentRemainingBalance);
    const defaultDebt = Math.max(currentOverdraw, Number(cod.debtAmount || 0));
    const isAdminOfficer = staffHasRole(currentStaff(), 'admin_officer');
    const savedAcceptedPosition = Number(cod.acceptedPosition ?? currentNetBookBalance);
    const savedAdjustment = Number(cod.adjustment ?? (savedAcceptedPosition - currentNetBookBalance));
    const savedCreateDebt = cod.createDebt ?? (defaultDebt > 0 || (cod.debtAmount || 0) > 0);
    const savedResolutionType = cod.resolutionType || (savedCreateDebt ? 'staff_debt' : 'balanced');
    openModal('Resolve Close of Day', `
      <div class="stack">
        <div class="note">Form is the approved opening money collected from the field. Net Balance is Total Credits minus Total Debits. Final Agreed Amount corrects the system total only. Debt can still be recorded against staff where required.</div>
        ${currentOverdraw > 0 ? `<div class="note" style="background:#fdecea;border-color:var(--danger)"><strong>Anomaly:</strong> this teller closed the day with a negative operational balance of ${money(currentOverdraw)}. Resolve directly with the staff involved before marking this closed.</div>` : ''}
        <div class="kpi-row">
          <div class="kpi"><div class="label">Form</div><div class="number">${money(formAmount)}</div></div>
          <div class="kpi"><div class="label">Total Credits</div><div class="number">${money(totalCredits)}</div></div>
          <div class="kpi"><div class="label">Total Debits</div><div class="number">${money(totalDebits)}</div></div>
          <div class="kpi"><div class="label">Net Balance</div><div class="number ${currentNetBookBalance<0?'balance-negative':''}">${money(currentNetBookBalance)}</div></div>
          <div class="kpi"><div class="label">Remaining Balance</div><div class="number ${currentRemainingBalance<0?'balance-negative':''}">${money(currentRemainingBalance)}</div></div>
          <div class="kpi"><div class="label">Variance</div><div class="number ${currentVariance>0?'balance-negative':''}">${money(currentVariance)}</div></div>
          <div class="kpi"><div class="label">Overdraw</div><div class="number ${currentOverdraw>0?'balance-negative':''}">${money(currentOverdraw)}</div></div>
        </div>
        <div class="form-grid two cod-resolution-grid">
          <div class="field"><label>Final Agreed Amount</label><input id="codAcceptedPosition" class="entry-input" type="number" value="${savedAcceptedPosition}" ${isAdminOfficer ? '' : 'readonly'}></div>
          <div class="field"><label>Adjustment</label><input id="codAdjustment" class="entry-input" type="number" value="${savedAdjustment}" readonly></div>
        </div>
        <div class="form-grid two cod-resolution-grid">
          <div class="field"><label>Resolution Type</label><select id="codResolutionType" class="entry-input"><option value="balanced" ${savedResolutionType==='balanced'?'selected':''}>Balanced</option><option value="staff_debt" ${savedResolutionType==='staff_debt'?'selected':''}>Staff Debt</option><option value="reversal_needed" ${savedResolutionType==='reversal_needed'?'selected':''}>Reversal Needed</option></select></div>
          <div class="field"><label>Create Teller Debt</label><select id="codCreateDebt" class="entry-input"><option value="yes" ${savedCreateDebt?'selected':''}>Yes</option><option value="no" ${!savedCreateDebt?'selected':''}>No</option></select></div>
        </div>
        <div class="form-grid two cod-resolution-grid">
          <div class="field"><label>Debt Amount</label><input id="codDebtAmount" class="entry-input" type="number" value="${cod.debtAmount || defaultDebt}"></div>
          <div class="field"><label>Resolution Note</label><textarea id="codResolutionNote" class="entry-input">${cod.resolutionNote || ''}</textarea></div>
        </div>
      </div>
    `,[
      {label:'Close', className:'secondary', onClick: closeModal},
      {label:'Resolve', onClick: async ()=> {
        const note = byId('codResolutionNote').value.trim();
        if (!note) return showToast('Resolution note required');
        const resolutionType = byId('codResolutionType').value;
        const createDebt = byId('codCreateDebt').value === 'yes';
        const acceptedPosition = isAdminOfficer ? Number(byId('codAcceptedPosition').value || 0) : savedAcceptedPosition;
        const adjustment = isAdminOfficer ? (acceptedPosition - currentNetBookBalance) : savedAdjustment;
        const debtAmt = createDebt ? Math.max(0, Number(byId('codDebtAmount').value || 0)) : 0;
        closeModal();
        showProcessing('Resolving COD...');
        await nextPaint();
        try {
        if (isSupabaseApprovalMode() && gateway.cod?.resolveCod) {
          const result = await gateway.cod.resolveCod({ codSubmissionId: cod.id, finalAgreedAmount: acceptedPosition, debtAmount: debtAmt, resolutionNote: note, resolvedByStaffId: currentStaff()?.id || '' });
          if (result?.ok === false) return showToast(result.error?.message || 'Unable to resolve COD');
          if (result?.ok && result.data) {
            Object.assign(cod, result.data, { status: 'resolved', resolutionType, reversalNeeded: resolutionType === 'reversal_needed', createDebt, staffName: cod.staffName, formAmount, totalCreditCash, totalCreditTransfer, totalDebitCash, totalDebitTransfer, totalCredits, totalDebits, netBookBalance: currentNetBookBalance, remainingBalance: currentRemainingBalance, variance: currentVariance, overdraw: currentOverdraw, acceptedPosition, adjustment: resolutionType === 'reversal_needed' ? 0 : adjustment });
            applyCodBusinessAdjustment(cod, resolutionType === 'reversal_needed' ? 0 : adjustment, resolutionType, note);
            await syncCodFromGateway({ staffId: cod.staffId, businessDate: cod.date });
            applyCodBusinessAdjustment(cod, resolutionType === 'reversal_needed' ? 0 : adjustment, resolutionType, note);
            await syncDebtBalancesFromGateway(cod.staffId);
          }
        } else {
          const shouldPostAdjustment = isAdminOfficer && resolutionType !== 'reversal_needed' && adjustment !== 0;
          cod.status = 'resolved';
          cod.resolutionType = resolutionType;
          cod.reversalNeeded = resolutionType === 'reversal_needed';
          cod.resolutionNote = note;
          cod.resolvedBy = currentStaff()?.name || 'System';
          cod.resolvedAt = new Date().toISOString();
          cod.acceptedPosition = acceptedPosition;
          cod.adjustment = resolutionType === 'reversal_needed' ? 0 : adjustment;
          cod.debtAmount = debtAmt;
          cod.createDebt = createDebt;
          cod.formAmount = formAmount;
          cod.totalCreditCash = totalCreditCash;
          cod.totalCreditTransfer = totalCreditTransfer;
          cod.totalDebitCash = totalDebitCash;
          cod.totalDebitTransfer = totalDebitTransfer;
          cod.totalCredits = totalCredits;
          cod.totalDebits = totalDebits;
          cod.netBookBalance = currentNetBookBalance;
          cod.remainingBalance = currentRemainingBalance;
          cod.variance = currentVariance;
          cod.overdraw = currentOverdraw;
          applyCodBusinessAdjustment(cod, shouldPostAdjustment ? adjustment : 0, resolutionType, note);
          const acc = ensureStaffAccount(cod.staffId);
          const existingDebtEntries = (acc.entries||[]).filter(e => e.type === 'cod_resolution_debt' && e.codId === cod.id);
          if (existingDebtEntries.length) {
            acc.entries = (acc.entries||[]).filter(e => !(e.type === 'cod_resolution_debt' && e.codId === cod.id));
            const previousDebt = existingDebtEntries.reduce((s,e)=>s+Number(e.amount||0),0);
            acc.debtBalance = Math.max(0, Number(acc.debtBalance || 0) - previousDebt);
            recalcStaffBalance(cod.staffId);
          }
          if (createDebt && debtAmt > 0) {
            acc.debtBalance = Number(acc.debtBalance || 0) + debtAmt;
            addStaffEntry(cod.staffId, 'cod_resolution_debt', debtAmt, 0, `COD debt recorded: ${note}`, { codId: cod.id });
          }
        }
        save(); render(); showToast(resolutionType === 'reversal_needed' ? 'COD flagged for reversal/correction' : 'COD resolved');
        } finally {
          hideProcessing();
        }
      }}
    ]);
    const acceptedInput = byId('codAcceptedPosition');
    const adjustmentInput = byId('codAdjustment');
    const createDebtInput = byId('codCreateDebt');
    const debtAmountInput = byId('codDebtAmount');
    const resolutionTypeInput = byId('codResolutionType');
    const syncAdjustment = () => {
      const acceptedPosition = isAdminOfficer ? Number(acceptedInput?.value || 0) : savedAcceptedPosition;
      const adjustment = acceptedPosition - currentNetBookBalance;
      if (adjustmentInput) adjustmentInput.value = String(resolutionTypeInput?.value === 'reversal_needed' ? 0 : adjustment);
    };
    const syncDebtField = () => {
      const debtEnabled = createDebtInput?.value === 'yes';
      if (debtAmountInput) {
        debtAmountInput.disabled = !debtEnabled;
        if (!debtEnabled) debtAmountInput.value = '0';
        else if (!debtAmountInput.value) debtAmountInput.value = String(cod.debtAmount ?? defaultDebt);
      }
    };
    if (acceptedInput && isAdminOfficer) acceptedInput.oninput = syncAdjustment;
    if (resolutionTypeInput) resolutionTypeInput.onchange = syncAdjustment;
    if (createDebtInput) createDebtInput.onchange = syncDebtField;
    syncAdjustment();
    syncDebtField();
  }

  function flattenBusinessEntries() {
    const txRows = flattenCustomerTx().map(t => ({
      date: t.date,
      accountNumber: t.customer?.accountNumber || '',
      accountName: t.customer?.name || t.accountName || t.customerName || t.customer?.accountNumber || '',
      details: t.details || t.note || '',
      note: t.note || t.details || '',
      kind: t.type,
      type: t.type,
      delta: t.type === 'credit' ? Number(t.amount || 0) : -Number(t.amount || 0),
      amount: Number(t.amount || 0),
      balanceAfter: Number(t.balanceAfter || 0),
      receivedOrPaidBy: t.receivedOrPaidBy || t.receivedBy || t.postedBy || '',
      postedBy: t.postedBy || t.postedById || '',
      approvedBy: t.approvedBy || ''
    }));
    const extras = (state.businessExtras || []).map(e => ({
      ...e,
      accountNumber: e.accountNumber || 'STAFF',
      accountName: e.accountName || e.customerName || e.accountNumber || 'STAFF',
      details: cleanOperationalNote(e.details || e.note) || '',
      note: cleanOperationalNote(e.note || e.details) || '',
      type: e.type === 'cod_adjustment' ? (e.kind || (Number(e.delta || 0) >= 0 ? 'credit' : 'debit')) : (e.type || e.kind || (Number(e.delta || 0) >= 0 ? 'credit' : 'debit')),
      kind: e.kind || (e.type === 'cod_adjustment' ? (Number(e.delta || 0) >= 0 ? 'credit' : 'debit') : e.type) || (Number(e.delta || 0) >= 0 ? 'credit' : 'debit'),
      delta: Number(e.delta || ((e.type || e.kind) === 'debit' ? -Number(e.amount || 0) : Number(e.amount || 0))),
      amount: Number(e.amount || 0),
      balanceAfter: Number(e.balanceAfter || 0),
      receivedOrPaidBy: e.receivedOrPaidBy || e.receivedBy || e.postedBy || '',
      postedBy: e.postedBy || '',
      approvedBy: e.approvedBy || ''
    }));
    return [...txRows, ...extras].sort((a,b)=>new Date(b.date)-new Date(a.date));
  }

  function renderBalanceFilters(kind) {
    const filter = state.ui[`${kind}Filter`] || { preset:'daily', from:'', to:'' };
    const presets = [['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['yearly','Yearly'],['all','All']];
    const types = kind==='business' ? [['all','All'],['credit','Credit'],['debit','Debit']] : [['all','All'],['income','Income'],['expense','Expense']]; const activeType = state.ui[`${kind}Type`] || 'all'; return `<div class="form-card balance-filters-card"><div class="action-inline balance-filters-row">${presets.map(([k,l])=>`<button class="filter-chip ${filter.preset===k?'active':'secondary'}" data-filter-kind="${kind}" data-filter-preset="${k}">${l}</button>`).join('')}<label class="inline-field"><span>From</span><input id="${kind}From" type="date" lang="en-GB" value="${filter.from||''}"></label><label class="inline-field"><span>To</span><input id="${kind}To" type="date" lang="en-GB" value="${filter.to||''}"></label><button class="secondary" id="${kind}CustomApply">Apply Custom</button><button class="secondary" id="${kind}ExportCsv">Export CSV</button><button class="secondary" id="${kind}PrintSummary">Print Summary</button></div><div class="action-inline balance-filters-row" style="margin-top:10px">${types.map(([k,l])=>`<button class="filter-chip ${activeType===k?'active':'secondary'}" data-type-kind="${kind}" data-type-filter="${k}">${l}</button>`).join('')}</div></div>`;
  }

  function bindBalanceFilters(kind) {
    qq(`[data-filter-kind="${kind}"]`).forEach(btn => btn.onclick = () => {
      state.ui[`${kind}Filter`] = { preset: btn.dataset.filterPreset, from:'', to:'' }; save(); renderWorkspace();
    });
    byId(`${kind}CustomApply`).onclick = () => { state.ui[`${kind}Filter`] = { preset:'custom', from:byId(`${kind}From`).value, to:byId(`${kind}To`).value }; save(); renderWorkspace(); };
    qq(`[data-type-kind="${kind}"]`).forEach(btn => btn.onclick = () => { state.ui[`${kind}Type`] = btn.dataset.typeFilter; save(); renderWorkspace(); });
    const moreBtn = byId(`${kind}More`);
    if (moreBtn) moreBtn.onclick = () => {
      const key = kind === 'business' ? 'businessEntriesLimit' : 'operationalEntriesLimit';
      state.ui[key] = (state.ui[key] || 20) + 20; save(); renderWorkspace();
    };
    const lessBtn = byId(`${kind}Less`);
    if (lessBtn) lessBtn.onclick = () => {
      const key = kind === 'business' ? 'businessEntriesLimit' : 'operationalEntriesLimit';
      state.ui[key] = Math.max(20, (state.ui[key] || 20) - 20); save(); renderWorkspace();
    };
    const tellerMore = byId('tellerMore');
    if (tellerMore) tellerMore.onclick = () => { state.ui.tellerEntriesLimit = (state.ui.tellerEntriesLimit || 20) + 20; save(); renderWorkspace(); };
    const tellerLess = byId('tellerLess');
    if (tellerLess) tellerLess.onclick = () => { state.ui.tellerEntriesLimit = Math.max(20, (state.ui.tellerEntriesLimit || 20) - 20); save(); renderWorkspace(); };
    byId(`${kind}ExportCsv`).onclick = () => {
      if (kind === 'operational') {
        exportOperationalStatementCsv();
        return;
      }
      if (kind === 'business') {
        exportBusinessStatementCsv();
        return;
      }
      const rows = filterByDate(flattenBusinessEntries(), state.ui.businessFilter || { preset: 'daily', from: '', to: '' });
      exportCsv(rows, `${kind}_balance.csv</div>`);
    };
    byId(`${kind}PrintSummary`).onclick = () => {
      if (kind === 'operational') {
        printOperationalStatement();
        return;
      }
      if (kind === 'business') {
        printBusinessStatement();
        return;
      }
      printHtml(byId('workspace').innerHTML, true);
    };
  }

  function dateOnly(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    const direct = raw.match(/^(\d{4}-\d{2}-\d{2})/);
    if (direct) return direct[1];
    const d = new Date(raw);
    if (isNaN(d)) return '';
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function filterRowDate(row) {
    return dateOnly(row?.date || row?.businessDate || row?.business_date || row?.transactionDate || row?.transaction_date || row?.postedAt || row?.posted_at || row?.approvedAt || row?.approved_at || row?.createdAt || row?.created_at || row?.requestedAt || row?.requested_at);
  }

  function filterDateReference(rows = []) {
    // Always filter against the active DUCESS business date — never real calendar date,
    // never the most-recent-entry date. Daily = what happened on the open business date.
    return dateOnly(businessDate && businessDate()) || '';
  }

  // First date a filter can reach (null = all dates) — used to make sure
  // the loaded history goes back that far (Fix B 2026-10-22).
  function filterStartDate(f) {
    const ref = filterDateReference();
    const preset = f?.preset || 'daily';
    if (preset === 'all') return null;
    if (preset === 'custom') return f.from || null;
    if (preset === 'daily') return ref;
    const d = new Date(`${ref}T12:00:00`);
    if (preset === 'weekly') { d.setDate(d.getDate() - 6); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
    if (preset === 'monthly') return `${ref.slice(0,7)}-01`;
    if (preset === 'yearly') return `${ref.slice(0,4)}-01-01`;
    return null;
  }

  function filterByDate(rows, filter) {
    const activeFilter = filter || { preset: 'daily', from: '', to: '' };
    historyCovers(filterStartDate(activeFilter));
    if (activeFilter.preset === 'all') return rows || [];
    const referenceIso = filterDateReference(rows || []);
    const referenceDate = new Date(`${referenceIso}T12:00:00`);
    return (rows || []).filter(r => {
      const iso = filterRowDate(r);
      if (!iso) return false;
      const d = new Date(`${iso}T12:00:00`);
      if (activeFilter.preset === 'daily') return iso === referenceIso;
      if (activeFilter.preset === 'weekly') {
        const start = new Date(referenceDate);
        start.setDate(referenceDate.getDate() - 6);
        start.setHours(0,0,0,0);
        const end = new Date(referenceDate);
        end.setHours(23,59,59,999);
        return d >= start && d <= end;
      }
      if (activeFilter.preset === 'monthly') return d.getFullYear() === referenceDate.getFullYear() && d.getMonth() === referenceDate.getMonth();
      if (activeFilter.preset === 'yearly') return d.getFullYear() === referenceDate.getFullYear();
      if (activeFilter.preset === 'custom') {
        if (activeFilter.from && iso < activeFilter.from) return false;
        if (activeFilter.to && iso > activeFilter.to) return false;
      }
      return true;
    });
  }

  function exportCsv(rows, filename) {
    if (!rows.length) return showToast('Nothing to export');
    const escapeCell = value => JSON.stringify(value ?? '');
    const csv = Array.isArray(rows[0])
      ? rows.map(row => (row || []).map(escapeCell).join(',')).join('\n')
      : (() => {
          const cols = Object.keys(rows[0]);
          return [cols.join(',')].concat(rows.map(r => cols.map(k => escapeCell(r[k])).join(','))).join('\n');
        })();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], {type:'text/csv;charset=utf-8;'}));
    a.download = filename; a.click();
  }

  function printHtml(html, autoPrint=true) {
    const w = window.open('', '_blank');
    const statementStyles = `
      <style>
        @page { size: landscape; margin: 10mm; }
        body { font-family: Arial, Helvetica, sans-serif; color:#111; margin:0; background:#fff; }
        .shell, .workspace { margin:0; padding:0; }
        .statement-sheet { padding: 4px 6px; }
        .statement-title { font-size: 16px; font-weight: 700; margin: 0 0 8px; }
        .statement-summary-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 8px;
          font-size: 11px;
          margin: 0 0 8px;
        }
        .statement-summary-item {
          padding: 4px 6px;
          border: 1px solid #999;
        }
        .statement-summary-item span { font-weight: 700; }
        .statement-rule { border-top: 1px solid #999; margin: 6px 0 8px; }
        .statement-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 9px;
          table-layout: fixed;
        }
        .statement-table th, .statement-table td {
          border: 1px solid #666;
          padding: 4px 5px;
          text-align: left;
          vertical-align: top;
          word-break: break-word;
        }
        .statement-table th { background: #f3f3f3; font-weight: 700; }
        .statement-total { margin-top: 8px; font-size: 11px; }
      </style>`;
    w.document.write(`<html><head><title>Print</title><link rel="stylesheet" href="app.css">${statementStyles}</head><body><div class="shell"><div class="workspace">${html}</div></div></body></html></div>`);
    w.document.close();
    w.focus();
    if (autoPrint) w.print();
  }

  function confirmAction(message, onYes) {
    openModal('Confirm Action', `<div class="note">${message}</div></div>`, [{label:'Cancel', className:'secondary', onClick: closeModal},{label:'Confirm', onClick:()=>{closeModal(); onYes();}}]);
  }

  function applySelectedCustomerToActiveTool() {
    const c = getSelectedCustomer();
    if (!c) return;
    if (state.ui.tool === 'check_balance') {
      state.ui.checkBalanceLoaded = true;
      save();
      const ws = byId('workspace');
      if (ws) lookupFill(ws, c); else render();
      return;
    }
    if (state.ui.tool === 'credit' || state.ui.tool === 'debit') {
      state.ui.txAccDraft = c.accountNumber || '';
      state.ui.selectedCustomerId = c.id;
      if (byId('txAcc')) byId('txAcc').value = c.accountNumber || '';
      if (byId('txName')) byId('txName').textContent = c.name || '—';
      if (byId('txBalance')) byId('txBalance').innerHTML = balanceHtml(c.balance);
      updateTxAccountMeta(c);
      save();
      return;
    }
    if (state.ui.tool === 'intra_transfer') {
      // Non Cash has two account fields on one screen (source/dest), unlike
      // every other tool here which only has one — nonCashSearchTarget is
      // set right before opening the modal so the selection routes to
      // whichever field's Search button was actually clicked.
      const target = state.ui.nonCashSearchTarget;
      const draft = state.ui.intraTransferDraft ||= {};
      if (isLocalOnlyStaffAccount(c)) { save(); return showToast(STAFF_WALLET_NON_CASH_MSG); }
      if (target === 'dest') {
        draft.destAcct = c.accountNumber || '';
        draft.destName = c.name || '';
        draft.destId = c.id;
        draft.destBalance = Number(c.balance || 0);
        // Picking a staff operational account via Search locks the Debit
        // side the same way typing+Enter does (see applyStaffAccountLock)
        // — this needs a full re-render since it changes the form shape.
        if (c.accountType === 'staff_operational') {
          applyStaffAccountLock(draft);
          save();
          renderWorkspace();
          return;
        }
      } else {
        draft.sourceAcct = c.accountNumber || '';
        draft.sourceName = c.name || '';
        draft.sourceId = c.id;
        draft.sourceBalance = Number(c.balance || 0);
      }
      // Full re-render so Name, Balance, Account Status and Account Type
      // all refresh together from the draft.
      save();
      renderWorkspace();
      return;
    }
    if (state.ui.tool === 'staff_credit' && state.ui.nonCashSearchTarget === 'staffCreditSource') {
      const draft = state.ui.staffCreditDraft ||= {};
      draft.sourceAcct = c.accountNumber || '';
      draft.sourceName = c.name || '';
      draft.sourceId = c.id;
      draft.sourceBalance = Number(c.balance || 0);
      state.ui.nonCashSearchTarget = '';
      save();
      renderWorkspace();
      return;
    }
    if (state.ui.tool === 'account_statement') {
      // stmtAcc no longer exists (2026-08-14 redesign) — statement now always
      // reflects state.ui.selectedCustomerId, set via Check Balance.
      state.ui.selectedCustomerId = c.id;
      state.ui.accountStatementGenerated = false;
      save();
      renderWorkspace();
      return;
    }
    if (state.ui.tool === 'account_maintenance' || state.ui.tool === 'account_reactivation') {
      // Route through the same persisted draft fillCustomer() uses, so a
      // background re-render doesn't wipe the picked customer's details.
      const prefix = state.ui.tool === 'account_reactivation' ? 'reactivation' : 'maintenance';
      const draft = state.ui[`${prefix}Draft`] ||= {};
      draft.accountNumber = c.accountNumber || '';
      draft.name = c.name || '';
      draft.address = c.address || '';
      draft.phone = c.phone || '';
      draft.nin = c.nin || '';
      draft.bvn = c.bvn || '';
      draft.oldAccountNumber = c.oldAccountNumber || '';
      draft.editable = false;
      save();
      renderWorkspace();
      return;
    }
  }

  function openChangePasswordModal() {
    openModal('Change Password', `
      <div class="form-grid two" style="gap:10px;max-width:520px">
        <div class="field" style="grid-column:1/-1"><label>Old Password</label>${passwordInputRow('<input id="changeOldPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'changeOldPassword')}</div>
        <div class="field"><label>New Password</label>${passwordInputRow('<input id="changeNewPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'changeNewPassword')}</div>
        <div class="field"><label>Confirm New Password</label>${passwordInputRow('<input id="changeConfirmPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'changeConfirmPassword')}</div>
      </div>
      <p style="margin:8px 0 0;font-size:0.78em;color:var(--text-muted)">After a refresh or reopen, DUCESS will require login again.</p>
    `, [
      { label:'Cancel', className:'secondary', onClick: closeModal },
      { label:'Update Password', onClick: async () => {
        const oldPassword = byId('changeOldPassword')?.value || '';
        const newPassword = byId('changeNewPassword')?.value || '';
        const confirmPassword = byId('changeConfirmPassword')?.value || '';
        if (!oldPassword) return showToast('Enter old password');
        if (!newPassword || newPassword.length < 6) return showToast('New password must be at least 6 characters');
        if (newPassword !== confirmPassword) return showToast('New passwords do not match');
        const submitBtn = document.querySelector('.modal-actions button:last-child');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Updating…'; }
        try {
          await nextPaint();
          const result = await gateway.auth?.changePassword?.({ oldPassword, newPassword });
          if (!result?.ok) {
            showToast(result?.error?.message || 'Could not change password');
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Update Password'; }
            return;
          }
          closeModal();
          showToast('✓ Password changed successfully');
        } catch (err) {
          showToast('Could not change password');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Update Password'; }
        }
      }}
    ]);
    bindPasswordToggles(byId('modalBody') || document);
    hardenCredentialInputs(byId('modalBody') || document);
  }

  function openLoginChangePasswordModal() {
    const loginStaffValue = (byId('loginStaffId')?.value || '').trim().toUpperCase();
    openModal('Change Password', `
      <div class="form-grid two" style="gap:10px;max-width:520px">
        <div class="field" style="grid-column:1/-1"><label>Staff ID</label><input id="loginChangeStaffId" class="entry-input" value="${escapeHtml(loginStaffValue)}" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true" style="text-transform:uppercase"></div>
        <div class="field" style="grid-column:1/-1"><label>Current Password</label>${passwordInputRow('<input id="loginChangeOldPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'loginChangeOldPassword')}</div>
        <div class="field"><label>New Password</label>${passwordInputRow('<input id="loginChangeNewPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'loginChangeNewPassword')}</div>
        <div class="field"><label>Confirm New Password</label>${passwordInputRow('<input id="loginChangeConfirmPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'loginChangeConfirmPassword')}</div>
      </div>
      <p style="margin:8px 0 0;font-size:0.78em;color:var(--text-muted)">Use your current Staff ID and password. After the update, sign in with the new password.</p>
    `, [
      { label:'Cancel', className:'secondary', onClick: closeModal },
      { label:'Update Password', onClick: async () => {
        const staffId = (byId('loginChangeStaffId')?.value || '').trim().toUpperCase();
        const oldPassword = byId('loginChangeOldPassword')?.value || '';
        const newPassword = byId('loginChangeNewPassword')?.value || '';
        const confirmPassword = byId('loginChangeConfirmPassword')?.value || '';
        if (!staffId) return showToast('Enter Staff ID');
        if (!oldPassword) return showToast('Enter current password');
        if (!newPassword || newPassword.length < 6) return showToast('New password must be at least 6 characters');
        if (newPassword !== confirmPassword) return showToast('New passwords do not match');
        const submitBtn = document.querySelector('.modal-actions button:last-child');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Updating…'; }
        try {
          await nextPaint();
          const loginResult = await gateway.auth?.loginWithStaffId?.({ staffId, password: oldPassword });
          if (!loginResult?.ok) {
            showToast(loginResult?.error?.message || 'Current Staff ID or password is incorrect');
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Update Password'; }
            return;
          }
          const result = await gateway.auth?.changePassword?.({ oldPassword, newPassword });
          if (!result?.ok) {
            showToast(result?.error?.message || 'Could not change password');
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Update Password'; }
            return;
          }
          await gateway.auth?.logout?.().catch?.(() => {});
          if (byId('loginStaffId')) byId('loginStaffId').value = staffId;
          if (byId('loginPassword')) byId('loginPassword').value = '';
          closeModal();
          showLoginScreen();
          showToast('✓ Password changed. Sign in with the new password.');
        } catch (err) {
          showToast('Could not change password');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Update Password'; }
        }
      }}
    ]);
    bindPasswordToggles(byId('modalBody') || document);
    hardenCredentialInputs(byId('modalBody') || document);
  }

  function openAdminResetPasswordModal(staffId) {
    if (!isAdminStaff()) return showToast('Only admin can reset passwords');
    const target = state.staff.find(s => s.id === staffId);
    if (!target) return showToast('Staff not found');
    const staffCode = target.staffCode || target.staff_code || target.staffId || target.id || '';
    openModal('Reset Staff Password', `
      <div style="max-width:520px">
        <p style="margin:0 0 10px;font-size:0.86em">Reset password for <strong>${escapeHtml(target.name || target.full_name || staffCode)}</strong>.</p>
        <div class="form-grid two" style="gap:10px">
          <div class="field"><label>Staff ID</label><div class="display-field">${escapeHtml(String(staffCode))}</div></div>
          <div class="field"><label>Temporary Password</label>${passwordInputRow('<input id="adminTempPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'adminTempPassword')}</div>
          <div class="field"><label>Confirm Password</label>${passwordInputRow('<input id="adminTempPasswordConfirm" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'adminTempPasswordConfirm')}</div>
        </div>
        <p style="margin:8px 0 0;font-size:0.78em;color:var(--text-muted)">Give this temporary password to the staff securely.</p>
      </div>
    `, [
      { label:'Cancel', className:'secondary', onClick: closeModal },
      { label:'Reset Password', onClick: async () => {
        const temporaryPassword = byId('adminTempPassword')?.value || '';
        const confirmPassword = byId('adminTempPasswordConfirm')?.value || '';
        if (!temporaryPassword || temporaryPassword.length < 6) return showToast('Temporary password must be at least 6 characters');
        if (temporaryPassword !== confirmPassword) return showToast('Passwords do not match');
        const submitBtn = document.querySelector('.modal-actions button:last-child');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Resetting…'; }
        try {
          await nextPaint();
          const actor = currentStaff();
          const result = await gateway.auth?.resetStaffPassword?.({
            staffId: target.id,
            staffCode,
            authUserId: target.authUserId || target.auth_user_id || target.uuid || '',
            temporaryPassword,
            updatedByStaffId: actor?.id || null,
            updatedByName: actor?.name || actor?.fullName || null,
          });
          if (!result?.ok) {
            showToast(result?.error?.message || 'Could not reset password');
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Reset Password'; }
            return;
          }
          closeModal();
          if (result.data?.loginCheck?.status === 'failed') {
            openModal('Password reset — login test FAILED', `<div class="stack"><p>The reset went through, but signing in with the new temporary password did not work.</p><p><strong>Reason:</strong> ${escapeHtml(result.data.loginCheck.message || 'unknown')}</p><p>Send this message to your developer.</p></div>`, [{ label: 'Close', onClick: closeModal }]);
            return;
          }
          showToast(result.data?.loginCheck?.status === 'ok' ? '✓ Staff password reset — login tested OK' : '✓ Staff password reset successfully');
        } catch (err) {
          showToast('Could not reset password');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Reset Password'; }
        }
      }}
    ]);
    bindPasswordToggles(byId('modalBody') || document);
    hardenCredentialInputs(byId('modalBody') || document);
  }


  function openRecoveryKeyDisplayModal(recoveryKey, generatedAt) {
    const safeKey = escapeHtml(recoveryKey || '');
    openModal('Admin Recovery Key', `
      <div class="compact-panel" style="padding:10px;border:1px solid var(--line);border-radius:12px">
        <p style="margin:0 0 8px;font-size:0.86em;color:var(--text-muted)">Save this key now. It is shown once and is required if the Admin forgets password.</p>
        <div style="font-family:monospace;font-size:0.98em;letter-spacing:.04em;padding:10px;border:1px dashed var(--line);border-radius:10px;background:var(--panel-soft);word-break:break-all">${safeKey}</div>
        <p style="margin:8px 0 0;font-size:0.76em;color:var(--text-muted)">Generated: ${escapeHtml(generatedAt || new Date().toISOString())}</p>
        <label style="display:inline-flex;gap:8px;align-items:center;margin-top:10px;font-size:0.82em;line-height:1.25"><input id="recoveryKeySavedConfirm" type="checkbox" style="width:14px;height:14px;min-width:14px;max-width:14px;margin:0;accent-color:var(--accent,#1f5f91)"> <span>I have copied/saved this recovery key safely.</span></label>
      </div>
    `, [
      { label:'Copy Key', className:'secondary', onClick: async () => {
        try { await navigator.clipboard.writeText(recoveryKey || ''); showToast('Recovery key copied'); } catch (_) { showToast('Copy failed. Please copy manually.'); }
      }},
      { label:'Download Key', className:'secondary', onClick: () => {
        const blob = new Blob([`DUCESS Admin Recovery Key\n\n${recoveryKey}\n\nGenerated: ${generatedAt || new Date().toISOString()}\nKeep this file offline and secure.`], { type:'text/plain' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'DUCESS-admin-recovery-key.txt';
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      }},
      { label:'Close', onClick: () => {
        if (!byId('recoveryKeySavedConfirm')?.checked) return showToast('Confirm that you have saved the recovery key');
        closeModal();
      }}
    ]);
  }

  async function openAdminRecoveryKeyModal(forceSetup=false) {
    if (!isAdminStaff()) return showToast('Only Admin can manage recovery key');
    const title = forceSetup ? 'Generate Recovery Key Required' : 'Admin Recovery Key';
    openModal(title, `
      <div class="compact-panel" style="padding:10px;border:1px solid var(--line);border-radius:12px">
        <p style="margin:0 0 8px;font-size:0.86em;color:var(--text-muted)">${forceSetup ? 'No Admin recovery key exists yet. Generate one now so this deployment can recover Admin access if password is forgotten.' : 'Generate or regenerate the Admin recovery key. Regeneration invalidates the previous key on this device/deployment.'}</p>
        <p style="margin:0;font-size:0.78em;color:var(--text-muted)">The key is displayed once. Store it offline before closing.</p>
      </div>
    `, [
      ...(forceSetup ? [] : [{ label:'Cancel', className:'secondary', onClick: closeModal }]),
      { label: forceSetup ? 'Generate Recovery Key' : 'Generate / Regenerate Key', onClick: async () => {
        const btn = q('#modalActions button:not(.secondary)');
        if (btn) { btn.disabled = true; btn.textContent = 'Generating…'; }
        try {
          const result = await gateway.auth?.generateAdminRecoveryKey?.({ regenerate: !forceSetup });
          if (!result?.ok) {
            showToast(result?.error?.message || 'Could not generate recovery key');
            if (btn) { btn.disabled = false; btn.textContent = forceSetup ? 'Generate Recovery Key' : 'Generate / Regenerate Key'; }
            return;
          }
          openRecoveryKeyDisplayModal(result.data?.recoveryKey, result.data?.generatedAt);
        } catch (err) {
          showToast('Could not generate recovery key');
          if (btn) { btn.disabled = false; btn.textContent = forceSetup ? 'Generate Recovery Key' : 'Generate / Regenerate Key'; }
        }
      }}
    ]);
  }

  async function enforceAdminRecoveryKeySetup() {
    if (!isAdminStaff()) return;
    try {
      const result = await gateway.auth?.hasAdminRecoveryKey?.();
      if (result?.ok && !result.data?.exists) setTimeout(() => openAdminRecoveryKeyModal(true), 250);
    } catch (_) {}
  }

  function openEditStaffCodeModal(staffId) {
    const staff = state.staff.find(s => s.id === staffId);
    if (!staff) return showToast('Staff not found');
    const currentCode = staff.staffCode || staff.staff_code || staff.staffId || staff.id || '';
    openModal('Edit Staff ID', `
      <p style="margin:0 0 10px;font-size:0.85em;color:var(--text-muted)">Staff ID is manager-assigned — it must be unique across all staff. Changing it changes their login ID.</p>
      <div class="field"><label>Staff ID <span style="color:red">*</span></label><input id="editStaffCodeInput" class="entry-input" value="${escapeHtml(String(currentCode))}" style="text-transform:uppercase" maxlength="10"></div>
    `, [
      {label:'Cancel', className:'secondary', onClick: closeModal},
      {label:'Save', onClick: async () => {
        const raw = byId('editStaffCodeInput')?.value?.trim();
        const newCode = raw ? raw.toUpperCase() : '';
        if (!newCode) return showToast('Enter a Staff ID');
        if (newCode.length > 10) return showToast('Staff ID must be 10 characters or fewer');
        if (newCode === currentCode.toUpperCase()) return closeModal();
        const clash = state.staff.some(s => s.id !== staffId && (s.staffCode || s.staff_code || s.staffId || s.id || '').toUpperCase() === newCode);
        if (clash) return showToast(`Staff ID "${newCode}" is already in use`);

        const submitBtn = document.querySelector('.modal-actions button:last-child');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Saving…'; }
        try {
          if (isSupabaseApprovalMode() && gateway.staff?.updateStaffCode) {
            const currentUser = state.staff.find(s => s.id === state.activeStaffId);
            const result = await gateway.staff.updateStaffCode({
              staffId,
              staffCode: newCode,
              updatedByStaffId: currentUser?.id || null,
              updatedByName: currentUser?.name || null,
            });
            if (!result.ok) {
              showToast(result.error?.message || 'Could not update Staff ID');
              if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Save'; }
              return;
            }
          }
          staff.staffCode = newCode;
          staff.staff_code = newCode;
          save();
          closeModal();
          render();
          showToast(`✓ Staff ID updated to "${newCode}"`);
        } catch (err) {
          showToast('Unexpected error updating Staff ID');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Save'; }
        }
      }}
    ]);
  }

  // ===== Role assignment / reassignment (role/staff separation) =====
  // Hard blockers keep the accountability trail intact: nothing a staff
  // member started under one role is left dangling when they move to another.
  // Warnings are informational — balances/debts stay on the person.
  function getRoleChangeIssues(st, newRole) {
    const blockers = [];
    const warnings = [];
    const infos = [];
    const curRole = staffRoleCode(st);
    const me = currentStaff();
    const name = st.name || st.full_name || 'This staff member';
    const leaving = hasAssignedRole(st) && curRole !== newRole;
    const ids = new Set([st.id, getStaffBackendId(st)].filter(Boolean));
    if (leaving) {
      const pending = (state.approvals || []).filter(a => a.status === 'pending' && (ids.has(a.requestedByStaffId) || ids.has(a.requestedBy) || ids.has(a.payload?.staffId)));
      if (pending.length) blockers.push(`${pending.length} pending approval request(s) raised by ${name} must be approved or rejected first — they were submitted as ${roleLabelOf(curRole)}.`);
      if (curRole === 'approving_officer') {
        const routed = (state.approvals || []).filter(a => a.status === 'pending' && ids.has(a.payload?.assignedApproverId));
        if (routed.length) blockers.push(`${routed.length} pending request(s) are routed to ${name} for approval — decide them (or have an Administrative Officer do so) first.`);
      }
      if (CASH_HANDLING_ROLES.includes(curRole) && (state.cod || []).some(c => c.staffId === st.id && c.status === 'pending')) {
        blockers.push(`${name} has an unresolved Close-of-Day submission — resolve it first.`);
      }
      if (curRole === 'admin_officer' && newRole !== 'admin_officer') {
        if (me && me.id === st.id) blockers.push('You cannot remove your own Administrative Officer role — ask another administrator to do it.');
        const otherAdmins = (state.staff || []).filter(x => x.id !== st.id && staffRoleCode(x) === 'admin_officer' && x.active !== false && x.is_active !== false);
        if (!otherAdmins.length) blockers.push('This is the only active Administrative Officer — assign another administrator before changing this role.');
      }
      if (CASH_HANDLING_ROLES.includes(curRole)) {
        const bal = Number(getStaffOperationalBalance(st.id) || 0);
        if (Math.abs(bal) > 0.009) warnings.push(`Operational balance of ₦${money(bal)} stays on ${name}'s own account and remains reported against them. Settle it first if it should not carry over.`);
      }
      const debt = Number(ensureStaffAccount(st.id).debtBalance || 0);
      if (debt > 0) warnings.push(`Outstanding debt of ₦${money(debt)} stays tied to ${name}.`);
    }
    // 2026-10-24: Treasury officers work from business Treasury accounts —
    // no personal operational account is opened for them.
    if (CASH_HANDLING_ROLES.includes(newRole) && newRole !== 'cash_officer') {
      const hasOp = (state.customers || []).some(c => c.accountType === 'staff_operational' && c.linkedStaffId === st.id);
      if (newRole === 'teller') infos.push(hasOp ? `${name}'s existing Teller Account will be re-used (same account number and balance).` : `${name}'s Teller Account is opened by Customer Service: Account Opening > Teller Account.`);
      else infos.push(hasOp ? `${name}'s existing operational account will be re-used (same account number and balance).` : `An operational account will be opened automatically for ${name}.`);
    }
    if (newRole === UNASSIGNED_ROLE) warnings.push(`${name} will lose all access until another role is assigned. History and balances are kept.`);
    return { blockers, warnings, infos };
  }

  // A staff member can hold at most ONE operational account, for life: it is
  // permanently tied to the person (linked_staff_id), so role changes never
  // move, close or duplicate it. Eligible = active, currently in the matching
  // role, no account yet and no account-opening request already pending.
  function isEligibleForOperationalAccount(staff, kind) {
    if (!staff || staff.active === false || staff.is_active === false) return false;
    // 2026-11-11 (client): any active staff member can be given a Teller account — the
    // list is no longer limited to people whose role is Teller. (The account is still
    // one per person, for life.)
    if ((state.customers || []).some(c => c.accountType === 'staff_operational' && c.linkedStaffId === staff.id)) return false;
    const pendingOpen = (state.approvals || []).some(a => a.status === 'pending' && a.type === 'account_opening' && a.payload?.accountType === 'staff_operational' && a.payload?.linkedStaffId === staff.id);
    return !pendingOpen;
  }

  function applyLocalRoleChange(st, newRole, note, actor) {
    const now = new Date().toISOString();
    state.roleAssignments ||= [];
    state.roleAssignments.forEach(a => { if (a.staffId === st.id && !a.endedAt) { a.endedAt = now; a.endedByStaffId = actor?.id || null; } });
    state.roleAssignments.push({ id: uid('ra'), staffId: st.id, roleCode: newRole, assignedAt: now, endedAt: null, assignedByStaffId: actor?.id || null, assignedByName: actor?.name || '', note: note || '' });
    st.role = newRole;
    st.role_code = newRole;
  }

  function openAssignRoleModal(staffId) {
    const st = (state.staff || []).find(x => x.id === staffId);
    if (!st) return showToast('Staff not found');
    if (!isAdminStaff()) return showToast('Only an Administrative Officer can assign roles');
    const curRole = staffRoleCode(st);
    const assigned = hasAssignedRole(st);
    const name = st.name || st.full_name || '';
    const options = ASSIGNABLE_ROLE_KEYS.map(k => `<option value="${k}" ${k === curRole ? 'disabled' : ''}>${escapeHtml(ROLE_LABELS[k])}${k === curRole ? ' (current)' : ''}</option>`).join('')
      + (assigned ? `<option value="${UNASSIGNED_ROLE}">— Remove role (no access) —</option>` : '');
    openModal(assigned ? 'Reassign Role' : 'Assign Role', `
      <p style="margin:0 0 10px"><strong>${escapeHtml(name)}</strong> <code style="font-size:0.85em">${escapeHtml(String(st.staffCode || st.staff_code || ''))}</code><br>
      <span style="font-size:0.85em;color:var(--text-muted)">Current role: ${escapeHtml(roleLabelOf(curRole))}</span></p>
      <div class="form-grid one" style="gap:10px">
        <div class="field"><label>New Role <span style="color:red">*</span></label>
          <select id="assignRoleSelect" class="entry-input"><option value="">— Select role —</option>${options}</select></div>
        <div class="field"><label>Reason${assigned ? ' <span style="color:red">*</span>' : ' (optional)'}</label><input id="assignRoleNote" class="entry-input" placeholder="e.g. Moved from Teller to Treasury"></div>
        <div class="field"><label>Additional Roles (optional)</label>
          <div id="assignExtraRoles" style="border:1px solid rgba(0,0,0,.12);border-radius:6px;padding:2px 8px">${ASSIGNABLE_ROLE_KEYS.map(k2 => `<label data-assign-extra-row="${k2}" style="display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;width:100%;margin:0;padding:7px 2px;text-align:left;font-size:13px;cursor:pointer;border-bottom:1px solid rgba(0,0,0,.06)"><input type="checkbox" data-assign-extra="${k2}" ${staffExtraRoleCodes(st).includes(k2) ? 'checked' : ''} style="width:18px;height:18px;min-width:18px;max-width:18px;flex:0 0 18px;margin:0;padding:0;appearance:auto;-webkit-appearance:checkbox"><span style="flex:1;text-align:left">${escapeHtml(ROLE_LABELS[k2])}</span></label>`).join('')}</div>
          <div style="font-size:0.78em;color:var(--text-muted);margin-top:4px">Tick any other roles this person should also hold. The role chosen above is the main role.</div></div>
      </div>
      <div id="assignRoleIssues" style="margin-top:10px;font-size:0.85em"></div>
      <p style="margin:10px 0 0;font-size:0.8em;color:var(--text-muted)">Access follows the role. Everything ${escapeHtml(name)} has already done stays recorded against ${escapeHtml(name)} under the role held at the time.</p>
    `, [
      { label: 'Cancel', className: 'secondary', onClick: closeModal },
      { label: assigned ? 'Reassign' : 'Assign Role', onClick: async () => {
        const newRole = byId('assignRoleSelect')?.value || '';
        const note = byId('assignRoleNote')?.value?.trim() || '';
        if (!newRole) return showToast('Select a role');
        if (newRole === curRole) return showToast(`${name} already holds this role`);
        const issues = getRoleChangeIssues(st, newRole);
        if (issues.blockers.length) return showToast(issues.blockers[0]);
        if (assigned && !note) return showToast('Enter a reason for the reassignment');
        const actor = currentStaff();
        const submitBtn = document.querySelector('.modal-actions button:last-child');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Saving…'; }
        try {
          let result = null;
          if (isSupabaseApprovalMode() && gateway.staff?.assignStaffRole) {
            result = await gateway.staff.assignStaffRole({
              staffId: st.id, roleCode: newRole, note,
              assignedByStaffId: actor?.id || null, assignedByName: actor?.name || null,
            });
            if (!result?.ok) {
              showToast(`Error: ${result?.error?.message || 'Could not assign role'}`);
              if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = assigned ? 'Reassign' : 'Assign Role'; }
              return;
            }
          }
          // 2026-11-11 (client): extra roles can be chosen at the same time as the main role.
          const extras = newRole === UNASSIGNED_ROLE ? [] : qq('[data-assign-extra]').filter(el => el.checked && el.dataset.assignExtra !== newRole).map(el => el.dataset.assignExtra);
          let extrasSaved = true;
          let extrasWarn = '';
          if (isSupabaseApprovalMode() && (extras.length || staffExtraRoleCodes(st).length)) {
            const er = await gateway.adminx?.setExtraRoles?.(st.id, extras, actor?.name || '');
            if (!er?.ok) { extrasSaved = false; extrasWarn = er?.error?.code === 'TABLE_MISSING' ? 'Run the staff-extra-roles SQL script in Supabase to save additional roles' : (er?.error?.message || 'Additional roles were not saved'); }
          }
          const fromLabel = roleLabelOf(curRole);
          applyLocalRoleChange(st, newRole, note, actor);
          if (extrasSaved) st.extraRoles = extras;
          save();
          if (isSupabaseApprovalMode()) await syncStaffFromGateway(); // pull server truth (staff + history)
          const action = newRole === UNASSIGNED_ROLE ? 'staff_role_removed' : (assigned ? 'staff_role_changed' : 'staff_role_assigned');
          pushAudit(action, `${name} (${st.staffCode || st.staff_code || ''}): ${fromLabel} → ${roleLabelOf(newRole)}${note ? `. Reason: ${note}` : ''}`);
          const op = result?.data?.operationalAccount;
          if (op) {
            await syncCustomersListFromGateway();
            pushAudit(result.data.operationalAccountReused ? 'operational_account_reused' : 'operational_account_opened', `Operational account ${op.account_number || op.accountNumber || ''} ${result.data.operationalAccountReused ? 're-used for' : 'auto-opened for'} ${name}`);
          } else if (result?.data?.operationalAccountError) {
            showToast(`Role assigned, but operational account setup failed: ${result.data.operationalAccountError}. Open it manually.`);
          }
          closeModal();
          render();
          showToast(extrasWarn ? `${name} is now ${roleLabelOf(newRole)}, but: ${extrasWarn}` : `✓ ${name} is now ${staffRoleLabels(st)}`);
        } catch (err) {
          showToast('Unexpected error assigning role');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = assigned ? 'Reassign' : 'Assign Role'; }
        }
      } }
    ]);
    const sel = byId('assignRoleSelect');
    const box = byId('assignRoleIssues');
    const paint = () => {
      const v = sel?.value || '';
      qq('[data-assign-extra]').forEach(cb => {
        const same = cb.dataset.assignExtra === v;
        if (same) cb.checked = false;
        cb.disabled = same || v === UNASSIGNED_ROLE;
        if (v === UNASSIGNED_ROLE) cb.checked = false;
        const row = cb.closest('label'); if (row) row.style.opacity = cb.disabled ? '.4' : '1';
      });
      if (!box) return;
      if (!v) { box.innerHTML = ''; return; }
      const iss = getRoleChangeIssues(st, v);
      box.innerHTML = [
        ...iss.blockers.map(t => `<div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:6px;padding:8px;margin-bottom:6px">⛔ ${escapeHtml(t)}</div>`),
        ...iss.warnings.map(t => `<div style="background:#fff8f0;border:1px solid #fbbf24;border-radius:6px;padding:8px;margin-bottom:6px">⚠ ${escapeHtml(t)}</div>`),
        ...iss.infos.map(t => `<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:8px;margin-bottom:6px">ℹ ${escapeHtml(t)}</div>`)
      ].join('');
    };
    if (sel) sel.onchange = paint;
  }

  async function openRoleHistoryModal(staffId) {
    const st = (state.staff || []).find(x => x.id === staffId);
    if (!st) return;
    if (isSupabaseApprovalMode()) await syncRoleAssignmentsFromGateway();
    const hist = getStaffRoleHistory(st.id);
    const rows = hist.length
      ? hist.slice().reverse().map(a => `<tr><td>${escapeHtml(roleLabelOf(a.roleCode))}${a.endedAt ? '' : ' <span style="font-size:0.8em;color:#065f46">(current)</span>'}</td><td>${fmtDateTime(a.assignedAt)}</td><td>${a.endedAt ? fmtDateTime(a.endedAt) : '—'}</td><td>${escapeHtml(a.assignedByName || '—')}</td><td style="font-size:12px">${escapeHtml(a.note || '—')}</td></tr>`).join('')
      : `<tr><td>${escapeHtml(roleLabelOf(staffRoleCode(st)))} <span style="font-size:0.8em;color:#065f46">(current)</span></td><td colspan="4" style="font-size:12px;color:var(--text-muted)">No role changes recorded — this is the role held since before role history was tracked.</td></tr>`;
    openModal(`Role History — ${st.name || st.full_name || ''}`, `
      <div class="table-wrap"><table class="table"><thead><tr><th>Role</th><th>From</th><th>To</th><th>Assigned By</th><th>Reason</th></tr></thead><tbody>${rows}</tbody></table></div>
      <p style="margin:10px 0 0;font-size:0.8em;color:var(--text-muted)">Transactions, approvals and audit entries by this staff member are tied to them; the role shown against each is the one they held at that time.</p>
    `, [{ label: 'Close', onClick: closeModal }]);
  }

  function bindStaffDirectory() {
    // REDESIGN 2026-08-14: staff_directory now shows Staff Salary Balance —
    // fetch fresh data on demand, same pattern used elsewhere for on-demand
    // reads. Guarded to only run when this tool (not staff_roster, which
    // shares this bind function) is the active screen.
    if (state.ui.tool === 'staff_directory') {
      const staffSalarySearch = byId('staffSalarySearch');
      if (staffSalarySearch) staffSalarySearch.oninput = debounce(() => {
        state.ui.staffSalarySearch = staffSalarySearch.value || '';
        save();
        renderWorkspace();
      }, 200);
      if (!state.ui.staffSalaryAccountsCache && !state.ui.staffSalaryBalanceLoading && gateway.customers?.listStaffSalaryAccounts) {
        state.ui.staffSalaryBalanceLoading = true;
        renderWorkspace();
        (async () => {
          try {
            const result = await gateway.customers.listStaffSalaryAccounts();
            state.ui.staffSalaryAccountsCache = result?.ok ? (result.data || []) : [];
            if (!result?.ok) showToast(result?.error?.message || 'Unable to load staff salary accounts');
          } catch (err) {
            state.ui.staffSalaryAccountsCache = [];
            showToast('Unexpected error loading staff salary accounts');
          } finally {
            state.ui.staffSalaryBalanceLoading = false;
            if (state.ui.tool === 'staff_directory') renderWorkspace();
          }
        })();
      }
      return;
    }
    const addBtn = byId('addStaffBtn');
    const backfillBtn = byId('backfillTreasuryAccountsBtn');
    if (backfillBtn) backfillBtn.onclick = async () => {
      if (!gateway.staff?.backfillTreasuryOperationalAccounts) return showToast('Not available');
      backfillBtn.disabled = true;
      backfillBtn.textContent = 'Working…';
      try {
        const result = await gateway.staff.backfillTreasuryOperationalAccounts();
        // SURGICAL FIX 2026-09-08: a toast is too easy to miss and too short
        // to hold a real diagnostic — show a persistent modal with exactly
        // what happened (found/created/skipped/errors) so a run that
        // doesn't do what's expected can actually be diagnosed instead of
        // just "it still doesn't work".
        if (!result?.ok) {
          openModal('Backfill Failed', `<div class="note">${escapeHtml(result?.error?.message || 'Unknown error')}</div>`, [{ label: 'Close', className: 'secondary', onClick: closeModal }]);
          return;
        }
        const { created = [], skipped = [], errors = [] } = result.data || {};
        if (created.length) await syncCustomersListFromGateway();
        const totalFound = created.length + skipped.length + errors.length;
        const body = `
          <div class="stack">
            <div class="note">${totalFound === 0 ? 'No active Treasury or Admin Officer staff found at all — check that their role is set correctly in Staff Directory.' : `Found ${totalFound} Treasury/Admin staff member${totalFound === 1 ? '' : 's'} total.`}</div>
            ${created.length ? `<div><strong>Opened (${created.length}):</strong><ul>${created.map(c => `<li>${escapeHtml(c.name)} — ${escapeHtml(c.accountNumber || '(no number returned)')}</li>`).join('')}</ul></div>` : ''}
            ${skipped.length ? `<div><strong>Already had one (${skipped.length}):</strong><ul>${skipped.map(n => `<li>${escapeHtml(n)}</li>`).join('')}</ul></div>` : ''}
            ${errors.length ? `<div><strong style="color:var(--accent-red)">Failed (${errors.length}):</strong><ul>${errors.map(e => `<li>${escapeHtml(e)}</li>`).join('')}</ul></div>` : ''}
          </div>`;
        openModal('Backfill Result', body, [{ label: 'Close', className: 'secondary', onClick: closeModal }]);
        render();
      } catch (err) {
        openModal('Backfill Failed', `<div class="note">Unexpected error: ${escapeHtml(err?.message || String(err))}</div>`, [{ label: 'Close', className: 'secondary', onClick: closeModal }]);
      } finally {
        backfillBtn.disabled = false;
        backfillBtn.textContent = 'Backfill Operational Accounts';
      }
    };
    if (addBtn) addBtn.onclick = () => {
      openModal('Onboard New Staff', `
      <div class="form-grid two" style="gap:12px">
        <div class="field"><label>Full Name <span style="color:red">*</span></label><input id="newStaffName" class="entry-input"></div>
        <div class="field"><label>Staff ID / Login ID <span style="color:red">*</span></label><input id="newStaffCode" class="entry-input" style="text-transform:uppercase" maxlength="10"></div>
        <div class="field"><label>Temporary Password <span style="color:red">*</span></label>${passwordInputRow('<input id="newStaffPassword" class="entry-input" type="password">', 'newStaffPassword')}</div>
        <div class="field" style="grid-column:1/-1"><label>Branch (optional)</label><input id="newStaffBranch" class="entry-input"></div>
      </div>
      <p style="margin:10px 0 0;font-size:0.82em;color:var(--text-muted)"><strong>Adding staff does not give any access.</strong> Once created, assign a role (Staff Directory → Assign Role) — their access depends entirely on the role they are given, and roles can be reassigned later.</p>
      <p style="margin:6px 0 0;font-size:0.82em;color:var(--text-muted)">Staff will log in using their Staff ID and this password. Keep it short and memorable. They can change their password after first login.</p>
    `,[
      {label:'Cancel', className:'secondary', onClick: closeModal},
      {label:'Create Staff Account', onClick: async () => {
        const name = byId('newStaffName')?.value?.trim();
        const codeRaw = byId('newStaffCode')?.value?.trim();
        const staffCode = codeRaw ? codeRaw.toUpperCase() : '';
        // Role/staff separation: staff are created with NO role; a role is
        // assigned afterwards (openAssignRoleModal).
        const role = UNASSIGNED_ROLE;
        const password = byId('newStaffPassword')?.value;
        const branch = byId('newStaffBranch')?.value?.trim() || null;

        if (!name) return showToast('Enter staff full name');
        if (!staffCode) return showToast('Enter a Staff ID / login ID');
        if (staffCode.length > 10) return showToast('Staff ID must be 10 characters or fewer');
        if (!password || password.length < 6) return showToast('Password must be at least 6 characters');
        if (state.staff.some(s => (s.staffCode || s.staff_code || s.staffId || s.id || '').toUpperCase() === staffCode)) {
          return showToast(`Staff ID "${staffCode}" already exists`);
        }

        const submitBtn = document.querySelector('.modal-actions button:last-child');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Creating…'; }

        try {
          let newStaffRecord = null;
          if (isSupabaseApprovalMode() && gateway.staff?.createStaff) {
            const currentStaff = state.staff.find(s => s.id === state.activeStaffId);
            const result = await gateway.staff.createStaff({
              staffCode,
              name,
              fullName: name,
              role,
              roleCode: role,
              branchId: branch,
              temporaryPassword: password,
              createdByStaffId: currentStaff?.id || null,
              createdByName: currentStaff?.name || null,
            });
            if (!result.ok) {
              showToast(`Error: ${result.error?.message || 'Could not create staff'}`);
              if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Create Staff Account'; }
              return;
            }
            newStaffRecord = { id: result.data?.id || result.data?.staffId || uid('st'), staffCode, name, role, active: true, ...(result.data || {}) };
          } else {
            // Local fallback
            newStaffRecord = { id: uid('st'), staffCode, name, role, active: true };
          }

          const loginCheck = newStaffRecord.loginCheck || null;
          delete newStaffRecord.loginCheck;
          state.staff.push(newStaffRecord);
          ensureStaffAccount(newStaffRecord.id);
          save();
          // SURGICAL PATCH 2026-08-13: staff creation was never recorded in
          // the audit trail — every other state-changing action calls
          // pushAudit(), this one was missed. The gateway also attempts a
          // server-side audit insert, but it's fire-and-forget and its result
          // is never checked, so this local entry is the reliable record.
          pushAudit('staff_created', `${name} (${staffCode}) added — no role assigned yet`);
          // SURGICAL PATCH 2026-08-14: tellers now get their operational
          // account auto-provisioned by the gateway at creation time (no more
          // separate Account Opening + approval step — see gateway.staff.createStaff).
          // SURGICAL ADDITION 2026-09-05: Treasury (cash_officer) gets the same
          // auto-provisioning now, so this is no longer teller-only.
          // Pull the fresh customer list so the new account shows up
          // immediately, and log it as its own audit entry (distinct from
          // "staff_created") since it's a separate record being opened.
          if (newStaffRecord.operationalAccount?.account_number) {
            await syncCustomersListFromGateway();
            pushAudit('operational_account_opened', `Operational account ${newStaffRecord.operationalAccount.account_number} auto-opened for ${name}`);
          }
          closeModal();
          render();
          if (loginCheck?.status === 'failed') {
            // The account exists but the temporary password does NOT sign in. Say so now.
            openModal('Staff created — login test FAILED', `<div class="stack"><p>${escapeHtml(name)} (${escapeHtml(staffCode)}) was added, but signing in with the temporary password you set did not work, and the automatic repair did not fix it.</p><p><strong>Reason:</strong> ${escapeHtml(loginCheck.message || 'unknown')}</p><p>Open Staff Directory → Reset Password for this person. If the reset also fails, the message above is what to send to your developer.</p></div>`, [{ label: 'Close', onClick: closeModal }]);
            return;
          }
          showToast(loginCheck?.status === 'repaired'
            ? `✓ Staff "${name}" (${staffCode}) created — login was repaired and tested. Now assign a role`
            : `✓ Staff "${name}" (${staffCode}) created${loginCheck?.status === 'ok' ? ' — login tested OK' : ''} — now assign a role`);
          // Straight on to step two: give the new staff member a role.
          if (isAdminStaff()) openAssignRoleModal(newStaffRecord.id);
        } catch (err) {
          showToast('Unexpected error creating staff');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Create Staff Account'; }
        }
      }}
    ]);
      bindPasswordToggles(byId('modalBody') || document);
    hardenCredentialInputs(byId('modalBody') || document);
    };

    const adminRecoveryKeyBtn = byId('adminRecoveryKeyBtn');
    if (adminRecoveryKeyBtn) adminRecoveryKeyBtn.onclick = () => openAdminRecoveryKeyModal(false);
    const adminRecoveryKeyInlineBtn = byId('adminRecoveryKeyInlineBtn');
    if (adminRecoveryKeyInlineBtn) adminRecoveryKeyInlineBtn.onclick = () => openAdminRecoveryKeyModal(false);
    qq('[data-staff-reset-password]').forEach(btn => btn.onclick = () => openAdminResetPasswordModal(btn.dataset.staffResetPassword));
    qq('[data-staff-edit-code]').forEach(btn => btn.onclick = () => openEditStaffCodeModal(btn.dataset.staffEditCode));

    const staffDirectorySearch = byId('staffDirectorySearch');
    if (staffDirectorySearch) {
      staffDirectorySearch.oninput = debounce(() => {
        state.ui.staffDirectorySearch = staffDirectorySearch.value || '';
        save();
        renderWorkspace();
      }, 200);
    }
    qq('[data-staff-ledger]').forEach(btn => btn.onclick = () => openStaffLedgerModal(btn.dataset.staffLedger));
    qq('[data-staff-assign-role]').forEach(btn => btn.onclick = () => openAssignRoleModal(btn.dataset.staffAssignRole));
    qq('[data-staff-role-history]').forEach(btn => btn.onclick = () => openRoleHistoryModal(btn.dataset.staffRoleHistory));

    qq('[data-staff-toggle]').forEach(btn => btn.onclick = async () => {
      const st = state.staff.find(s => s.id === btn.dataset.staffToggle);
      if (!st) return;
      const isCurrentlyActive = st.active !== false && st.is_active !== false;

      if (isCurrentlyActive) {
        // Safety checks before deactivation
        const acc = ensureStaffAccount(st.id);
        const checks = [];
        if (Number(acc.balance || 0) !== 0) checks.push(`Outstanding FORM balance: ₦${money(acc.balance)}`);
        if (Number(acc.debtBalance || 0) > 0) checks.push(`Unpaid debt: ₦${money(acc.debtBalance)}`);
        const hasOpenCod = (state.cod || []).some(c => c.staffId === st.id && c.status === 'pending');
        if (hasOpenCod) checks.push('Unresolved COD submission');
        const hasPendingApprovals = (state.approvals || []).some(a => a.requestedByStaffId === st.id && a.status === 'pending');
        if (hasPendingApprovals) checks.push('Pending approval requests');

        if (checks.length > 0) {
          const blockers = checks.map(c => `• ${c}`).join('\n');
          openModal('Cannot Deactivate Staff', `
            <p style="margin:0 0 12px">Cannot deactivate <strong>${escapeHtml(st.name || st.full_name)}</strong> — the following must be resolved first:</p>
            <div style="background:var(--surface-alt,#fff8f0);border:1px solid #fbbf24;border-radius:6px;padding:12px;white-space:pre-line;font-size:0.9em">${escapeHtml(blockers)}</div>
          `, [{label:'OK', onClick: closeModal}]);
          return;
        }

        openModal('Confirm Deactivation', `
          <p>Are you sure you want to deactivate <strong>${escapeHtml(st.name || st.full_name)}</strong>?</p>
          <p style="font-size:0.85em;color:var(--text-muted)">Their login will be disabled. All historical records are preserved.</p>
          <div class="field" style="margin-top:10px"><label>Reason (optional)</label><input id="deactivateReason" class="entry-input"></div>
        `, [
          {label:'Cancel', className:'secondary', onClick: closeModal},
          {label:'Deactivate', onClick: async () => {
            const reason = byId('deactivateReason')?.value?.trim() || '';
            closeModal();
            if (isSupabaseApprovalMode() && gateway.staff?.updateStaffStatus) {
              const currentStaff = state.staff.find(s => s.id === state.activeStaffId);
              await gateway.staff.updateStaffStatus({
                staffId: st.id,
                isActive: false,
                reason,
                updatedByStaffId: currentStaff?.id || null,
                updatedByName: currentStaff?.name || null,
              });
            }
            st.active = false;
            st.is_active = false;
            if (state.activeStaffId === st.id) {
              const replacement = state.staff.find(s => s.id !== st.id && s.active !== false && s.is_active !== false);
              if (replacement) state.activeStaffId = replacement.id;
            }
            save(); render();
            showToast(`Staff "${st.name || st.full_name}" deactivated`);
          }}
        ]);
      } else {
        // Reactivation
        openModal('Reactivate Staff', `
          <p>Reactivate <strong>${escapeHtml(st.name || st.full_name)}</strong> and restore their login access?</p>
        `, [
          {label:'Cancel', className:'secondary', onClick: closeModal},
          {label:'Reactivate', onClick: async () => {
            closeModal();
            if (isSupabaseApprovalMode() && gateway.staff?.updateStaffStatus) {
              const currentStaff = state.staff.find(s => s.id === state.activeStaffId);
              await gateway.staff.updateStaffStatus({
                staffId: st.id,
                isActive: true,
                updatedByStaffId: currentStaff?.id || null,
                updatedByName: currentStaff?.name || null,
              });
            }
            st.active = true;
            st.is_active = true;
            save(); render();
            showToast(`Staff "${st.name || st.full_name}" reactivated`);
          }}
        ]);
      }
    });
  }

  function bindCustomerDirectory() {
    const searchInput = byId('customerDirectorySearch');
    if (!searchInput) return;

    const applySearch = () => {
      const value = searchInput.value || '';
      const start = searchInput.selectionStart ?? value.length;
      const end = searchInput.selectionEnd ?? value.length;
      state.ui.customerDirectorySearch = value;
      renderWorkspace();
      const nextInput = byId('customerDirectorySearch');
      if (nextInput) {
        nextInput.focus();
        try { nextInput.setSelectionRange(start, end); } catch (err) {}
      }
    };

    const persistSearch = () => save();

    searchInput.addEventListener('input', applySearch);
    searchInput.addEventListener('search', applySearch);
    searchInput.addEventListener('change', persistSearch);
    searchInput.addEventListener('blur', persistSearch);

    const closeBtn = byId('customerDirectoryCloseBtn');
    if (closeBtn) {
      closeBtn.onclick = () => {
        state.ui.tool = null;
        save();
        renderWorkspace();
      };
    }

    // Remove customer buttons
    qq('[data-remove-customer]').forEach(btn => {
      btn.onclick = () => {
        const customerId = btn.dataset.removeCustomer;
        const customer = state.customers.find(c => c.id === customerId);
        if (!customer) return;
        openModal('Remove Customer', `
          <p>Remove <strong>${escapeHtml(customer.name)}</strong> (${escapeHtml(customer.accountNumber || '—')}) from the active customer list?</p>
          <p style="font-size:0.85em;color:var(--text-muted)">All transaction history and audit records are preserved. This action can be reversed by Admin.</p>
        `, [
          { label: 'Cancel', className: 'secondary', onClick: closeModal },
          { label: 'Remove Customer', onClick: () => {
            customer.active = false;
            customer.removedAt = new Date().toISOString();
            save();
            closeModal();
            render();
            showToast(`${customer.name} removed from active list`);
          }}
        ]);
      };
    });
  }


  function makePasswordToggle(inputId, label='Show') {
    return `<button type="button" class="secondary tiny-btn" data-password-toggle="${inputId}" style="white-space:nowrap;padding:7px 10px;font-size:0.78em">${label}</button>`;
  }

  function bindPasswordToggles(root=document) {
    qq('[data-password-toggle]', root).forEach(btn => {
      if (btn.dataset.boundPasswordToggle === '1') return;
      btn.dataset.boundPasswordToggle = '1';
      btn.onclick = () => {
        const input = byId(btn.dataset.passwordToggle);
        if (!input) return;
        const showing = input.type === 'text';
        input.type = showing ? 'password' : 'text';
        btn.textContent = showing ? 'Show' : 'Hide';
      };
    });
  }

  function passwordInputRow(inputHtml, inputId) {
    return `<div style="display:flex;gap:6px;align-items:center">${inputHtml}${makePasswordToggle(inputId)}</div>`;
  }

  function hardenCredentialInputs(root=document) {
    qq('input[type="password"], #loginStaffId, [data-no-password-store]', root).forEach(input => {
      input.setAttribute('autocomplete', input.id === 'loginPassword' ? 'new-password' : 'off');
      input.setAttribute('autocorrect', 'off');
      input.setAttribute('autocapitalize', 'none');
      input.setAttribute('spellcheck', 'false');
      input.setAttribute('data-no-password-store', 'true');
      if (!input.name || /password|username|staff/i.test(input.name)) {
        input.name = `ducess_${input.id || 'credential'}_${Math.random().toString(36).slice(2,8)}`;
      }
    });
  }

  function openAdminRecoveryModal() {
    openModal('Admin Password Recovery', `
      <div class="grid two compact-grid">
        <div class="field"><label>Admin Staff ID</label><input id="recoverAdminStaffId" class="entry-input" type="text" autocomplete="username"></div>
        <div class="field"><label>Recovery Key</label>${passwordInputRow('<input id="recoverAdminCode" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'recoverAdminCode')}</div>
        <div class="field"><label>Temporary Password</label>${passwordInputRow('<input id="recoverAdminTempPassword" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'recoverAdminTempPassword')}</div>
        <div class="field"><label>Confirm Password</label>${passwordInputRow('<input id="recoverAdminTempConfirm" class="entry-input" type="password" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" data-no-password-store="true">', 'recoverAdminTempConfirm')}</div>
      </div>
      <p style="margin:8px 0 0;font-size:0.78em;color:var(--text-muted)">Use the Admin Recovery Key generated inside Administration. The key is shown once and should be stored offline. After reset, sign in with the temporary password and change it immediately.</p>
    `, [
      { label:'Cancel', className:'secondary', onClick: closeModal },
      { label:'Reset Admin Password', onClick: async () => {
        const staffCode = byId('recoverAdminStaffId')?.value?.trim() || '';
        const recoveryCode = byId('recoverAdminCode')?.value || '';
        const temporaryPassword = byId('recoverAdminTempPassword')?.value || '';
        const confirmPassword = byId('recoverAdminTempConfirm')?.value || '';
        if (!staffCode) return showToast('Enter Admin Staff ID');
        if (!recoveryCode) return showToast('Enter recovery key');
        if (!temporaryPassword || temporaryPassword.length < 6) return showToast('Temporary password must be at least 6 characters');
        if (temporaryPassword !== confirmPassword) return showToast('Passwords do not match');
        const submitBtn = q('#modalActions button:not(.secondary)');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Resetting…'; }
        try {
          const result = await gateway.auth?.recoverAdminPassword?.({ staffCode, recoveryCode, temporaryPassword });
          if (!result?.ok) {
            showToast(result?.error?.message || 'Admin recovery reset failed');
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Reset Admin Password'; }
            return;
          }
          closeModal();
          showToast('✓ Admin password reset. Sign in with the temporary password.');
        } catch (err) {
          showToast('Admin recovery reset failed');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Reset Admin Password'; }
        }
      }}
    ]);
    bindPasswordToggles(byId('modalBody') || document);
    hardenCredentialInputs(byId('modalBody') || document);
  }

  // ===== LOGIN SCREEN =====
  function showLoginScreen() {
    const screen = byId('loginScreen');
    if (screen) screen.classList.remove('hidden');
    const shell = document.querySelector('.shell');
    if (shell) shell.style.visibility = 'hidden';
  }

  function hideLoginScreen() {
    const screen = byId('loginScreen');
    if (screen) screen.classList.add('hidden');
    const shell = document.querySelector('.shell');
    if (shell) shell.style.visibility = '';
  }

  function bindLoginScreen() {
    const btn = byId('loginBtn');
    const staffInput = byId('loginStaffId');
    const passInput = byId('loginPassword');
    const errEl = byId('loginError');
    hardenCredentialInputs(byId('loginScreen') || document);
    if (staffInput) staffInput.value = '';
    if (passInput) passInput.value = '';
    if (!btn) return;
    if (passInput && !passInput.parentElement?.querySelector('[data-password-toggle="loginPassword"]')) {
      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.gap = '6px';
      row.style.alignItems = 'center';
      passInput.parentElement.insertBefore(row, passInput);
      row.appendChild(passInput);
      const toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.className = 'secondary tiny-btn';
      toggle.dataset.passwordToggle = 'loginPassword';
      toggle.style.whiteSpace = 'nowrap';
      toggle.style.padding = '7px 10px';
      toggle.style.fontSize = '0.78em';
      toggle.textContent = 'Show';
      row.appendChild(toggle);
    }
    if (btn.parentElement && !byId('loginPasswordTools')) {
      const tools = document.createElement('div');
      tools.id = 'loginPasswordTools';
      tools.style.display = 'flex';
      tools.style.alignItems = 'center';
      tools.style.justifyContent = 'space-between';
      tools.style.gap = '8px';
      tools.style.marginTop = '8px';

      const changeBtn = document.createElement('button');
      changeBtn.type = 'button';
      changeBtn.id = 'loginChangePasswordBtn';
      changeBtn.className = 'secondary tiny-btn';
      changeBtn.style.flex = '1';
      changeBtn.style.padding = '6px 8px';
      changeBtn.style.fontSize = '0.74em';
      changeBtn.textContent = 'Change password';
      changeBtn.onclick = openLoginChangePasswordModal;
      tools.appendChild(changeBtn);

      const recoverBtn = document.createElement('button');
      recoverBtn.type = 'button';
      recoverBtn.id = 'adminRecoveryBtn';
      recoverBtn.className = 'secondary tiny-btn';
      recoverBtn.style.flex = '1';
      recoverBtn.style.padding = '6px 8px';
      recoverBtn.style.fontSize = '0.74em';
      recoverBtn.textContent = 'Admin forgot password?';
      recoverBtn.onclick = openAdminRecoveryModal;
      tools.appendChild(recoverBtn);

      btn.parentElement.appendChild(tools);
    }
    bindPasswordToggles(byId('loginScreen') || document);
    hardenCredentialInputs(byId('loginScreen') || document);

    async function attemptLogin() {
      const staffId = (staffInput?.value || '').trim();
      const password = (passInput?.value || '').trim();
      if (!staffId || !password) {
        errEl.textContent = 'Please enter your Staff ID and password.';
        errEl.classList.remove('hidden');
        return;
      }
      btn.disabled = true;
      btn.textContent = 'Signing in…';
      errEl.classList.add('hidden');
      // SURGICAL FIX 2026-08-27: this had no try/catch around it — if
      // loginWithStaffId (or anything it calls) THREW instead of cleanly
      // resolving to {ok:false}, e.g. a network hiccup or timeout, the
      // button never got reset. It stayed stuck on "Signing in…" forever,
      // with the actual error going out as an unhandled promise rejection
      // that doesn't show up as a normal console message — exactly what
      // the screenshot showed (a red error-count badge, no visible auth
      // error). Now every path — success, a clean error, or an unexpected
      // throw — always resets the button and always shows something to
      // the person trying to log in.
      try {
        const result = await gateway.auth.loginWithStaffId({ staffId, password });
        if (!result.ok) {
          // 2026-11-02: say what actually went wrong — a just-added staff member
          // hitting a bad password is the common case.
          const raw = String(result.error?.message || '');
          errEl.textContent = /invalid login credentials/i.test(raw)
            ? 'Wrong Staff ID or password. If this staff member was just added, ask the admin to use Reset Password on them in Staff Directory.'
            : /not confirmed/i.test(raw)
              ? 'This login has not been confirmed in Supabase Auth yet — ask the admin/IT to confirm the user.'
              : (raw || 'Invalid Staff ID or password.');
          errEl.classList.remove('hidden');
          return;
        }
        // Signed in to Supabase Auth but no staff profile is linked to it —
        // previously this "succeeded" silently and left the person on a blank screen.
        if (isSupabaseApprovalMode() && !result.data?.staff?.id) {
          try { await gateway.auth?.logout?.(); } catch (_e) {}
          errEl.textContent = 'Signed in, but no staff profile is linked to this login. Ask the admin to check this staff member in Staff Directory.';
          errEl.classList.remove('hidden');
          return;
        }
        // Login success — wipe typed credentials from the DOM immediately.
        if (passInput) passInput.value = '';
        if (staffInput) staffInput.value = '';
        // Login success — set active staff from session
        const sessionStaff = result.data?.staff;
        if (sessionStaff?.id) {
          state.activeStaffId = sessionStaff.id;
          save();
        }
        // SURGICAL PATCH 2026-08-18: state.ui.selectedCustomerId is shared
        // across Check Balance / Maintenance / Reactivation / Statement and
        // was never cleared on login — so a customer looked up in a PREVIOUS
        // session (possibly days earlier, by a different staff member on a
        // shared device) would silently resurface on Statement of Account
        // looking like a hardcoded "default customer". Reset per-session state
        // on every fresh login so nothing carries over.
        state.ui.selectedCustomerId = null;
        state.ui.checkBalanceLoaded = false;
        state.ui.accountStatementGenerated = false;
        save();
        hideLoginScreen();
        await syncStaffFromGateway();
        await syncApprovalsFromGateway();
        await syncCodFromGateway();
        await syncJournalsFromGateway().catch(() => {});
        render();
        ensureAdminTellerAccount();
        await enforceAdminRecoveryKeySetup();
        if (staffRoleCode(currentStaff()) === 'admin_officer') {
          loadStorageUsage().then(u => {
            const pct = u?.ok ? Math.round(Number(u.database_bytes || 0) / STORAGE_LIMIT_BYTES * 100) : 0;
            if (pct >= 80) showToast(`Database space ${pct}% used — see ICT Unit → Data Backup.`);
          }).catch(() => {});
        }
      } catch (err) {
        console.warn('[DUCESS] Login failed with an unexpected error', err);
        errEl.textContent = 'Sign-in failed unexpectedly — check your connection and try again.';
        errEl.classList.remove('hidden');
      } finally {
        btn.disabled = false;
        btn.textContent = 'Sign In';
      }
    }

    btn.onclick = attemptLogin;
    passInput.onkeydown = (e) => { if (e.key === 'Enter') attemptLogin(); };
    staffInput.onkeydown = (e) => { if (e.key === 'Enter') passInput?.focus(); };
  }
  // ===== END LOGIN SCREEN =====

  // 2026-11-09 (client): the Admin has a Teller account by default. If the signed-in
  // Admin has none yet, one is opened automatically (once per session).
  let adminTellerEnsured = false;
  async function ensureAdminTellerAccount() {
    const st = currentStaff();
    if (!st || adminTellerEnsured || staffRoleCode(st) !== 'admin_officer') return;
    if (staffOperationalAccountNumber(st.id)) { adminTellerEnsured = true; return; }
    adminTellerEnsured = true;
    try {
      if (isSupabaseApprovalMode()) {
        if (!gateway?.staff?.backfillTreasuryOperationalAccounts) return;
        const res = await gateway.staff.backfillTreasuryOperationalAccounts();
        if (res?.ok && (res.data?.created || []).length) { await syncCustomersListFromGateway(); render(); }
      } else {
        const num = await gateway?.customers?.generateSystemAccountNumber?.('staff_operational');
        const accountNumber = num?.ok ? num.data : '';
        if (!accountNumber) return;
        const first = String(st.name || '').trim().split(/\s+/)[0] || st.name || 'Admin';
        state.customers.push({ id: uid('c'), accountNumber, name: `ADMIN ${first}`, accountType: 'staff_operational', linkedStaffId: st.id, balance: 0, phone: '', active: true, createdAt: new Date().toISOString(), transactions: [], systemAssigned: true });
        save(); render();
      }
    } catch (_e) { /* non-blocking: Staff Directory > Backfill Operational Accounts still works */ }
  }

  function startApp() {
    try {
      const navEntry = performance.getEntriesByType?.('navigation')?.[0];
      if (navEntry?.type === 'reload') {
        state.ui.module = null;
        state.ui.tool = null;
        save();
      }
    } catch (err) {}
    applyTheme(state.ui.theme || 'classic', false);
    bindLoginScreen();
    window.addEventListener('pageshow', () => {
      const login = byId('loginScreen');
      if (login && !login.classList.contains('hidden')) {
        if (byId('loginStaffId')) byId('loginStaffId').value = '';
        if (byId('loginPassword')) byId('loginPassword').value = '';
        hardenCredentialInputs(login);
      }
    }, { once: true });

    if (isSupabaseApprovalMode()) {
      // Security rule: never restore a previous terminal session after refresh/reopen.
      // The shell may render behind the login overlay, but staff must sign in again.
      gateway.auth?.logout?.().catch(() => {});
      state.ui.module = null;
      state.ui.tool = null;
      save();
      showLoginScreen();
      render();
    } else {
      // Local mode — skip login
      render();
      ensureAdminTellerAccount();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApp, { once: true });
  } else {
    startApp();
  }
})();



