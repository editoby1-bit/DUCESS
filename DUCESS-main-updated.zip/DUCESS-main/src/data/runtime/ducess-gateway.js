(function (global) {
  console.log("DUCESS GATEWAY LOADED", Date.now());
  const defaultResult = {
    ok(data) { return { ok: true, data }; },
    err(code, message, details) { return { ok: false, error: { code, message, details } }; }
  };

  
  async function resolveStaffUuid(client, localId) {
    if (!localId) return null;
    // if already a UUID, return as-is
    if (/^[0-9a-f-]{36}$/i.test(localId)) return localId;
    try {
      const { data } = await client
        .from('staff')
        .select('id, staff_code')
        .eq('staff_code', localId)
        .maybeSingle();
      // return the real UUID if found, otherwise null (never pass a non-UUID to a UUID column)
      return data?.id || null;
    } catch (e) {
      return null;
    }
  }
const ROLE_DEFAULT_TOOLS = {
    customer_service: ['check_balance','account_opening','account_maintenance','account_reactivation','account_statement'],
    teller: ['check_balance','account_statement','credit','debit'],
    approving_officer: ['check_balance','account_statement','credit','debit','approval_queue','business_balance','operational_balance'],
    admin_officer: ['check_balance','account_opening','account_maintenance','account_reactivation','account_statement','credit','debit','approval_queue','permissions','operational_accounts','staff_directory','business_balance','operational_balance','teller_balances'],
    report_officer: ['check_balance','account_statement','business_balance','operational_balance','teller_balances']
  };

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function mergeConfig(options = {}) {
    const runtimeConfig = global.__DUCESS_CONFIG__ || {};
    return {
      ...runtimeConfig,
      ...options,
      supabase: {
        ...(runtimeConfig.supabase || {}),
        ...(options.supabase || {}),
      }
    };
  }

  // ROLE/STAFF SEPARATION 2026-10-11: roles that carry an operational
  // (cash) account, and the account-name convention for each. Shared by
  // createStaff (legacy role-at-creation path) and assignStaffRole.
  // 2026-10-24: Treasury (cash_officer) no longer gets a personal operational
  // account — Treasury accounts are business accounts opened in Account Opening.
  // 2026-10-29 (client): a Teller Account is NOT opened automatically when the
  // Teller role is assigned any more — Customer Service opens it in Account
  // Opening > Teller Account (so the newly assigned teller appears in that list).
  const CASH_ROLES = ['admin_officer'];
  function operationalDisplayName(roleCode, fullName) {
    const firstName = String(fullName || '').trim().split(/\s+/)[0] || fullName;
    return roleCode === 'cash_officer' ? `TREASURY ${firstName}` : roleCode === 'admin_officer' ? `ADMIN ${firstName}` : `TELLER ${fullName}`;
  }
  function normalizeRoleAssignment(raw) {
    if (!raw) return null;
    return {
      id: raw.id,
      staffId: raw.staffId || raw.staff_id || '',
      roleCode: raw.roleCode || raw.role_code || raw.role || 'unassigned',
      assignedAt: raw.assignedAt || raw.assigned_at || '',
      endedAt: raw.endedAt || raw.ended_at || null,
      assignedByStaffId: raw.assignedByStaffId || raw.assigned_by_staff_id || null,
      assignedByName: raw.assignedByName || raw.assigned_by_name || '',
      endedByStaffId: raw.endedByStaffId || raw.ended_by_staff_id || null,
      note: raw.note || '',
    };
  }

  function buildDefaultPermissions(roleCode) {
    return (ROLE_DEFAULT_TOOLS[roleCode] || []).map((toolCode) => ({
      toolCode,
      allowed: true,
      source: 'role'
    }));
  }

  function normalizeStaffSummary(rawStaff) {
    if (!rawStaff) return null;
    return {
      id: rawStaff.id,
      staffId: rawStaff.staffId || rawStaff.staff_code || rawStaff.code || '',
      fullName: rawStaff.fullName || rawStaff.full_name || rawStaff.name || '',
      // ROLE/STAFF SEPARATION 2026-10-11: a staff row with no role is
      // 'unassigned' (no access) — it no longer silently defaults to
      // customer_service. Role is granted separately via assignStaffRole.
      roleCode: rawStaff.roleCode || rawStaff.role_code || rawStaff.role || 'unassigned',
      isActive: typeof rawStaff.isActive === 'boolean' ? rawStaff.isActive : (typeof rawStaff.is_active === 'boolean' ? rawStaff.is_active : rawStaff.active !== false),
      branchId: rawStaff.branchId ?? rawStaff.branch_id ?? null,
      uuid: rawStaff.uuid || rawStaff.id || '',
      authUserId: rawStaff.authUserId || rawStaff.auth_user_id || '',
      authEmail: rawStaff.authEmail || rawStaff.auth_email || '',
    };
  }

  function normalizeStaffSession(sessionToken, expiresAt, rawStaff, permissions) {
    const staff = normalizeStaffSummary(rawStaff);
    if (!staff) return null;
    return {
      sessionToken: sessionToken || undefined,
      expiresAt: expiresAt || undefined,
      staff,
      permissions: Array.isArray(permissions) ? permissions : buildDefaultPermissions(staff.roleCode),
    };
  }


  function normalizeTempGrantRecord(rawGrant) {
    if (!rawGrant) return null;
    return {
      id: rawGrant.id,
      staffId: rawGrant.staffId || rawGrant.staff_id || '',
      toolCode: rawGrant.toolCode || rawGrant.tool_code || '',
      startsAt: rawGrant.startsAt || rawGrant.starts_at || undefined,
      endsAt: rawGrant.endsAt || rawGrant.ends_at || undefined,
      note: rawGrant.note || '',
      enabled: typeof rawGrant.enabled === 'boolean' ? rawGrant.enabled : rawGrant.is_enabled !== false,
      grantedByStaffId: rawGrant.grantedByStaffId || rawGrant.granted_by_staff_id || undefined,
    };
  }


  function normalizeLocalTransaction(rawTx) {
    if (!rawTx) return null;
    return {
      id: rawTx.id,
      type: rawTx.type || rawTx.txType || rawTx.tx_type || 'credit',
      amount: Number(rawTx.amount || 0),
      details: rawTx.details || rawTx.note || '',
      postedBy: rawTx.postedBy || rawTx.posted_by || '',
      postedById: rawTx.postedById || rawTx.posted_by_id || '',
      approvedBy: rawTx.approvedBy || rawTx.approved_by || null,
      counterparty: rawTx.counterparty || rawTx.channel || '',
      // 2026-11-09: keep who received/paid the money so the statement can show it.
      ...(rawTx.receivedOrPaidBy || rawTx.received_or_paid_by ? { receivedOrPaidBy: rawTx.receivedOrPaidBy || rawTx.received_or_paid_by } : {}),
      date: rawTx.date || rawTx.effective_at || rawTx.created_at || new Date().toISOString(),
      balanceAfter: rawTx.balanceAfter ?? rawTx.balance_after ?? null,
      // Fix B 2026-10-22: summary ("brought forward") rows keep their markers.
      ...(rawTx.__bf ? { __bf: true, __count: Number(rawTx.__count || 1) } : {}),
    };
  }

  function normalizeCustomerRecord(rawCustomer) {
    if (!rawCustomer) return null;
    const transactions = Array.isArray(rawCustomer.transactions)
      ? rawCustomer.transactions.map(normalizeLocalTransaction).filter(Boolean)
      : [];
    let balance = Number(rawCustomer.balance ?? rawCustomer.book_balance ?? rawCustomer.bookBalance ?? 0);
    if ((!Number.isFinite(balance) || balance === 0) && transactions.length) {
      balance = transactions.reduce((sum, tx) => sum + (tx.type === 'credit' ? Number(tx.amount || 0) : -Number(tx.amount || 0)), 0);
    }
    return {
      id: rawCustomer.id,
      customerNumber: rawCustomer.customerNumber ?? rawCustomer.customer_number ?? null,
      accountNumber: String(rawCustomer.accountNumber ?? rawCustomer.account_number ?? ''),
      oldAccountNumber: rawCustomer.oldAccountNumber ?? rawCustomer.old_account_number ?? '',
      name: rawCustomer.name || rawCustomer.fullName || rawCustomer.full_name || '',
      address: rawCustomer.address || '',
      nin: rawCustomer.nin || '',
      bvn: rawCustomer.bvn || '',
      phone: rawCustomer.phone || '',
      balance,
      photo: rawCustomer.photo || rawCustomer.photo_path || '',
      active: typeof rawCustomer.active === 'boolean'
        ? rawCustomer.active
        : (typeof rawCustomer.is_active === 'boolean'
          ? rawCustomer.is_active
          : !['inactive', 'dormant', 'closed', 'frozen'].includes(String(rawCustomer.status || '').toLowerCase())),
      createdAt: rawCustomer.createdAt || rawCustomer.created_at || new Date().toISOString(),
      // 2026-10-21: keep the raw status so the app can tell a blocked
      // ('frozen') account from a closed one — 'active' alone can't.
      accountStatus: String(rawCustomer.accountStatus || rawCustomer.status || (rawCustomer.closed ? 'closed' : (rawCustomer.frozen ? 'frozen' : ''))).toLowerCase(),
      transactions,
      staffId: rawCustomer.staffId || rawCustomer.staff_id || rawCustomer.linkedStaffId || rawCustomer.linked_staff_id || null,
      accountType: rawCustomer.accountType || rawCustomer.account_type || 'customer',
    };
  }

  function customerToSummary(customer) {
    const normalized = normalizeCustomerRecord(customer);
    if (!normalized) return null;
    return {
      id: normalized.id,
      customerNumber: normalized.customerNumber,
      accountNumber: normalized.accountNumber,
      fullName: normalized.name,
      phone: normalized.phone || null,
      status: normalized.active ? 'active' : 'inactive',
      accountStatus: normalized.accountStatus,
      linkedStaffId: normalized.staffId || null,
      oldAccountNumber: normalized.oldAccountNumber,
      address: normalized.address,
      nin: normalized.nin,
      bvn: normalized.bvn,
      balance: normalized.balance,
      photo: normalized.photo,
      active: normalized.active,
      createdAt: normalized.createdAt,
      transactions: normalized.transactions,
      accountType: normalized.accountType,
      name: normalized.name,
    };
  }

  function customerToAccountSummary(customer) {
    const normalized = normalizeCustomerRecord(customer);
    if (!normalized) return null;
    return {
      accountId: normalized.id,
      accountNumber: normalized.accountNumber,
      customerId: normalized.id,
      customerName: normalized.name,
      status: normalized.active ? 'active' : 'inactive',
      bookBalance: Number(normalized.balance || 0),
    };
  }

  function normalizeStatementEntry(rawTx) {
    const tx = normalizeLocalTransaction(rawTx);
    if (!tx) return null;
    return {
      id: tx.id,
      txType: tx.type === 'debit' ? 'debit' : 'credit',
      amount: Number(tx.amount || 0),
      details: tx.details || '',
      date: tx.date,
      balanceAfter: tx.balanceAfter ?? null,
    };
  }

  function normalizeCodSubmissionRecord(row) {
    if (!row) return null;
    return {
      id: String(row.id || ''),
      staffId: row.staffId || row.staff_id || '',
      businessDate: row.businessDate || row.business_date || row.date || '',
      date: row.businessDate || row.business_date || row.date || '',
      openingBalance: Number(row.openingBalance ?? row.opening_balance ?? 0),
      formAmount: Number(row.formAmount ?? row.openingBalance ?? row.opening_balance ?? 0),
      floatTopUps: Number(row.floatTopUps ?? row.float_topups ?? 0),
      effectiveOpeningBalance: Number(row.effectiveOpeningBalance ?? row.effective_opening_balance ?? 0),
      totalCredits: Number(row.totalCredits ?? row.total_credits ?? 0),
      totalDebits: Number(row.totalDebits ?? row.total_debits ?? 0),
      netBookBalance: Number(row.netBookBalance ?? row.net_book_balance ?? 0),
      remainingBalance: Number(row.remainingBalance ?? row.remaining_balance ?? 0),
      expectedCash: Number(row.expectedCash ?? row.expected_cash ?? 0),
      actualCash: Number(row.actualCash ?? row.actual_cash ?? 0),
      variance: Number(row.variance ?? 0),
      overdraw: row.overdraw != null ? Number(row.overdraw) : Math.max(0, -(Number(row.remainingBalance ?? row.remaining_balance ?? 0))),
      note: row.note || '',
      status: row.status || 'submitted',
      submittedByStaffId: row.submittedByStaffId || row.submitted_by_staff_id || null,
      submittedAt: row.submittedAt || row.submitted_at || undefined,
      resolutionNote: row.resolutionNote || row.resolution_note || '',
      acceptedPosition: Number(row.acceptedPosition ?? row.final_agreed_amount ?? row.finalAgreedAmount ?? row.net_book_balance ?? 0),
      adjustment: Number(row.adjustment ?? row.adjustment_amount ?? 0),
      debtAmount: Number(row.debtAmount ?? row.debt_amount ?? 0),
      resolvedBy: row.resolvedBy || row.resolved_by_name || row.resolved_by_staff_id || null,
      resolvedAt: row.resolvedAt || row.resolved_at || undefined,
      runningFloat: Number(row.runningFloat ?? row.remaining_balance ?? row.remainingBalance ?? 0),
    };
  }

  function normalizeDebtRecord(row) {
    if (!row) return null;
    return {
      id: String(row.id || ''),
      staffId: row.staffId || row.staff_id || '',
      businessDate: row.businessDate || row.business_date || '',
      amount: Number(row.amount || 0),
      status: row.status || 'open',
      sourceCodSubmissionId: row.sourceCodSubmissionId || row.source_cod_submission_id || null,
      note: row.note || '',
      createdAt: row.createdAt || row.created_at || undefined,
      updatedAt: row.updatedAt || row.updated_at || undefined,
    };
  }

  async function getCodPreview(_payload) {
  return {
    ok: true,
    data: {
      openingBalance: 0,
      floatTopUps: 0,
      effectiveOpeningBalance: 0,
      totalCredits: 0,
      totalDebits: 0,
      netBookBalance: 0,
      remainingBalance: 0,
      expectedCash: 0
    }
  };
}

async function submitCod(_payload) {
  return {
    ok: true,
    data: {
      id: null,
      staffId: null,
      businessDate: null,
      openingBalance: 0,
      floatTopUps: 0,
      effectiveOpeningBalance: 0,
      totalCredits: 0,
      totalDebits: 0,
      netBookBalance: 0,
      remainingBalance: 0,
      expectedCash: 0,
      actualCash: 0,
      variance: 0,
      overdraw: 0,
      status: 'submitted'
    }
  };
}

async function listCodSubmissions(_filters) {
  return {
    ok: true,
    data: []
  };
}

async function getCodSubmissionById(_codId) {
  return {
    ok: true,
    data: null
  };
}

async function resolveCod(_payload) {
  return {
    ok: true,
    data: {
      id: null,
      codSubmissionId: null,
      finalAgreedAmount: 0,
      adjustment: 0,
      debtAmount: 0,
      resolutionNote: ''
    }
  };
}

async function listDebts(_filters) {
  return {
    ok: true,
    data: []
  };
}

async function getDebtById(_debtId) {
  return {
    ok: true,
    data: null
  };
}

async function submitDebtRepayment(_payload) {
  return {
    ok: true,
    data: null
  };
}
  
  function createLocalAdapter(options = {}) {
    const config = mergeConfig(options);
    const storageKey = config.storageKey || 'duces_enterprise_ledger_v1';
    const authStorageKey = `${storageKey}__gateway_auth`;

    const appState = {
      loadState() {
        try {
          const raw = global.localStorage.getItem(storageKey);
          return raw ? JSON.parse(raw) : null;
        } catch (error) {
          return null;
        }
      },
      saveState(state) {
        global.localStorage.setItem(storageKey, JSON.stringify(state));
      },
      bootstrapState(seedFactory) {
        const loaded = appState.loadState();
        return loaded || seedFactory();
      }
    };

    function readAuthSession() {
      try {
        const raw = global.localStorage.getItem(authStorageKey);
        return raw ? JSON.parse(raw) : null;
      } catch {
        return null;
      }
    }

    function writeAuthSession(session) {
      if (!session) {
        global.localStorage.removeItem(authStorageKey);
        return;
      }
      global.localStorage.setItem(authStorageKey, JSON.stringify(session));
    }

    function getLocalState() {
      return appState.loadState() || {};
    }

    function getLocalStaffRows() {
      const state = getLocalState();
      return Array.isArray(state.staff) ? state.staff : [];
    }

    function buildLocalSessionFromState(staffId) {
      const state = getLocalState();
      const allStaff = getLocalStaffRows();
      const target = allStaff.find((item) => item.id === staffId)
        || allStaff.find((item) => item.id === state.activeStaffId)
        || allStaff[0]
        || null;
      if (!target) return null;
      const normalized = normalizeStaffSummary(target);
      return normalizeStaffSession(`local-${normalized.id}`, undefined, normalized, buildDefaultPermissions(normalized.roleCode));
    }

    async function notYet(name) {
      return defaultResult.err('NOT_IMPLEMENTED', `${name} is skeleton-only in Phase 3B.3`);
    }

    async function getCurrentStaff() {
      const session = readAuthSession();
      if (session?.staff) return defaultResult.ok(normalizeStaffSummary(session.staff));
      const fallback = buildLocalSessionFromState();
      return defaultResult.ok(fallback?.staff || null);
    }

    async function getStaffById(staffId) {
      const match = getLocalStaffRows().find((item) => item.id === staffId || item.staffId === staffId || item.staff_code === staffId) || null;
      return defaultResult.ok(normalizeStaffSummary(match));
    }

    async function listStaff(filters = {}) {
      const normalizedRows = getLocalStaffRows().map(normalizeStaffSummary).filter(Boolean);
      const filtered = normalizedRows.filter((staff) => {
        if (filters.roleCode && staff.roleCode !== filters.roleCode) return false;
        if (typeof filters.isActive === 'boolean' && staff.isActive !== filters.isActive) return false;
        if (filters.search) {
          const q = String(filters.search).trim().toLowerCase();
          const hay = `${staff.fullName} ${staff.staffId}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });
      return defaultResult.ok(filtered);
    }

    async function listActiveStaff() {
      const result = await listStaff({ isActive: true });
      return result;
    }



    async function listStaffLedger(staffId, filters = {}) {
      const state = getLocalState();
      const acc = (state.staffAccounts || {})[staffId] || null;
      let rows = Array.isArray(acc?.entries) ? acc.entries : [];
      if (filters.startDate) rows = rows.filter((row) => String(row.floatDate || row.float_date || row.date || row.createdAt || row.created_at || '').slice(0,10) >= filters.startDate);
      if (filters.endDate) rows = rows.filter((row) => String(row.floatDate || row.float_date || row.date || row.createdAt || row.created_at || '').slice(0,10) <= filters.endDate);
      return defaultResult.ok(rows);
    }

    async function createStaff(payload = {}) {
      const state = getLocalState();
      state.staff ||= [];
      const id = `st_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-4)}`;
      const staff = {
        id,
        staffId: payload.staffCode || payload.staffId || id,
        staff_code: payload.staffCode || payload.staffId || id,
        name: payload.name || payload.fullName || '',
        fullName: payload.name || payload.fullName || '',
        role: payload.role || payload.roleCode || 'unassigned',
        role_code: payload.role || payload.roleCode || 'unassigned',
        branchId: payload.branchId || null,
        branch_id: payload.branchId || null,
        authEmail: payload.authEmail || '',
        auth_email: payload.authEmail || '',
        authUserId: payload.authUserId || '',
        auth_user_id: payload.authUserId || '',
        active: true,
        is_active: true,
        createdAt: new Date().toISOString(),
      };
      state.staff.push(staff);
      writeLocalState(state);
      return defaultResult.ok(normalizeStaffSummary(staff));
    }

    async function updateStaffStatus(payload = {}) {
      const state = getLocalState();
      const staffId = payload.staffId || payload.id;
      const staff = (state.staff || []).find((item) => item.id === staffId || item.staffId === staffId || item.staff_code === staffId);
      if (!staff) return defaultResult.err('STAFF_NOT_FOUND', 'Staff not found.');
      staff.active = payload.isActive !== false;
      staff.is_active = payload.isActive !== false;
      staff.updatedAt = new Date().toISOString();
      writeLocalState(state);
      return defaultResult.ok(normalizeStaffSummary(staff));
    }

    // ROLE/STAFF SEPARATION 2026-10-11 — local/offline adapter. Closes the
    // staff member's open assignment (if any), opens a new one and updates
    // the staff row's current role. Same history shape as the Supabase table.
    async function assignStaffRole(payload = {}) {
      const state = getLocalState();
      const staffId = payload.staffId || payload.id;
      const roleCode = String(payload.roleCode || payload.role || 'unassigned');
      const staff = (state.staff || []).find((item) => item.id === staffId || item.staffId === staffId || item.staff_code === staffId);
      if (!staff) return defaultResult.err('STAFF_NOT_FOUND', 'Staff not found.');
      const now = new Date().toISOString();
      state.roleAssignments ||= [];
      state.roleAssignments.forEach((a) => { if (a.staffId === staff.id && !a.endedAt) { a.endedAt = now; a.endedByStaffId = payload.assignedByStaffId || null; } });
      state.roleAssignments.push({ id: `ra_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-4)}`, staffId: staff.id, roleCode, assignedAt: now, endedAt: null, assignedByStaffId: payload.assignedByStaffId || null, assignedByName: payload.assignedByName || '', note: payload.note || '' });
      staff.role = roleCode;
      staff.role_code = roleCode;
      staff.updatedAt = now;
      writeLocalState(state);
      return defaultResult.ok(normalizeStaffSummary(staff));
    }

    async function listRoleAssignments() {
      const state = getLocalState();
      return defaultResult.ok((state.roleAssignments || []).map(normalizeRoleAssignment).filter(Boolean));
    }

    async function updateStaffCode(payload = {}) {
      const state = getLocalState();
      const staffId = payload.staffId || payload.id;
      const newCode = String(payload.staffCode || '').trim().toUpperCase();
      if (!newCode) return defaultResult.err('STAFF_CODE_REQUIRED', 'New Staff ID is required.');
      const staff = (state.staff || []).find((item) => item.id === staffId || item.staffId === staffId || item.staff_code === staffId);
      if (!staff) return defaultResult.err('STAFF_NOT_FOUND', 'Staff not found.');
      const clash = (state.staff || []).some((item) => item.id !== staff.id && String(item.staff_code || item.staffId || '').toUpperCase() === newCode);
      if (clash) return defaultResult.err('STAFF_CODE_TAKEN', `Staff ID "${newCode}" is already in use.`);
      staff.staffId = newCode;
      staff.staff_code = newCode;
      staff.updatedAt = new Date().toISOString();
      writeLocalState(state);
      return defaultResult.ok(normalizeStaffSummary(staff));
    }

    async function getEffectivePermissions(staffId) {
      const staffResult = await getStaffById(staffId);
      if (!staffResult.ok) return staffResult;
      const staff = staffResult.data;
      if (!staff) return defaultResult.ok([]);

      const state = getLocalState();
      const rolePerms = buildDefaultPermissions(staff.roleCode);
      const tempPerms = (Array.isArray(state.tempGrants) ? state.tempGrants : [])
        .map(normalizeTempGrantRecord)
        .filter(Boolean)
        .filter((grant) => grant.staffId === staff.id && grant.enabled !== false)
        .map((grant) => ({ toolCode: grant.toolCode, allowed: true, source: 'temp_grant' }));

      const merged = new Map();
      rolePerms.forEach((perm) => merged.set(`role:${perm.toolCode}`, perm));
      tempPerms.forEach((perm) => merged.set(`temp_grant:${perm.toolCode}`, perm));
      return defaultResult.ok(Array.from(merged.values()));
    }

    async function hasPermission(payload) {
      const permsResult = await getEffectivePermissions(payload?.staffId);
      if (!permsResult.ok) return permsResult;
      const allowed = permsResult.data.some((perm) => perm.toolCode === payload?.toolCode && perm.allowed !== false);
      return defaultResult.ok(allowed);
    }

    async function listTempGrants(staffId) {
      const grants = (Array.isArray(getLocalState().tempGrants) ? getLocalState().tempGrants : [])
        .map(normalizeTempGrantRecord)
        .filter(Boolean)
        .filter((grant) => !staffId || grant.staffId === staffId);
      return defaultResult.ok(grants);
    }

    async function listCustomers(filters = {}) {
      const rows = (Array.isArray(getLocalState().customers) ? getLocalState().customers : [])
        .map(customerToSummary)
        .filter(Boolean)
        .filter((customer) => {
          if (filters.status && customer.status !== filters.status) return false;
          if (filters.search) {
            const q = String(filters.search).trim().toLowerCase();
            const hay = `${customer.fullName} ${customer.accountNumber} ${customer.phone || ''}`.toLowerCase();
            if (!hay.includes(q)) return false;
          }
          return true;
        });
      return defaultResult.ok(rows);
    }

    async function searchCustomers(query) {
      return listCustomers({ search: query || '' });
    }

    async function getCustomerById(customerId) {
      const row = (Array.isArray(getLocalState().customers) ? getLocalState().customers : [])
        .find((item) => item.id === customerId) || null;
      return defaultResult.ok(customerToSummary(row));
    }

    async function getCustomerByAccountNumber(accountNumber) {
      const key = String(accountNumber || '').trim();
      const row = (Array.isArray(getLocalState().customers) ? getLocalState().customers : [])
        .find((item) => String(item.accountNumber || '') === key) || null;
      return defaultResult.ok(customerToSummary(row));
    }

    async function getAccountByNumber(accountNumber) {
      const customerResult = await getCustomerByAccountNumber(accountNumber);
      if (!customerResult.ok) return customerResult;
      return defaultResult.ok(customerResult.data ? customerToAccountSummary(customerResult.data) : null);
    }

    async function getAccountSummary(accountId) {
      if (!canUseSupabase()) return local.accounts.getAccountSummary(accountId);
      const key = String(accountId || '').trim();
      if (!key) return defaultResult.ok(null);

      // Resolve staff accounts first for UUID, staff code, local staff id, or staff posting account.
      const earlyStaffSummary = await fetchStaffAccountByKey(key);
      if (!earlyStaffSummary.ok && earlyStaffSummary.error?.code !== 'STAFF_PROFILE_NOT_FOUND') return earlyStaffSummary;
      if (earlyStaffSummary.ok && earlyStaffSummary.data) {
        const staffBalance = await fetchBalancesByAccountIds([earlyStaffSummary.data.accountId]);
        if (staffBalance.ok && staffBalance.data[0] && staffBalance.data[0].book_balance != null) {
          earlyStaffSummary.data.bookBalance = Number(staffBalance.data[0].book_balance || 0);
        }
        return defaultResult.ok(earlyStaffSummary.data);
      }

      // Migration bridge: approval payloads often pass the customer id as accountId.
      // Only query customers.id when the value is UUID-like; staff codes such as ST4
      // are not valid UUID values and must not be sent to the customers.id filter.
      let customer = null;
      if (isUuidLike(key)) {
        const directCustomerResult = await getCustomerById(key);
        if (!directCustomerResult.ok) return directCustomerResult;
        customer = directCustomerResult.data;
      }

      let accountRow = null;
      if (!customer && isUuidLike(key)) {
        const accountResult = await fetchAccountBySelector({ id: key });
        if (!accountResult.ok) return accountResult;
        accountRow = accountResult.data;
        if (accountRow?.customer_id) {
          const customerResult = await getCustomerById(accountRow.customer_id);
          if (!customerResult.ok) return customerResult;
          customer = customerResult.data;
        }
      }

      if (!customer && accountRow?.account_number) {
        const customerResult = await getCustomerByAccountNumber(accountRow.account_number);
        if (!customerResult.ok) return customerResult;
        customer = customerResult.data;
      }

      if (!customer) {
        const byAccountNumber = await getCustomerByAccountNumber(key);
        if (!byAccountNumber.ok) return byAccountNumber;
        customer = byAccountNumber.data;
      }

      if (!customer) {
        const staffSummary = await fetchStaffAccountByKey(key);
        if (!staffSummary.ok) return staffSummary;
        if (staffSummary.data) {
          const staffBalance = await fetchBalancesByAccountIds([staffSummary.data.accountId]);
          if (staffBalance.ok && staffBalance.data[0] && staffBalance.data[0].book_balance != null) {
            staffSummary.data.bookBalance = Number(staffBalance.data[0].book_balance || 0);
          }
          return defaultResult.ok(staffSummary.data);
        }
      }

      if (!customer) return defaultResult.ok(null);
      const summary = customerToAccountSummary(customer);
      if (summary && accountRow?.id) summary.accountId = accountRow.id;
      if (summary && accountRow?.status) summary.status = accountRow.status;
      if (summary) summary.accountType = summary.accountType || 'customer';
      const balanceResult = await fetchBalancesByAccountIds([summary?.accountId]);
      if (summary && balanceResult.ok && balanceResult.data[0] && balanceResult.data[0].book_balance != null) {
        summary.bookBalance = Number(balanceResult.data[0].book_balance || 0);
      }
      return defaultResult.ok(summary);
    }

    async function getAccountStatement(payload = {}) {
      const customerResult = await getCustomerById(payload.accountId);
      if (!customerResult.ok) return customerResult;
      const customer = customerResult.data;
      const entries = Array.isArray(customer?.transactions) ? customer.transactions.map(normalizeStatementEntry).filter(Boolean) : [];
      const fromDate = payload.fromDate ? new Date(payload.fromDate).getTime() : null;
      const toDate = payload.toDate ? new Date(payload.toDate).getTime() : null;
      let filtered = entries.filter((entry) => {
        const time = new Date(entry.date).getTime();
        if (fromDate && time < fromDate) return false;
        if (toDate && time > toDate + 86399999) return false;
        return true;
      }).sort((a, b) => new Date(b.date) - new Date(a.date));
      if (payload.limit && payload.limit > 0) filtered = filtered.slice(0, payload.limit);
      return defaultResult.ok(filtered);
    }

    function subscribeRealtime(handlers = {}) {
      if (!canUseSupabase() || typeof client.channel !== 'function') {
        return () => {};
      }
      const channelName = `ducess-live-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const channel = client.channel(channelName);
      const notify = (kind, payload) => {
        try {
          if (typeof handlers.onEvent === 'function') handlers.onEvent(kind, payload);
          const specific = handlers[kind];
          if (typeof specific === 'function') specific(payload);
        } catch (err) {
        }
      };
      const tables = [
        [approvalRequestsTable, 'approval'],
        [codSubmissionsTable, 'cod'],
        [codResolutionsTable, 'cod'],
        [debtsTable, 'debt'],
        [customerTransactionsTable, 'balance'],
        [customerBalancesTable, 'balance'],
        [customersTable, 'customer'],
        [staffTable, 'staff'],
      ];
      tables.forEach(([table, kind]) => {
        channel.on('postgres_changes', { event: '*', schema: 'public', table }, (payload) => notify(kind, payload));
      });
      channel.subscribe((status) => {
        if (typeof handlers.onStatus === 'function') handlers.onStatus(status);
      });
      return () => {
        try { client.removeChannel(channel); } catch (_) {}
      };
    }

    return {
      auth: {
        async loginWithStaffId(payload) {
          const session = buildLocalSessionFromState(payload?.staffId);
          if (!session) return defaultResult.err('AUTH_NOT_FOUND', 'Staff profile not found in local adapter.');
          writeAuthSession(session);
          return defaultResult.ok(session);
        },
        async logout() {
          writeAuthSession(null);
          return defaultResult.ok({ success: true });
        },
        async getSession() {
          const saved = readAuthSession();
          if (saved?.staff?.id) return defaultResult.ok(saved);
          const fallback = buildLocalSessionFromState();
          return defaultResult.ok(fallback);
        },
        async getCurrentStaffContext() {
          const sessionResult = await this.getSession();
          if (!sessionResult.ok) return sessionResult;
          return defaultResult.ok({
            businessDate: getLocalState().businessDate,
            activeStaffId: sessionResult.data?.staff?.id || '',
            session: sessionResult.data || null,
          });
        },
        async changePassword() {
          return defaultResult.err('AUTH_PASSWORD_UNAVAILABLE', 'Password changes require Supabase Auth.');
        },
        async resetStaffPassword() {
          return defaultResult.err('AUTH_PASSWORD_UNAVAILABLE', 'Admin password reset requires Supabase Auth.');
        },
        async hasAdminRecoveryKey() {
          try { return defaultResult.ok({ exists: !!localStorage.getItem('ducess_admin_recovery_key_hash_v1') }); } catch (_) { return defaultResult.ok({ exists: false }); }
        },
        async generateAdminRecoveryKey() {
          return defaultResult.err('AUTH_RECOVERY_REQUIRES_SUPABASE', 'Recovery key setup requires Supabase mode.');
        },
        async recoverAdminPassword() {
          return defaultResult.err('AUTH_RECOVERY_UNAVAILABLE', 'Admin recovery requires Supabase Auth.');
        },
      },
      staff: {
        getCurrentStaff,
        getStaffById,
        listStaff,
        listActiveStaff,
        createStaff,
        updateStaffStatus,
        updateStaffCode,
        assignStaffRole,
        listRoleAssignments,
        listStaffLedger,
      },
      permissions: {
        getEffectivePermissions,
        hasPermission,
        listTempGrants,
        createTempGrant: () => notYet('permissions.createTempGrant'),
        revokeTempGrant: () => notYet('permissions.revokeTempGrant'),
      },
      customers: {
        listCustomers,
        searchCustomers,
        getCustomerById,
        getCustomerByAccountNumber,
        submitAccountOpening: () => notYet('customers.submitAccountOpening'),
        submitAccountMaintenance: () => notYet('customers.submitAccountMaintenance'),
        submitAccountReactivation: () => notYet('customers.submitAccountReactivation'),
        listStaffSalaryAccounts: async () => ({ ok: true, data: [] }),
        generateSystemAccountNumber: async (acctType) => {
          // Local (non-Supabase) fallback — no DB sequence available, so
          // derive a simple counter from however many of this type already
          // exist locally. Consistent format with the Supabase RPCs (T#,
          // S#, E#, I#), just not a durable sequence.
          const prefix = { staff_operational: 'T', treasury: 'TR', staff_salary: 'S', expense: 'E', income: 'I' }[acctType];
          if (!prefix) return { ok: false, error: { code: 'INVALID_ACCOUNT_TYPE', message: `No system-assigned number generator for account type "${acctType}".` } };
          const count = (Array.isArray(getLocalState().customers) ? getLocalState().customers : []).filter(c => c.accountType === acctType || (prefix === 'T' && c.accountType === 'staff_operational')).length;
          return { ok: true, data: `${prefix}${count + 1}` };
        },
        peekSystemAccountNumber: async (acctType) => {
          // Local fallback: same non-consuming preview counter as the real
          // generator above (local mode has no sequence to distinguish
          // "peek" from "consume" — the local generator is already
          // effectively a peek since it just counts existing rows).
          const prefix = { staff_operational: 'T', treasury: 'TR', staff_salary: 'S', expense: 'E', income: 'I' }[acctType];
          if (!prefix) return { ok: false, error: { code: 'INVALID_ACCOUNT_TYPE', message: `No system-assigned number preview for account type "${acctType}".` } };
          const count = (Array.isArray(getLocalState().customers) ? getLocalState().customers : []).filter(c => c.accountType === acctType || (prefix === 'T' && c.accountType === 'staff_operational')).length;
          return { ok: true, data: `${prefix}${count + 1}` };
        },
      },
      accounts: {
        getAccountByNumber,
        getAccountSummary,
        getAccountStatement,
        submitCredit: () => notYet('accounts.submitCredit'),
        submitDebit: () => notYet('accounts.submitDebit'),
        submitJournalEntries: () => notYet('accounts.submitJournalEntries'),
      },
      approvals: {
        listApprovalRequests: () => notYet('approvals.listApprovalRequests'),
        getApprovalRequestById: () => notYet('approvals.getApprovalRequestById'),
        submitApprovalRequest: () => notYet('approvals.submitApprovalRequest'),
        approveRequest: () => notYet('approvals.approveRequest'),
        rejectRequest: () => notYet('approvals.rejectRequest'),
      },
      cod: {
        getCodPreview,
        submitCod,
        listCodSubmissions,
        getCodSubmissionById,
        resolveCod,
        listDebts,
        getDebtById,
        submitDebtRepayment,
      },
      dashboard: {
        getDashboardSummary: () => notYet('dashboard.getDashboardSummary'),
        getBusinessBalanceSummary: () => notYet('dashboard.getBusinessBalanceSummary'),
        getOperationalBalanceSummary: () => notYet('dashboard.getOperationalBalanceSummary'),
      },
      appState,
      audit: {
        listAuditLog: async () => ({ ok: true, data: [] }),
        insertAuditLogEntry: async () => ({ ok: true, data: null }),
      },
      // 2026-10-22 Administration redesign: staff profiles + ICT logs live
      // in Supabase; the local adapter has no table, so the app keeps them
      // in browser storage instead.
      history: {
        window: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
      },
      sync: {
        snapshot: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
        digest: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
        changedSince: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
      },
      adminx: {
        listStaffProfiles: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
        getStaffProfile: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
        saveStaffProfile: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
        listIctLogs: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
        addIctLog: async () => ({ ok: false, error: { code: 'LOCAL_ONLY' } }),
      },
      __meta: {
        adapter: 'local',
        phase: '3B.3',
        usesLocalBehavior: true,
      },
      __utils: { clone, normalizeStaffSummary, normalizeStaffSession, buildDefaultPermissions, normalizeTempGrantRecord }
    };
  }
  function createSupabaseClient(config) {
    const url = "https://ghhqlxwuvqilusisieom.supabase.co";
const anonKey = "sb_publishable_8jZ0dBPAzFqJ6xi3CxAkdw_qrzP6p8I";
    const supabaseFactory = global.supabase?.createClient;

    if (!supabaseFactory) {
      return { error: defaultResult.err('SUPABASE_LIBRARY_MISSING', 'Supabase client library is not loaded in the frontend.') };
    }
    if (!url || !anonKey) {
      return { error: defaultResult.err('SUPABASE_ENV_MISSING', 'Supabase URL or anon key is missing. Update src/data/runtime/ducess-config.js or window.__DUCESS_CONFIG__.') };
    }

    try {
      const client = supabaseFactory(url, anonKey, {
        auth: {
          // DUCESS terminals must not silently restore a one-time login after refresh/reopen.
          // Keep Supabase auth in memory only for the active page session.
          persistSession: false,
          autoRefreshToken: false,
          detectSessionInUrl: true,
        }
      });
      return { client };
    } catch (error) {
      return { error: defaultResult.err('SUPABASE_CLIENT_INIT_FAILED', 'Failed to initialize Supabase client.', error) };
    }
  }


  function createSupabaseAdapter(options = {}) {
    const config = mergeConfig(options);
    const local = createLocalAdapter(options);
    const { client, error } = createSupabaseClient(config);
    const staffTable = config?.supabase?.staffTable || 'staff';
    const staffProfileSelect = config?.supabase?.staffProfileSelect || 'id, staff_code, full_name, role_code, is_active, branch_id, auth_user_id, auth_email';
    const staffRolePermissionsTable = config?.supabase?.staffRolePermissionsTable || 'staff_role_permissions';
    const staffTempGrantsTable = config?.supabase?.staffTempGrantsTable || 'staff_temp_grants';
    const staffEmailMode = config?.supabase?.staffEmailMode || 'synthetic_suffix';
    const syntheticEmailSuffix = config?.supabase?.syntheticEmailSuffix || '@ducess.local';
    const customersTable = config?.supabase?.customersTable || 'customers';
    const customersSelect = config?.supabase?.customersSelect || 'id, customer_number, account_number, old_account_number, full_name, address, nin, bvn, phone, photo_path, status, linked_staff_id, account_type, created_at, is_active';
    const customerTransactionsTable = config?.supabase?.customerTransactionsTable || 'customer_transactions';
    const customerTransactionsSelect = config?.supabase?.customerTransactionsSelect || 'id, customer_id, account_id, tx_type, amount, details, posted_by, posted_by_id, approved_by, counterparty, effective_at, created_at, balance_after';
    const customerBalancesTable = config?.supabase?.customerBalancesTable || 'customer_account_balances';
    const customerBalancesSelect = config?.supabase?.customerBalancesSelect || 'account_id, book_balance, updated_at';
    const customerAccountsTable = config?.supabase?.customerAccountsTable || 'customer_accounts';
    const customerAccountsSelect = config?.supabase?.customerAccountsSelect || 'id, customer_id, account_number, status, account_type, opened_at';
    const approvalRequestsTable = config?.supabase?.approvalRequestsTable || 'approval_requests';
    const approvalRequestsSelect = config?.supabase?.approvalRequestsSelect || 'id, request_type, status, payload, requested_at, requested_by_staff_id, requested_by_name, approved_at, approved_by_staff_id, approved_by_name, decision_note, entity_type, entity_id';
    const staffCashLedgerTable = config?.supabase?.staffCashLedgerTable || 'staff_cash_ledger';
    const staffCashLedgerSelect = config?.supabase?.staffCashLedgerSelect || 'id, staff_id, entry_type, amount, delta, note, approval_request_id, float_date, created_at';
    const auditLogTable = config?.supabase?.auditLogTable || 'audit_log';
    const auditLogSelect = config?.supabase?.auditLogSelect || 'id, actor_staff_id, action_type, entity_type, entity_id, metadata, created_at';
    const codSubmissionsTable = config?.supabase?.codSubmissionsTable || 'cod_submissions';
    const codSubmissionsSelect = config?.supabase?.codSubmissionsSelect || 'id, staff_id, business_date, opening_balance, float_topups, effective_opening_balance, total_credits, total_debits, net_book_balance, remaining_balance, expected_cash, actual_cash, variance, overdraw, note, status, submitted_by_staff_id, submitted_at';
    const codResolutionsTable = config?.supabase?.codResolutionsTable || 'cod_resolutions';
    const codResolutionsSelect = config?.supabase?.codResolutionsSelect || 'id, cod_submission_id, final_agreed_amount, adjustment_amount, debt_amount, resolution_note, resolved_by_staff_id, resolved_at';
    const debtsTable = config?.supabase?.debtsTable || 'debts';
    const debtsSelect = config?.supabase?.debtsSelect || 'id, staff_id, business_date, source_cod_submission_id, amount, status, note, created_by_staff_id, created_at, updated_at';
    const debtRepaymentsTable = config?.supabase?.debtRepaymentsTable || 'debt_repayments';
    const debtRepaymentsSelect = config?.supabase?.debtRepaymentsSelect || 'id, debt_id, amount, payment_date, note, requested_by_staff_id, approved_by_staff_id, approval_request_id, status, created_at';
    const approvalPostingRpc = config?.supabase?.approvalPostingRpc || '';

    function normalizeApprovalRecord(row) {
      if (!row) return null;
      const payload = row.payload && typeof row.payload === 'object' ? clone(row.payload) : {};
      return {
        id: String(row.id || ''),
        type: row.request_type || row.type || '',
        requestType: row.request_type || row.type || '',
        status: row.status || 'pending',
        payload,
        requestedAt: row.requested_at || row.requestedAt || new Date().toISOString(),
        requestedBy: row.requested_by_staff_id || row.requestedByStaffId || row.requestedBy || '',
        requestedByStaffId: row.requested_by_staff_id || row.requestedByStaffId || row.requestedBy || '',
        requestedByName: row.requested_by_name || row.requestedByName || '',
        approvedAt: row.approved_at || row.approvedAt || null,
        approvedBy: row.approved_by_name || row.approvedByName || '',
        approvedByStaffId: row.approved_by_staff_id || row.approvedByStaffId || '',
        decisionNote: row.decision_note || row.decisionNote || '',
        entityType: row.entity_type || row.entityType || '',
        entityId: row.entity_id || row.entityId || '',
      };
    }
    // PASTE THIS RIGHT HERE
async function listTempGrants(_staffId) {
  return defaultResult.ok([]);
}
function subscribeRealtime() {
  return () => {};
}


    function isoAtMidday(dateValue) {
      const raw = String(dateValue || '').trim();
      if (!raw) return new Date().toISOString();
      return raw.includes('T') ? raw : `${raw}T12:00:00.000Z`;
    }

    function normalizeNumber(value) {
      const num = Number(value || 0);
      return Number.isFinite(num) ? num : 0;
    }

    function mergeApprovalPayload(existingPayload, patch) {
      return {
        ...(existingPayload && typeof existingPayload === 'object' ? clone(existingPayload) : {}),
        ...(patch && typeof patch === 'object' ? clone(patch) : {}),
      };
    }

    function inferApprovalDate(requestRow) {
      return requestRow?.payload?.businessDate || requestRow?.payload?.date || requestRow?.requested_at || new Date().toISOString();
    }

    function resolveRequestEntries(requestRow) {
      const payload = requestRow?.payload || {};
      if (requestRow?.request_type === 'customer_credit_journal' || requestRow?.request_type === 'customer_debit_journal') {
        return Array.isArray(payload.rows) ? payload.rows : Array.isArray(payload.entries) ? payload.entries : [];
      }
      return [payload];
    }

    async function fetchApprovalRequestRow(requestId, requiredStatus) {
      let query = client.from(approvalRequestsTable).select(approvalRequestsSelect).eq('id', requestId);
      if (requiredStatus) query = query.eq('status', requiredStatus);
      const { data, error: queryError } = await query.maybeSingle();
      if (queryError) return defaultResult.err('APPROVAL_FETCH_FAILED', 'Could not load approval request from Supabase.', queryError);
      if (!data) return defaultResult.err(requiredStatus === 'pending' ? 'APPROVAL_NOT_PENDING' : 'APPROVAL_NOT_FOUND', requiredStatus === 'pending' ? 'Approval request is no longer pending.' : 'Approval request was not found.');
      return defaultResult.ok(data);
    }

    function isMissingColumnOrRelationError(error) {
      const code = String(error?.code || '');
      const message = String(error?.message || '').toLowerCase();
      const details = String(error?.details || '').toLowerCase();
      return code === '42703' || code === '42P01' || code === 'PGRST204' ||
        (message.includes('column') && (message.includes('does not exist') || message.includes('not found'))) ||
        message.includes('could not find') || details.includes('does not exist');
    }

    async function fetchExistingPostedTransactionsByRequest(requestId) {
      if (!requestId) return defaultResult.ok([]);
      const { data, error: queryError } = await client
        .from(customerTransactionsTable)
        .select('id, account_id, customer_id, amount, tx_type, balance_after, approval_request_id')
        .eq('approval_request_id', requestId)
        .order('created_at', { ascending: true });
      if (queryError) {
        if (isMissingColumnOrRelationError(queryError)) {
          return defaultResult.ok([]);
        }
        return defaultResult.err('POSTED_TX_CHECK_FAILED', 'Could not verify previously posted transactions.', queryError);
      }
      return defaultResult.ok(Array.isArray(data) ? data : []);
    }

    async function fetchExistingStaffCashEntryByRequest(requestId) {
      if (!requestId) return defaultResult.ok(null);
      const { data, error: queryError } = await client
        .from(staffCashLedgerTable)
        .select(staffCashLedgerSelect)
        .eq('approval_request_id', requestId)
        .maybeSingle();
      if (queryError && queryError.code !== 'PGRST116') return defaultResult.err('STAFF_LEDGER_CHECK_FAILED', 'Could not verify previously posted staff cash entry.', queryError);
      return defaultResult.ok(data || null);
    }

    async function upsertAccountBalance(accountId, nextBalance) {
      const { error: upsertError } = await client
        .from(customerBalancesTable)
        .upsert({
          account_id: accountId,
          book_balance: normalizeNumber(nextBalance),
          updated_at: new Date().toISOString(),
        }, { onConflict: 'account_id' });
      if (upsertError) return defaultResult.err('ACCOUNT_BALANCE_UPDATE_FAILED', 'Could not update account balance in Supabase.', upsertError);
      return defaultResult.ok(true);
    }

    async function insertStaffCashLedgerEntry(payload = {}, plan = null) {
      const existingResult = await fetchExistingStaffCashEntryByRequest(payload.approvalRequestId);
      if (!existingResult.ok) return existingResult;
      if (existingResult.data) return defaultResult.ok(existingResult.data);
      const insertRow = {
        staff_id: await resolveStaffUuid(client, payload.staffId) || null,
        entry_type: payload.entryType || 'approval_posting',
        amount: normalizeNumber(payload.amount),
        delta: normalizeNumber(payload.delta),
        note: payload.note || '',
        approval_request_id: payload.approvalRequestId || null,
        float_date: payload.floatDate || null,
        created_by_staff_id: payload.createdByStaffId || null,
        approved_by_staff_id: payload.approvedByStaffId || null,
        created_at: new Date().toISOString(),
      };
      if (plan) { plan.ledger = insertRow; return defaultResult.ok(insertRow); }
      const { data, error: insertError } = await client.from(staffCashLedgerTable).insert(insertRow).select(staffCashLedgerSelect).maybeSingle();
      if (insertError) return defaultResult.err('STAFF_LEDGER_INSERT_FAILED', 'Could not write staff cash ledger entry in Supabase.', insertError);
      return defaultResult.ok(data || insertRow);
    }

    async function insertAuditLogEntry(payload = {}) {
      const meta = clone(payload.metadata || {});
      if (payload.before != null) meta.before = payload.before;
      if (payload.after != null) meta.after = payload.after;
      if (payload.actorName) meta.actorName = payload.actorName;
      if (payload.details) meta.details = payload.details;
      const insertRow = {
        actor_staff_id: payload.actorStaffId || null,
        action_type: payload.actionType || 'approval_posted',
        entity_type: payload.entityType || 'approval_request',
        entity_id: payload.entityId || null,
        metadata: meta,
        created_at: new Date().toISOString(),
      };
      const { data, error: insertError } = await client.from(auditLogTable).insert(insertRow).select(auditLogSelect).maybeSingle();
      if (insertError) return defaultResult.err('AUDIT_LOG_INSERT_FAILED', 'Could not write audit log entry in Supabase.', insertError);
      return defaultResult.ok(data || insertRow);
    }

    async function listAuditLog(filters = {}) {
      if (!canUseSupabase()) return defaultResult.ok([]);
      let query = client.from(auditLogTable).select(auditLogSelect).limit(filters.limit || 200);
      if (filters.actorStaffId) query = query.eq('actor_staff_id', filters.actorStaffId);
      if (filters.actionType) query = query.eq('action_type', filters.actionType);
      if (filters.entityType) query = query.eq('entity_type', filters.entityType);
      if (filters.fromDate) query = query.gte('created_at', filters.fromDate);
      if (filters.toDate) query = query.lte('created_at', filters.toDate + 'T23:59:59Z');
      const { data, error, count, status, statusText } = await query;
      if (error) { console.warn('[DUCESS audit] listAuditLog failed:', error); return defaultResult.ok([]); }
      const normalized = (data || []).map(row => ({
        id: row.id,
        actorStaffId: row.actor_staff_id || '',
        actionType: row.action_type || '',
        action: row.action_type || '',
        entityType: row.entity_type || '',
        entityId: row.entity_id || '',
        metadata: row.metadata || {},
        before: row.metadata?.before || null,
        after: row.metadata?.after || null,
        details: row.metadata?.details || row.metadata?.note || '',
        actor: row.metadata?.actorName || '',
        actorId: row.actor_staff_id || '',
        at: row.created_at,
        createdAt: row.created_at,
      }));
      return defaultResult.ok(normalized);
    }

   async function postSingleCustomerTransaction(requestRow, entry, txType, approver, options = {}) {
  const approvalRequestId = requestRow?.id;
  const accountLookupId = entry?.accountType === 'staff' ? (entry?.staffAccountUuid || entry?.staffUuid || entry?.staffAccountId || entry?.staffId || entry?.accountNumber || entry?.accountId || entry?.customerId) : (entry?.accountId || entry?.customerId || entry?.accountNumber || requestRow?.entity_id || requestRow?.entityId);

  const accountSummaryResult = await getAccountSummary(accountLookupId);
  if (!accountSummaryResult.ok) return accountSummaryResult;

  const accountSummary = accountSummaryResult.data;
  if (!accountSummary?.accountId) {
    // Staff accounts may not have a real Supabase account_id but the local
    // state handles their balance. Return success so the approval can proceed.
    if (entry?.accountType === 'staff') {
      return defaultResult.ok({
        alreadyPosted: false,
        requestId: requestRow?.id,
        accountId: null,
        customerId: null,
        amount: normalizeNumber(entry?.amount),
        sourceAmount: normalizeNumber(entry?.amount),
        totalChargeAmount: 0,
        chargeBreakdown: [],
        customerCreditAmount: normalizeNumber(entry?.amount),
        txType,
        balanceAfter: null,
        transactionId: null,
        staffAccountHandledLocally: true
      });
    }
    return defaultResult.err('ACCOUNT_NOT_FOUND', 'Could not resolve target account for approved request.');
  }

  const currentBalance = normalizeNumber(accountSummary.bookBalance);
  const sourceAmount = normalizeNumber(entry?.amount);
  const chargeRows = Array.isArray(entry?.chargeBreakdown) ? entry.chargeBreakdown : [];
  const explicitChargeTotal = normalizeNumber(entry?.totalChargeAmount || 0);
  const rowChargeTotal = chargeRows.reduce((sum, row) => sum + normalizeNumber(row?.amount), 0);
  const totalChargeAmount = rowChargeTotal > 0 ? rowChargeTotal : explicitChargeTotal;
  const computedCustomerCredit = Math.max(0, sourceAmount - totalChargeAmount);
  const amount = txType === 'credit' && totalChargeAmount > 0
    ? normalizeNumber(entry?.customerCreditAmount || computedCustomerCredit)
    : sourceAmount;
  if (Array.isArray(options.resumePool) && options.resumePool.length) {
    const hit = options.resumePool.findIndex(tx => String(tx.account_id) === String(accountSummary.accountId) && String(tx.tx_type) === txType && normalizeNumber(tx.amount) === amount);
    if (hit >= 0) {
      const done = options.resumePool.splice(hit, 1)[0];
      return defaultResult.ok({ alreadyPosted: true, requestId: approvalRequestId, accountId: accountSummary.accountId, customerId: entry?.customerId || accountSummary.customerId || null, amount, sourceAmount, totalChargeAmount, chargeBreakdown: chargeRows, customerCreditAmount: amount, txType, balanceAfter: done.balance_after ?? null, transactionId: done.id || null });
    }
  }
  const delta = txType === 'credit' ? amount : -amount;
  // 2026-11-02 (client): an account with no money must never be debited. Checked
  // against the balance as it stands INCLUDING earlier lines of the same posting
  // plan, so two debits in one request can't together overdraw. Expense/income
  // book accounts are not money-holding accounts and are exempt.
  if (txType === 'debit' && !['expense', 'income'].includes(String(accountSummary.accountType || ''))) {
    const planKey = String(accountSummary.accountId);
    const planRunning = options.plan?.runningBalances;
    const available = planRunning && planRunning.has(planKey) ? planRunning.get(planKey) : currentBalance;
    if (amount > available + 0.0001) {
      return defaultResult.err('INSUFFICIENT_FUNDS', `Insufficient funds: account ${accountSummary.accountNumber || ''} has ${Number(available).toLocaleString('en-US')} and cannot be debited ${Number(amount).toLocaleString('en-US')}.`);
    }
  }
  if (options.plan) {
    options.plan.runningBalances = options.plan.runningBalances || new Map();
    const k = String(accountSummary.accountId);
    options.plan.runningBalances.set(k, (options.plan.runningBalances.has(k) ? options.plan.runningBalances.get(k) : currentBalance) + delta);
  }
  const balanceAfter = currentBalance + delta;
  const chargeText = txType === 'credit' && chargeRows.length
    ? chargeRows.map(row => `${row?.label || row?.accountName || 'Charge'} ${normalizeNumber(row?.amount).toLocaleString('en-US')}`).join(' • ')
    : '';
  const customerGetsText = txType === 'credit' && totalChargeAmount > 0 ? `To Customer Account ${amount.toLocaleString('en-US')}` : '';
  const detailPieces = [entry?.details || '', chargeText, customerGetsText].filter(Boolean);

  const insertRow = {
    customer_id: accountSummary.accountType === 'staff' ? null : (accountSummary.customerId || entry?.customerId || null),
    account_id: accountSummary.accountId,
    tx_type: txType,
    amount,
    details: detailPieces.join(' • '),
    posted_by: requestRow?.requested_by_name || entry?.requestedByName || '',
    posted_by_id: null,
    approved_by: approver?.name || '',
    counterparty: entry?.receivedOrPaidBy || entry?.counterparty || '',
    effective_at: isoAtMidday(entry?.businessDate || entry?.date || inferApprovalDate(requestRow)),
    created_at: new Date().toISOString(),
    balance_after: balanceAfter,
    approval_request_id: approvalRequestId
  };

  // Fix B 2026-10-22: in plan mode nothing is written here — the line is
  // queued and committed together with the rest of the approval (see
  // commitPostingPlan), so a request posts completely or not at all.
  if (options.plan) {
    const { balance_after: _planned, ...planRow } = insertRow;
    options.plan.transactions.push({ row: planRow, accountId: accountSummary.accountId, delta, seedBalance: currentBalance });
    return defaultResult.ok({ alreadyPosted: false, requestId: approvalRequestId, accountId: accountSummary.accountId, customerId: entry?.customerId || accountSummary.customerId || null, amount, sourceAmount, totalChargeAmount, chargeBreakdown: chargeRows, customerCreditAmount: amount, txType, balanceAfter, transactionId: null });
  }

  const insertAttempt = await client
    .from(customerTransactionsTable)
    .insert(insertRow);


  if (insertAttempt.error && insertAttempt.error.message) {
    return defaultResult.err(
      'CUSTOMER_TX_INSERT_FAILED',
      insertAttempt.error.message,
      insertAttempt.error
    );
  }

  const balanceResult = await upsertAccountBalance(accountSummary.accountId, balanceAfter);
  if (!balanceResult.ok) return balanceResult;

  return defaultResult.ok({
    alreadyPosted: false,
    requestId: approvalRequestId,
    accountId: accountSummary.accountId,
    customerId: entry?.customerId || accountSummary.customerId || null,
    amount,
    sourceAmount,
    totalChargeAmount,
    chargeBreakdown: chargeRows,
    customerCreditAmount: amount,
    txType,
    balanceAfter,
    transactionId: null
  });
}

    // 2026-10-24: what kind of account a posting touches — a business
    // account (customer, Treasury, ...) takes real transactions, a staff
    // operational account a staff cash ledger line.
    async function postingAccountKind(id, number) {
      const cols = 'id, account_number, account_type, linked_staff_id';
      let row = null;
      if (id && isUuidLike(String(id))) {
        const r = await client.from(customersTable).select(cols).eq('id', id).limit(1).maybeSingle();
        row = r.data || null;
      }
      if (!row && number) {
        const r = await client.from(customersTable).select(cols).eq('account_number', String(number)).limit(1).maybeSingle();
        row = r.data || null;
      }
      return row ? { id: row.id, accountNumber: row.account_number, type: row.account_type || 'customer', linkedStaffId: row.linked_staff_id || null } : null;
    }

    async function performDirectPostingForApproval(requestRow, approver, decisionNote, plan = null) {
  const type = requestRow?.request_type || requestRow?.type || '';
  const payload = requestRow?.payload || {};

  if (type === 'account_opening') {
  const acctType = payload.accountType || 'customer';
  const fullName = payload.fullName || payload.name || '';
  const phone = payload.phone || '';

  // Generate system account number at approval time for non-customer types
  let generatedAccountNumber = String(payload.generatedAccountNumber || '').trim();
  if (acctType === 'treasury' && !generatedAccountNumber) {
    const { data: seqData } = await client.rpc('generate_treasury_account_number');
    generatedAccountNumber = seqData || '';
  } else if (acctType === 'staff_operational' && !generatedAccountNumber) {
    const { data: seqData } = await client.rpc('generate_staff_operational_account_number');
    generatedAccountNumber = seqData || '';
  } else if (acctType === 'staff_salary' && !generatedAccountNumber) {
    const { data: seqData } = await client.rpc('generate_staff_salary_account_number');
    generatedAccountNumber = seqData || '';
  } else if (acctType === 'expense' && !generatedAccountNumber) {
    const { data: seqData } = await client.rpc('generate_expense_account_number');
    generatedAccountNumber = seqData || '';
  } else if (acctType === 'income' && !generatedAccountNumber) {
    const { data: seqData } = await client.rpc('generate_income_account_number');
    generatedAccountNumber = seqData || '';
  }

  if (!generatedAccountNumber) {
    return defaultResult.err('ACCOUNT_NUMBER_REQUIRED',
      acctType === 'customer'
        ? 'Account number must be entered before approving account opening.'
        : 'Failed to generate system account number — check database sequences.');
  }

  // For customer accounts check for duplicates
  if (acctType === 'customer') {
    const existing = await client.from(customersTable).select(customersSelect).eq('full_name', fullName).eq('phone', phone).limit(1).maybeSingle();
    if (existing.error) return defaultResult.err('CUSTOMER_LOOKUP_FAILED', 'Could not verify existing customer before posting approval.', existing.error);
    if (existing.data) return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: null, customer: existing.data, decisionNote: decisionNote || '', alreadyPosted: true });
  }

  // Operational accounts are permanently tied to ONE staff member (2026-10-11):
  // refuse a second one for the same person — whichever role they hold now.
  if (acctType === 'staff_operational') {
    if (!payload.linkedStaffId) return defaultResult.err('STAFF_LINK_REQUIRED', 'An operational account must be linked to a staff member.');
    const existingOp = await client.from(customersTable).select('id, account_number').eq('account_type', 'staff_operational').eq('linked_staff_id', payload.linkedStaffId).limit(1).maybeSingle();
    if (existingOp.error) return defaultResult.err('STAFF_LINK_CHECK_FAILED', 'Could not verify existing operational account for this staff member.', existingOp.error);
    if (existingOp.data) return defaultResult.err('STAFF_ALREADY_LINKED', `This staff member already has operational account ${existingOp.data.account_number}. It stays permanently linked to them.`, existingOp.data);
  }

  const customerRow = {
    account_number: generatedAccountNumber,
    old_account_number: payload.oldAccountNumber || payload.old_account_number || '',
    full_name: fullName,
    address: payload.address || '',
    nin: payload.nin || '',
    bvn: payload.bvn || '',
    phone: phone,
    photo_path: payload.photo || payload.photoRef || payload.photo_path || '',
    status: 'active',
    account_type: acctType,
    display_name: payload.name || fullName,
    linked_staff_id: payload.linkedStaffId || null,
    // Classification-only role tag for staff_salary accounts (2026-08-14) —
    // NOT a link to any specific staff record, just what the account holder's
    // role is, so it can be filtered on the Staff Salary Balance report.
    staff_role_code: acctType === 'staff_salary' ? (payload.staffRole || payload.staffRoleCode || null) : null,
    system_assigned: acctType !== 'customer',
    created_at: new Date().toISOString(),
    is_active: true
  };

  const inserted = await client
  .from(customersTable)
  .insert([customerRow])
  .select(customersSelect)
  .maybeSingle();

if (inserted.error) {
  const msg = String(inserted.error.message || '').toLowerCase();

  // If the staff_role_code column hasn't been migrated in yet, don't let
  // that break account opening for every account type — retry once without
  // it so customer/expense/income/staff_salary postings keep working.
  if ((inserted.error.code === '42703' || msg.includes('column')) && msg.includes('staff_role_code')) {
    const { staff_role_code, ...rowWithoutRoleCode } = customerRow;
    const retryInsert = await client.from(customersTable).insert([rowWithoutRoleCode]).select(customersSelect).maybeSingle();
    if (!retryInsert.error) {
      return defaultResult.ok({
        posted: true,
        requestType: type,
        transactions: [],
        cashLedger: null,
        customer: retryInsert.data,
        decisionNote: decisionNote || ''
      });
    }
  }

  if (inserted.error.code === '23505' || msg.includes('duplicate') || msg.includes('unique')) {
    if (msg.includes('account_number')) {
      return defaultResult.err(
        'ACCOUNT_NUMBER_ALREADY_USED',
        'Account number already used.',
        inserted.error
      );
    }

    return defaultResult.err(
      'CUSTOMER_ALREADY_EXISTS',
      'A customer with the same details already exists.',
      inserted.error
    );
  }

  return defaultResult.err(
    'CUSTOMER_CREATE_FAILED',
    'Could not create customer from approved account opening.',
    inserted.error
  );
}

  return defaultResult.ok({
    posted: true,
    requestType: type,
    transactions: [],
    cashLedger: null,
    customer: inserted.data,
    decisionNote: decisionNote || ''
  });
}

      // Intra-bank transfer: debit source, credit destination, non-cash
      if (type === 'intra_bank_transfer') {
        const amount = normalizeNumber(payload.amount);
        // Debit source customer
        const debitResult = await postSingleCustomerTransaction(requestRow, {
          customerId: payload.sourceAccountId, accountNumber: payload.sourceAccountNumber,
          customerName: payload.sourceAccountName, amount, txType: 'debit',
          details: payload.details || `Transfer to ${payload.destAccountName || payload.destAccountNumber}`,
          paymentMode: 'transfer', payoutSource: 'transfer'
        }, 'debit', approver, { skipExistingCheck: true });
        if (!debitResult.ok) return debitResult;
        // Credit destination customer
        const creditResult = await postSingleCustomerTransaction(requestRow, {
          customerId: payload.destAccountId, accountNumber: payload.destAccountNumber,
          customerName: payload.destAccountName, amount, txType: 'credit',
          details: payload.details || `Transfer from ${payload.sourceAccountName || payload.sourceAccountNumber}`,
          paymentMode: 'transfer'
        }, 'credit', approver, { skipExistingCheck: true });
        if (!creditResult.ok) return creditResult;
        return defaultResult.ok({ posted: true, requestType: type, transactions: [debitResult.data, creditResult.data], cashLedger: null, decisionNote: decisionNote || '' });
      }

      // Cash receipt: Cash Officer self-credit to own operational account
      if (type === 'cash_receipt') {
        // 2026-10-24: cash received into a business Treasury account is a
        // real credit on that account.
        const treasury = await postingAccountKind(payload.treasuryAccountId || payload.operationalAccountId, payload.treasuryAccountNumber || payload.operationalAccountNumber);
        if (treasury?.type === 'treasury') {
          const creditResult = await postSingleCustomerTransaction(requestRow, {
            customerId: treasury.id, accountNumber: treasury.accountNumber,
            amount: normalizeNumber(payload.amount), txType: 'credit',
            details: payload.note || `Cash received${payload.receivedFromName ? ` from ${payload.receivedFromName}` : ''}`,
            receivedOrPaidBy: payload.receivedFromName || '', paymentMode: payload.paymentMode || 'cash', date: payload.date
          }, 'credit', approver, { skipExistingCheck: true, plan });
          if (!creditResult.ok) return creditResult;
          return defaultResult.ok({ posted: true, requestType: type, transactions: [creditResult.data], cashLedger: null, decisionNote: decisionNote || '' });
        }
        const ledgerResult = await insertStaffCashLedgerEntry({
          approvalRequestId: requestRow.id,
          staffId: payload.staffId || null,
          entryType: 'cash_receipt',
          amount: normalizeNumber(payload.amount),
          delta: normalizeNumber(payload.amount),
          note: payload.note || `Cash receipt by ${payload.staffName || 'Cash Officer'} (${payload.paymentMode || 'cash'})`,
          floatDate: payload.date || null,
          createdByStaffId: requestRow.requested_by_staff_id || null,
          approvedByStaffId: approver?.staffId || null,
        });
        if (!ledgerResult.ok) return ledgerResult;
        return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: ledgerResult.data, decisionNote: decisionNote || '' });
      }

      // Inter-staff credit: Cash Officer credits a Teller's operational account
      if (type === 'inter_staff_credit') {
        const amount = normalizeNumber(payload.amount);
        // 2026-10-24: one side may be a business account (a Treasury account
        // funding a teller, or a teller's Till going into a Treasury
        // account). That side is a real transaction on the account, the
        // staff side a ledger line; both are written together.
        const srcKind = payload.sourceAccountId || payload.sourceAccountNumber ? await postingAccountKind(payload.sourceAccountId, payload.sourceAccountNumber) : null;
        const dstKind = await postingAccountKind(payload.targetAccountId, payload.targetAccountNumber);
        const srcIsBusiness = !!srcKind && srcKind.type !== 'staff_operational';
        const dstIsBusiness = !!dstKind && dstKind.type !== 'staff_operational';
        if (srcIsBusiness || dstIsBusiness) {
          const transactions = [];
          let cashLedger = null;
          if (srcKind) {
            if (srcIsBusiness) {
              const r = await postSingleCustomerTransaction(requestRow, {
                customerId: srcKind.id, accountNumber: srcKind.accountNumber, amount, txType: 'debit',
                details: payload.note || `Transfer to ${payload.targetAccountName || payload.targetAccountNumber || 'staff account'}`,
                receivedOrPaidBy: payload.receivedBy || payload.paidBy || '', paymentMode: 'transfer', payoutSource: 'transfer', date: payload.date
              }, 'debit', approver, { skipExistingCheck: true, plan });
              if (!r.ok) return r;
              transactions.push(r.data);
            } else {
              const r = await insertStaffCashLedgerEntry({
                approvalRequestId: requestRow.id, staffId: srcKind.linkedStaffId || payload.staffId || null,
                entryType: 'inter_staff_debit', amount, delta: -amount,
                note: payload.note || `Transfer to ${payload.targetAccountName || payload.targetAccountNumber || 'account'}`,
                floatDate: payload.date || null, createdByStaffId: requestRow.requested_by_staff_id || null, approvedByStaffId: approver?.staffId || null,
              }, plan);
              if (!r.ok) return r;
              cashLedger = r.data;
            }
          }
          if (dstIsBusiness) {
            const r = await postSingleCustomerTransaction(requestRow, {
              customerId: dstKind.id, accountNumber: dstKind.accountNumber, amount, txType: 'credit',
              details: payload.note || `Transfer from ${payload.sourceAccountName || payload.sourceAccountNumber || 'staff account'}`,
              receivedOrPaidBy: payload.paidBy || payload.receivedBy || '', paymentMode: 'transfer', date: payload.date
            }, 'credit', approver, { skipExistingCheck: true, plan });
            if (!r.ok) return r;
            transactions.push(r.data);
          } else {
            const r = await insertStaffCashLedgerEntry({
              approvalRequestId: requestRow.id, staffId: dstKind?.linkedStaffId || payload.staffId || null,
              entryType: 'inter_staff_credit', amount, delta: amount,
              note: payload.note || `Operational credit from ${payload.sourceAccountName || payload.staffName || 'Treasury'} to ${payload.targetAccountName || payload.targetAccountNumber || 'teller account'}`,
              floatDate: payload.date || null, createdByStaffId: requestRow.requested_by_staff_id || null, approvedByStaffId: approver?.staffId || null,
            }, plan);
            if (!r.ok) return r;
            cashLedger = r.data;
          }
          return defaultResult.ok({ posted: true, requestType: type, transactions, cashLedger, decisionNote: decisionNote || '' });
        }
        // SURGICAL FIX 2026-09-16 (client-observed bug): this ledger write
        // previously ALWAYS credited payload.staffId — the ACTING/GIVING
        // staff who performed the transfer — with a POSITIVE delta and
        // entryType 'inter_staff_credit'. That's backwards: the giver
        // should be debited, and the credit belongs to the actual
        // RECIPIENT (whoever's operational account payload.targetAccountId
        // points at), not whoever initiated it. This is what was making
        // Non Cash / Teller-to-Teller funding show up as a "Received"
        // figure on the wrong staff member's Teller Balances row.
        if (payload.sourceAccountId) {
          const debitLedgerResult = await insertStaffCashLedgerEntry({
            approvalRequestId: requestRow.id,
            staffId: payload.staffId || null,
            entryType: 'inter_staff_debit',
            amount,
            delta: -amount,
            note: payload.note || `Funded ${payload.targetAccountName || payload.targetAccountNumber || 'staff account'} from own balance`,
            floatDate: payload.date || null,
            createdByStaffId: requestRow.requested_by_staff_id || null,
            approvedByStaffId: approver?.staffId || null,
          });
          if (!debitLedgerResult.ok) return debitLedgerResult;
        }
        // Resolve the actual recipient's staff id from the target account
        // (falls back to payload.staffId only if that lookup fails, so a
        // legitimate credit is never silently dropped).
        let recipientStaffId = payload.staffId || null;
        try {
          const targetSummary = await getAccountSummary(payload.targetAccountId || payload.targetAccountNumber);
          if (targetSummary.ok && targetSummary.data?.customerId) {
            const targetCustomerResult = await getCustomerById(targetSummary.data.customerId);
            if (targetCustomerResult.ok && targetCustomerResult.data?.linkedStaffId) {
              recipientStaffId = targetCustomerResult.data.linkedStaffId;
            }
          }
        } catch (_) { /* fall back to payload.staffId */ }
        const ledgerResult = await insertStaffCashLedgerEntry({
          approvalRequestId: requestRow.id,
          staffId: recipientStaffId,
          entryType: 'inter_staff_credit',
          amount,
          delta: amount,
          note: payload.note || `Operational credit from ${payload.staffName || 'Cash Officer'} to ${payload.targetAccountName || payload.targetAccountNumber || 'teller account'} (${payload.paymentMode || 'cash'})`,
          floatDate: payload.date || null,
          createdByStaffId: requestRow.requested_by_staff_id || null,
          approvedByStaffId: approver?.staffId || null,
        });
        if (!ledgerResult.ok) return ledgerResult;
        return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: ledgerResult.data, decisionNote: decisionNote || '' });
      }

      // SURGICAL FIX/ADDITION 2026-10-21: customer-status requests. Approving
      // Account Maintenance or Reactivation previously only marked the
      // request approved — the customer row itself was never changed in
      // Supabase. Block (freeze) and Closure (remove from service, records
      // kept) are new and work the same way.
      const customerStatusTypes = ['account_maintenance', 'account_reactivation', 'account_block', 'account_closure'];
      if (customerStatusTypes.includes(type)) {
        const customerId = payload.customerId || requestRow.entity_id || '';
        if (!customerId) return defaultResult.err('CUSTOMER_REQUIRED', 'This request has no customer attached.');
        let patch;
        if (type === 'account_maintenance') {
          const m = payload.patch || payload.updates || {};
          patch = {};
          if (m.name) { patch.full_name = m.name; patch.display_name = m.name; }
          if (m.address !== undefined) patch.address = m.address || '';
          if (m.phone) patch.phone = m.phone;
          if (m.nin) patch.nin = m.nin;
          if (m.bvn) patch.bvn = m.bvn;
          if (m.oldAccountNumber !== undefined) patch.old_account_number = m.oldAccountNumber || '';
        } else if (type === 'account_reactivation') {
          patch = { status: 'active', is_active: true };
        } else if (type === 'account_block') {
          patch = { status: 'frozen', is_active: true };
        } else {
          patch = { status: 'closed', is_active: false };
        }
        if (!Object.keys(patch).length) return defaultResult.ok({ posted: false, requestType: type, transactions: [], cashLedger: null, decisionNote: decisionNote || '' });
        const upd = await client.from(customersTable).update(patch).eq('id', customerId).select(customersSelect).maybeSingle();
        if (upd.error) return defaultResult.err('CUSTOMER_UPDATE_FAILED', 'Could not update the customer for this approval.', upd.error);
        if (!upd.data) return defaultResult.err('CUSTOMER_NOT_FOUND', 'The customer for this approval was not found.');
        return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: null, customer: upd.data, decisionNote: decisionNote || '' });
      }

      const postable = ['customer_credit', 'customer_debit', 'customer_credit_journal', 'customer_debit_journal', 'float_topup', 'float_declaration', 'debt_repayment'];
      if (!postable.includes(type)) {
        return defaultResult.ok({ posted: false, requestType: type, transactions: [], cashLedger: null, decisionNote: decisionNote || '' });
      }

      if (type === 'float_declaration') {
        const ledgerResult = await insertStaffCashLedgerEntry({
          approvalRequestId: requestRow.id,
          staffId: payload.staffId || null,
          entryType: 'approved_form',
          amount: normalizeNumber(payload.amount || payload.floatAmount),
          delta: normalizeNumber(payload.amount || payload.floatAmount),
          note: payload.note || `Approved form for ${payload.staffName || 'staff'}`,
          floatDate: payload.date || payload.float_date || null,
          createdByStaffId: requestRow.requested_by_staff_id || null,
          approvedByStaffId: approver?.staffId || null,
        });
        if (!ledgerResult.ok) return ledgerResult;
        return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: ledgerResult.data, decisionNote: decisionNote || '' });
      }

      if (type === 'float_topup') {
        return defaultResult.ok({ posted: false, requestType: type, transactions: [], cashLedger: null, decisionNote: decisionNote || '', disabled: true });
      }

      if (type === 'debt_repayment') {
        const debtResult = await getDebtById(payload.debtId || requestRow.entity_id || '');
        if (!debtResult.ok) return debtResult;
        const debt = debtResult.data;
        if (!debt) return defaultResult.err('DEBT_NOT_FOUND', 'Target debt was not found for repayment.');
        const repaymentAmount = Math.max(0, normalizeNumber(payload.amount));
        const repaymentCheck = await client.from(debtRepaymentsTable).select('id').eq('approval_request_id', requestRow.id).limit(1);
        if (repaymentCheck.error) return defaultResult.err('DEBT_REPAYMENT_CHECK_FAILED', 'Could not verify prior debt repayment posting.', repaymentCheck.error);
        if (!(repaymentCheck.data || []).length) {
          const repaymentRow = {
            debt_id: debt.id,
            amount: repaymentAmount,
            payment_date: payload.paymentDate || payload.payment_date || new Date().toISOString().slice(0,10),
            note: payload.note || '',
            requested_by_staff_id: requestRow.requested_by_staff_id || null,
            approved_by_staff_id: approver?.staffId || null,
            approval_request_id: requestRow.id,
            status: 'approved',
            created_at: new Date().toISOString(),
          };
          const ins = await client.from(debtRepaymentsTable).insert(repaymentRow).select(debtRepaymentsSelect).maybeSingle();
          if (ins.error) return defaultResult.err('DEBT_REPAYMENT_INSERT_FAILED', 'Could not post debt repayment in Supabase.', ins.error);
          const remaining = Math.max(0, normalizeNumber(debt.amount) - repaymentAmount);
          const nextStatus = remaining === 0 ? 'paid' : 'part_paid';
          const upd = await client.from(debtsTable).update({ amount: remaining, status: nextStatus, updated_at: new Date().toISOString() }).eq('id', debt.id).select(debtsSelect).maybeSingle();
          if (upd.error) return defaultResult.err('DEBT_UPDATE_FAILED', 'Could not update debt after repayment.', upd.error);
          return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: null, debt: normalizeDebtRecord(upd.data), repayment: ins.data, decisionNote: decisionNote || '' });
        }
        return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: null, debt, decisionNote: decisionNote || '', alreadyPosted: true });
      }

      const txType = (type === 'customer_debit' || type === 'customer_debit_journal') ? 'debit' : 'credit';
      const entries = resolveRequestEntries(requestRow);
      // Direct customer_credit/customer_debit draw on the daily FORM directly,
      // using the actual posted amount. Journals draw on it via their own
      // declared FORM amount instead (not the sum of their rows).
      const isJournal = (type === 'customer_credit_journal' || type === 'customer_debit_journal');
      // SURGICAL ADDITION 2026-09-22 (client-confirmed design, cont'd 2): a
      // journal's funding account can be ANY account, not just a staff
      // operational one. When fundingLeg is set, that account gets an
      // ordinary customer transaction (opposite direction from the rows,
      // posted further below) instead of a staff cash ledger entry. It's
      // one extra posted transaction beyond the row entries, so it has to
      // be counted into the idempotency checks below or a retry would
      // either think a partial post happened, or (worse) skip the funding
      // leg forever after the rows already posted once.
      const hasFundingLeg = isJournal && !!(payload.fundingLeg && payload.fundingLeg.accountId);
      const expectedEntryCount = entries.length + (hasFundingLeg ? 1 : 0);

      // Staff account transactions are handled entirely by local state (applyRequest).
      // Skip Supabase posting for them to avoid "customer not found" errors.
      const allStaffEntries = entries.length > 0 && entries.every(e => e.accountType === 'staff');
      const hasStaffEntry = entries.some(e => e.accountType === 'staff');
      if (allStaffEntries || (hasStaffEntry && (type === 'customer_credit' || type === 'customer_debit'))) {
        return defaultResult.ok({ posted: true, requestType: type, transactions: [], cashLedger: null, decisionNote: decisionNote || '', staffAccountHandledLocally: true });
      }

      const existingTxResult = await fetchExistingPostedTransactionsByRequest(requestRow.id);
      if (!existingTxResult.ok) return existingTxResult;
      if (existingTxResult.data.length >= expectedEntryCount && expectedEntryCount > 0) {
        return defaultResult.ok({ posted: true, requestType: type, transactions: existingTxResult.data, cashLedger: null, decisionNote: decisionNote || '', alreadyPosted: true });
      }
      // Fix B 2026-10-22: a journal that stopped part-way (timeout / lost
      // connection) used to be blocked with PARTIAL_POST_DETECTED. Approving
      // it again now resumes: lines already posted for this request are
      // matched (account + type + amount, each used once) and skipped, and
      // only the missing lines are posted.
      const resumePool = existingTxResult.data.length > 0 ? [...existingTxResult.data] : null;
      const results = [];
      for (const entry of entries) {
        const postedResult = await postSingleCustomerTransaction(requestRow, entry, txType, approver, { skipExistingCheck: true, resumePool, plan });
        if (!postedResult.ok) return postedResult;
        results.push(postedResult.data);
      }

      // Post the funding leg — opposite direction from the rows above,
      // against whichever account the teller chose to fund this journal
      // from. Guarded by its own idempotency check (against the SAME
      // pre-loop snapshot used above) since it isn't one of `entries`.
      if (hasFundingLeg) {
        const alreadyPostedFundingLeg = (existingTxResult.data || []).some(tx => String(tx.account_id) === String(payload.fundingLeg.accountId));
        if (!alreadyPostedFundingLeg) {
          const fundingTxType = txType === 'credit' ? 'debit' : 'credit';
          const fundingResult = await postSingleCustomerTransaction(requestRow, {
            customerId: payload.fundingLeg.accountId,
            accountId: payload.fundingLeg.accountId,
            accountNumber: payload.fundingLeg.accountNumber,
            amount: normalizeNumber(payload.formAmount),
            details: `Journal funding leg for ${payload.journalNumber || ''}`
          }, fundingTxType, approver, { skipExistingCheck: true, resumePool, plan });
          if (!fundingResult.ok) return fundingResult;
          results.push(fundingResult.data);
        }
      }

      const journalFormAmount = normalizeNumber(payload.formAmount);
      const directTotalAmount = results.reduce((sum, item) => sum + normalizeNumber(item?.sourceAmount || item?.amount), 0);
      const ledgerAmount = isJournal ? journalFormAmount : directTotalAmount;
      // SURGICAL FIX 2026-09-04 (client-confirmed bug): delta was hardcoded
      // negative for BOTH customer_credit (a deposit — should INCREASE what
      // the teller has to work with) and customer_debit (a withdrawal —
      // should decrease it), so every deposit silently reduced a teller's
      // operational balance/ledger balance instead of increasing it. Now
      // signed by txType, matching postSingleCustomerTransaction's delta
      // convention above (credit=+, debit=-).
      // A journal funded via fundingLeg (a non-staff account) already had
      // its ledger effect posted above as an ordinary customer transaction
      // — skip the staff cash ledger entry entirely in that case. Otherwise
      // post it against fundingStaffId (falling back to staffId) exactly
      // as before.
      if (!hasFundingLeg) {
        const ledgerResult = await insertStaffCashLedgerEntry({
          approvalRequestId: requestRow.id,
          staffId: (isJournal && payload.fundingStaffId) ? payload.fundingStaffId : (payload.staffId || payload.requestedByStaffId || requestRow.requested_by_staff_id || null),
          entryType: type,
          amount: ledgerAmount,
          delta: ledgerAmount ? (txType === 'credit' ? Math.abs(ledgerAmount) : -Math.abs(ledgerAmount)) : 0,
          note: payload.note || payload.details || payload.description || `${type}${isJournal ? ' form' : ''} posted from approval ${requestRow.id}`,
          floatDate: payload.date || payload.businessDate || null,
          createdByStaffId: requestRow.requested_by_staff_id || null,
          approvedByStaffId: approver?.staffId || null,
        }, plan);
        if (!ledgerResult.ok) return ledgerResult;
        return defaultResult.ok({ posted: true, requestType: type, transactions: results, cashLedger: ledgerResult.data, decisionNote: decisionNote || '' });
      }

      return defaultResult.ok({ posted: true, requestType: type, transactions: results, cashLedger: null, decisionNote: decisionNote || '' });
    }

    async function markApprovalDecision(requestId, status, actor, note, payloadPatch) {
      const currentResult = await getApprovalRequestById(requestId);
      if (!currentResult.ok) return currentResult;
      const current = currentResult.data;
      const patch = {
        status,
        approved_at: new Date().toISOString(),
        approved_by_staff_id: actor?.staffId || '',
        approved_by_name: actor?.name || '',
        decision_note: note || '',
        payload: mergeApprovalPayload(current?.payload, payloadPatch),
      };
      const { data, error: updateError } = await client.from(approvalRequestsTable).update(patch).eq('id', requestId).eq('status', 'pending').select(approvalRequestsSelect).maybeSingle();
      if (updateError) return defaultResult.err(status === 'approved' ? 'APPROVAL_APPROVE_FAILED' : 'APPROVAL_REJECT_FAILED', status === 'approved' ? 'Could not approve request in Supabase.' : 'Could not reject request in Supabase.', updateError);
      if (!data) return defaultResult.err('APPROVAL_NOT_PENDING', 'Approval request is no longer pending.');
      return defaultResult.ok(normalizeApprovalRecord(data));
    }

    async function listApprovalRequests(filters = {}) {
      if (!canUseSupabase()) return local.approvals.listApprovalRequests(filters);
      // SURGICAL FIX 2026-08-22 (Supabase egress overage — org hit 141% of
      // free-tier quota): this is the routine list/poll query, called by
      // every client on every sync — it does NOT need the full base64
      // photo/field-note bytes that account_opening and journal payloads
      // can carry (each 40KB-several-hundred-KB), it only needs list-level
      // fields (type, status, dates, amounts, etc.) for rendering the
      // queue/badges. Reads from a lightweight view that replaces those two
      // heavy keys with small placeholders (keeping "has a photo"/"has a
      // note" truthiness and filename/type intact for list badges) instead
      // of the raw table. getApprovalRequestById and fetchApprovalRequestRow
      // (used by the actual approve/reject/posting path and by the detail
      // modal) are UNCHANGED — they still read the raw table with the real
      // full payload, so nothing here can cause a stripped photo to ever
      // get posted to a customer record.
      const listSource = config?.supabase?.approvalRequestsListView || 'approval_requests_list_view';
      // SURGICAL FIX 2026-09-30: filters.all pages through EVERY request
      // (500 per request) instead of stopping at the latest 100 — Opening
      // Cash/Till/COD are summed from all approved requests, so a capped
      // list silently dropped older funding once there were >100 requests.
      // filters.ids fetches just those requests (cheap status check).
      if (filters?.all || (Array.isArray(filters?.ids) && filters.ids.length)) {
        const PAGE = 500;
        const collected = [];
        let useView = true;
        for (let from = 0; ; from += PAGE) {
          let q = client.from(useView ? listSource : approvalRequestsTable).select(approvalRequestsSelect).order('requested_at', { ascending: false }).order('id', { ascending: false });
          if (Array.isArray(filters?.ids) && filters.ids.length) q = q.in('id', filters.ids);
          if (filters?.status) q = q.eq('status', filters.status);
          if (filters?.requestType) q = q.eq('request_type', filters.requestType);
          if (filters?.requestedByStaffId) q = q.eq('requested_by_staff_id', filters.requestedByStaffId);
          const { data: pageData, error: pageError } = await q.range(from, from + PAGE - 1);
          if (pageError && useView && from === 0 && isMissingColumnOrRelationError(pageError)) { useView = false; from -= PAGE; continue; }
          if (pageError) return defaultResult.err('APPROVAL_LIST_FAILED', 'Could not load approval requests from Supabase.', pageError);
          const rows = Array.isArray(pageData) ? pageData : [];
          collected.push(...rows);
          if (rows.length < PAGE) break;
        }
        return defaultResult.ok(collected.map(normalizeApprovalRecord).filter(Boolean));
      }
      let query = client.from(listSource).select(approvalRequestsSelect).order('requested_at', { ascending: false });
      if (filters?.status) query = query.eq('status', filters.status);
      if (filters?.requestType) query = query.eq('request_type', filters.requestType);
      if (filters?.requestedByStaffId) query = query.eq('requested_by_staff_id', filters.requestedByStaffId);
      const limit = Number(filters?.limit || 100);
      if (Number.isFinite(limit) && limit > 0) query = query.limit(Math.min(limit, 500));
      let { data, error: queryError } = await query;
      if (queryError && isMissingColumnOrRelationError(queryError)) {
        // View not created yet (migration not run) — fall back to the raw
        // table so the app keeps working; just without the egress savings
        // until the SQL migration is applied.
        let fallbackQuery = client.from(approvalRequestsTable).select(approvalRequestsSelect).order('requested_at', { ascending: false });
        if (filters?.status) fallbackQuery = fallbackQuery.eq('status', filters.status);
        if (filters?.requestType) fallbackQuery = fallbackQuery.eq('request_type', filters.requestType);
        if (filters?.requestedByStaffId) fallbackQuery = fallbackQuery.eq('requested_by_staff_id', filters.requestedByStaffId);
        if (Number.isFinite(limit) && limit > 0) fallbackQuery = fallbackQuery.limit(Math.min(limit, 500));
        const fallbackResult = await fallbackQuery;
        data = fallbackResult.data;
        queryError = fallbackResult.error;
      }
      if (queryError) return defaultResult.err('APPROVAL_LIST_FAILED', 'Could not load approval requests from Supabase.', queryError);
      return defaultResult.ok((data || []).map(normalizeApprovalRecord).filter(Boolean));
    }

    async function getApprovalRequestById(requestId) {
      if (!canUseSupabase()) return local.approvals.getApprovalRequestById(requestId);
      const { data, error: queryError } = await client.from(approvalRequestsTable).select(approvalRequestsSelect).eq('id', requestId).maybeSingle();
      if (queryError) return defaultResult.err('APPROVAL_FETCH_FAILED', 'Could not load approval request from Supabase.', queryError);
      return defaultResult.ok(normalizeApprovalRecord(data));
    }

    async function submitApprovalRequest(payload = {}) {
  // SURGICAL PATCH 2026-08-12: this guard used to be a no-op ("FORCE Supabase" debug
  // override left mid-edit), so when the Supabase client wasn't actually available
  // this fell straight through into a network call on a broken/null client — the
  // request would hang with no error and no record ever got created. Restore the
  // same local-adapter fallback every other function in this file uses.
  if (!canUseSupabase()) return local.approvals.submitApprovalRequest(payload);

  const insertPayload = {
    request_type: payload.requestType || payload.type || '',
    status: 'pending',
    payload: clone(payload.payload || {}),
    requested_by_staff_id: payload.requestedByStaffId || payload.requested_by_staff_id || '',
    requested_by_name: payload.requestedByName || payload.requested_by_name || '',
    requested_at: new Date().toISOString(),
    entity_type: payload.entityType || payload.entity_type || null,
    entity_id: payload.entityId || payload.entity_id || null,
  };


  const { data, error: insertError } = await client
    .from(approvalRequestsTable)
    .insert([insertPayload])
    .select(approvalRequestsSelect)
    .single();


if (insertError) {
  console.error('APPROVAL INSERT ERROR MESSAGE:', insertError.message);
  console.error('APPROVAL INSERT ERROR DETAILS:', insertError.details);
  console.error('APPROVAL INSERT ERROR HINT:', insertError.hint);
  console.error('APPROVAL INSERT ERROR CODE:', insertError.code);
}
if (insertError) return defaultResult.err('APPROVAL_CREATE_FAILED', 'Could not create approval request in Supabase.', insertError);
return defaultResult.ok(normalizeApprovalRecord(data));
}
    async function markApprovalApprovedDirect(payload = {}) {
      if (!canUseSupabase()) return local.approvals.approveRequest(payload);
      const patch = {
        status: 'approved',
        approved_at: new Date().toISOString(),
        approved_by_staff_id: payload.approvedByStaffId || '',
        approved_by_name: payload.approvedByName || '',
        decision_note: payload.note || 'Staff account — handled locally',
      };
      const { data, error } = await client
        .from(approvalRequestsTable)
        .update(patch)
        .eq('id', payload.requestId)
        .eq('status', 'pending')
        .select(approvalRequestsSelect)
        .maybeSingle();
      if (error) return defaultResult.err('APPROVAL_APPROVE_FAILED', 'Could not approve request in Supabase.', error);
      if (!data) return defaultResult.err('APPROVAL_NOT_PENDING', 'Approval request is no longer pending.');
      return defaultResult.ok(normalizeApprovalRecord(data));
    }

    async function setReviewLock(payload = {}) {
      if (!canUseSupabase()) return defaultResult.ok(null);
      const requestId = payload.requestId || payload.id || '';
      if (!requestId) return defaultResult.err('APPROVAL_LOCK_INVALID', 'Approval request id is required.');
      const ttlMs = Number(payload.ttlMs || 60000);
      const currentResult = await getApprovalRequestById(requestId);
      if (!currentResult.ok) return currentResult;
      const current = currentResult.data;
      if (!current || current.status !== 'pending') return defaultResult.err('APPROVAL_NOT_PENDING', 'Approval request is no longer pending.');
      const existing = current.payload?.__reviewLock || null;
      const existingStarted = existing?.startedAt ? new Date(existing.startedAt).getTime() : 0;
      const now = Date.now();
      const actorId = String(payload.staffId || payload.staff_id || '');
      if (existingStarted && (now - existingStarted) < ttlMs && String(existing.staffId || '') && String(existing.staffId || '') !== actorId) {
        return defaultResult.err('APPROVAL_LOCKED', `This request is being reviewed by ${existing.staffName || 'another staff'}.`);
      }
      const nextPayload = mergeApprovalPayload(current.payload, {
        __reviewLock: {
          staffId: actorId,
          staffName: payload.staffName || payload.staff_name || 'Staff',
          startedAt: new Date(now).toISOString()
        }
      });
      const { data, error } = await client
        .from(approvalRequestsTable)
        .update({ payload: nextPayload })
        .eq('id', requestId)
        .eq('status', 'pending')
        .select(approvalRequestsSelect)
        .maybeSingle();
      if (error) return defaultResult.err('APPROVAL_LOCK_FAILED', 'Could not mark this request as being reviewed in Supabase.', error);
      if (!data) return defaultResult.err('APPROVAL_NOT_PENDING', 'Approval request is no longer pending.');
      return defaultResult.ok(normalizeApprovalRecord(data));
    }

    async function approveRequest(payload = {}) {
      if (!canUseSupabase()) return local.approvals.approveRequest(payload);
      const approver = {
        staffId: payload.approvedByStaffId || payload.approved_by_staff_id || '',
        name: payload.approvedByName || payload.approved_by_name || '',
      };
      const decisionNote = payload.note || '';

      // Always fetch the request row first so we can inspect the payload
      // (needed for both the RPC bypass check and the direct posting path).
      const requestResult = await fetchApprovalRequestRow(payload.requestId, 'pending');
      if (!requestResult.ok) return requestResult;
      const requestRow = requestResult.data;

      if (approvalPostingRpc) {
        // For staff account transactions, skip the RPC (which doesn't know about
        // DUCESS staff accounts) and fall through to direct posting which detects
        // staff entries and returns staffAccountHandledLocally: true.
        const requestPayload = requestRow?.payload || {};
        const isStaffCreditDebit = (requestRow?.request_type === 'customer_credit' || requestRow?.request_type === 'customer_debit') && (requestPayload.accountType === 'staff' || requestPayload.accountType === 'staff_wallet');
        const isStaffJournal = (requestRow?.request_type === 'customer_credit_journal' || requestRow?.request_type === 'customer_debit_journal') && Array.isArray(requestPayload.rows) && requestPayload.rows.length > 0 && requestPayload.rows.some(r => r.accountType === 'staff' || r.accountType === 'staff_wallet');
        if (!isStaffCreditDebit && !isStaffJournal) {
          const { data, error: rpcError } = await client.rpc(approvalPostingRpc, {
            p_request_id: payload.requestId,
            p_approved_by_staff_id: approver.staffId,
            p_approved_by_name: approver.name,
            p_decision_note: decisionNote,
          });
          if (rpcError) return defaultResult.err('APPROVAL_POST_RPC_FAILED', 'Could not approve and post request through Supabase RPC.', rpcError);
          return defaultResult.ok(normalizeApprovalRecord(data));
        }
        // Staff account — fall through to direct posting path below
      }
      if (payload?.payload && typeof payload.payload === 'object') {
  requestRow.payload = {
    ...(requestRow.payload || {}),
    ...payload.payload
  };
}

      const plan = { transactions: [], ledger: null };
      const postingResult = await performDirectPostingForApproval(requestRow, approver, decisionNote, plan);
      if (!postingResult.ok) return postingResult;

      // 2026-10-23 (database space): the approval and its audit entry keep a
      // compact record of what was posted (account, type, amount, balance)
      // instead of a full copy — the transactions table holds the detail.
      const compactTx = (Array.isArray(postingResult.data?.transactions) ? postingResult.data.transactions : [])
        .map(t => ({ accountId: t?.accountId ?? null, txType: t?.txType || '', amount: normalizeNumber(t?.amount), balanceAfter: t?.balanceAfter ?? null }));
      const ledger = postingResult.data?.cashLedger;
      const compactLedger = ledger ? { amount: normalizeNumber(ledger.amount), delta: normalizeNumber(ledger.delta) } : null;
      const postingMeta = {
        __posting: {
          posted: postingResult.data?.posted !== false,
          postedAt: new Date().toISOString(),
          requestType: requestRow.request_type || '',
          transactions: compactTx,
          cashLedger: compactLedger,
        }
      };

      const auditEntry = {
        actorStaffId: approver.staffId,
        actionType: 'approval_posted',
        entityType: 'approval_request',
        entityId: payload.requestId,
        metadata: {
          requestType: requestRow.request_type || '',
          posted: postingResult.data?.posted !== false,
          transactions: compactTx,
          cashLedger: compactLedger,
          decisionNote,
        }
      };
      if (plan.transactions.length || plan.ledger) return commitPostingPlan(payload.requestId, plan, approver, decisionNote, postingMeta, auditEntry);

      const approvalResult = await markApprovalDecision(payload.requestId, 'approved', approver, decisionNote, postingMeta);
      if (!approvalResult.ok) return approvalResult;

      const auditResult = await insertAuditLogEntry(auditEntry);
      if (!auditResult.ok) return auditResult;

      return approvalResult;
    }

    // Fix B 2026-10-22: all-or-nothing posting. Every line, the balance
    // updates, the staff ledger entry, the approval status and the audit
    // entry go to the database function ducess_commit_posting in ONE call —
    // it runs as a single transaction, locks each account balance while it
    // updates it (so two approvers can't overwrite each other) and refuses
    // a request that is no longer pending. Until that function is installed
    // (sql/2026-10-22-fix-b-atomic-posting.sql) the same writes run one by
    // one as before.
    let commitRpcAvailable = true;
    function isMissingRpcError(error) {
      const code = String(error?.code || ''); const msg = String(error?.message || '').toLowerCase();
      return code === 'PGRST202' || code === '42883' || msg.includes('could not find the function');
    }
    async function commitPostingPlan(requestId, plan, approver, decisionNote, postingMeta, auditEntry) {
      const current = await getApprovalRequestById(requestId);
      if (!current.ok) return current;
      if (!current.data || current.data.status !== 'pending') return defaultResult.err('APPROVAL_NOT_PENDING', 'Approval request is no longer pending.');
      const mergedPayload = mergeApprovalPayload(current.data.payload, postingMeta);
      const auditRow = {
        actor_staff_id: auditEntry.actorStaffId || null,
        action_type: auditEntry.actionType || 'approval_posted',
        entity_type: auditEntry.entityType || 'approval_request',
        entity_id: auditEntry.entityId || null,
        metadata: clone(auditEntry.metadata || {}),
        created_at: new Date().toISOString(),
      };
      if (commitRpcAvailable) {
        const { data, error: rpcError } = await client.rpc('ducess_commit_posting', {
          p_request_id: requestId,
          p_transactions: plan.transactions.map(t => ({ row: t.row, delta: t.delta, seed_balance: t.seedBalance })),
          p_ledger: plan.ledger || null,
          p_approval: { approved_by_staff_id: approver?.staffId || '', approved_by_name: approver?.name || '', decision_note: decisionNote || '', payload: mergedPayload },
          p_audit: auditRow,
        });
        if (!rpcError) return defaultResult.ok(normalizeApprovalRecord(data?.approval || data));
        if (!isMissingRpcError(rpcError)) {
          if (/APPROVAL_NOT_PENDING/.test(rpcError.message || '')) return defaultResult.err('APPROVAL_NOT_PENDING', 'Approval request is no longer pending.');
          return defaultResult.err('POSTING_COMMIT_FAILED', 'Posting was not saved and nothing was posted. Please try again.', rpcError);
        }
        commitRpcAvailable = false;
      }
      const running = new Map();
      for (const t of plan.transactions) {
        const key = String(t.accountId);
        const balanceAfter = (running.has(key) ? running.get(key) : t.seedBalance) + t.delta;
        const ins = await client.from(customerTransactionsTable).insert({ ...t.row, balance_after: balanceAfter });
        if (ins.error && ins.error.message) return defaultResult.err('CUSTOMER_TX_INSERT_FAILED', ins.error.message, ins.error);
        const bal = await upsertAccountBalance(t.accountId, balanceAfter);
        if (!bal.ok) return bal;
        running.set(key, balanceAfter);
      }
      if (plan.ledger) {
        const { error: ledgerError } = await client.from(staffCashLedgerTable).insert(plan.ledger);
        if (ledgerError) return defaultResult.err('STAFF_LEDGER_INSERT_FAILED', 'Could not write staff cash ledger entry in Supabase.', ledgerError);
      }
      const approvalResult = await markApprovalDecision(requestId, 'approved', approver, decisionNote, postingMeta);
      if (!approvalResult.ok) return approvalResult;
      const auditResult = await insertAuditLogEntry(auditEntry);
      if (!auditResult.ok) return auditResult;
      return approvalResult;
    }

    async function rejectRequest(payload = {}) {
      if (!canUseSupabase()) return local.approvals.rejectRequest(payload);
      return markApprovalDecision(payload.requestId, 'rejected', {
        staffId: payload.rejectedByStaffId || payload.rejected_by_staff_id || '',
        name: payload.rejectedByName || payload.rejected_by_name || '',
      }, payload.note || '', null);
    }

    async function submitAccountOpening(payload = {}) {
      return submitApprovalRequest({
        requestType: 'account_opening',
        requestedByStaffId: payload.openedByStaffId || payload.requestedByStaffId || '',
        requestedByName: payload.requestedByName || payload.openedByName || '',
        payload: clone(payload),
      });
    }

    async function submitAccountMaintenance(payload = {}) {
      return submitApprovalRequest({
        requestType: 'account_maintenance',
        requestedByStaffId: payload.requestedByStaffId || '',
        requestedByName: payload.requestedByName || '',
        payload: clone(payload),
      });
    }

    async function submitAccountReactivation(payload = {}) {
      return submitApprovalRequest({
        requestType: 'account_reactivation',
        requestedByStaffId: payload.requestedByStaffId || '',
        requestedByName: payload.requestedByName || '',
        payload: clone(payload),
      });
    }

    async function submitCredit(payload = {}) {
      return submitApprovalRequest({
        requestType: 'customer_credit',
        requestedByStaffId: payload.requestedByStaffId || '',
        requestedByName: payload.requestedByName || '',
        payload: clone(payload),
      });
    }

    async function submitDebit(payload = {}) {
      return submitApprovalRequest({
        requestType: 'customer_debit',
        requestedByStaffId: payload.requestedByStaffId || '',
        requestedByName: payload.requestedByName || '',
        payload: clone(payload),
      });
    }


    async function fetchApprovedCustomerTransactionsForStaffDate(staffId, businessDate) {
      let query = client.from(customerTransactionsTable).select(customerTransactionsSelect);
      if (staffId) query = query.eq('posted_by_id', staffId);
      if (businessDate) {
        const start = `${businessDate}T00:00:00.000Z`;
        const endDate = new Date(`${businessDate}T00:00:00.000Z`);
        endDate.setUTCDate(endDate.getUTCDate() + 1);
        const end = endDate.toISOString();
        query = query.gte('effective_at', start).lt('effective_at', end);
      }
      const { data, error: queryError } = await query.order('effective_at', { ascending: true, nullsFirst: false }).order('created_at', { ascending: true });
      if (queryError) return defaultResult.err('COD_TX_FETCH_FAILED', 'Could not load approved customer transactions from Supabase.', queryError);
      const rows = (Array.isArray(data) ? data : []).filter((row) => {
        const d = String(row.effective_at || row.created_at || '').slice(0,10);
        return !businessDate || d === businessDate;
      });
      return defaultResult.ok(rows);
    }

    async function fetchApprovedStaffCashEntriesForStaffDate(staffId, businessDate) {
      let query = client.from(staffCashLedgerTable).select(staffCashLedgerSelect);
      if (staffId) query = query.eq('staff_id', staffId);
      if (businessDate) query = query.eq('float_date', businessDate);
      const { data, error: queryError } = await query.order('created_at', { ascending: true });
      if (queryError) return defaultResult.err('COD_LEDGER_FETCH_FAILED', 'Could not load staff cash ledger entries from Supabase.', queryError);
      const rows = (Array.isArray(data) ? data : []).filter((row) => {
        const d = String(row.float_date || row.created_at || '').slice(0,10);
        return !businessDate || d === businessDate;
      });
      return defaultResult.ok(rows);
    }

    function computeCodMetricsFromRows(transactionRows = [], cashRows = []) {
      const totalCredits = transactionRows.filter((row) => String(row.tx_type || row.type || '').toLowerCase() === 'credit').reduce((sum, row) => sum + normalizeNumber(row.amount), 0);
      const totalDebits = transactionRows.filter((row) => String(row.tx_type || row.type || '').toLowerCase() === 'debit').reduce((sum, row) => sum + normalizeNumber(row.amount), 0);
      const openingBalance = cashRows
        .filter((row) => ['approved_form', 'approved_float'].includes(String(row.entry_type || '').toLowerCase()))
        .reduce((sum, row) => sum + normalizeNumber(row.amount), 0);
      const floatTopUps = 0;
      const effectiveOpeningBalance = openingBalance;
      const netBookBalance = totalCredits - totalDebits;
      const remainingBalance = openingBalance - totalCredits - totalDebits;
      const expectedCash = remainingBalance;
      const overdraw = Math.max(0, -remainingBalance);
      return { openingBalance, floatTopUps, effectiveOpeningBalance, totalCredits, totalDebits, netBookBalance, remainingBalance, expectedCash, overdraw };
    }

    async function getCodPreview(payload = {}) {
      if (!canUseSupabase()) return local.cod.getCodPreview(payload);
      const txResult = await fetchApprovedCustomerTransactionsForStaffDate(payload.staffId, payload.businessDate);
      if (!txResult.ok) return txResult;
      const cashResult = await fetchApprovedStaffCashEntriesForStaffDate(payload.staffId, payload.businessDate);
      if (!cashResult.ok) return cashResult;
      return defaultResult.ok(computeCodMetricsFromRows(txResult.data, cashResult.data));
    }

    async function listCodSubmissions(filters = {}) {
      if (!canUseSupabase()) return local.cod.listCodSubmissions(filters);
      let query = client.from(codSubmissionsTable).select(codSubmissionsSelect).order('submitted_at', { ascending: false });
      if (filters.staffId) query = query.eq('staff_id', filters.staffId);
      if (filters.businessDate || filters.date) query = query.eq('business_date', filters.businessDate || filters.date);
      const limit = Number(filters?.limit || 100);
      if (Number.isFinite(limit) && limit > 0) query = query.limit(Math.min(limit, 500));
      const { data, error: queryError } = await query;
      if (queryError) return defaultResult.err('COD_LIST_FAILED', 'Could not load COD submissions from Supabase.', queryError);
      const baseRows = (data || []).map(normalizeCodSubmissionRecord).filter(Boolean);
      const ids = baseRows.map((row) => row.id).filter(Boolean);
      let resolutionMap = new Map();
      if (ids.length) {
        const { data: resData, error: resErr } = await client.from(codResolutionsTable).select(codResolutionsSelect).in('cod_submission_id', ids);
        if (resErr) return defaultResult.err('COD_RESOLUTION_LIST_FAILED', 'Could not load COD resolutions from Supabase.', resErr);
        resolutionMap = new Map((resData || []).map((row) => [String(row.cod_submission_id), row]));
      }
      return defaultResult.ok(baseRows.map((row) => {
        const res = resolutionMap.get(row.id);
        return res ? Object.assign({}, row, normalizeCodSubmissionRecord(res), { id: row.id, staffId: row.staffId, businessDate: row.businessDate, date: row.date }) : row;
      }));
    }

    async function getCodSubmissionById(codId) {
      if (!canUseSupabase()) return local.cod.getCodSubmissionById(codId);
      const listResult = await listCodSubmissions({});
      if (!listResult.ok) return listResult;
      return defaultResult.ok((listResult.data || []).find((row) => row.id === codId) || null);
    }

    async function submitCod(payload = {}) {
      if (!canUseSupabase()) return local.cod.submitCod(payload);
      let metrics = payload.metrics && typeof payload.metrics === 'object' ? clone(payload.metrics) : null;
      if (!metrics) {
        const previewResult = await getCodPreview({ staffId: payload.staffId, businessDate: payload.businessDate });
        if (!previewResult.ok) return previewResult;
        metrics = previewResult.data;
      }
      const resolvedStaffId = await resolveStaffUuid(client, payload.staffUuid || payload.staffBackendId || payload.staffId);
      if (!resolvedStaffId) return defaultResult.ok(null); // placeholder staff not in Supabase yet — skip silently
      let existingData = null;
      try {
        const existingQuery = client.from(codSubmissionsTable).select('id').eq('staff_id', resolvedStaffId).eq('business_date', payload.businessDate).maybeSingle();
        const existingResult = await existingQuery;
        if (existingResult.error && existingResult.error.code !== 'PGRST116') {
        } else {
          existingData = existingResult.data || null;
        }
      } catch (existingError) {
      }
      const row = {
        staff_id: resolvedStaffId,
        business_date: payload.businessDate || '',
        opening_balance: normalizeNumber(metrics.openingBalance),
        float_topups: normalizeNumber(metrics.floatTopUps),
        effective_opening_balance: normalizeNumber(metrics.effectiveOpeningBalance),
        total_credits: normalizeNumber(metrics.totalCredits),
        total_debits: normalizeNumber(metrics.totalDebits),
        net_book_balance: normalizeNumber(metrics.netBookBalance),
        remaining_balance: normalizeNumber(metrics.remainingBalance),
        expected_cash: normalizeNumber(metrics.expectedCash),
        actual_cash: normalizeNumber(payload.actualCash),
        variance: normalizeNumber(payload.actualCash) - normalizeNumber(metrics.expectedCash),
        overdraw: normalizeNumber(metrics.overdraw),
        note: payload.note || '',
        status: (normalizeNumber(payload.actualCash) - normalizeNumber(metrics.expectedCash) === 0 && normalizeNumber(metrics.overdraw) === 0) ? 'submitted' : 'flagged',
        submitted_by_staff_id: (await resolveStaffUuid(client, payload.submittedByStaffUuid || payload.submittedByStaffBackendId || payload.submittedByStaffId || payload.staffUuid || payload.staffBackendId || payload.staffId)) || resolvedStaffId || null,
        submitted_at: new Date().toISOString(),
      };
      let res;
      if (existingData?.id) {
        res = await client.from(codSubmissionsTable).update(row).eq('id', existingData.id).select(codSubmissionsSelect).single();
      } else {
        res = await client.from(codSubmissionsTable).insert(row).select(codSubmissionsSelect).single();
      }
      if (res.error) return defaultResult.err('COD_SUBMIT_FAILED', 'Could not submit COD record to Supabase.', res.error);
      await insertAuditLogEntry({ actorStaffId: row.submitted_by_staff_id || resolvedStaffId || null, actionType: 'cod_submission', entityType: 'cod_submission', entityId: res.data?.id || null, metadata: clone(row) });
      return defaultResult.ok(normalizeCodSubmissionRecord(res.data));
    }

    async function listDebts(filters = {}) {
      if (!canUseSupabase()) return local.cod.listDebts(filters);
      let query = client.from(debtsTable).select(debtsSelect).order('created_at', { ascending: false });
      if (filters.staffId) query = query.eq('staff_id', filters.staffId);
      if (filters.status) query = query.eq('status', filters.status);
      const { data, error: queryError } = await query;
      if (queryError) return defaultResult.err('DEBT_LIST_FAILED', 'Could not load debts from Supabase.', queryError);
      return defaultResult.ok((data || []).map(normalizeDebtRecord).filter(Boolean));
    }

    async function getDebtById(debtId) {
      if (!canUseSupabase()) return local.cod.getDebtById(debtId);
      const { data, error: queryError } = await client.from(debtsTable).select(debtsSelect).eq('id', debtId).maybeSingle();
      if (queryError) return defaultResult.err('DEBT_FETCH_FAILED', 'Could not load debt from Supabase.', queryError);
      return defaultResult.ok(normalizeDebtRecord(data));
    }

    async function submitDebtRepayment(payload = {}) {
      if (!canUseSupabase()) return local.cod.submitDebtRepayment(payload);
      return submitApprovalRequest({
        requestType: 'debt_repayment',
        requestedByStaffId: payload.requestedByStaffId || '',
        requestedByName: payload.requestedByName || '',
        payload: clone(payload),
        entityType: 'debt',
        entityId: payload.debtId || null,
      });
    }

    async function resolveCod(payload = {}) {
      if (!canUseSupabase()) return local.cod.resolveCod(payload);
      const submissionResult = await getCodSubmissionById(payload.codSubmissionId);
      if (!submissionResult.ok) return submissionResult;
      const cod = submissionResult.data;
      if (!cod) return defaultResult.err('COD_NOT_FOUND', 'COD submission was not found.');
      const finalAgreedAmount = normalizeNumber(payload.finalAgreedAmount);
      const adjustmentAmount = finalAgreedAmount - normalizeNumber(cod.netBookBalance);
      const debtAmount = Math.max(0, normalizeNumber(payload.debtAmount));
      let existingRes = await client.from(codResolutionsTable).select(codResolutionsSelect).eq('cod_submission_id', payload.codSubmissionId).maybeSingle();
      if (existingRes.error && existingRes.error.code != 'PGRST116') return defaultResult.err('COD_RESOLUTION_CHECK_FAILED', 'Could not verify COD resolution.', existingRes.error);
      const resolutionRow = {
        cod_submission_id: payload.codSubmissionId,
        final_agreed_amount: finalAgreedAmount,
        adjustment_amount: adjustmentAmount,
        debt_amount: debtAmount,
        resolution_note: payload.resolutionNote || '',
        resolved_by_staff_id: payload.resolvedByStaffId || '',
        resolved_at: new Date().toISOString(),
      };
      let resolutionResult;
      if (existingRes.data?.id) resolutionResult = await client.from(codResolutionsTable).update(resolutionRow).eq('id', existingRes.data.id).select(codResolutionsSelect).single();
      else resolutionResult = await client.from(codResolutionsTable).insert(resolutionRow).select(codResolutionsSelect).single();
      if (resolutionResult.error) return defaultResult.err('COD_RESOLUTION_FAILED', 'Could not store COD resolution in Supabase.', resolutionResult.error);
      if (adjustmentAmount !== 0) {
        const existingAdj = await fetchExistingPostedTransactionsByRequest(`cod-resolution:${payload.codSubmissionId}`);
      }
      if (adjustmentAmount !== 0) {
        const existingAudit = await client.from(customerTransactionsTable).select('id').eq('approval_request_id', `cod-resolution:${payload.codSubmissionId}`).limit(1);
        if (!existingAudit.error && !(existingAudit.data || []).length) {
          const adjustmentRow = {
            customer_id: null,
            account_id: null,
            tx_type: adjustmentAmount > 0 ? 'credit' : 'debit',
            amount: Math.abs(adjustmentAmount),
            details: `COD adjustment for ${cod.staffId} ${cod.businessDate}`,
            posted_by: 'COD Resolution',
            posted_by_id: payload.resolvedByStaffId || '',
            approved_by: payload.resolvedByStaffId || '',
            counterparty: cod.staffId || '',
            effective_at: isoAtMidday(cod.businessDate),
            created_at: new Date().toISOString(),
            balance_after: null,
            approval_request_id: `cod-resolution:${payload.codSubmissionId}`,
            status: 'approved',
          };
          await client.from(customerTransactionsTable).insert(adjustmentRow);
        }
      }
      if (debtAmount > 0) {
        const existingDebt = await client.from(debtsTable).select(debtsSelect).eq('source_cod_submission_id', payload.codSubmissionId).maybeSingle();
        const debtRow = {
          staff_id: cod.staffId,
          business_date: cod.businessDate,
          source_cod_submission_id: payload.codSubmissionId,
          amount: debtAmount,
          status: debtAmount > 0 ? 'open' : 'paid',
          note: payload.resolutionNote || '',
          created_by_staff_id: payload.resolvedByStaffId || '',
          updated_at: new Date().toISOString(),
        };
        if (existingDebt.data?.id) await client.from(debtsTable).update(debtRow).eq('id', existingDebt.data.id);
        else { debtRow['created_at'] = new Date().toISOString(); await client.from(debtsTable).insert(debtRow); }
      }
      await client.from(codSubmissionsTable).update({ status: 'resolved' }).eq('id', payload.codSubmissionId);
      await insertAuditLogEntry({ actorStaffId: payload.resolvedByStaffId || null, actionType: 'cod_resolution', entityType: 'cod_submission', entityId: payload.codSubmissionId, metadata: { finalAgreedAmount, adjustmentAmount, debtAmount, resolutionNote: payload.resolutionNote || '' } });
      const refreshed = await getCodSubmissionById(payload.codSubmissionId);
      return refreshed.ok ? refreshed : defaultResult.ok(Object.assign({}, cod, normalizeCodSubmissionRecord(resolutionResult.data), { status: 'resolved' }));
    }

    async function submitJournalEntries(payload = {}) {
      const rows = Array.isArray(payload.entries) ? payload.entries : [];
      const inferredType = rows.some((row) => row?.txType === 'debit') ? 'customer_debit_journal' : 'customer_credit_journal';
      return submitApprovalRequest({
        requestType: inferredType,
        requestedByStaffId: payload.requestedByStaffId || '',
        requestedByName: payload.requestedByName || '',
        payload: clone(payload),
      });
    }

    function canUseSupabase() {
      return !!client;
    }

    async function getStaffProfileBySelector(selector) {
      if (!canUseSupabase()) return error;
      let query = client.from(staffTable).select(staffProfileSelect).limit(1);
      Object.entries(selector || {}).forEach(([column, value]) => {
        if (value !== undefined && value !== null && value !== '') query = query.eq(column, value);
      });
      const { data, error: queryError } = await query.maybeSingle();
      if (queryError) return defaultResult.err('STAFF_PROFILE_FETCH_FAILED', 'Could not fetch staff profile from Supabase.', queryError);
      if (!data) return defaultResult.err('STAFF_PROFILE_NOT_FOUND', 'No matching staff profile was found in Supabase.');
      return defaultResult.ok(data);
    }


    function isUuidLike(value) {
      return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value || '').trim());
    }

    function staffToAccountSummary(rawStaff) {
      const staff = normalizeStaffSummary(rawStaff);
      if (!staff) return null;
      return {
        accountId: staff.id || staff.uuid || staff.staffId,
        accountNumber: staff.staffId || rawStaff?.staff_code || '',
        customerId: null,
        customerName: staff.fullName || rawStaff?.full_name || staff.staffId || '',
        status: staff.isActive === false ? 'inactive' : 'active',
        bookBalance: 0,
        accountType: 'staff',
        staffId: staff.staffId || rawStaff?.staff_code || '',
        staffUuid: staff.id || staff.uuid || ''
      };
    }

    async function fetchStaffAccountByKey(value) {
      if (!canUseSupabase()) return defaultResult.ok(null);
      const key = String(value || '').trim();
      if (!key) return defaultResult.ok(null);

      if (isUuidLike(key)) {
        const byId = await getStaffProfileBySelector({ id: key });
        if (byId.ok && byId.data) return defaultResult.ok(staffToAccountSummary(byId.data));
        if (!byId.ok && byId.error?.code !== 'STAFF_PROFILE_NOT_FOUND') return byId;
      }

      if (isUuidLike(key)) {
        const byAuth = await getStaffProfileBySelector({ auth_user_id: key });
        if (byAuth.ok && byAuth.data) return defaultResult.ok(staffToAccountSummary(byAuth.data));
        if (!byAuth.ok && byAuth.error?.code !== 'STAFF_PROFILE_NOT_FOUND') return byAuth;
      }

      const attempts = Array.from(new Set([key, key.toUpperCase(), key.toLowerCase()].filter(Boolean)));
      for (const staffCode of attempts) {
        const byCode = await getStaffProfileBySelector({ staff_code: staffCode });
        if (byCode.ok && byCode.data) return defaultResult.ok(staffToAccountSummary(byCode.data));
        if (!byCode.ok && byCode.error?.code !== 'STAFF_PROFILE_NOT_FOUND') return byCode;
      }

      // DUCESS staff posting account numbers are commonly 4000, 4001, etc.
      // If that number is used, map it to staff list order instead of querying customers.
      if (/^4\d{3}$/.test(key)) {
        const { data, error: listError } = await client.from(staffTable).select(staffProfileSelect).order('staff_code', { ascending: true });
        if (!listError && Array.isArray(data)) {
          const index = Number(key) - 4000;
          const row = data[index];
          if (row) return defaultResult.ok({ ...staffToAccountSummary(row), accountNumber: key });
        }
      }
      return defaultResult.ok(null);
    }

    async function fetchRolePermissions(roleCode) {
      if (!canUseSupabase() || !roleCode) return defaultResult.ok([]);
      const { data, error: queryError } = await client
        .from(staffRolePermissionsTable)
        .select('tool_code, allowed')
        .eq('role_code', roleCode);
      if (queryError) return defaultResult.ok([]); // table may not exist yet — fall back to default permissions
      const normalized = (Array.isArray(data) ? data : [])
        .filter((item) => item?.tool_code)
        .map((item) => ({ toolCode: item.tool_code, allowed: item.allowed !== false, source: 'role' }));
      return defaultResult.ok(normalized);
    }

    async function fetchTempGrants(staffId) {
      if (!canUseSupabase() || !staffId) return defaultResult.ok([]);
      const { data, error: queryError } = await client
        .from(staffTempGrantsTable)
        .select('id, staff_id, tool_code, starts_at, ends_at, note, enabled, granted_by_staff_id')
        .eq('staff_id', staffId)
        .eq('enabled', true);
      if (queryError) return defaultResult.ok([]); // table may not exist yet — skip temp grants
      const normalized = (Array.isArray(data) ? data : [])
        .map(normalizeTempGrantRecord)
        .filter(Boolean);
      return defaultResult.ok(normalized);
    }


    // Fix B 2026-10-22 (egress): customer reads skip photo_path — a base64
    // photo per customer was re-downloaded with every customer list sync.
    // The photo now loads only when a customer is shown (getCustomerPhoto).
    const customersListSelect = customersSelect.split(',').map(c => c.trim()).filter(c => c && c !== 'photo_path').join(', ');
    async function fetchCustomersRows(filters = {}) {
      if (!canUseSupabase()) return defaultResult.err('SUPABASE_UNAVAILABLE', 'Supabase client is not available.');
      let query = client.from(customersTable).select(customersListSelect);
      if (filters.customerId) query = query.eq('id', filters.customerId);
      if (Array.isArray(filters.ids)) query = query.in('id', filters.ids.length ? filters.ids : ['00000000-0000-0000-0000-000000000000']);
      if (filters.accountNumber) query = query.eq('account_number', String(filters.accountNumber).trim());
      if (filters.linkedStaffId) query = query.eq('linked_staff_id', filters.linkedStaffId);
      if (filters.status) query = query.eq('status', filters.status);
      if (filters.search) {
        const escaped = String(filters.search).replace(/,/g, ' ');
        query = query.or(`full_name.ilike.%${escaped}%,account_number.ilike.%${escaped}%,phone.ilike.%${escaped}%`);
      }
      const { data, error: queryError } = await query.order('created_at', { ascending: true });
      if (queryError) return defaultResult.err('CUSTOMERS_FETCH_FAILED', 'Could not fetch customers from Supabase.', queryError);
      return defaultResult.ok(Array.isArray(data) ? data : []);
    }

    async function fetchTransactionsByCustomerIds(customerIds) {
      if (!canUseSupabase()) return defaultResult.err('SUPABASE_UNAVAILABLE', 'Supabase client is not available.');
      const ids = Array.isArray(customerIds) ? customerIds.filter(Boolean) : [];
      if (!ids.length) return defaultResult.ok([]);
      // SURGICAL FIX 2026-09-29: Supabase returns at most 1000 rows per
      // request, and customer balances are summed from these rows — past
      // 1000 transactions the newest were silently dropped (wrong
      // balances). Now pages through with .range(), and batches customer
      // ids so the request URL can't outgrow server limits. Each customer
      // lives in exactly one batch, so per-customer order is preserved.
      const PAGE = 1000;
      const ID_BATCH = 150;
      const all = [];
      for (let i = 0; i < ids.length; i += ID_BATCH) {
        const batch = ids.slice(i, i + ID_BATCH);
        for (let from = 0; ; from += PAGE) {
          const { data, error: queryError } = await client
            .from(customerTransactionsTable)
            .select(customerTransactionsSelect)
            .in('customer_id', batch)
            .order('effective_at', { ascending: true, nullsFirst: false })
            .order('created_at', { ascending: true })
            .order('id', { ascending: true })
            .range(from, from + PAGE - 1);
          if (queryError) return defaultResult.err('CUSTOMER_TX_FETCH_FAILED', 'Could not fetch customer transactions from Supabase.', queryError);
          const rows = Array.isArray(data) ? data : [];
          all.push(...rows);
          if (rows.length < PAGE) break;
        }
      }
      return defaultResult.ok(all);
    }

    async function fetchTransactionsByAccountId(accountId) {
      if (!canUseSupabase()) return defaultResult.err('SUPABASE_UNAVAILABLE', 'Supabase client is not available.');
      if (!accountId) return defaultResult.ok([]);
      let primary = await client
        .from(customerTransactionsTable)
        .select(customerTransactionsSelect)
        .eq('account_id', accountId)
        .order('effective_at', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: true });
      if (primary.error) return defaultResult.err('ACCOUNT_TX_FETCH_FAILED', 'Could not fetch account statement from Supabase.', primary.error);
      let rows = Array.isArray(primary.data) ? primary.data : [];
      if (!rows.length) {
        const secondary = await client
          .from(customerTransactionsTable)
          .select(customerTransactionsSelect)
          .eq('customer_id', accountId)
          .order('effective_at', { ascending: true, nullsFirst: false })
          .order('created_at', { ascending: true });
        if (secondary.error) return defaultResult.err('ACCOUNT_TX_FETCH_FAILED', 'Could not fetch account statement from Supabase.', secondary.error);
        rows = Array.isArray(secondary.data) ? secondary.data : [];
      }
      return defaultResult.ok(rows);
    }

    async function fetchBalancesByAccountIds(accountIds) {
      if (!canUseSupabase()) return defaultResult.err('SUPABASE_UNAVAILABLE', 'Supabase client is not available.');
      const ids = Array.isArray(accountIds) ? accountIds.filter(Boolean) : [];
      if (!ids.length) return defaultResult.ok([]);
      const { data, error: queryError } = await client
        .from(customerBalancesTable)
        .select(customerBalancesSelect)
        .in('account_id', ids);
      if (queryError) return defaultResult.err('ACCOUNT_BALANCE_FETCH_FAILED', 'Could not fetch account balances from Supabase.', queryError);
      return defaultResult.ok(Array.isArray(data) ? data : []);
    }

    async function fetchAccountBySelector(selector = {}) {
      if (!canUseSupabase()) return defaultResult.err('SUPABASE_UNAVAILABLE', 'Supabase client is not available.');
      let query = client.from(customerAccountsTable).select(customerAccountsSelect).limit(1);
      Object.entries(selector).forEach(([column, value]) => {
        if (value !== undefined && value !== null && value !== '') query = query.eq(column, value);
      });
      const { data, error: queryError } = await query.maybeSingle();
      if (queryError) {
        // Migration bridge: current DUCESS can use customers.account_number directly
        // without a customer_accounts table. Missing legacy account table should
        // not block approval posting.
        if (isMissingColumnOrRelationError(queryError)) return defaultResult.ok(null);
        return defaultResult.err('ACCOUNT_FETCH_FAILED', 'Could not fetch account from Supabase.', queryError);
      }
      return defaultResult.ok(data || null);
    }

    function txRowToLocal(row) {
      return normalizeLocalTransaction({
        id: row.id,
        type: row.tx_type,
        amount: row.amount,
        details: row.details,
        posted_by: row.posted_by,
        posted_by_id: row.posted_by_id,
        approved_by: row.approved_by,
        counterparty: row.counterparty,
        effective_at: row.effective_at || row.created_at,
        created_at: row.created_at,
        balance_after: row.balance_after,
        __bf: row.__bf, __count: row.__count,
      });
    }

    async function buildCustomersForUi(rows, opts = {}) {
      const customerRows = Array.isArray(rows) ? rows : [];
      const customerIds = customerRows.map((row) => row.id).filter(Boolean);
      const txResult = opts.txRows ? defaultResult.ok(opts.txRows) : opts.skipTransactions ? defaultResult.ok([]) : await fetchTransactionsByCustomerIds(customerIds);
      if (!txResult.ok) return txResult;
      const txRows = txResult.data;
      const txByCustomer = new Map();
      txRows.forEach((row) => {
        const key = row.customer_id;
        if (!key) return;
        if (!txByCustomer.has(key)) txByCustomer.set(key, []);
        txByCustomer.get(key).push(txRowToLocal(row));
      });

      const normalized = customerRows.map((row) => customerToSummary({
        id: row.id,
        customer_number: row.customer_number,
        account_number: row.account_number,
        old_account_number: row.old_account_number,
        full_name: row.full_name,
        address: row.address,
        nin: row.nin,
        bvn: row.bvn,
        phone: row.phone,
        photo_path: row.photo_path,
        status: row.status,
        linked_staff_id: row.linked_staff_id,
        account_type: row.account_type,
        created_at: row.created_at,
        is_active: row.is_active,
        transactions: txByCustomer.get(row.id) || [],
      })).filter(Boolean);

      normalized.forEach((customer) => {
        let running = 0;
        (customer.transactions || []).sort((a, b) => new Date(a.date) - new Date(b.date)).forEach((tx) => {
          running += tx.type === 'credit' ? Number(tx.amount || 0) : -Number(tx.amount || 0);
          tx.balanceAfter = tx.balanceAfter ?? running;
        });
        customer.balance = Number(customer.transactions?.length ? running : customer.balance || 0);
      });
      return defaultResult.ok(normalized);
    }

    async function getCurrentStaff() {
      if (!canUseSupabase()) return local.staff.getCurrentStaff();
      const { data, error: sessionError } = await client.auth.getSession();
      if (sessionError) return defaultResult.err('AUTH_SESSION_FAILED', sessionError.message || 'Unable to fetch current session.', sessionError);
      const authSession = data?.session;
      if (!authSession?.user) return defaultResult.ok(null);

      let staffResult = await getStaffProfileBySelector({ auth_user_id: authSession.user.id });
      if (!staffResult.ok && authSession.user.email) {
        staffResult = await getStaffProfileBySelector({ auth_email: authSession.user.email });
      }
      if (!staffResult.ok) return staffResult;
      return defaultResult.ok(normalizeStaffSummary(staffResult.data));
    }

    async function getStaffById(staffId) {
      if (!canUseSupabase()) return local.staff.getStaffById(staffId);
      if (!staffId) return defaultResult.ok(null);

      let staffResult = await getStaffProfileBySelector({ id: staffId });
      if (!staffResult.ok) {
        staffResult = await getStaffProfileBySelector({ staff_code: staffId });
      }
      if (!staffResult.ok) {
        if (staffResult.error?.code === 'STAFF_PROFILE_NOT_FOUND') return defaultResult.ok(null);
        return staffResult;
      }
      return defaultResult.ok(normalizeStaffSummary(staffResult.data));
    }

   async function listStaff(filters = {}) {
      if (!canUseSupabase() || !client) return local.staff.listStaff(filters);
      try {
        let query = client.from(staffTable).select('id, staff_code, full_name, role_code, is_active, branch_id, auth_user_id, auth_email');
        if (filters.roleCode) query = query.eq('role_code', filters.roleCode);
        if (typeof filters.isActive === 'boolean') query = query.eq('is_active', filters.isActive);
        if (filters.search) {
          const escaped = String(filters.search).replace(/,/g, ' ');
          query = query.or(`full_name.ilike.%${escaped}%,staff_code.ilike.%${escaped}%`);
        }
        const { data, error: queryError } = await query.order('full_name', { ascending: true });
        if (queryError) {
          return local.staff.listStaff(filters);
        }
        return defaultResult.ok((Array.isArray(data) ? data : []).map(normalizeStaffSummary).filter(Boolean));
      } catch (err) {
        return local.staff.listStaff(filters);
      }
    }
    async function listActiveStaff() {
      return listStaff({ isActive: true });
    }


    // ROLE/STAFF SEPARATION 2026-10-11: operational-account provisioning,
    // extracted from createStaff so assignStaffRole can reuse it. A staff
    // member has AT MOST ONE staff_operational account for life — it is tied
    // to the person (linked_staff_id), not the role. If one already exists
    // (they held a cash role before) it is reused and re-activated, never
    // duplicated, so every balance and ledger line stays on the same account.
    async function provisionStaffOperationalAccount(staffUuid, fullName, roleCode) {
      try {
        const existing = await client.from(customersTable).select(customersSelect)
          .eq('linked_staff_id', staffUuid).eq('account_type', 'staff_operational').limit(1).maybeSingle();
        if (existing?.data) {
          const patch = { display_name: operationalDisplayName(roleCode, fullName), status: 'active', is_active: true };
          const upd = await client.from(customersTable).update(patch).eq('id', existing.data.id).select(customersSelect).maybeSingle();
          if (upd.error) return { account: existing.data, error: null, reused: true, renameError: upd.error.message };
          return { account: upd.data || existing.data, error: null, reused: true };
        }
        const { data: seqData, error: seqError } = await client.rpc('generate_staff_operational_account_number');
        if (seqError || !seqData) return { account: null, error: seqError?.message || 'Failed to generate operational account number.' };
        const acctInsert = await client.from(customersTable).insert({
          account_number: seqData,
          full_name: fullName,
          display_name: operationalDisplayName(roleCode, fullName),
          phone: '',
          status: 'active',
          account_type: 'staff_operational',
          linked_staff_id: staffUuid,
          system_assigned: true,
          created_at: new Date().toISOString(),
          is_active: true,
        }).select(customersSelect).maybeSingle();
        if (acctInsert.error) return { account: null, error: acctInsert.error.message };
        return { account: acctInsert.data, error: null };
      } catch (err) {
        return { account: null, error: err?.message || 'Unexpected error provisioning staff operational account.' };
      }
    }

    // Grants (or changes, or removes with roleCode 'unassigned') a staff
    // member's role. Goes through the ducess_assign_staff_role RPC so closing
    // the old assignment, opening the new one, updating staff.role_code and
    // the audit row happen atomically and admin-only. Deliberately NO raw
    // table fallback (same reasoning as updateStaffCode): changing role_code
    // without history would break the accountability trail.
    async function assignStaffRole(payload = {}) {
      if (!canUseSupabase()) return local.staff.assignStaffRole(payload);
      const roleCode = String(payload.roleCode || payload.role || 'unassigned');
      const rpcName = config?.supabase?.assignStaffRoleRpc || 'ducess_assign_staff_role';
      let staffUuid;
      try { staffUuid = await resolveStaffUuid(client, payload.staffId); } catch (_e) { staffUuid = payload.staffId; }
      try {
        const { error: rpcError } = await client.rpc(rpcName, {
          p_staff_id: staffUuid,
          p_role_code: roleCode,
          p_note: payload.note || '',
          p_assigned_by_staff_id: payload.assignedByStaffId || null,
          p_assigned_by_name: payload.assignedByName || null,
        });
        if (rpcError) return defaultResult.err('ROLE_ASSIGN_FAILED', rpcError.message || `The "${rpcName}" function isn't set up in Supabase yet — run supabase-staff-role-assignments.sql first.`, rpcError);
      } catch (err) {
        return defaultResult.err('ROLE_ASSIGN_FAILED', `The "${rpcName}" function isn't set up in Supabase yet — run supabase-staff-role-assignments.sql first.`, err);
      }
      const { data: staffRow, error: staffErr } = await client.from(staffTable).select(staffProfileSelect).eq('id', staffUuid).single();
      if (staffErr || !staffRow) return defaultResult.err('ROLE_ASSIGN_REFRESH_FAILED', 'Role was assigned but the staff record could not be re-read — refresh the page.', staffErr);
      // 2026-10-30: never report success if the database did not actually keep
      // the new role (the app used to say "is now Teller" while the staff
      // record still read Unassigned).
      {
        const normRole = (r) => { const v = String(r || '').trim().toLowerCase(); return (!v || v === 'unassigned') ? 'unassigned' : v; };
        if (normRole(staffRow.role_code) !== normRole(roleCode)) {
          return defaultResult.err('ROLE_NOT_SAVED', `The database accepted the request but the role is still "${staffRow.role_code || 'unassigned'}". The role was NOT saved — run DIAGNOSE-role-assignment.sql in Supabase and send me the result.`, staffRow);
        }
      }
      const summary = normalizeStaffSummary(staffRow);
      if (CASH_ROLES.includes(roleCode)) {
        const prov = await provisionStaffOperationalAccount(staffRow.id, summary.fullName, roleCode);
        if (prov.account) summary.operationalAccount = prov.account;
        if (prov.reused) summary.operationalAccountReused = true;
        if (prov.error) summary.operationalAccountError = prov.error;
      }
      return defaultResult.ok(summary);
    }

    async function listRoleAssignments() {
      if (!canUseSupabase()) return local.staff.listRoleAssignments();
      try {
        const { data, error: listError } = await client.from('staff_role_assignments')
          .select('id, staff_id, role_code, assigned_at, ended_at, assigned_by_staff_id, assigned_by_name, ended_by_staff_id, note')
          .order('assigned_at', { ascending: true }).limit(5000);
        // Table not migrated yet → treat as "no history" so the app still
        // loads; role-at-time then falls back to each staff's current role.
        if (listError) return defaultResult.ok([]);
        return defaultResult.ok((data || []).map(normalizeRoleAssignment).filter(Boolean));
      } catch (_e) {
        return defaultResult.ok([]);
      }
    }

    // 2026-11-04: login self-test. Tries the just-set password on a throwaway
    // client (nothing is stored, the admin's session is untouched) so the admin
    // learns IMMEDIATELY whether the new staff member can actually sign in.
    async function testStaffLogin({ emails = [], password }) {
      const factory = global.supabase?.createClient;
      const url = client?.supabaseUrl || config?.supabase?.url;
      const key = client?.supabaseKey || config?.supabase?.anonKey;
      if (!factory || !url || !key) return { status: 'skipped', message: 'Login test is not available in this browser.' };
      const tmp = factory(url, key, { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false, storageKey: 'ducess-login-test' } });
      const tried = [];
      let lastMessage = '';
      for (const email of Array.from(new Set(emails.filter(Boolean).map(e => String(e).trim())))) {
        const { data, error } = await tmp.auth.signInWithPassword({ email, password });
        if (!error && data?.user) {
          try { await tmp.auth.signOut(); } catch (_e) {}
          return { status: 'ok', email, userId: data.user.id, tried };
        }
        tried.push(email);
        lastMessage = error?.message || lastMessage;
      }
      return { status: 'failed', message: lastMessage || 'Sign-in failed', tried };
    }

    async function createStaff(payload = {}) {
      if (!canUseSupabase()) return local.staff.createStaff(payload);

      const staffCode = (payload.staffCode || payload.staffId || '').toUpperCase();
      const fullName = payload.name || payload.fullName || '';
      // ROLE/STAFF SEPARATION 2026-10-11: staff are created WITHOUT a role
      // ('unassigned') — a role is granted afterwards via assignStaffRole.
      const roleCode = payload.role || payload.roleCode || 'unassigned';
      const branchId = payload.branchId || null;
      const temporaryPassword = payload.temporaryPassword ? String(payload.temporaryPassword).trim() : null;
      const syntheticEmail = `${staffCode}${config?.supabase?.syntheticEmailSuffix || '@ducess.local'}`;

      // Step 1: Call Edge Function to create the Supabase Auth user (keeps service key off frontend)
      let authUserId = null;
      let edgeJson = null;
      const edgeFnUrl = config?.supabase?.createStaffEdgeFn
        || `${config?.supabase?.url || ''}/functions/v1/create-staff-user`;
      if (temporaryPassword && edgeFnUrl) {
        try {
          const resp = await fetch(edgeFnUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${config?.supabase?.anonKey || ''}` },
            body: JSON.stringify({ staffCode, staffId: staffCode, email: syntheticEmail, password: temporaryPassword, temporaryPassword, fullName, roleCode }),
          });
          const json = await resp.json().catch(() => ({}));
          edgeJson = json;
          if (resp.ok && json.id) {
            authUserId = json.id;
          } else {
            // If the auth user already exists (orphaned from a previous failed attempt),
            // recover its ID from the Edge Function response or from any existing
            // staff profile row, then continue to the profile insert rather than bailing.
            const alreadyRegistered = (json.error || '').toLowerCase().includes('already') ||
              (json.error || '').toLowerCase().includes('registered') ||
              (json.error || '').toLowerCase().includes('email address');
            if (alreadyRegistered) {
              // Try to get the auth_user_id from the Edge Function's recovery field first
              if (json.userId || json.user_id || json.auth_user_id) {
                authUserId = json.userId || json.user_id || json.auth_user_id;
              } else {
                // Fall back: check if a staff profile already exists with this email —
                // if so, that's a true duplicate staff, not an orphan, and we should stop.
                const { data: existingProfile } = await client
                  .from(staffTable)
                  .select('id, staff_code, auth_user_id')
                  .eq('staff_code', staffCode)
                  .maybeSingle();
                if (existingProfile) {
                  return defaultResult.err('STAFF_ALREADY_EXISTS', `A staff member with code ${staffCode} already exists.`, existingProfile);
                }
                // No profile row exists — this is a genuine orphan.
                // Leave authUserId null and proceed; profile will be created
                // without an auth_user_id link (admin can re-link manually if needed).
              }
            } else {
              return defaultResult.err('AUTH_USER_CREATE_FAILED', json.error || 'Edge Function failed to create auth user', json);
            }
          }
        } catch (err) {
          return defaultResult.err('EDGE_FN_ERROR', 'Could not reach create-staff-user Edge Function', err);
        }
      }

      // Step 1.5 (2026-11-04): prove the new login works; repair it if it does not.
      let loginCheck = { status: 'skipped' };
      let rowEmail = syntheticEmail;
      if (temporaryPassword && edgeFnUrl) {
        const lower = staffCode.toLowerCase();
        const candidates = [edgeJson?.email, edgeJson?.user?.email, syntheticEmail, `${lower}${syntheticEmailSuffix}`, `${lower}@ducess.local`];
        loginCheck = await testStaffLogin({ emails: candidates, password: temporaryPassword });
        if (loginCheck.status === 'failed') {
          // Force the account's password to exactly what the admin typed, then test again.
          const fix = await resetStaffPassword({ staffCode, authUserId, temporaryPassword }).catch(e => ({ ok: false, error: { message: String(e?.message || e) } }));
          if (fix?.ok) {
            const again = await testStaffLogin({ emails: candidates, password: temporaryPassword });
            if (again.status === 'ok') loginCheck = { ...again, status: 'repaired' };
            else loginCheck = { ...again, message: again.message };
          } else {
            loginCheck = { ...loginCheck, message: `${loginCheck.message} (automatic repair failed: ${fix?.error?.message || 'unknown'})` };
          }
        }
        if (loginCheck.email) rowEmail = loginCheck.email;
      }

      // Step 2: Insert staff profile row - build defensively, only add optional cols if they exist
      const insertRow = { staff_code: staffCode, full_name: fullName, role_code: roleCode, is_active: true };
      if (branchId) insertRow.branch_id = branchId;
      if (authUserId) insertRow.auth_user_id = authUserId;
      if (rowEmail) insertRow.auth_email = rowEmail;
     
      let data, insertError;
      ({ data, error: insertError } = await client.from(staffTable).insert(insertRow).select(staffProfileSelect).single());
      if (insertError && (insertError.code === '42703' || (insertError.message || '').includes('column'))) {
        const minRow = { staff_code: staffCode, full_name: fullName, role_code: roleCode, is_active: true };
        ({ data, error: insertError } = await client.from(staffTable).insert(minRow).select('id, staff_code, full_name, role_code, is_active').single());
      }
      if (insertError) return defaultResult.err('STAFF_CREATE_FAILED', 'Staff auth user created but profile insert failed: ' + insertError.message, insertError);

      // Step 2.5 (2026-08-14): auto-provision the teller's operational account
      // at creation time — same "T"+4-digit prefix/sequence rules as before,
      // but no separate Account Opening request and no approval step. This is
      // deterministic and system-generated; there is nothing here for an
      // approving officer to review, so routing it through the approval queue
      // would just add a hop with no actual decision in it.
      // SURGICAL ADDITION 2026-09-05 (client request): Treasury (cash_officer)
      // gets the same auto-provisioned operational account as a Teller —
      // it's what they debit from to fund tellers via Non Cash/"Debit an
      // Account", and what Cash Receipt credits. Same account-number
      // sequence/table, only the display name differs: client asked
      // specifically for "TREASURY <first name>" (not full name, unlike the
      // Teller convention below, which stays as-is).
      // SURGICAL ADDITION 2026-09-07 (client request): Admin Officer also
      // gets one now, following the same "ADMIN <first name>" convention as
      // Treasury's first-name naming.
      let operationalAccount = null;
      let operationalAccountError = null;
      if (CASH_ROLES.includes(roleCode)) {
        const prov = await provisionStaffOperationalAccount(data.id, fullName, roleCode);
        operationalAccount = prov.account;
        operationalAccountError = prov.error;
      }
      // Legacy path only (a role passed at creation): open the first
      // history row so the role is attributable from day one.
      if (roleCode && roleCode !== 'unassigned') {
        try {
          await client.from('staff_role_assignments').insert({ staff_id: data.id, role_code: roleCode, assigned_by_staff_id: payload.createdByStaffId || null, assigned_by_name: payload.createdByName || null, note: 'Assigned at creation' });
        } catch (_e) {}
      }

      // Step 3: Log audit
      try {
        await client.from(config?.supabase?.auditLogTable || 'audit_log').insert({
          actor_staff_id: payload.createdByStaffId || null,
          action_type: 'staff_created',
          entity_type: 'staff',
          entity_id: data.id,
          metadata: { staff_code: staffCode, full_name: fullName, role_code: roleCode, auth_user_id: authUserId, operational_account_number: operationalAccount?.account_number || null },
        });
      } catch (_e) {}

      const staffSummary = normalizeStaffSummary(data);
      if (operationalAccount) staffSummary.operationalAccount = operationalAccount;
      if (operationalAccountError) staffSummary.operationalAccountError = operationalAccountError;
      staffSummary.loginCheck = loginCheck;
      return defaultResult.ok(staffSummary);
    }

    // SURGICAL ADDITION 2026-09-05 (client request), GENERALIZED 2026-09-07:
    // one-time backfill so every Treasury (cash_officer) AND Admin Officer
    // staff member already in the system gets the same auto-provisioned
    // operational account new ones now get (see createStaff above) —
    // "TREASURY <first name>" / "ADMIN <first name>", same T#### sequence.
    // Skips anyone who already has one; safe to run more than once.
    async function backfillTreasuryOperationalAccounts() {
      if (!canUseSupabase()) {
        return defaultResult.err('LOCAL_MODE_UNSUPPORTED', 'Operational account backfill requires Supabase — local/offline mode does not track linked staff accounts.');
      }
      try {
        const { data: eligibleStaff, error: staffError } = await client
          .from(staffTable)
          .select('id, staff_code, full_name, role_code, is_active')
          .in('role_code', ['admin_officer'])
          .eq('is_active', true);
        if (staffError) return defaultResult.err('STAFF_QUERY_FAILED', staffError.message, staffError);

        const { data: existingAccounts, error: acctError } = await client
          .from(customersTable)
          .select('linked_staff_id')
          .eq('account_type', 'staff_operational');
        if (acctError) return defaultResult.err('ACCOUNT_QUERY_FAILED', acctError.message, acctError);
        const alreadyProvisioned = new Set((existingAccounts || []).map(r => r.linked_staff_id).filter(Boolean));

        const created = [];
        const skipped = [];
        const errors = [];
        for (const s of (eligibleStaff || [])) {
          if (alreadyProvisioned.has(s.id)) { skipped.push(s.full_name); continue; }
          try {
            const { data: seqData, error: seqError } = await client.rpc('generate_staff_operational_account_number');
            if (seqError || !seqData) { errors.push(`${s.full_name}: ${seqError?.message || 'failed to generate account number'}`); continue; }
            const firstName = String(s.full_name || '').trim().split(/\s+/)[0] || s.full_name;
            const displayName = s.role_code === 'admin_officer' ? `ADMIN ${firstName}` : `TREASURY ${firstName}`;
            const acctInsert = await client.from(customersTable).insert({
              account_number: seqData,
              full_name: s.full_name,
              display_name: displayName,
              phone: '',
              status: 'active',
              account_type: 'staff_operational',
              linked_staff_id: s.id,
              system_assigned: true,
              created_at: new Date().toISOString(),
              is_active: true,
            }).select(customersSelect).maybeSingle();
            if (acctInsert.error) { errors.push(`${s.full_name}: ${acctInsert.error.message}`); continue; }
            created.push({ name: s.full_name, accountNumber: acctInsert.data?.account_number });
          } catch (err) {
            errors.push(`${s.full_name}: ${err?.message || 'unexpected error'}`);
          }
        }

        try {
          await client.from(config?.supabase?.auditLogTable || 'audit_log').insert({
            action_type: 'treasury_accounts_backfilled',
            entity_type: 'staff',
            metadata: { created: created.length, skipped: skipped.length, errors: errors.length },
          });
        } catch (_e) {}

        return defaultResult.ok({ created, skipped, errors });
      } catch (err) {
        return defaultResult.err('BACKFILL_FAILED', err?.message || 'Unexpected error during backfill', err);
      }
    }

    async function updateStaffStatus(payload = {}) {
      if (!canUseSupabase()) return local.staff.updateStaffStatus(payload);
      const rpcName = config?.supabase?.updateStaffStatusRpc || 'ducess_update_staff_status';
      try {
        const { data: rpcData, error: rpcError } = await client.rpc(rpcName, {
          staff_id: await resolveStaffUuid(client, payload.staffId),
          is_active: payload.isActive !== false,
          reason: payload.reason || '',
          override_used: payload.override === true,
          updated_by_staff_id: payload.updatedByStaffId || null,
          updated_by_name: payload.updatedByName || null,
        });
        if (!rpcError) return defaultResult.ok(normalizeStaffSummary(Array.isArray(rpcData) ? rpcData[0] : rpcData));
      } catch (err) {}
      const { data, error: updateError } = await client.from(staffTable).update({ is_active: payload.isActive !== false }).eq('id', payload.staffId).select(staffProfileSelect).single();
      if (updateError) return defaultResult.err('STAFF_STATUS_UPDATE_FAILED', 'Could not update staff status in Supabase.', updateError);
      return defaultResult.ok(normalizeStaffSummary(data));
    }

    async function updateStaffCode(payload = {}) {
      if (!canUseSupabase()) return local.staff.updateStaffCode(payload);
      const newCode = String(payload.staffCode || '').trim().toUpperCase();
      if (!newCode) return defaultResult.err('STAFF_CODE_REQUIRED', 'New Staff ID is required.');
      const rpcName = config?.supabase?.updateStaffCodeRpc || 'ducess_update_staff_code';
      // Deliberately NOT falling back to a raw table update here (unlike
      // updateStaffStatus above): staff_code can be the basis of the
      // staff member's Supabase Auth login email (see
      // resolveAuthEmailByStaffId / synthetic_suffix mode). A raw column
      // update would desync it from the actual auth account and lock
      // them out. This RPC must be created server-side to update both
      // staff_code and, where applicable, the linked auth user's email
      // in the same transaction — see supabase-account-number-prefixes.sql
      // companion notes for the staff_code rename RPC.
      try {
        const { data: rpcData, error: rpcError } = await client.rpc(rpcName, {
          staff_id: await resolveStaffUuid(client, payload.staffId),
          new_staff_code: newCode,
          updated_by_staff_id: payload.updatedByStaffId || null,
          updated_by_name: payload.updatedByName || null,
        });
        if (!rpcError) return defaultResult.ok(normalizeStaffSummary(Array.isArray(rpcData) ? rpcData[0] : rpcData));
        return defaultResult.err('STAFF_CODE_UPDATE_FAILED', rpcError.message || `The "${rpcName}" function isn't set up in Supabase yet — see the SQL notes.`, rpcError);
      } catch (err) {
        return defaultResult.err('STAFF_CODE_UPDATE_FAILED', `The "${rpcName}" function isn't set up in Supabase yet — see the SQL notes.`, err);
      }
    }

    async function getEffectivePermissions(staffId) {
      if (!canUseSupabase()) return local.permissions.getEffectivePermissions(staffId);
      const staffResult = await getStaffById(staffId);
      if (!staffResult.ok) return staffResult;
      const staff = staffResult.data;
      if (!staff) return defaultResult.ok([]);

      const rolePermsResult = await fetchRolePermissions(staff.roleCode);
      const tempGrantResult = await fetchTempGrants(staff.id);

      const rolePerms = rolePermsResult.ok && rolePermsResult.data.length
        ? rolePermsResult.data.filter((item) => item.allowed !== false)
        : buildDefaultPermissions(staff.roleCode);
      const tempPerms = tempGrantResult.ok
        ? tempGrantResult.data.map((item) => ({ toolCode: item.toolCode, allowed: item.enabled !== false, source: 'temp_grant' }))
        : [];

      const merged = new Map();
      rolePerms.forEach((perm) => {
        if (perm?.toolCode) merged.set(`role:${perm.toolCode}`, perm);
      });
      tempPerms.forEach((perm) => {
        if (perm?.toolCode) merged.set(`temp_grant:${perm.toolCode}`, perm);
      });
      return defaultResult.ok(Array.from(merged.values()));
    }

    async function hasPermission(payload) {
      if (!canUseSupabase()) return local.permissions.hasPermission(payload);
      const permsResult = await getEffectivePermissions(payload?.staffId);
      if (!permsResult.ok) return permsResult;
      return defaultResult.ok(permsResult.data.some((perm) => perm.toolCode === payload?.toolCode && perm.allowed !== false));
    }

    // Pages through a set-returning history function, 1000 rows a page; each
    // page continues after the previous page's last row (keyset paging).
    async function rpcPages(fn, args, cursorCol) {
      const all = [];
      let after = null;
      for (;;) {
        const { data, error } = await client.rpc(fn, { ...args, p_after_at: after ? after[cursorCol] : null, p_after_id: after ? String(after.id) : null, p_limit: 1000 });
        if (error) return defaultResult.err(isMissingRpcError(error) ? 'HISTORY_UNSUPPORTED' : 'HISTORY_FETCH_FAILED', 'Could not load history.', error);
        const rows = Array.isArray(data) ? data : [];
        all.push(...rows);
        if (rows.length < 1000) break;
        after = rows[rows.length - 1];
      }
      return defaultResult.ok(all);
    }
    // History functions return whole rows; keep only the columns the normal
    // transaction read selects, so dates and fields come out identical.
    const txSelectColumns = customerTransactionsSelect.split(',').map(c => c.trim()).filter(Boolean);
    function pickTxColumns(row) {
      const out = {};
      txSelectColumns.forEach(c => { out[c] = row[c] === undefined ? null : row[c]; });
      return out;
    }

    function syncSpec(kind) {
      // Transactions are insert-only, so they carry inserted_at (server
      // time) rather than an updated_at trigger.
      if (kind === 'approvals') return { table: approvalRequestsTable, col: 'updated_at', select: 'id, updated_at' };
      if (kind === 'transactions') return { table: customerTransactionsTable, col: 'inserted_at', select: 'id, customer_id, inserted_at', notNull: 'customer_id' };
      return { table: customersTable, col: 'updated_at', select: 'id, updated_at' };
    }

    async function getCustomerPhoto(customerId) {
      if (!canUseSupabase() || !customerId) return defaultResult.ok('');
      const { data, error: queryError } = await client.from(customersTable).select('photo_path').eq('id', customerId).maybeSingle();
      if (queryError) return defaultResult.err('CUSTOMER_PHOTO_FAILED', 'Could not load customer photo.', queryError);
      return defaultResult.ok(data?.photo_path || '');
    }

    async function listCustomers(filters = {}) {
      if (!canUseSupabase()) return local.customers.listCustomers(filters);
      const rowsResult = await fetchCustomersRows(filters);
      if (!rowsResult.ok) return rowsResult;
      return buildCustomersForUi(rowsResult.data || []);
    }

    async function searchCustomers(query) {
      if (!canUseSupabase()) return local.customers.searchCustomers(query);
      return listCustomers({ search: query || '' });
    }

    // SURGICAL ADDITION 2026-08-14: dedicated, self-contained read for the
    // Staff Salary Balance report. Deliberately NOT folded into
    // fetchCustomersRows/customersSelect (used by login/session sync and every
    // other customer read) — if the staff_role_code column hasn't been
    // migrated in yet, this function degrades gracefully on its own instead
    // of breaking every other customer-related screen in the app.
    // SURGICAL ADDITION 2026-08-24 (client request): system-assigned account
    // numbers (Teller/Staff Salary/Expense/Income) used to only be generated
    // at APPROVAL time, deep inside performDirectPostingForApproval. Client
    // now wants Customer Service to see the number at the point of
    // CREATION, before the request is even sent for approval. This exposes
    // the same RPCs performDirectPostingForApproval already calls, but
    // callable directly from the Account Opening submit flow. Approval-time
    // logic is untouched — it already checks "is a number already present?"
    // before generating one, so passing a pre-generated number through the
    // payload is handled correctly with zero changes needed there.
    async function generateSystemAccountNumber(acctType) {
      if (!canUseSupabase()) return defaultResult.err('NOT_SUPPORTED', 'System account number generation requires Supabase mode.');
      const rpcName = {
        staff_operational: 'generate_staff_operational_account_number',
        treasury: 'generate_treasury_account_number',
        staff_salary: 'generate_staff_salary_account_number',
        expense: 'generate_expense_account_number',
        income: 'generate_income_account_number',
      }[acctType];
      if (!rpcName) return defaultResult.err('INVALID_ACCOUNT_TYPE', `No system-assigned number generator for account type "${acctType}".`);
      const { data, error: rpcError } = await client.rpc(rpcName);
      if (rpcError || !data) return defaultResult.err('ACCOUNT_NUMBER_GENERATION_FAILED', 'Could not generate account number — check database sequences.', rpcError);
      return defaultResult.ok(data);
    }

    // SURGICAL ADDITION 2026-08-26 (client correction): the function above
    // is number-CONSUMING (nextval) — calling it just to show a preview on
    // the form burned a real number every time, even on cancelled/abandoned
    // requests (this is why testing produced numbers like "I3008" instead
    // of starting at 1). This is the non-consuming counterpart: it shows
    // what the NEXT number would be without reserving it, safe to call
    // repeatedly for a live on-form preview. The REAL number is only
    // assigned by generateSystemAccountNumber above, called once, at
    // actual submission — never for preview purposes.
    async function peekSystemAccountNumber(acctType) {
      if (!canUseSupabase()) return defaultResult.err('NOT_SUPPORTED', 'System account number preview requires Supabase mode.');
      const rpcName = {
        staff_operational: 'peek_staff_operational_account_number',
        treasury: 'peek_treasury_account_number',
        staff_salary: 'peek_staff_salary_account_number',
        expense: 'peek_expense_account_number',
        income: 'peek_income_account_number',
      }[acctType];
      if (!rpcName) return defaultResult.err('INVALID_ACCOUNT_TYPE', `No system-assigned number preview for account type "${acctType}".`);
      const { data, error: rpcError } = await client.rpc(rpcName);
      if (rpcError || !data) return defaultResult.err('ACCOUNT_NUMBER_PREVIEW_FAILED', 'Could not preview account number.', rpcError);
      return defaultResult.ok(data);
    }

    async function listStaffSalaryAccounts() {
      if (!canUseSupabase()) return defaultResult.ok([]);
      const cols = 'id, account_number, full_name, display_name, status, is_active, created_at, staff_role_code';
      let { data, error: queryError } = await client.from(customersTable).select(cols).eq('account_type', 'staff_salary').order('created_at', { ascending: true });
      if (queryError) {
        const msg = String(queryError.message || '').toLowerCase();
        if (queryError.code === '42703' || msg.includes('column')) {
          // Migration not applied yet — retry without the role column so the
          // report still works, just without role classification/filtering.
          const retry = await client.from(customersTable).select('id, account_number, full_name, display_name, status, is_active, created_at').eq('account_type', 'staff_salary').order('created_at', { ascending: true });
          if (retry.error) return defaultResult.err('STAFF_SALARY_LIST_FAILED', 'Could not fetch staff salary accounts.', retry.error);
          data = retry.data; queryError = null;
        } else {
          return defaultResult.err('STAFF_SALARY_LIST_FAILED', 'Could not fetch staff salary accounts.', queryError);
        }
      }
      const staffAccountIds = (data || []).map(r => r.id).filter(Boolean);
      const txResult = staffAccountIds.length ? await fetchTransactionsByCustomerIds(staffAccountIds) : { ok: true, data: [] };
      const txByCustomer = new Map();
      (txResult.ok ? txResult.data : []).forEach(row => {
        const key = row.customer_id;
        if (!key) return;
        if (!txByCustomer.has(key)) txByCustomer.set(key, 0);
        txByCustomer.set(key, txByCustomer.get(key) + (row.tx_type === 'credit' ? Number(row.amount || 0) : -Number(row.amount || 0)));
      });
      const normalized = (data || []).map(row => ({
        id: row.id,
        accountNumber: row.account_number,
        name: row.display_name || row.full_name || '',
        staffRoleCode: row.staff_role_code || null,
        active: typeof row.is_active === 'boolean' ? row.is_active : String(row.status || 'active').toLowerCase() === 'active',
        createdAt: row.created_at,
        balance: Number(txByCustomer.get(row.id) || 0),
      }));
      return defaultResult.ok(normalized);
    }

    async function getCustomerById(customerId) {
      if (!canUseSupabase()) return local.customers.getCustomerById(customerId);
      const rowsResult = await fetchCustomersRows({ customerId });
      if (!rowsResult.ok) return rowsResult;
      const built = await buildCustomersForUi((rowsResult.data || []).slice(0, 1));
      if (!built.ok) return built;
      return defaultResult.ok(built.data[0] || null);
    }

    async function getCustomerByAccountNumber(accountNumber) {
      if (!canUseSupabase()) return local.customers.getCustomerByAccountNumber(accountNumber);
      const rowsResult = await fetchCustomersRows({ accountNumber });
      if (!rowsResult.ok) return rowsResult;
      const built = await buildCustomersForUi((rowsResult.data || []).slice(0, 1));
      if (!built.ok) return built;
      return defaultResult.ok(built.data[0] || null);
    }

    async function getAccountByNumber(accountNumber) {
      if (!canUseSupabase()) return local.accounts.getAccountByNumber(accountNumber);
      const customerResult = await getCustomerByAccountNumber(accountNumber);
      if (!customerResult.ok) return customerResult;
      return defaultResult.ok(customerResult.data ? customerToAccountSummary(customerResult.data) : null);
    }

    // Fix B 2026-10-22 (egress): account lookups for posting used to pull the
    // customer's whole transaction history just to read a balance. The
    // balance comes from customer_account_balances instead (see below).
    async function getCustomerLight(selector) {
      const rowsResult = await fetchCustomersRows(selector);
      if (!rowsResult.ok) return rowsResult;
      const built = await buildCustomersForUi((rowsResult.data || []).slice(0, 1), { skipTransactions: true });
      if (!built.ok) return built;
      return defaultResult.ok(built.data[0] || null);
    }

    async function getAccountSummary(accountId) {
      if (!canUseSupabase()) return local.accounts.getAccountSummary(accountId);
      const key = String(accountId || '').trim();
      if (!key) return defaultResult.ok(null);

      // Staff account fast-path: try staff lookup first for UUID-like keys and 4xxx account numbers.
      // This avoids the "customer not found" error for staff accounts that are not in the customers table.
      const earlyStaffResult = await fetchStaffAccountByKey(key);
      if (earlyStaffResult.ok && earlyStaffResult.data) {
        return defaultResult.ok(earlyStaffResult.data);
      }

      // Migration bridge: approval payloads often pass the customer id as accountId.
      // Resolve from customers first so posting does not depend on customer_accounts.
      let customer = null;
      const directCustomerResult = await getCustomerLight({ customerId: key });
      if (!directCustomerResult.ok) return directCustomerResult;
      customer = directCustomerResult.data;

      let accountRow = null;
      if (!customer) {
        const accountResult = await fetchAccountBySelector({ id: key });
        if (!accountResult.ok) return accountResult;
        accountRow = accountResult.data;
        if (accountRow?.customer_id) {
          const customerResult = await getCustomerLight({ customerId: accountRow.customer_id });
          if (!customerResult.ok) return customerResult;
          customer = customerResult.data;
        }
      }

      if (!customer && accountRow?.account_number) {
        const customerResult = await getCustomerLight({ accountNumber: accountRow.account_number });
        if (!customerResult.ok) return customerResult;
        customer = customerResult.data;
      }

      if (!customer) {
        const byAccountNumber = await getCustomerLight({ accountNumber: key });
        if (!byAccountNumber.ok) return byAccountNumber;
        customer = byAccountNumber.data;
      }

      if (!customer) return defaultResult.ok(null);
      const summary = customerToAccountSummary(customer);
      if (summary && accountRow?.id) summary.accountId = accountRow.id;
      if (summary && accountRow?.status) summary.status = accountRow.status;
      const balanceResult = await fetchBalancesByAccountIds([summary?.accountId]);
      if (summary && balanceResult.ok && balanceResult.data[0] && balanceResult.data[0].book_balance != null) {
        summary.bookBalance = Number(balanceResult.data[0].book_balance || 0);
      } else if (summary && customer?.id) {
        // No stored balance yet: total this customer's transactions (just
        // type + amount) — same figure the full history used to give.
        const { data: txs, error: sumError } = await client.from(customerTransactionsTable).select('tx_type, amount').eq('customer_id', customer.id);
        if (sumError) return defaultResult.err('ACCOUNT_BALANCE_FETCH_FAILED', 'Could not total the account balance.', sumError);
        summary.bookBalance = (txs || []).reduce((sum, t) => sum + (t.tx_type === 'credit' ? 1 : -1) * Number(t.amount || 0), 0);
      }
      return defaultResult.ok(summary);
    }

    async function getAccountStatement(payload = {}) {
      if (!canUseSupabase()) return local.accounts.getAccountStatement(payload);
      const txResult = await fetchTransactionsByAccountId(payload.accountId);
      if (!txResult.ok) return txResult;
      const fromDate = payload.fromDate ? new Date(payload.fromDate).getTime() : null;
      const toDate = payload.toDate ? new Date(payload.toDate).getTime() : null;
      let entries = (txResult.data || []).map((row) => normalizeStatementEntry({
        id: row.id,
        type: row.tx_type,
        amount: row.amount,
        details: row.details,
        effective_at: row.effective_at || row.created_at,
        created_at: row.created_at,
        balance_after: row.balance_after,
      })).filter(Boolean).filter((entry) => {
        const time = new Date(entry.date).getTime();
        if (fromDate && time < fromDate) return false;
        if (toDate && time > toDate + 86399999) return false;
        return true;
      }).sort((a, b) => new Date(b.date) - new Date(a.date));
      if (payload.limit && payload.limit > 0) entries = entries.slice(0, payload.limit);
      return defaultResult.ok(entries);
    }

    async function buildSessionFromSupabaseAuthSession(authSession) {
      if (!authSession?.user) return defaultResult.ok(null);

      const currentStaffResult = await getCurrentStaff();
      if (!currentStaffResult.ok) return currentStaffResult;
      const currentStaff = currentStaffResult.data;
      if (!currentStaff) return defaultResult.ok(null);

      const permissionsResult = await getEffectivePermissions(currentStaff.id);
      if (!permissionsResult.ok) return permissionsResult;

      return defaultResult.ok(
        normalizeStaffSession(
          authSession.access_token,
          authSession.expires_at ? new Date(authSession.expires_at * 1000).toISOString() : undefined,
          currentStaff,
          permissionsResult.data
        )
      );
    }

    async function resolveAuthEmailByStaffId(staffId) {
      // 2026-11-02: Staff IDs are stored upper-case at creation; match the typed ID
      // whatever its case or stray spaces so a newly added staff can log in.
      const typedId = String(staffId || '').trim();
      let staffResult = await getStaffProfileBySelector({ staff_code: typedId.toUpperCase() });
      if (!staffResult.ok && typedId !== typedId.toUpperCase()) staffResult = await getStaffProfileBySelector({ staff_code: typedId });
      if (!staffResult.ok) return staffResult;

      const row = staffResult.data;
      const email = row.auth_email || (staffEmailMode === 'synthetic_suffix' ? `${row.staff_code}${syntheticEmailSuffix}` : null);
      if (!email) return defaultResult.err('AUTH_EMAIL_NOT_FOUND', 'Auth email could not be resolved for this Staff ID.');
      return defaultResult.ok({ email, staffRow: row });
    }

    async function loginWithStaffId(payload) {
      if (!canUseSupabase()) return local.auth.loginWithStaffId(payload);
      if (!payload?.staffId || !payload?.password) {
        return defaultResult.err('AUTH_INPUT_REQUIRED', 'Staff ID and password are required.');
      }

      const emailResult = await resolveAuthEmailByStaffId(payload.staffId);
      if (!emailResult.ok) return emailResult;

      const signInResult = await client.auth.signInWithPassword({
        email: emailResult.data.email,
        password: payload.password,
      });

      if (signInResult.error) {
        return defaultResult.err('AUTH_LOGIN_FAILED', signInResult.error.message || 'Unable to sign in with Supabase.', signInResult.error);
      }

      const authSession = signInResult.data?.session;
      const sessionResult = await buildSessionFromSupabaseAuthSession(authSession);
      // Audit: login
      if (sessionResult.ok && sessionResult.data?.staff?.id) {
        await insertAuditLogEntry({
          actorStaffId: sessionResult.data.staff.id,
          actorName: sessionResult.data.staff.fullName || '',
          actionType: 'staff_login',
          entityType: 'staff',
          entityId: sessionResult.data.staff.id,
          details: `${sessionResult.data.staff.fullName || ''} logged in`,
        }).catch(() => {});
      }
      return sessionResult;
    }

    async function changePassword(payload = {}) {
      if (!canUseSupabase()) return local.auth.changePassword(payload);
      const oldPassword = payload.oldPassword || '';
      const newPassword = payload.newPassword || '';
      if (!oldPassword || !newPassword) return defaultResult.err('AUTH_PASSWORD_INPUT_REQUIRED', 'Old and new password are required.');
      if (String(newPassword).length < 6) return defaultResult.err('AUTH_PASSWORD_TOO_SHORT', 'Password must be at least 6 characters.');

      const sessionResult = await client.auth.getSession();
      const authSession = sessionResult.data?.session;
      const email = authSession?.user?.email;
      if (sessionResult.error || !authSession?.user || !email) {
        return defaultResult.err('AUTH_SESSION_REQUIRED', 'Active login session is required to change password.', sessionResult.error || null);
      }

      const verifyResult = await client.auth.signInWithPassword({ email, password: oldPassword });
      if (verifyResult.error) {
        return defaultResult.err('AUTH_OLD_PASSWORD_FAILED', 'Old password is incorrect.', verifyResult.error);
      }

      const updateResult = await client.auth.updateUser({ password: newPassword });
      if (updateResult.error) {
        return defaultResult.err('AUTH_PASSWORD_UPDATE_FAILED', updateResult.error.message || 'Could not update password.', updateResult.error);
      }

      try {
        const staffResult = await getCurrentStaff();
        const staff = staffResult.ok ? staffResult.data : null;
        await insertAuditLogEntry({
          actorStaffId: staff?.id || null,
          actorName: staff?.fullName || staff?.name || '',
          actionType: 'staff_password_changed',
          entityType: 'staff',
          entityId: staff?.id || null,
          details: 'Staff changed own password',
        }).catch(() => {});
      } catch (_) {}

      const refreshed = await client.auth.getSession();
      return buildSessionFromSupabaseAuthSession(refreshed.data?.session || verifyResult.data?.session || authSession);
    }

    async function resetStaffPassword(payload = {}) {
      if (!canUseSupabase()) return local.auth.resetStaffPassword(payload);
      const staffCode = String(payload.staffCode || payload.staffId || '').trim().toUpperCase();
      const staffAuthUserId = payload.authUserId || payload.auth_user_id || null;
      const temporaryPassword = String(payload.temporaryPassword || payload.password || '').trim();
      if (!staffCode && !staffAuthUserId) return defaultResult.err('AUTH_RESET_TARGET_REQUIRED', 'Select staff to reset password.');
      if (!temporaryPassword || String(temporaryPassword).length < 6) return defaultResult.err('AUTH_PASSWORD_TOO_SHORT', 'Temporary password must be at least 6 characters.');

      const sessionResult = await client.auth.getSession();
      const accessToken = sessionResult.data?.session?.access_token || config?.supabase?.anonKey || '';
      const resetFnUrl = config?.supabase?.resetStaffPasswordEdgeFn
        || `${config?.supabase?.url || ''}/functions/v1/reset-staff-password`;
      const fallbackFnUrl = config?.supabase?.createStaffEdgeFn || `${config?.supabase?.url || ''}/functions/v1/create-staff-user`;
      const body = {
        action: 'reset_password',
        staffCode,
        staffId: payload.staffId || staffCode,
        authUserId: staffAuthUserId,
        password: temporaryPassword,
        temporaryPassword,
      };

      async function callResetEndpoint(url) {
        // 2026-11-05: a blocked/failed preflight (function not deployed or no CORS) makes
        // fetch THROW, which skipped the fallback and gave a vague toast. Catch it here.
        let resp;
        try {
          resp = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
            body: JSON.stringify(body),
          });
        } catch (netErr) {
          return defaultResult.err('AUTH_RESET_UNREACHABLE', 'Password reset service is unreachable. The reset-staff-password Edge Function must be deployed with CORS enabled.', netErr);
        }
        const json = await resp.json().catch(() => ({}));
        if (!resp.ok || json.error) return defaultResult.err('AUTH_RESET_FAILED', json.error || json.message || 'Password reset failed.', json);
        return defaultResult.ok(json);
      }

      let result = await callResetEndpoint(resetFnUrl);
      if (!result.ok && fallbackFnUrl && fallbackFnUrl !== resetFnUrl) {
        // 2026-11-05: create-staff-user cannot reset passwords (it only creates, so it always
        // answers "already registered") and was masking the real error. Keep the primary
        // function's own error whenever it actually answered.
        const primary = result;
        result = await callResetEndpoint(fallbackFnUrl);
        if (!result.ok && primary?.error?.code !== 'AUTH_RESET_UNREACHABLE') result = primary;
      }
      if (!result.ok) return result;

      // 2026-11-04: prove the new temporary password really signs in.
      let loginCheck = { status: 'skipped' };
      try {
        const emailRes = staffCode ? await resolveAuthEmailByStaffId(staffCode) : { ok: false };
        const lower = staffCode.toLowerCase();
        loginCheck = await testStaffLogin({ emails: [emailRes?.data?.email, `${staffCode}${syntheticEmailSuffix}`, `${lower}${syntheticEmailSuffix}`], password: String(temporaryPassword).trim() });
      } catch (_e) {}

      try {
        await insertAuditLogEntry({
          actorStaffId: payload.updatedByStaffId || null,
          actorName: payload.updatedByName || '',
          actionType: 'staff_password_reset',
          entityType: 'staff',
          entityId: payload.staffId || staffAuthUserId || staffCode,
          details: `Admin reset password for ${staffCode || staffAuthUserId}`,
        }).catch(() => {});
      } catch (_) {}
      return defaultResult.ok({ success: true, loginCheck });
    }



    const adminRecoveryStorageKey = 'ducess_admin_recovery_key_hash_v1';
    const adminRecoveryMetaKey = 'ducess_admin_recovery_key_meta_v1';

    function bytesToHex(bytes) {
      return Array.from(bytes || []).map((b) => b.toString(16).padStart(2, '0')).join('');
    }

    async function sha256Hex(value) {
      const text = String(value || '');
      if (crypto?.subtle && typeof TextEncoder !== 'undefined') {
        const buffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
        return bytesToHex(new Uint8Array(buffer));
      }
      let h1 = 0x811c9dc5;
      for (let i = 0; i < text.length; i += 1) {
        h1 ^= text.charCodeAt(i);
        h1 = Math.imul(h1, 0x01000193) >>> 0;
      }
      return String(h1.toString(16)).padStart(8, '0');
    }

    function makeRecoveryKey() {
      const bytes = new Uint8Array(12);
      if (crypto?.getRandomValues) crypto.getRandomValues(bytes);
      else for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
      const body = Array.from(bytes).map((b) => (b % 36).toString(36).toUpperCase()).join('').match(/.{1,4}/g).join('-');
      return `DUCESS-RK-${body}`;
    }

    async function hasAdminRecoveryKey() {
      try {
        const hash = localStorage.getItem(adminRecoveryStorageKey) || '';
        return defaultResult.ok({ exists: !!hash });
      } catch (err) {
        return defaultResult.ok({ exists: false });
      }
    }

    async function generateAdminRecoveryKey(payload = {}) {
      if (!canUseSupabase()) return local.auth.generateAdminRecoveryKey(payload);
      const sessionResult = await client.auth.getSession();
      if (sessionResult.error || !sessionResult.data?.session?.user) {
        return defaultResult.err('AUTH_SESSION_REQUIRED', 'Login as Admin to generate recovery key.', sessionResult.error || null);
      }
      const staffResult = await getCurrentStaff();
      const staff = staffResult.ok ? staffResult.data : null;
      const role = String(staff?.roleCode || staff?.role_code || staff?.role || '').trim().toLowerCase();
      const roleLabel = String(staff?.roleLabel || staff?.title || staff?.fullName || '').trim().toLowerCase();
      const canManageRecoveryKey = ['admin','admin_officer','administrator','administrative_officer'].includes(role) || roleLabel.includes('admin');
      if (!canManageRecoveryKey) return defaultResult.err('AUTH_ADMIN_ONLY', 'Only Admin can generate recovery key.');
      const key = makeRecoveryKey();
      const hash = await sha256Hex(key);
      try {
        localStorage.setItem(adminRecoveryStorageKey, hash);
        localStorage.setItem(adminRecoveryMetaKey, JSON.stringify({ generatedAt: new Date().toISOString(), generatedBy: staff?.id || null }));
      } catch (err) {
        return defaultResult.err('AUTH_RECOVERY_STORE_FAILED', 'Could not store recovery key hash on this device.', err);
      }
      await insertAuditLogEntry({
        actorStaffId: staff?.id || null,
        actorName: staff?.fullName || staff?.name || '',
        actionType: payload.regenerate ? 'admin_recovery_key_regenerated' : 'admin_recovery_key_generated',
        entityType: 'auth',
        entityId: 'admin_recovery',
        details: payload.regenerate ? 'Admin regenerated recovery key' : 'Admin generated recovery key',
      }).catch(() => {});
      return defaultResult.ok({ recoveryKey: key, generatedAt: new Date().toISOString() });
    }

    async function verifyLocalRecoveryKey(recoveryKey) {
      const entered = String(recoveryKey || '').trim();
      if (!entered) return false;
      try {
        const storedHash = localStorage.getItem(adminRecoveryStorageKey) || '';
        if (!storedHash) return false;
        return (await sha256Hex(entered)) === storedHash;
      } catch (_) { return false; }
    }

    async function recoverAdminPassword(payload = {}) {
      if (!canUseSupabase()) return defaultResult.err('AUTH_RECOVERY_UNAVAILABLE', 'Admin recovery requires Supabase Auth.');
      const staffCode = String(payload.staffCode || '').trim().toUpperCase();
      const recoveryCode = String(payload.recoveryCode || payload.recoveryKey || '').trim();
      const temporaryPassword = payload.temporaryPassword || payload.password || '';
      if (!staffCode) return defaultResult.err('AUTH_RECOVERY_STAFF_REQUIRED', 'Enter the Admin Staff ID.');
      if (!recoveryCode) return defaultResult.err('AUTH_RECOVERY_CODE_REQUIRED', 'Enter the recovery code.');
      if (!temporaryPassword || String(temporaryPassword).length < 6) return defaultResult.err('AUTH_PASSWORD_TOO_SHORT', 'Temporary password must be at least 6 characters.');
      const keyOk = await verifyLocalRecoveryKey(recoveryCode);
      if (!keyOk) return defaultResult.err('AUTH_RECOVERY_KEY_INVALID', 'Recovery key is invalid or has not been generated on this deployment.');

      const recoveryFnUrl = config?.supabase?.recoverAdminPasswordEdgeFn
        || config?.supabase?.resetStaffPasswordEdgeFn
        || `${config?.supabase?.url || ''}/functions/v1/reset-staff-password`;
      const accessToken = config?.supabase?.anonKey || '';
      const resp = await fetch(recoveryFnUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
        body: JSON.stringify({
          action: 'admin_recovery_reset',
          staffCode,
          recoveryCode,
          recoveryKey: recoveryCode,
          password: temporaryPassword,
          temporaryPassword,
        }),
      });
      const json = await resp.json().catch(() => ({}));
      if (!resp.ok || json.error) {
        return defaultResult.err('AUTH_ADMIN_RECOVERY_FAILED', json.error || json.message || 'Admin recovery reset failed.', json);
      }
      return defaultResult.ok({ success: true });
    }

    async function logout() {
      if (!canUseSupabase()) return local.auth.logout();
      // Audit: logout before signing out
      const sessionBefore = await client.auth.getSession();
      const logoutStaffId = sessionBefore.data?.session?.user?.id || null;
      const { error: signOutError } = await client.auth.signOut();
      if (signOutError) return defaultResult.err('AUTH_LOGOUT_FAILED', signOutError.message || 'Unable to sign out.', signOutError);
      if (logoutStaffId) {
        await insertAuditLogEntry({
          actorStaffId: logoutStaffId,
          actionType: 'staff_logout',
          entityType: 'staff',
          entityId: logoutStaffId,
          details: 'Staff logged out',
        }).catch(() => {});
      }
      return defaultResult.ok({ success: true });
    }

    async function getSession() {
      if (!canUseSupabase()) return local.auth.getSession();
      const { data, error: sessionError } = await client.auth.getSession();
      if (sessionError) return defaultResult.err('AUTH_SESSION_FAILED', sessionError.message || 'Unable to fetch current session.', sessionError);
      return buildSessionFromSupabaseAuthSession(data?.session || null);
    }

    async function getCurrentStaffContext() {
      const sessionResult = await getSession();
      if (!sessionResult.ok) return sessionResult;
      return defaultResult.ok({
        businessDate: (local.appState.loadState() || {}).businessDate,
        activeStaffId: sessionResult.data?.staff?.id || '',
        session: sessionResult.data || null,
      });
    }

    async function listStaffLedger(staffId, filters = {}) {
      if (!canUseSupabase() || !client) return defaultResult.ok([]);
      try {
        let query = client.from(staffCashLedgerTable).select(staffCashLedgerSelect);
        if (staffId) query = query.eq('staff_id', staffId);
        if (filters.startDate) query = query.gte('float_date', filters.startDate);
        if (filters.endDate) query = query.lte('float_date', filters.endDate);
        const { data, error } = await query.order('created_at', { ascending: true });
        if (error) {
          return defaultResult.ok([]);
        }
        return defaultResult.ok(Array.isArray(data) ? data : []);
      } catch (err) {
        return defaultResult.ok([]);
      }
    }

        return {
      ...local,
      auth: {
        loginWithStaffId,
        logout,
        getSession,
        getCurrentStaffContext,
        changePassword,
        resetStaffPassword,
        hasAdminRecoveryKey,
        generateAdminRecoveryKey,
        recoverAdminPassword,
      },
      staff: {
        getCurrentStaff,
        getStaffById,
        listStaff,
        listActiveStaff,
        createStaff,
        updateStaffStatus,
        updateStaffCode,
        assignStaffRole,
        listRoleAssignments,
        listStaffLedger,
        backfillTreasuryOperationalAccounts,
      },
      permissions: {
        getEffectivePermissions,
        hasPermission,
        listTempGrants,
        createTempGrant: (...args) => local.permissions.createTempGrant(...args),
        revokeTempGrant: (...args) => local.permissions.revokeTempGrant(...args),
      },
      customers: {
        getCustomerPhoto,
        listCustomers,
        searchCustomers,
        getCustomerById,
        getCustomerByAccountNumber,
        submitAccountOpening,
        submitAccountMaintenance,
        submitAccountReactivation,
        listStaffSalaryAccounts,
        generateSystemAccountNumber,
        peekSystemAccountNumber,
      },
      accounts: {
        getAccountByNumber,
        getAccountSummary,
        getAccountStatement,
        submitCredit,
        submitDebit,
        submitJournalEntries,
      },
      approvals: {
        listApprovalRequests,
        getApprovalRequestById,
        submitApprovalRequest,
        approveRequest,
        markApprovalApprovedDirect,
        setReviewLock,
        rejectRequest,
      },
      cod: {
        getCodPreview,
        submitCod,
        listCodSubmissions,
        getCodSubmissionById,
        resolveCod,
        listDebts,
        getDebtById,
        submitDebtRepayment,
      },
      audit: {
        listAuditLog,
        insertAuditLogEntry,
      },
      // 2026-10-22 Administration redesign (client sheet "Administrative /
      // Audit & ICT Unit"). Tables come from the staff_profiles / ict_logs
      // SQL script. The profile list never pulls photos (egress); a single
      // profile (with photo) loads only when that staff member is opened.
      // Fix B 2026-10-22 (egress): incremental sync. Needs the updated_at
      // columns from sql/2026-10-22-fix-b-incremental-sync.sql; until that
      // runs these return SYNC_UNSUPPORTED and the app keeps full reloads.
      // Fix B 2026-10-22: recent history + summaries (sql/2026-10-22-fix-b-history-window.sql).
      history: {
        async window(from) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const { data, error } = await client.rpc('ducess_history_window', { p_from: from || null });
          if (error) return defaultResult.err(isMissingRpcError(error) ? 'HISTORY_UNSUPPORTED' : 'HISTORY_WINDOW_FAILED', 'Could not load history summary.', error);
          return defaultResult.ok({ from: data?.from || null, approvals: (data?.approvals || []).map(normalizeApprovalRecord).filter(Boolean), transactions: data?.transactions || [] });
        },
        async approvals(from, oldFrom) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const rows = await rpcPages(oldFrom !== undefined ? 'ducess_history_gap_approvals' : 'ducess_recent_approvals', oldFrom !== undefined ? { p_new_from: from, p_old_from: oldFrom } : { p_from: from }, 'requested_at');
          if (!rows.ok) return rows;
          return defaultResult.ok(rows.data.map(normalizeApprovalRecord).filter(Boolean));
        },
        // Customers (no photos) with transactions from the window start plus
        // the summary rows for older ones; oldFrom given = only the gap.
        async transactions(from, oldFrom) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const rows = await rpcPages(oldFrom !== undefined ? 'ducess_history_gap_transactions' : 'ducess_recent_transactions', oldFrom !== undefined ? { p_new_from: from, p_old_from: oldFrom } : { p_from: from }, 'created_at');
          if (!rows.ok) return rows;
          return defaultResult.ok(rows.data.map(pickTxColumns));
        },
        async customers(txRows) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const rowsResult = await fetchCustomersRows({});
          if (!rowsResult.ok) return rowsResult;
          return buildCustomersForUi(rowsResult.data || [], { txRows });
        },
        async transactionsByIds(ids) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const list = (ids || []).filter(Boolean);
          if (!list.length) return defaultResult.ok([]);
          const { data, error } = await client.from(customerTransactionsTable).select(customerTransactionsSelect).in('id', list);
          if (error) return defaultResult.err('CUSTOMER_TX_FETCH_FAILED', 'Could not fetch transactions.', error);
          return defaultResult.ok((Array.isArray(data) ? data : []).map(row => ({ customerId: row.customer_id, tx: txRowToLocal(row) })));
        },
        toLocal: (row) => txRowToLocal(row),
        async customerTransactions(customerId) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          return fetchTransactionsByCustomerIds([customerId]);
        },
        async customersByIds(ids) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const rowsResult = await fetchCustomersRows({ ids });
          if (!rowsResult.ok) return rowsResult;
          return buildCustomersForUi(rowsResult.data || [], { skipTransactions: true });
        },
      },
      sync: {
        async digest(kind, prevAt) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const { data, error } = await client.rpc('ducess_sync_digest', { p_kind: kind, p_prev: prevAt || null });
          if (error) return defaultResult.err(isMissingRpcError(error) || isMissingColumnOrRelationError(error) ? 'SYNC_UNSUPPORTED' : 'SYNC_DIGEST_FAILED', 'Could not read the sync check.', error);
          return defaultResult.ok(data);
        },
        async snapshot(kind) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const spec = syncSpec(kind);
          let cq = client.from(spec.table).select('id', { count: 'exact', head: true });
          if (spec.notNull) cq = cq.not(spec.notNull, 'is', null);
          const [countRes, latestRes] = await Promise.all([
            cq,
            client.from(spec.table).select(spec.col).order(spec.col, { ascending: false, nullsFirst: false }).limit(1),
          ]);
          const err = countRes.error || latestRes.error;
          if (err) return defaultResult.err(isMissingColumnOrRelationError(err) ? 'SYNC_UNSUPPORTED' : 'SYNC_SNAPSHOT_FAILED', 'Could not read sync snapshot.', err);
          return defaultResult.ok({ count: Number(countRes.count || 0), cursor: latestRes.data?.[0]?.[spec.col] || null });
        },
        async changedSince(kind, since) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const spec = syncSpec(kind);
          let q = client.from(spec.table).select(spec.select).gt(spec.col, since).order(spec.col, { ascending: true }).limit(1000);
          if (spec.notNull) q = q.not(spec.notNull, 'is', null);
          const { data, error } = await q;
          if (error) return defaultResult.err(isMissingColumnOrRelationError(error) ? 'SYNC_UNSUPPORTED' : 'SYNC_CHANGES_FAILED', 'Could not read changes.', error);
          return defaultResult.ok((Array.isArray(data) ? data : []).map(r => ({ ...r, ts: r[spec.col] })));
        },
      },
      adminx: {
        async listStaffProfiles() {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const { data, error } = await client.from('staff_profiles').select('staff_id, job_title, phone, gender, date_of_birth, residential_address, email, qualification, date_of_employment, salary_account_number, bvn, nin, guarantor, referee, next_of_kin, marital_status, initial_position, updated_at');
          if (error) return defaultResult.err(isMissingColumnOrRelationError(error) ? 'TABLE_MISSING' : 'PROFILE_LIST_FAILED', 'Could not load staff profiles.', error);
          return defaultResult.ok(data || []);
        },
        async getStaffProfile(staffId) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const { data, error } = await client.from('staff_profiles').select('*').eq('staff_id', staffId).maybeSingle();
          if (error) return defaultResult.err(isMissingColumnOrRelationError(error) ? 'TABLE_MISSING' : 'PROFILE_GET_FAILED', 'Could not load the staff profile.', error);
          return defaultResult.ok(data || null);
        },
        async saveStaffProfile(staffId, profile = {}) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const row = { ...profile, staff_id: staffId, updated_at: new Date().toISOString() };
          const { data, error } = await client.from('staff_profiles').upsert(row, { onConflict: 'staff_id' }).select('staff_id, updated_at').maybeSingle();
          if (error) return defaultResult.err(isMissingColumnOrRelationError(error) ? 'TABLE_MISSING' : 'PROFILE_SAVE_FAILED', 'Could not save the staff profile.', error);
          return defaultResult.ok(data);
        },
        // 2026-11-10: extra roles — a staff member can hold more than one role. The main
        // role stays on staff.role_code; any others live in staff_extra_roles.
        async listExtraRoles() {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const { data, error } = await client.from('staff_extra_roles').select('staff_id, role_code');
          if (error) return defaultResult.err(isMissingColumnOrRelationError(error) ? 'TABLE_MISSING' : 'EXTRA_ROLES_LIST_FAILED', 'Could not load extra roles.', error);
          return defaultResult.ok(data || []);
        },
        async setExtraRoles(staffId, roleCodes = [], grantedBy = '') {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const want = [...new Set((roleCodes || []).map(String).filter(Boolean))];
          const cur = await client.from('staff_extra_roles').select('role_code').eq('staff_id', String(staffId));
          if (cur.error) return defaultResult.err(isMissingColumnOrRelationError(cur.error) ? 'TABLE_MISSING' : 'EXTRA_ROLES_SAVE_FAILED', 'Could not read current extra roles.', cur.error);
          const have = (cur.data || []).map(r => r.role_code);
          const remove = have.filter(r => !want.includes(r));
          const add = want.filter(r => !have.includes(r));
          if (remove.length) {
            const del = await client.from('staff_extra_roles').delete().eq('staff_id', String(staffId)).in('role_code', remove);
            if (del.error) return defaultResult.err('EXTRA_ROLES_SAVE_FAILED', 'Could not remove roles.', del.error);
          }
          if (add.length) {
            const ins = await client.from('staff_extra_roles').insert(add.map(r => ({ staff_id: String(staffId), role_code: r, granted_by_name: grantedBy || null })));
            if (ins.error) return defaultResult.err('EXTRA_ROLES_SAVE_FAILED', 'Could not add roles.', ins.error);
          }
          return defaultResult.ok({ staffId, roles: want });
        },
        async storageUsage() {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const { data, error } = await client.rpc('ducess_storage_usage');
          if (error) return defaultResult.err(isMissingRpcError(error) ? 'FUNCTION_MISSING' : 'STORAGE_USAGE_FAILED', 'Could not read database size.', error);
          return defaultResult.ok(data);
        },
        async listIctLogs(category) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          let q = client.from('ict_logs').select('id, category, checked_items, note, staff_id, staff_name, created_at').order('created_at', { ascending: false }).limit(50);
          if (category) q = q.eq('category', category);
          const { data, error } = await q;
          if (error) return defaultResult.err(isMissingColumnOrRelationError(error) ? 'TABLE_MISSING' : 'ICT_LIST_FAILED', 'Could not load ICT records.', error);
          return defaultResult.ok(data || []);
        },
        async addIctLog(entry = {}) {
          if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
          const { data, error } = await client.from('ict_logs').insert({ category: entry.category, checked_items: entry.checkedItems || [], note: entry.note || '', staff_id: entry.staffId || null, staff_name: entry.staffName || '' }).select('id, category, checked_items, note, staff_id, staff_name, created_at').maybeSingle();
          if (error) return defaultResult.err(isMissingColumnOrRelationError(error) ? 'TABLE_MISSING' : 'ICT_SAVE_FAILED', 'Could not save the ICT record.', error);
          return defaultResult.ok(data);
        },
      },
      // 2026-11-03: journals live in the database (sql/2026-11-03-journals.sql),
      // not the browser. Lists never carry the field-note photo (egress);
      // get() loads one journal in full.
      journals: (() => {
        const LIST_COLS = 'id, journal_number, kind, status, staff_id, staff_name, business_date, journal_date, counterparty, confirmed_by, description, form_amount, form_payment_mode, rows, has_field_note, created_at, updated_at';
        const fromRow = (r) => !r ? null : ({
          id: r.id, journalNumber: r.journal_number, kind: r.kind || 'credit', status: r.status || 'draft',
          staffId: r.staff_id || '', staffName: r.staff_name || '',
          date: r.business_date || '', journalDate: r.journal_date || '',
          counterparty: r.counterparty || '', confirmedBy: r.confirmed_by || '', description: r.description || '',
          formAmount: Number(r.form_amount || 0), formPaymentMode: r.form_payment_mode || 'cash',
          rows: Array.isArray(r.rows) ? r.rows : [],
          fieldNote: r.field_note || null, hasFieldNote: !!r.has_field_note,
          createdAt: r.created_at || '', updatedAt: r.updated_at || ''
        });
        const toRow = (j) => ({
          id: String(j.id), journal_number: String(j.journalNumber), kind: j.kind || 'credit', status: j.status || 'draft',
          staff_id: j.staffId || null, staff_name: j.staffName || '',
          business_date: j.date || null, journal_date: j.journalDate || null,
          counterparty: j.counterparty || '', confirmed_by: j.confirmedBy || '', description: j.description || '',
          form_amount: Number(j.formAmount || 0), form_payment_mode: j.formPaymentMode || 'cash',
          rows: Array.isArray(j.rows) ? j.rows : [],
          field_note: j.fieldNote || null, has_field_note: !!j.fieldNote || !!j.hasFieldNote,
          ...(j.createdAt ? { created_at: j.createdAt } : {}),
          updated_at: new Date().toISOString()
        });
        const missing = (error) => isMissingColumnOrRelationError(error) || isMissingRpcError(error);
        return {
          // Egress-safe (same idea as the history window + incremental sync):
          //  - first load: only the last `windowDays` days, plus every draft;
          //  - later loads: only journals changed since `since` (usually none).
          async list(opts = {}) {
            if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
            let q = client.from('journals').select(LIST_COLS);
            if (opts.since) {
              q = q.gt('updated_at', opts.since);
            } else {
              const from = new Date(Date.now() - (Number(opts.windowDays) || 45) * 86400000).toISOString();
              q = q.or(`status.eq.draft,created_at.gte.${from}`);
            }
            const { data, error } = await q.order('created_at', { ascending: true }).limit(500);
            if (error) return defaultResult.err(missing(error) ? 'TABLE_MISSING' : 'JOURNAL_LIST_FAILED', 'Could not load journals.', error);
            return defaultResult.ok((data || []).map(fromRow));
          },
          async epoch() {
            if (!canUseSupabase()) return defaultResult.ok(null);
            const { data, error } = await client.from('ducess_meta').select('value').eq('key', 'data_epoch').maybeSingle();
            if (error) return defaultResult.ok(null);
            return defaultResult.ok(data?.value || null);
          },
          async get(id) {
            if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
            const { data, error } = await client.from('journals').select(LIST_COLS + ', field_note').eq('id', String(id)).maybeSingle();
            if (error) return defaultResult.err('JOURNAL_GET_FAILED', 'Could not load the journal.', error);
            return defaultResult.ok(fromRow(data));
          },
          async nextNumber() {
            if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
            const { data, error } = await client.rpc('ducess_next_journal_number');
            if (error || !data) return defaultResult.err(missing(error) ? 'TABLE_MISSING' : 'JOURNAL_NUMBER_FAILED', 'Could not get a Journal Number from the database.', error);
            return defaultResult.ok(String(data));
          },
          async save(journal) {
            if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
            const { error } = await client.from('journals').upsert(toRow(journal), { onConflict: 'id' });
            if (error) return defaultResult.err(missing(error) ? 'TABLE_MISSING' : 'JOURNAL_SAVE_FAILED', 'Could not save the journal to the database.', error);
            return defaultResult.ok(true);
          },
          // One-time upload of journals a browser already holds. Existing ids are
          // left alone; a clashing Journal Number is skipped and reported.
          async importLocal(list = []) {
            if (!canUseSupabase()) return defaultResult.err('LOCAL_ONLY', 'Supabase is not available.');
            let imported = 0; const skipped = [];
            for (const j of list) {
              if (!j?.id || !j?.journalNumber) continue;
              const { error } = await client.from('journals').upsert(toRow(j), { onConflict: 'id', ignoreDuplicates: true });
              if (error) {
                if (missing(error)) return defaultResult.err('TABLE_MISSING', 'Journals table is not set up yet.', error);
                skipped.push(j.journalNumber);
              } else imported += 1;
            }
            return defaultResult.ok({ imported, skipped });
          }
        };
      })(),
      __meta: {
        adapter: 'supabase',
        phase: '3E',
        usesLocalBehavior: true,
        authProvider: 'supabase',
        staffProvider: 'supabase',
        permissionsProvider: 'supabase',
        customersProvider: 'supabase',
        accountsReadProvider: 'supabase',
        accountWritesProvider: 'backend_approval_queue',
        approvalsProvider: 'supabase',
        authoritativePostingProvider: approvalPostingRpc ? 'supabase_rpc' : 'supabase_safe_mutation',
      },
      __supabase: {
        client: client || null,
        configured: !!client,
      },
      __realtime: {
        subscribe: subscribeRealtime,
      }
    };
  }
  function createGateway(options = {}) {
  const config = mergeConfig(options);
  return createSupabaseAdapter(config);
}

  global.DucessGateway = {
    createGateway,
    createLocalAdapter,
    createSupabaseAdapter,
  };
})(window);


